# Shooter 3D (Android, Kotlin + OpenGL ES 2.0)

Game tembak 3D orang pertama. Buka folder ini di Android Studio lalu Run.

## Yang baru di versi ini
- **Sound effect realistis** (30 suara, di `app/src/main/assets/sfx/`): tembakan berlapis (crack + ledakan + dentuman + gema),
  suara reload mekanis (magasin lepas/masuk, bolt, pump, peluru shotgun masuk satu-satu), langkah kaki, hit/headshot,
  ledakan drone, dengung drone (makin dekat makin keras), detak jantung saat darah tipis, angin latar, dll.
  Suara musuh & tembakan teman bersifat 3D (volume menurut jarak, kiri/kanan menurut arah).
  Dibuat sendiri lewat `tools/gen_sfx.py` (sintesis, tanpa sample pihak ketiga) — jalankan ulang untuk mengubah suara.
- **Sistem amunisi & reload**: Repeater (magasin 30) dan Blaster (6 peluru, diisi satu-satu, boleh dipotong untuk menembak).
  Peluru cadangan terbatas. Tombol **R** = reload, otomatis reload saat magasin kosong.
- **Animasi reload**: senjata miring, magasin lepas & jatuh, tangan mengambil magasin baru, handle ditarik; shotgun memasukkan peluru satu per satu lalu pump.
- **Item di peta**: kotak peluru (senapan = kuning, shotgun = merah) dan paket darah (+30). Harus dicari keliling peta.
  Peluru baru spawn **tiap 2 menit**, paket darah **tiap 1 menit** (timer tampil di HUD).
- **Peta jauh lebih luas** (200 x 200 m): 6 bangunan berpintu, deretan tembok cover, halaman peti, plaza tengah, kabut jarak.
  Tembok memblokir peluru dan pemain; drone terbang melewati tembok tinggi. Ada **minimap** (item hanya terlihat radius 30 m).
- **Mabar LAN co-op (maks 4 pemain)**: Menu → "Mabar LAN". Satu orang *Buat Room*, teman *Gabung Room*
  (room muncul otomatis, atau ketik IP host). Harus satu WiFi / hotspot yang sama. Host menjalankan simulasi.
- Kontrol: joystick kiri (melayang), geser layar kanan untuk membidik, **tahan FIRE lalu geser jari = tembak sambil menggerakkan kamera**,
  **SCOPE** (zoom teropong, sensitivitas & sebaran peluru mengecil, jalan lebih pelan), R = reload, GANTI = ganti senjata.
- Tampilan menu baru: latar bergradasi, kartu mode, chip pilihan, panel lobby & pengaturan.

## Kontrol & mode
Wave Survival, Time Attack 60s, Target Practice 90s, Boss Rush (solo atau co-op). Pengaturan grafis, FPS, sensitivitas, volume di menu.

## Struktur kode (app/src/main/java/com/example/shooter3d)
Game.kt (logika, senjata, item, sinkron jaringan) · World.kt (peta, tabrakan, raycast) · GameRenderer.kt (render, animasi senjata, partikel)
· HudView.kt (HUD, minimap, kontrol sentuh) · Sfx.kt (audio) · Net.kt (TCP/UDP LAN) · LobbyActivity.kt · GameActivity.kt

Model 3D: Kenney Blaster Kit & Platformer Kit (CC0). Konversi model: `tools/glb2mesh.py`.
