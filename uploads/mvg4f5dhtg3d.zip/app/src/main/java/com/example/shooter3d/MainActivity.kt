package com.example.shooter3d
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val frame = FrameLayout(this); frame.addView(BgView(this))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(Ui.dp(this@MainActivity, 36f), Ui.dp(this@MainActivity, 16f), Ui.dp(this@MainActivity, 36f), Ui.dp(this@MainActivity, 16f)) }

        // ---- kiri: judul & cara main
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        val title = SpannableString("SHOOTER 3D").apply { setSpan(ForegroundColorSpan(Ui.ACCENT), 8, 10, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        left.addView(TextView(this).apply { text = title; textSize = 44f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; letterSpacing = .06f })
        left.addView(TextView(this).apply { text = "Cari peluru. Bertahan hidup. Ajak temanmu."; textSize = 16f; setTextColor(Ui.SUB); setPadding(0, 0, 0, Ui.dp(this@MainActivity, 18f)) })
        val tips = Ui.panel(this)
        for (t in listOf("Joystick kiri untuk jalan, geser layar kanan untuk membidik",
            "Tahan FIRE lalu geser jari = menembak sambil memutar kamera",
            "SCOPE untuk zoom, R untuk reload, GANTI untuk ganti senjata",
            "Peluru baru muncul tiap 2 menit, paket darah tiap 1 menit")) tips.addView(TextView(this).apply { text = "•  $t"; textSize = 13f; setTextColor(0xFFC9D6E6.toInt()); setPadding(0, Ui.dp(this@MainActivity, 3f), 0, Ui.dp(this@MainActivity, 3f)) })
        left.addView(tips)
        row.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        // ---- kanan: pilihan mode
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(this@MainActivity, 24f), 0, 0, 0) }
        fun go(m: Mode) { startActivity(Intent(this, GameActivity::class.java).putExtra("mode", m.name).putExtra("role", "SOLO")) }
        fun pair(a: View, b: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val m = Ui.dp(this@MainActivity, 5f)
            addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(0, 0, m, 0) })
            addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(m, 0, 0, 0) })
        }
        val rowLp = { LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, Ui.dp(this@MainActivity, 5f), 0, Ui.dp(this@MainActivity, 5f)) } }
        right.addView(Ui.section(this, "Main sendiri"))
        right.addView(pair(Ui.card(this, "Wave Survival", "Bertahan dari gelombang drone", 0xFF4C8DFF.toInt()) { go(Mode.WAVE) },
            Ui.card(this, "Boss Rush", "Lawan boss tanpa henti", 0xFFE5484D.toInt()) { go(Mode.BOSS) }), rowLp())
        right.addView(pair(Ui.card(this, "Time Attack", "Sebanyak mungkin dalam 60 detik", 0xFFF5A524.toInt()) { go(Mode.TIME) },
            Ui.card(this, "Target Practice", "Latihan menembak 90 detik", 0xFF8E5CF0.toInt()) { go(Mode.TARGET) }), rowLp())
        right.addView(Ui.section(this, "Bersama teman"))
        right.addView(Ui.card(this, "Mabar LAN (Co-op)", "Sampai 4 pemain lewat WiFi / hotspot yang sama", Ui.GREEN) { startActivity(Intent(this, LobbyActivity::class.java)) }, rowLp())
        right.addView(Ui.gap(this, 6f))
        right.addView(Ui.button(this, "Pengaturan Grafis & Suara", Ui.GRAY) { startActivity(Intent(this, SettingsActivity::class.java)) }, rowLp())
        row.addView(ScrollView(this).apply { isFillViewport = true; addView(right) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.15f))

        frame.addView(row)
        setContentView(frame)
    }
}
