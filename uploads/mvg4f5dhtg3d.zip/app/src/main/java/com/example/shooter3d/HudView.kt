package com.example.shooter3d
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** Satu view untuk semua HUD + kontrol sentuh multi-touch: joystick (kiri), bidik (geser kanan), FIRE, RELOAD, GANTI, minimap. */
class HudView(ctx: Context, private val g: Game, private val gfx: Gfx) : View(ctx) {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; setShadowLayer(4f, 0f, 0f, Color.BLACK) }
    private val path = Path()
    private val en = ArrayList<Enemy>(); private val pk = ArrayList<Pickup>(); private val pl = ArrayList<Player>()
    private var u = 10f
    var onExit: (() -> Unit)? = null

    // sentuhan
    private var joyId = -1; private var fireId = -1; private var lookId = -1; private var rldId = -1; private var swId = -1; private var scId = -1
    private var fireX = 0f; private var fireY = 0f
    private var joyCx = 0f; private var joyCy = 0f; private var joyKx = 0f; private var joyKy = 0f
    private var lookX = 0f; private var lookY = 0f

    private fun fireC() = floatArrayOf(width - 17f * u, height - 19f * u, 12f * u)
    private fun rldC() = floatArrayOf(width - 36f * u, height - 11f * u, 7f * u)
    private fun swC() = floatArrayOf(width - 31f * u, height - 30f * u, 7f * u)
    private fun scC() = floatArrayOf(width - 47f * u, height - 22f * u, 6.5f * u)
    private fun hit(c: FloatArray, x: Float, y: Float) = hypot(x - c[0], y - c[1]) <= c[2] * 1.15f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { u = min(w, h) / 100f }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { val i = e.actionIndex; down(e.getPointerId(i), e.getX(i), e.getY(i)) }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> { for (i in 0 until e.pointerCount) up(e.getPointerId(i)) }
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (fireId < 0 && hit(fireC(), x, y)) { fireId = id; fireX = x; fireY = y; g.firing = true; return }
        if (scId < 0 && hit(scC(), x, y)) { scId = id; g.wantScope = true; return }
        if (rldId < 0 && hit(rldC(), x, y)) { rldId = id; g.wantReload = true; return }
        if (swId < 0 && hit(swC(), x, y)) { swId = id; g.wantSwitch = true; return }
        if (joyId < 0 && x < width * .45f && y > height * .2f) {
            joyId = id; joyCx = x.coerceIn(14f * u, width.toFloat()); joyCy = y.coerceAtMost(height - 13f * u); joyKx = joyCx; joyKy = joyCy; return
        }
        if (lookId < 0) { lookId = id; lookX = x; lookY = y }
    }

    private fun move(id: Int, x: Float, y: Float) {
        if (id == joyId) {
            val r = 11f * u; var dx = x - joyCx; var dy = y - joyCy; val l = hypot(dx, dy)
            if (l > r) { dx = dx / l * r; dy = dy / l * r }
            joyKx = joyCx + dx; joyKy = joyCy + dy
            var mx = dx / r; var my = -dy / r
            if (hypot(mx, my) < .12f) { mx = 0f; my = 0f }
            g.moveX = mx; g.moveY = my
        } else if (id == lookId) {
            look(x - lookX, y - lookY); lookX = x; lookY = y
        } else if (id == fireId) {          // geser jari di tombol FIRE = tetap menembak sambil menggerakkan kamera
            look(x - fireX, y - fireY); fireX = x; fireY = y
        }
    }

    /** Putar kamera; sensitivitas mengecil otomatis saat scope supaya bidikan tetap halus. */
    private fun look(dx: Float, dy: Float) {
        val me = g.me; val k = gfx.sens * (g.fov() / 65f)
        me.yaw += dx * k; me.pitch = (me.pitch - dy * k).coerceIn(-70f, 70f)
    }

    private fun up(id: Int) {
        if (id == fireId) { fireId = -1; g.firing = false }
        if (id == rldId) rldId = -1
        if (id == swId) swId = -1
        if (id == scId) scId = -1
        if (id == lookId) lookId = -1
        if (id == joyId) { joyId = -1; g.moveX = 0f; g.moveY = 0f }
    }

    // ------------------------------------------------------------------ gambar
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT) {
        textP.textSize = size * u; textP.color = color; textP.textAlign = align; c.drawText(s, x, y, textP)
    }
    private fun fmt(t: Float): String { val s = max(0f, t).toInt(); return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }
    private fun rgb(f: FloatArray) = Color.rgb((f[0] * 255).toInt(), (f[1] * 255).toInt(), (f[2] * 255).toInt())

    private fun circleBtn(c: Canvas, b: FloatArray, label: String, pressed: Boolean, size: Float, base: Int) {
        fillP.style = Paint.Style.FILL; fillP.color = if (pressed) (base and 0x00FFFFFF) or 0xAA000000.toInt() else (base and 0x00FFFFFF) or 0x66000000
        c.drawCircle(b[0], b[1], b[2], fillP)
        strokeP.strokeWidth = .5f * u; strokeP.color = 0xCCFFFFFF.toInt(); c.drawCircle(b[0], b[1], b[2], strokeP)
        txt(c, label, b[0], b[1] + size * u * .35f, size, Color.WHITE, Paint.Align.CENTER)
    }

    override fun onDraw(c: Canvas) {
        if (u <= 0f) return
        g.copyWorld(en, pk, pl)
        val me = g.me; val w = width.toFloat(); val h = height.toFloat()

        // --- efek kena damage & darah tipis
        if (g.hurtFlash > 0f) { fillP.style = Paint.Style.FILL; fillP.color = Color.argb((g.hurtFlash * 110).toInt().coerceIn(0, 255), 220, 0, 0); c.drawRect(0f, 0f, w, h, fillP) }
        if (me.alive && me.hp < 30f) {
            val a = (40 + 40 * sin(g.time * 6f)).toInt().coerceIn(0, 255)
            strokeP.color = Color.argb(a, 255, 0, 0); strokeP.strokeWidth = 5f * u; c.drawRect(0f, 0f, w, h, strokeP)
        }

        // --- scope: layar menyempit dengan lingkaran teropong + reticle
        val z = g.zoom
        if (z > .02f && me.alive) {
            val sx = w / 2; val sy = h / 2; val r = h * .46f; val a = (z * 255).toInt().coerceIn(0, 255)
            path.reset(); path.fillType = Path.FillType.EVEN_ODD; path.addRect(0f, 0f, w, h, Path.Direction.CW); path.addCircle(sx, sy, r, Path.Direction.CW)
            fillP.style = Paint.Style.FILL; fillP.color = Color.argb(a, 0, 0, 0); c.drawPath(path, fillP)
            path.reset(); path.fillType = Path.FillType.WINDING
            strokeP.color = Color.argb(a, 15, 15, 15); strokeP.strokeWidth = 1.2f * u; c.drawCircle(sx, sy, r, strokeP)
            strokeP.color = Color.argb(a * 220 / 255, 0, 0, 0); strokeP.strokeWidth = .12f * u * 2f
            c.drawLine(sx - r, sy, sx - 2f * u, sy, strokeP); c.drawLine(sx + 2f * u, sy, sx + r, sy, strokeP)
            c.drawLine(sx, sy - r, sx, sy - 2f * u, strokeP); c.drawLine(sx, sy + 2f * u, sx, sy + r, strokeP)
            strokeP.strokeWidth = .5f * u
            c.drawLine(sx - r, sy, sx - r * .55f, sy, strokeP); c.drawLine(sx + r * .55f, sy, sx + r, sy, strokeP)
            c.drawLine(sx, sy - r, sx, sy - r * .55f, strokeP); c.drawLine(sx, sy + r * .55f, sx, sy + r, strokeP)
            fillP.color = Color.argb(a, 255, 40, 40); c.drawCircle(sx, sy, .35f * u, fillP)
            for (i in 1..4) { val d = i * 3.2f * u; fillP.color = Color.argb(a * 200 / 255, 0, 0, 0)
                c.drawCircle(sx + d, sy, .22f * u, fillP); c.drawCircle(sx - d, sy, .22f * u, fillP); c.drawCircle(sx, sy + d, .22f * u, fillP) }
        }

        // --- crosshair
        if (me.alive && z < .3f) {
            val cx = w / 2; val cy = h / 2; val gap = 1.4f * u; val len = 1.8f * u
            strokeP.color = Color.WHITE; strokeP.strokeWidth = .35f * u
            c.drawLine(cx - gap - len, cy, cx - gap, cy, strokeP); c.drawLine(cx + gap, cy, cx + gap + len, cy, strokeP)
            c.drawLine(cx, cy - gap - len, cx, cy - gap, strokeP); c.drawLine(cx, cy + gap, cx, cy + gap + len, strokeP)
            if (g.hitMark > 0f) {
                strokeP.color = if (g.hitHead) Color.rgb(255, 210, 0) else Color.RED; strokeP.strokeWidth = .55f * u
                val a = 1.2f * u; val b = 2.6f * u
                c.drawLine(cx - b, cy - b, cx - a, cy - a, strokeP); c.drawLine(cx + b, cy - b, cx + a, cy - a, strokeP)
                c.drawLine(cx - b, cy + b, cx - a, cy + a, strokeP); c.drawLine(cx + b, cy + b, cx + a, cy + a, strokeP)
            }
        }

        // --- HP
        val bx = 2f * u; var by = 2f * u
        fillP.style = Paint.Style.FILL; fillP.color = 0x99000000.toInt(); c.drawRoundRect(bx, by, bx + 34f * u, by + 4f * u, u, u, fillP)
        val f = (me.hp / 100f).coerceIn(0f, 1f)
        fillP.color = Color.rgb((255 * (1f - f)).toInt().coerceIn(0, 255) + 0, (60 + 170 * f).toInt().coerceIn(0, 255), 60)
        c.drawRoundRect(bx, by, bx + 34f * u * f, by + 4f * u, u, u, fillP)
        txt(c, "HP ${max(0, me.hp.toInt())}", bx + 1.2f * u, by + 3.2f * u, 2.8f, Color.WHITE)
        by += 8.5f * u
        val modeTxt = when (g.mode) { Mode.WAVE -> "Gelombang ${g.wave}"; Mode.BOSS -> "Boss #${g.wave}"
            Mode.TIME -> "Waktu ${max(0, 60 - g.time.toInt())}s"; Mode.TARGET -> "Waktu ${max(0, 90 - g.time.toInt())}s" }
        txt(c, "Skor ${if (pl.size > 1) g.teamScore() else me.score}   $modeTxt", bx, by, 3f, Color.WHITE); by += 4.5f * u
        // timer item baru
        fillP.color = rgb(Models.pickupGlow[0]); c.drawRect(bx, by - 2.2f * u, bx + 2f * u, by - .2f * u, fillP)
        txt(c, "Peluru baru ${fmt(g.ammoT)}", bx + 3f * u, by, 2.6f, Color.WHITE); by += 3.8f * u
        fillP.color = rgb(Models.pickupGlow[2]); c.drawRect(bx, by - 2.2f * u, bx + 2f * u, by - .2f * u, fillP)
        txt(c, "Darah +30 ${fmt(g.healthT)}", bx + 3f * u, by, 2.6f, Color.WHITE); by += 4.5f * u
        // teman
        for (p in pl) {
            if (p.id == g.myId) continue
            fillP.color = rgb(Models.playerTint[p.id % Models.playerTint.size]); c.drawCircle(bx + u, by - u, u, fillP)
            txt(c, "${p.name}  ${if (p.alive) "${p.hp.toInt()} HP" else "tumbang"}", bx + 3f * u, by, 2.6f, if (p.alive) Color.WHITE else Color.LTGRAY); by += 3.8f * u
        }
        if (gfx.showFps) txt(c, "${Perf.fps} FPS", w / 2, 3.5f * u, 2.6f, Color.YELLOW, Paint.Align.CENTER)

        // --- pengumuman
        if (g.announceT > 0f && g.announce.isNotEmpty()) {
            val a = (min(1f, g.announceT) * 255).toInt()
            textP.textSize = 3.2f * u; val tw = textP.measureText(g.announce) + 6f * u
            fillP.color = Color.argb(a * 140 / 255, 0, 0, 0); c.drawRoundRect(w / 2 - tw / 2, 6f * u, w / 2 + tw / 2, 12.5f * u, 2f * u, 2f * u, fillP)
            txt(c, g.announce, w / 2, 10.6f * u, 3.2f, Color.argb(a, 255, 240, 160), Paint.Align.CENTER)
        }

        // --- minimap
        drawMap(c, me, w - 2f * u - 17f * u, 2f * u + 17f * u, 17f * u)

        // --- amunisi
        val wp = me.weapon
        txt(c, Game.NAMES[wp], w - 3f * u, h - 48f * u, 2.8f, Color.LTGRAY, Paint.Align.RIGHT)
        val low = me.mag[wp] <= Game.MAG[wp] / 4
        txt(c, "${me.mag[wp]}", w - 15f * u, h - 41f * u, 7f, if (low) Color.rgb(255, 90, 70) else Color.WHITE, Paint.Align.RIGHT)
        txt(c, "/ ${me.reserve[wp]}", w - 3f * u, h - 41f * u, 4f, Color.LTGRAY, Paint.Align.RIGHT)
        if (g.reloading && me.alive) {
            val bw = 26f * u; val bxx = w / 2 - bw / 2; val byy = h * .72f
            fillP.color = 0x99000000.toInt(); c.drawRoundRect(bxx, byy, bxx + bw, byy + 2.4f * u, u, u, fillP)
            fillP.color = Color.rgb(255, 200, 60); c.drawRoundRect(bxx, byy, bxx + bw * (g.rt / max(.1f, g.rTotal)).coerceIn(0f, 1f), byy + 2.4f * u, u, u, fillP)
            txt(c, "MENGISI ULANG", w / 2, byy - .8f * u, 2.8f, Color.WHITE, Paint.Align.CENTER)
        } else if (me.alive && me.mag[wp] == 0 && me.reserve[wp] == 0) {
            val a = (170 + 85 * sin(g.time * 8f)).toInt().coerceIn(0, 255)
            txt(c, "PELURU HABIS! Cari kotak peluru di peta", w / 2, h * .74f, 3.4f, Color.argb(a, 255, 90, 70), Paint.Align.CENTER)
        }
        if (!me.alive && !g.over) {
            txt(c, "KAMU TUMBANG", w / 2, h * .42f, 7f, Color.rgb(255, 80, 70), Paint.Align.CENTER)
            txt(c, "Bertahan hidup, tunggu teman... kamu akan bangkit", w / 2, h * .42f + 5f * u, 3f, Color.WHITE, Paint.Align.CENTER)
        }

        // --- kontrol
        if (joyId >= 0) { drawJoy(c, joyCx, joyCy, joyKx, joyKy) } else drawJoy(c, 16f * u, h - 16f * u, 16f * u, h - 16f * u, true)
        circleBtn(c, fireC(), "FIRE", fireId >= 0, 3.6f, Color.rgb(230, 50, 40))
        circleBtn(c, rldC(), "R", rldId >= 0, 4.4f, Color.rgb(240, 170, 30))
        circleBtn(c, swC(), "GANTI", swId >= 0, 2.5f, Color.rgb(60, 130, 230))
        circleBtn(c, scC(), "SCOPE", scId >= 0 || g.scoped, 2.2f, Color.rgb(140, 90, 220))
        postInvalidateOnAnimation()
    }

    private fun drawJoy(c: Canvas, cx: Float, cy: Float, kx: Float, ky: Float, idle: Boolean = false) {
        fillP.style = Paint.Style.FILL; fillP.color = if (idle) 0x22FFFFFF else 0x33FFFFFF; c.drawCircle(cx, cy, 11f * u, fillP)
        strokeP.color = if (idle) 0x55FFFFFF else 0xAAFFFFFF.toInt(); strokeP.strokeWidth = .45f * u; c.drawCircle(cx, cy, 11f * u, strokeP)
        fillP.color = if (idle) 0x44FFFFFF else 0x99FFFFFF.toInt(); c.drawCircle(kx, ky, 4.8f * u, fillP)
    }

    private fun drawMap(c: Canvas, me: Player, cx: Float, cy: Float, r: Float) {
        val range = 55f; val sc = r / range
        val yr = Math.toRadians(me.yaw.toDouble()).toFloat()
        val fx = sin(yr); val fz = -cos(yr); val rx = cos(yr); val rz = sin(yr)
        c.save()
        path.reset(); path.addCircle(cx, cy, r, Path.Direction.CW); c.clipPath(path)
        fillP.style = Paint.Style.FILL; fillP.color = 0xAA101820.toInt(); c.drawCircle(cx, cy, r, fillP)
        fillP.color = 0xFF8A9096.toInt()
        for (b in World.boxes) {
            if (b.x1 < me.x - range - 5f || b.x0 > me.x + range + 5f || b.z1 < me.z - range - 5f || b.z0 > me.z + range + 5f) continue
            path.reset()
            val xs = floatArrayOf(b.x0, b.x1, b.x1, b.x0); val zs = floatArrayOf(b.z0, b.z0, b.z1, b.z1)
            for (i in 0 until 4) {
                val dx = xs[i] - me.x; val dz = zs[i] - me.z
                val sx = cx + (dx * rx + dz * rz) * sc; val sy = cy - (dx * fx + dz * fz) * sc
                if (i == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
            }
            path.close(); c.drawPath(path, fillP)
        }
        // item dalam radius 30 m ("radar dekat": tetap harus dicari dulu)
        for (k in pk) {
            val dx = k.x - me.x; val dz = k.z - me.z
            if (hypot(dx, dz) > 30f) continue
            fillP.color = rgb(Models.pickupGlow[k.type])
            c.drawRect(cx + (dx * rx + dz * rz) * sc - .9f * u, cy - (dx * fx + dz * fz) * sc - .9f * u, cx + (dx * rx + dz * rz) * sc + .9f * u, cy - (dx * fx + dz * fz) * sc + .9f * u, fillP)
        }
        for (e in en) {
            val dx = e.x - me.x; val dz = e.z - me.z
            fillP.color = if (e.type == 3) Color.YELLOW else Color.rgb(255, 60, 60)
            c.drawCircle(cx + (dx * rx + dz * rz) * sc, cy - (dx * fx + dz * fz) * sc, .6f * u, fillP)
        }
        for (p in pl) {
            if (p.id == g.myId) continue
            val dx = p.x - me.x; val dz = p.z - me.z
            fillP.color = rgb(Models.playerTint[p.id % Models.playerTint.size])
            c.drawCircle(cx + (dx * rx + dz * rz) * sc, cy - (dx * fx + dz * fz) * sc, 1f * u, fillP)
        }
        c.restore()
        // pemain sendiri (segitiga menghadap atas)
        fillP.color = Color.WHITE; path.reset(); path.moveTo(cx, cy - 1.6f * u); path.lineTo(cx - 1.1f * u, cy + 1.1f * u); path.lineTo(cx + 1.1f * u, cy + 1.1f * u); path.close(); c.drawPath(path, fillP)
        strokeP.color = 0xCCFFFFFF.toInt(); strokeP.strokeWidth = .5f * u; c.drawCircle(cx, cy, r, strokeP)
    }
}
