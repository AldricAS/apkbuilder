package com.example.shooter3d
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val gfx = Gfx.load(this)
        val p = Ui.panel(this)
        p.addView(TextView(this).apply { text = "Pengaturan"; textSize = 26f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        p.addView(Ui.section(this, "Kualitas grafis (resolusi, jarak pandang, rumput & awan)"))
        p.addView(Ui.chips(this, Gfx.QUALITY.toList(), gfx.quality) { gfx.quality = it; gfx.save(this) })
        p.addView(Ui.section(this, "Batas FPS"))
        p.addView(Ui.chips(this, listOf("30", "60", "Tanpa batas"), Gfx.FPS.indexOf(gfx.fpsCap).coerceAtLeast(0)) { gfx.fpsCap = Gfx.FPS[it]; gfx.save(this) })
        p.addView(Ui.section(this, "Tampilkan FPS"))
        p.addView(Ui.chips(this, listOf("Mati", "Nyala"), if (gfx.showFps) 1 else 0) { gfx.showFps = it == 1; gfx.save(this) })
        p.addView(Ui.section(this, "Sensitivitas bidik"))
        p.addView(SeekBar(this).apply { max = 100; progress = ((gfx.sens - .05f) / .45f * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { gfx.sens = .05f + v / 100f * .45f; gfx.save(this@SettingsActivity) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} }) })
        p.addView(Ui.section(this, "Volume suara"))
        p.addView(SeekBar(this).apply { max = 100; progress = (gfx.vol * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { gfx.vol = v / 100f; gfx.save(this@SettingsActivity) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} }) })
        p.addView(Ui.gap(this, 10f))
        p.addView(Ui.button(this, "Selesai", Ui.ACCENT) { finish() })
        setContentView(Ui.screen(this, p))
    }
}
