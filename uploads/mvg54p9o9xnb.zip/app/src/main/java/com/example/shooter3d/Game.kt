package com.example.shooter3d
import java.io.DataInputStream
import java.io.DataOutputStream
import kotlin.math.*
import kotlin.random.Random

enum class Mode(val label: String) {
    WAVE("Wave Survival"), TIME("Time Attack 60s"), TARGET("Target Practice 90s"), BOSS("Boss Rush")
}
enum class Role { SOLO, HOST, CLIENT }

/** type: 0 Prajurit, 1 Pengintai (cepat), 2 Berat (shotgun, tebal), 3 target latihan, 4 Boss. */
class Enemy(val id: Int, var x: Float, var z: Float, val type: Int, var hp: Float) {
    var flash = 0f; var bob = Random.nextFloat() * 6f; var lift = 0f
    var tx = x; var tz = z   // target interpolasi (klien)
    var yaw = 0f             // arah hadap (derajat), menghadap pemain terdekat
    var walk = 0f; var moveAmt = 0f      // animasi jalan
    var aim = 0f; var aimT = 0f          // aim: 0..1 (angkat senjata), aimT: sisa waktu membidik
    var muzzle = 0f                      // kilatan moncong
    var fireCd = .8f + Random.nextFloat() * 1.6f
    var strafeDir = if (Random.nextBoolean()) 1f else -1f; var strafeT = 1f + Random.nextFloat() * 2f
    var los = false; var losT = Random.nextFloat() * .2f
    var stuckT = 0f          // lama terhalang tembok saat mengejar
    var idleT = 0f           // lama tidak bisa maju & tidak melihat pemain (watchdog)
}
/** type: 0 peluru senapan, 1 peluru shotgun, 2 paket darah. */
class Pickup(val id: Int, val type: Int, val x: Float, val z: Float)

class Player(val id: Int, var name: String) {
    var x = 0f; var z = 0f; var yaw = 0f; var pitch = 0f
    var tx = 0f; var tz = 0f; var tyaw = 0f
    var hp = 100f; var alive = true; var weapon = 0; var score = 0; var kills = 0
    var flash = 0f; var respawnT = 0f; var hurtAcc = 0f; var walk = 0f
    val mag = intArrayOf(30, 6)
    val reserve = intArrayOf(60, 12)
}

/** Kejadian (suara, efek, notifikasi). Sebagian dikirim lewat jaringan ke teman. */
class GameEvent(val type: Int, val pid: Int = -1, val x: Float = 0f, val z: Float = 0f, val a: Float = 0f,
                val i: Int = 0, val text: String = "", val target: Int = -1)
object Ev {
    const val SHOT = 1; const val HIT = 2; const val KILL = 3; const val HURT = 4; const val PICKUP = 5
    const val ANNOUNCE = 6; const val OVER = 7; const val DOWN = 8; const val ESHOT = 9
    // lokal saja:
    const val SCOPE = 25; const val DRY = 20; const val RELOAD_SND = 21; const val STEP = 22; const val SWITCH = 23; const val IMPACT = 24
    fun networked(t: Int) = t in 1..9
}
interface NetOut { fun shot(weapon: Int); fun hit(eid: Int, dmg: Float, head: Boolean) }
class RStep(val t: Float, val snd: Int, val fill: Int)

class Game(val mode: Mode, val role: Role, val myId: Int, roster: List<Pair<Int, String>>, val diff: Int = 1) {
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f
    @Volatile var firing = false
    @Volatile var wantReload = false
    @Volatile var wantSwitch = false
    @Volatile var wantScope = false

    val players = ArrayList<Player>()
    val enemies = ArrayList<Enemy>()
    val pickups = ArrayList<Pickup>()
    private val events = ArrayList<GameEvent>()
    var netHook: ((GameEvent) -> Unit)? = null
    var netOut: NetOut? = null
    val me: Player
    private val dI = diff.coerceIn(0, 2)

    var wave = 0; var time = 0f; var over = false
    var shots = 0; var hits = 0
    var ammoT = 120f; var healthT = 60f
    private var nextId = 1; private var spawnT = 0f; private var waveDelay = 3f

    // ---- keadaan senjata lokal (dipakai renderer untuk animasi & HUD)
    var cd = 0f; var recoil = 0f; var muzzle = 0f; var switchT = 0f; var dryT = 0f
    var reloading = false; var rt = 0f; var rTotal = 0f
    val rSteps = ArrayList<RStep>(); private var rNext = 0
    var walkPhase = 0f; var walkAmt = 0f; private var stepDist = 0f
    var scoped = false; var zoom = 0f
    var hurtFlash = 0f; var hitMark = 0f; var hitHead = false
    var announce = ""; var announceT = 0f
    var dmgDir = 0f; var dmgDirT = 0f      // arah tembakan musuh yang mengenai kita (bearing dunia, derajat)
    private val tmp = FloatArray(2)
    // ---- pencarian jalan musuh: peta alur (BFS) dari tiap pemain, sel 1 m, dihitung ulang 2x per detik
    private var blockedGrid: BooleanArray? = null
    private val fields = HashMap<Int, IntArray>()
    private val bfsQueue = IntArray(GN * GN)
    private val flowOut = FloatArray(2)
    private var fieldT = 0f
    private val fieldPos = HashMap<Int, FloatArray>()      // posisi pemain saat peta alur terakhir dihitung (x, z, umur)

    companion object {
        // tipe musuh: 0 Prajurit, 1 Pengintai, 2 Berat, 3 target latihan, 4 Boss
        val H = floatArrayOf(1.85f, 1.7f, 2.15f, 2.2f, 3.1f)
        val Y0 = floatArrayOf(0f, 0f, 0f, 0f, 0f)
        val R = floatArrayOf(.55f, .5f, .7f, .7f, 1.0f)
        val HEAD = floatArrayOf(.78f, .78f, .78f, .6f, .78f)   // bagian atas tubuh yang dihitung headshot
        val SPEED = floatArrayOf(2.6f, 4.4f, 1.8f, 0f, 1.7f)
        val PTS = intArrayOf(10, 15, 30, 5, 100)
        val HP = floatArrayOf(3f, 2f, 8f, 1f, 30f)
        // senjata musuh: jarak ideal, jarak tembak maks, jeda tembak (detik), damage per tembakan, akurasi dasar
        val E_PREF = floatArrayOf(14f, 7f, 9f, 0f, 17f)
        val E_RANGE = floatArrayOf(30f, 20f, 17f, 0f, 34f)
        val E_CD = floatArrayOf(1.1f, .5f, 1.7f, 0f, .85f)
        val E_DMG = floatArrayOf(6f, 3f, 11f, 0f, 10f)
        val E_ACC = floatArrayOf(.55f, .5f, .62f, 0f, .65f)
        val E_NAME = arrayOf("Prajurit", "Pengintai", "Berat", "Target", "Boss")
        // tingkat kesulitan: Mudah, Normal, Sulit
        val DIFF_NAMES = arrayOf("Mudah", "Normal", "Sulit")
        val DIFF_INFO = arrayOf("Musuh lebih lemah, sering meleset, jumlahnya lebih sedikit",
            "Seimbang: musuh menembak cukup akurat dan bergerak cekatan",
            "Musuh tangguh, akurat, cepat menembak, dan datang lebih banyak")
        private val D_HP = floatArrayOf(.7f, 1f, 1.4f)
        private val D_DMG = floatArrayOf(.55f, 1f, 1.3f)
        private val D_ACC = floatArrayOf(.6f, 1f, 1.2f)
        private val D_RATE = floatArrayOf(.75f, 1f, 1.2f)
        private val D_SPD = floatArrayOf(.85f, 1f, 1.1f)
        private val D_SPAWN = floatArrayOf(.75f, 1f, 1.25f)
        private val D_SCORE = floatArrayOf(.8f, 1f, 1.4f)
        val NAMES = arrayOf("Repeater", "Blaster")
        val CD = floatArrayOf(.1f, .75f)
        val DMG = floatArrayOf(1f, 1f)
        val PELLETS = intArrayOf(1, 6)
        val SPREAD = floatArrayOf(.012f, .06f)
        val MAG = intArrayOf(30, 6)
        val CAP = intArrayOf(150, 40)
        val AMMO_AMT = intArrayOf(30, 8)
        val SCOPE_FOV = floatArrayOf(24f, 40f)   // sudut pandang saat scope (normal 65)
        const val GN = 200                    // peta 200 x 200 sel (1 m)
        const val HEAL = 30f
        const val SPEED_WALK = 6f
        const val AMMO_EVERY = 120f
        const val HEAL_EVERY = 60f
        const val MAX_PLAYERS = 4
    }

    init {
        World.build()
        for ((id, name) in roster) addPlayer(id, name)
        if (players.none { it.id == myId }) addPlayer(myId, "Pemain")
        me = players.first { it.id == myId }
        val rifle = when (mode) { Mode.TIME -> 200; Mode.TARGET -> 240; else -> 90 }
        val shell = when (mode) { Mode.TIME -> 40; Mode.TARGET -> 60; else -> 16 }
        for (p in players) { p.reserve[0] = rifle; p.reserve[1] = shell }
        if (role != Role.CLIENT) {
            grid()
            repeat(3) { spawnPickup(0); spawnPickup(1); spawnPickup(2) }
        }
    }

    private fun addPlayer(id: Int, name: String): Player {
        val p = Player(id, name)
        val s = World.spawns[id % World.spawns.size]
        p.x = s[0]; p.z = s[1]; p.tx = p.x; p.tz = p.z
        players += p; return p
    }

    private fun limit() = when (mode) { Mode.TIME -> 60f; Mode.TARGET -> 90f; else -> 0f }

    fun dir(yawDeg: Float, pitchDeg: Float): FloatArray {
        val y = Math.toRadians(yawDeg.toDouble()).toFloat(); val p = Math.toRadians(pitchDeg.toDouble()).toFloat()
        return floatArrayOf(sin(y) * cos(p), sin(p), -cos(y) * cos(p))
    }

    // ------------------------------------------------------------------ event
    /** Event dari simulasi (host/solo): disimpan lokal dan diteruskan ke teman. */
    private fun emit(ev: GameEvent) { push(ev); if (Ev.networked(ev.type)) netHook?.invoke(ev) }
    private fun emitLocal(ev: GameEvent) { push(ev) }

    private fun push(ev: GameEvent) {
        when (ev.type) {
            Ev.ANNOUNCE -> { announce = ev.text; announceT = 4.5f }
            Ev.HURT -> if (ev.pid == myId) hurtFlash = min(1f, hurtFlash + .5f)
            Ev.HIT -> if (ev.pid == myId) { hitMark = .2f; hitHead = ev.a > .5f }
            Ev.ESHOT -> {
                val en = enemies.firstOrNull { it.id == ev.i }
                if (en != null) { en.muzzle = .09f; en.aimT = 1.2f }
                if (ev.pid == myId && ev.a > .5f) {
                    dmgDir = Math.toDegrees(atan2((ev.x - me.x).toDouble(), -(ev.z - me.z).toDouble())).toFloat(); dmgDirT = 1.6f
                }
            }
        }
        if (events.size > 300) events.removeAt(0)
        events += ev
    }

    @Synchronized fun drainEvents(out: ArrayList<GameEvent>) { out.addAll(events); events.clear() }

    /** Event dari host (dipanggil di thread jaringan klien). */
    @Synchronized fun receiveEvent(ev: GameEvent) {
        if (ev.type == Ev.PICKUP && ev.pid == myId && ev.i < 2) addAmmo(me, ev.i, ev.a.toInt())
        if (ev.type == Ev.HIT && ev.pid == myId) return          // sudah diprediksi lokal
        if (ev.type == Ev.SHOT && ev.pid == myId) return         // suara tembakan sendiri sudah diputar lokal
        if (ev.type == Ev.OVER) over = true
        push(ev)
    }

    @Synchronized fun copyWorld(en: ArrayList<Enemy>, pk: ArrayList<Pickup>, pl: ArrayList<Player>) {
        en.clear(); en.addAll(enemies); pk.clear(); pk.addAll(pickups); pl.clear(); pl.addAll(players)
    }

    /** Sudut pandang kamera saat ini (menyempit mulus ketika scope aktif). */
    fun fov(): Float = 65f + (SCOPE_FOV[me.weapon] - 65f) * zoom

    fun teamScore(): Int { var s = 0; for (p in players) s += p.score; return s }

    // ------------------------------------------------------------------ item
    private fun addAmmo(p: Player, type: Int, amt: Int) { p.reserve[type] = min(CAP[type], p.reserve[type] + amt) }

    private fun spawnPickup(type: Int): Boolean {
        var count = 0
        for (k in pickups) if (k.type == type) count++
        if (count >= (if (type == 2) 5 else 8)) return false
        for (attempt in 0 until 25) {
            val s = World.spots[Random.nextInt(World.spots.size)]
            var ok = true
            for (k in pickups) if (hypot(k.x - s[0], k.z - s[1]) < 4f) { ok = false; break }
            if (!ok) continue
            pickups += Pickup(nextId++, type, s[0], s[1]); return true
        }
        return false
    }

    // ------------------------------------------------------------------ update
    @Synchronized fun update(dt: Float) {
        time += dt
        recoil = max(0f, recoil - dt * 7f); muzzle = max(0f, muzzle - dt); dryT = max(0f, dryT - dt)
        hurtFlash = max(0f, hurtFlash - dt * 1.6f); hitMark = max(0f, hitMark - dt); announceT = max(0f, announceT - dt); dmgDirT = max(0f, dmgDirT - dt)
        for (p in players) p.flash = max(0f, p.flash - dt)
        if (wantScope) { wantScope = false; if (me.alive && !over && !reloading && switchT <= 0f) { scoped = !scoped; emitLocal(GameEvent(Ev.SCOPE)) } }
        if (!me.alive || over) scoped = false
        zoom += ((if (scoped) 1f else 0f) - zoom) * min(1f, dt * 10f)
        if (!over && me.alive) localPlayer(dt)
        if (role == Role.CLIENT) interpolate(dt) else if (!over) simulate(dt) else interpolate(dt)
    }

    private fun localPlayer(dt: Float) {
        val p = me
        // --- gerak
        var mx = moveX; var my = moveY
        val len = hypot(mx, my); if (len > 1f) { mx /= len; my /= len }
        val yr = Math.toRadians(p.yaw.toDouble()).toFloat()
        val sp = SPEED_WALK * (if (reloading) .88f else 1f) * (if (scoped) .6f else 1f)
        val nx = p.x + (sin(yr) * my + cos(yr) * mx) * sp * dt
        val nz = p.z + (-cos(yr) * my + sin(yr) * mx) * sp * dt
        World.push(nx, nz, .45f, 0f, tmp)
        val moved = hypot(tmp[0] - p.x, tmp[1] - p.z)
        p.x = tmp[0]; p.z = tmp[1]
        val movingNow = if (dt > 0f && moved / dt > 1.2f) 1f else 0f
        walkAmt += (movingNow - walkAmt) * min(1f, dt * 8f)
        walkPhase += moved * 1.7f; stepDist += moved
        if (stepDist > 2.3f) { stepDist = 0f; emitLocal(GameEvent(Ev.STEP)) }
        // --- senjata
        cd -= dt; switchT = max(0f, switchT - dt)
        if (wantSwitch) { wantSwitch = false; if (switchT <= 0f) switchWeapon() }
        if (wantReload) { wantReload = false; startReload() }
        if (reloading) updateReload(dt)
        if (firing && cd <= 0f && switchT <= 0f) tryShoot()
    }

    private fun switchWeapon() {
        cancelReload(); scoped = false; me.weapon = 1 - me.weapon; switchT = .45f; cd = max(cd, .3f)
        emitLocal(GameEvent(Ev.SWITCH))
    }

    private fun startReload() {
        val p = me; val w = p.weapon
        if (reloading || switchT > 0f || !p.alive) return
        val need = MAG[w] - p.mag[w]
        if (need <= 0 || p.reserve[w] <= 0) return
        rSteps.clear()
        if (w == 0) {
            rSteps += RStep(.30f, 0, 0)     // tombol lepas + magasin lepas
            rSteps += RStep(1.00f, 1, 0)    // magasin baru meluncur masuk (clack di ~1.2 s)
            rSteps += RStep(1.42f, 2, 0)    // tarik & lepas handle (clack di ~1.7 s)
            rSteps += RStep(1.72f, -1, 999) // peluru terisi
            rTotal = 2.2f
        } else {
            val n = min(need, p.reserve[w]); var t = .38f
            for (i in 0 until n) { rSteps += RStep(t, 3, 1); t += .32f }
            rSteps += RStep(t + .04f, 4, 0)
            rTotal = t + .6f
        }
        reloading = true; scoped = false; rt = 0f; rNext = 0
    }

    private fun cancelReload() { reloading = false; rt = 0f }

    private fun updateReload(dt: Float) {
        rt += dt
        val p = me; val w = p.weapon
        while (rNext < rSteps.size && rt >= rSteps[rNext].t) {
            val s = rSteps[rNext++]
            if (s.snd >= 0) emitLocal(GameEvent(Ev.RELOAD_SND, i = s.snd))
            if (s.fill > 0) {
                val take = min(min(s.fill, MAG[w] - p.mag[w]), p.reserve[w])
                p.mag[w] += take; p.reserve[w] -= take
            }
        }
        if (rt >= rTotal) { reloading = false; rt = 0f }
    }

    private fun tryShoot() {
        val p = me; val w = p.weapon
        if (reloading) {
            if (w == 1 && p.mag[1] > 0 && rt > .4f) cancelReload() else return   // shotgun boleh dipotong untuk menembak
        }
        if (p.mag[w] <= 0) {
            if (p.reserve[w] > 0) startReload()
            else if (dryT <= 0f) { dryT = .45f; cd = .3f; emitLocal(GameEvent(Ev.DRY)) }
            return
        }
        shoot()
    }

    private fun shoot() {
        val p = me; val w = p.weapon
        cd = CD[w]; p.mag[w]--; shots++; recoil = 1f; muzzle = .06f
        val shotEv = GameEvent(Ev.SHOT, pid = myId, x = p.x, z = p.z, a = w.toFloat())
        if (role == Role.CLIENT) { emitLocal(shotEv); netOut?.shot(w) } else emit(shotEv)

        val hitE = ArrayList<Enemy>(); val hitD = ArrayList<Float>(); val hitH = ArrayList<Boolean>()
        val sp = SPREAD[w] * 57f * (if (scoped) .3f else 1f)
        repeat(PELLETS[w]) {
            val d = dir(p.yaw + (Random.nextFloat() - .5f) * sp * 2f, p.pitch + (Random.nextFloat() - .5f) * sp * 2f)
            val wallT = World.rayBlock(p.x, 1.6f, p.z, d[0], d[1], d[2], 220f)
            var best: Enemy? = null; var bt = 1e9f
            val hl = hypot(d[0], d[2])
            if (hl > 1e-4f) for (e in enemies) {
                val rx = e.x - p.x; val rz = e.z - p.z
                val tca = (rx * d[0] + rz * d[2]) / hl            // jarak horizontal ke titik terdekat
                if (tca < 0f) continue
                val d2 = rx * rx + rz * rz - tca * tca
                val rr = R[e.type]
                if (d2 >= rr * rr) continue
                val th = tca - sqrt(rr * rr - d2)                  // jarak horizontal saat masuk silinder
                val t = max(0f, th) / hl                           // d unit => t = jarak sinar
                val yy = 1.6f + d[1] * t
                if (t >= wallT || t >= bt || yy < Y0[e.type] || yy > Y0[e.type] + H[e.type]) continue
                bt = t; best = e
            }
            val e = best
            if (e != null) {
                val head = 1.6f + d[1] * bt > Y0[e.type] + H[e.type] * HEAD[e.type]
                val dmg = DMG[w] * (if (head) 2f else 1f)
                val k = hitE.indexOf(e)
                if (k < 0) { hitE.add(e); hitD.add(dmg); hitH.add(head) } else { hitD[k] = hitD[k] + dmg; if (head) hitH[k] = true }
            } else if (wallT < 219f) {
                emitLocal(GameEvent(Ev.IMPACT, x = p.x + d[0] * wallT, z = p.z + d[2] * wallT, a = 1.6f + d[1] * wallT))
            }
        }
        if (hitE.isNotEmpty()) hits++
        for (k in hitE.indices) {
            val e = hitE[k]
            if (role == Role.CLIENT) {
                e.flash = .1f
                emitLocal(GameEvent(Ev.HIT, pid = myId, x = e.x, z = e.z, a = if (hitH[k]) 1f else 0f))
                netOut?.hit(e.id, hitD[k], hitH[k])
            } else applyHit(myId, e.id, hitD[k], hitH[k])
        }
    }

    /** Terapkan damage ke musuh (host/solo). */
    @Synchronized fun applyHit(pid: Int, eid: Int, dmg: Float, head: Boolean) {
        if (over || role == Role.CLIENT) return
        val e = enemies.firstOrNull { it.id == eid } ?: return
        e.hp -= dmg; e.flash = .1f
        emit(GameEvent(Ev.HIT, pid = pid, x = e.x, z = e.z, a = if (head) 1f else 0f))
        if (e.hp <= 0f) {
            enemies.remove(e)
            val pl = players.firstOrNull { it.id == pid }
            if (pl != null) { pl.score += (PTS[e.type] * (if (head) 2 else 1) * D_SCORE[dI]).toInt(); pl.kills++ }
            emit(GameEvent(Ev.KILL, pid = pid, x = e.x, z = e.z, i = e.type))
        }
    }

    // ------------------------------------------------------------------ simulasi (host / solo)
    private fun spawn(type: Int, hp: Float = -1f) {
        val alive = players.filter { it.alive }
        val c = if (alive.isEmpty()) me else alive[Random.nextInt(alive.size)]
        var x = 0f; var z = 0f
        for (t in 0 until 14) {
            val a = Random.nextFloat() * 6.283f
            val d = if (type == 3) 10f + Random.nextFloat() * 25f else 36f + Random.nextFloat() * 18f
            x = (c.x + cos(a) * d).coerceIn(-World.HALF + 4f, World.HALF - 4f); z = (c.z + sin(a) * d).coerceIn(-World.HALF + 4f, World.HALF - 4f)
            if (!World.blocked(x, z, 1.5f)) break
        }
        val h = if (hp > 0f) hp else if (type == 3) HP[3] else HP[type] * D_HP[dI]
        enemies += Enemy(nextId++, x, z, type, h)
    }

    /** Pilih jenis musuh biasa: Prajurit (paling sering), Pengintai, dan Berat (mulai gelombang 3). */
    private fun pickType(heavyOk: Boolean): Int {
        val r = Random.nextInt(100)
        return if (heavyOk && r < 18) 2 else if (r < 48) 1 else 0
    }

    /** Hadapkan musuh ke pemain hidup terdekat (dipakai klien, yang tidak menjalankan AI). */
    private fun faceNearest(e: Enemy) {
        var bd = 1e9f; var tx = 0f; var tz = 0f
        for (p in players) { if (!p.alive) continue; val d = hypot(p.x - e.x, p.z - e.z); if (d < bd) { bd = d; tx = p.x; tz = p.z } }
        if (bd < 1e8f) e.yaw = Math.toDegrees(atan2((tx - e.x).toDouble(), (tz - e.z).toDouble())).toFloat()
    }

    private fun grid(): BooleanArray {
        var b = blockedGrid
        if (b == null) {
            val o = -World.HALF
            b = BooleanArray(GN * GN)
            for (j in 0 until GN) for (i in 0 until GN) b[j * GN + i] = World.blocked(o + i + .5f, o + j + .5f, .65f)
            blockedGrid = b
        }
        return b
    }

    /** Hitung jarak-jalan (langkah sel) dari posisi (px,pz) ke semua sel yang bisa dilewati. */
    private fun buildField(pid: Int, px: Float, pz: Float) {
        val bl = grid(); val o = -World.HALF
        val d = fields.getOrPut(pid) { IntArray(GN * GN) }
        java.util.Arrays.fill(d, -1)
        var ci = (px - o).toInt().coerceIn(0, GN - 1); var cj = (pz - o).toInt().coerceIn(0, GN - 1)
        if (bl[cj * GN + ci]) {                                   // pemain mepet tembok: pakai sel bebas terdekat
            var bd = 1e9f; var bi = ci; var bj = cj
            for (dj in -3..3) for (di in -3..3) {
                val a = ci + di; val b = cj + dj
                if (a < 0 || b < 0 || a >= GN || b >= GN || bl[b * GN + a]) continue
                val dd = (di * di + dj * dj).toFloat(); if (dd < bd) { bd = dd; bi = a; bj = b }
            }
            ci = bi; cj = bj
        }
        var h = 0; var t = 0
        bfsQueue[t++] = cj * GN + ci; d[cj * GN + ci] = 0
        while (h < t) {
            val c = bfsQueue[h++]; val x = c % GN; val y = c / GN; val nd = d[c] + 1
            if (x > 0 && d[c - 1] < 0 && !bl[c - 1]) { d[c - 1] = nd; bfsQueue[t++] = c - 1 }
            if (x < GN - 1 && d[c + 1] < 0 && !bl[c + 1]) { d[c + 1] = nd; bfsQueue[t++] = c + 1 }
            if (y > 0 && d[c - GN] < 0 && !bl[c - GN]) { d[c - GN] = nd; bfsQueue[t++] = c - GN }
            if (y < GN - 1 && d[c + GN] < 0 && !bl[c + GN]) { d[c + GN] = nd; bfsQueue[t++] = c + GN }
        }
    }

    /** Arah langkah berikutnya untuk musuh e menuju pemain pid mengikuti peta alur. Hasil di flowOut; false bila tidak ada jalan. */
    private fun flowDir(e: Enemy, pid: Int): Boolean {
        val f = fields[pid] ?: return false; val bl = grid(); val o = -World.HALF
        val ci = (e.x - o).toInt(); val cj = (e.z - o).toInt()
        if (ci < 0 || cj < 0 || ci >= GN || cj >= GN) return false
        val here = f[cj * GN + ci]
        var best = if (here >= 0) here else Int.MAX_VALUE; var bx = -1; var bz = -1
        for (dj in -1..1) for (di in -1..1) {
            if (di == 0 && dj == 0) continue
            val a = ci + di; val b = cj + dj
            if (a < 0 || b < 0 || a >= GN || b >= GN) continue
            val v = f[b * GN + a]; if (v < 0) continue
            if (di != 0 && dj != 0 && (bl[cj * GN + a] || bl[b * GN + ci])) continue     // jangan memotong sudut tembok
            if (v < best) { best = v; bx = a; bz = b }
        }
        if (bx < 0) return false
        val tx = o + bx + .5f - e.x; val tz = o + bz + .5f - e.z; val l = max(.001f, hypot(tx, tz))
        flowOut[0] = tx / l; flowOut[1] = tz / l; return true
    }

    /** Satu tembakan musuh ke pemain t. Kena atau meleset ditentukan akurasi, jarak, dan kesulitan. */
    private fun enemyShoot(e: Enemy, t: Player, dist: Float) {
        val ty = e.type; val rng = E_RANGE[ty]
        var chance = E_ACC[ty] * D_ACC[dI] * (1f - .55f * (dist / rng)).coerceIn(.2f, 1f)
        if (e.moveAmt > .5f) chance *= .8f
        val hit = Random.nextFloat() < chance.coerceAtMost(.95f)
        emit(GameEvent(Ev.ESHOT, pid = t.id, x = e.x, z = e.z, a = if (hit) 1f else 0f, i = e.id))
        if (hit) {
            var dmg = E_DMG[ty] * D_DMG[dI]
            if (ty == 2) dmg *= (1.4f - dist / rng).coerceIn(.35f, 1.2f)    // shotgun lemah dari jauh
            t.hp -= dmg
            emit(GameEvent(Ev.HURT, pid = t.id, a = dmg, target = t.id))
        }
    }

    private fun simulate(dt: Float) {
        val n = players.size
        val scale = 1f + .6f * (n - 1)
        // --- timer item: peluru tiap 2 menit, darah tiap 1 menit
        ammoT -= dt
        if (ammoT <= 0f) {
            ammoT = AMMO_EVERY
            var made = 0
            repeat(2 + n) { if (spawnPickup(it % 2)) made++ }
            if (made > 0) emit(GameEvent(Ev.ANNOUNCE, text = "Peluru baru muncul di peta! Cari di sekitar bangunan & peti.", i = 2))
        }
        healthT -= dt
        if (healthT <= 0f) {
            healthT = HEAL_EVERY
            if (spawnPickup(2)) emit(GameEvent(Ev.ANNOUNCE, text = "Paket darah (+${HEAL.toInt()}) muncul di peta!", i = 3))
        }
        // --- mode
        when (mode) {
            Mode.WAVE -> if (enemies.isEmpty()) {
                waveDelay -= dt
                if (waveDelay <= 0f) {
                    wave++; waveDelay = 4f
                    val cnt = ((2 + wave * 1.8f) * scale * D_SPAWN[dI]).toInt().coerceIn(2, 28)
                    repeat(cnt) { spawn(pickType(wave >= 3)) }
                    if (wave % 5 == 0) spawn(4, HP[4] * D_HP[dI] + wave * 2f)
                    emit(GameEvent(Ev.ANNOUNCE, text = "Gelombang $wave", i = 1))
                }
            }
            Mode.TIME -> {
                spawnT -= dt
                if (spawnT <= 0f) {
                    spawnT = 1.5f / (scale * D_SPAWN[dI])
                    if (enemies.size < (7 + 2 * (n - 1)) * D_SPAWN[dI]) spawn(pickType(Random.nextInt(4) == 0))
                }
            }
            Mode.TARGET -> { while (enemies.size < 6) spawn(3) }
            Mode.BOSS -> if (enemies.isEmpty()) {
                wave++; spawn(4, HP[4] * D_HP[dI] + wave * 5f)
                repeat(min(6, max(0, wave - 2))) { spawn(pickType(wave >= 4)) }
                emit(GameEvent(Ev.ANNOUNCE, text = "Boss #$wave", i = 1))
            }
        }
        fieldT -= dt
        if (fieldT <= 0f) {
            fieldT = .5f
            for (p in players) if (p.alive) {
                val lp = fieldPos.getOrPut(p.id) { floatArrayOf(1e9f, 1e9f, 0f) }; lp[2] += .5f
                if (hypot(p.x - lp[0], p.z - lp[1]) > 1.5f || lp[2] >= 3f) { buildField(p.id, p.x, p.z); lp[0] = p.x; lp[1] = p.z; lp[2] = 0f }
            }
        }
        // --- musuh: mendekat, mencari posisi tembak, bergeser (strafing), lalu menembak bila ada garis pandang
        for (e in enemies) {
            e.flash = max(0f, e.flash - dt); e.bob += dt * 6f; e.muzzle = max(0f, e.muzzle - dt); e.aimT = max(0f, e.aimT - dt)
            if (e.type == 3) continue
            var tgt: Player? = null; var bd = 1e9f
            for (p in players) { if (!p.alive) continue; val d = hypot(p.x - e.x, p.z - e.z); if (d < bd) { bd = d; tgt = p } }
            val t = tgt ?: continue
            val ty = e.type
            val dx = t.x - e.x; val dz = t.z - e.z; val dist = max(bd, .01f)
            e.yaw = Math.toDegrees(atan2(dx.toDouble(), dz.toDouble())).toFloat()
            // garis pandang (dicek 5x per detik supaya hemat CPU)
            e.losT -= dt
            if (e.losT <= 0f) {
                e.losT = .2f
                e.los = dist < E_RANGE[ty] && World.rayBlock(e.x, 1.5f, e.z, dx / dist, 0f, dz / dist, dist) >= dist - .6f
            }
            val pref = E_PREF[ty]
            var mx = 0f; var mz = 0f
            if (!e.los || dist > pref + 3f) {                                                    // mendekat (lewat jalan bila terhalang)
                if (!e.los && dist > 3f && flowDir(e, t.id)) { mx = flowOut[0]; mz = flowOut[1] } else { mx = dx / dist; mz = dz / dist }
            }
            else if (dist < pref - 4f) { mx = -dx / dist * .6f; mz = -dz / dist * .6f }         // mundur sedikit
            if (e.los) {                                                                       // bergeser kiri/kanan
                e.strafeT -= dt
                if (e.strafeT <= 0f) { e.strafeT = 1.2f + Random.nextFloat() * 2.2f; e.strafeDir = if (Random.nextBoolean()) 1f else -1f }
                mx += -dz / dist * e.strafeDir * .55f; mz += dx / dist * e.strafeDir * .55f
            }
            if (!e.los && e.stuckT > .5f) { mx = -dz / dist * e.strafeDir + dx / dist * .3f; mz = dx / dist * e.strafeDir + dz / dist * .3f }   // susuri tembok
            if (dist < 2.2f) { mx = 0f; mz = 0f }
            val ml = hypot(mx, mz)
            var movedNow = 0f
            if (ml > 1e-3f) {
                val sp = SPEED[ty] * D_SPD[dI] * min(1f, ml) * dt
                World.push(e.x + mx / ml * sp, e.z + mz / ml * sp, R[ty] * .8f, 0f, tmp)
                val moved = hypot(tmp[0] - e.x, tmp[1] - e.z)
                e.x = tmp[0]; e.z = tmp[1]; e.walk += moved * 2.2f; movedNow = moved
                if (!e.los && moved < sp * .4f) {                  // terhalang: ganti arah menyusuri tembok
                    e.stuckT += dt
                    if (e.stuckT > 2.5f) { e.stuckT = .6f; e.strafeDir = -e.strafeDir }
                } else e.stuckT = max(0f, e.stuckT - dt * 2f)
                e.moveAmt += ((if (dt > 0f && moved / dt > .3f) 1f else 0f) - e.moveAmt) * min(1f, dt * 8f)
            } else e.moveAmt += (0f - e.moveAmt) * min(1f, dt * 8f)
            if (!e.los && dist > 3f && movedNow < SPEED[ty] * dt * .3f) e.idleT += dt else e.idleT = 0f
            if (e.idleT > 12f) {                                                                 // macet terlalu lama: pindahkan ke titik baru
                e.idleT = 0f
                for (tr in 0 until 14) {
                    val an = Random.nextFloat() * 6.283f; val dd = 22f + Random.nextFloat() * 16f
                    val nx = (t.x + cos(an) * dd).coerceIn(-World.HALF + 4f, World.HALF - 4f); val nz = (t.z + sin(an) * dd).coerceIn(-World.HALF + 4f, World.HALF - 4f)
                    if (!World.blocked(nx, nz, 1.5f)) { e.x = nx; e.z = nz; e.tx = nx; e.tz = nz; break }
                }
            }
            for (o in enemies) {                                                                // jangan menumpuk
                if (o === e || o.type == 3) continue
                val ox = e.x - o.x; val oz = e.z - o.z; val od = hypot(ox, oz)
                if (od < 1.1f && od > .001f) { e.x += ox / od * (1.1f - od) * .5f; e.z += oz / od * (1.1f - od) * .5f }
            }
            // menembak
            e.fireCd -= dt
            if (!e.los) e.fireCd = max(e.fireCd, .6f)                                           // waktu bereaksi setelah melihat pemain
            else {
                e.aimT = max(e.aimT, .6f)
                if (e.fireCd <= 0f) { e.fireCd = E_CD[ty] / D_RATE[dI] * (.85f + Random.nextFloat() * .3f); enemyShoot(e, t, dist) }
            }
        }
        // --- kematian / bangkit
        var anyAlive = false
        for (p in players) {
            if (p.alive && p.hp <= 0f) {
                p.hp = 0f; p.alive = false; p.respawnT = 20f
                emit(GameEvent(Ev.DOWN, pid = p.id, x = p.x, z = p.z))
                if (players.size > 1) emit(GameEvent(Ev.ANNOUNCE, text = "${p.name} tumbang! Bangkit 20 detik lagi bila tim masih hidup.", i = 4))
            }
            if (p.alive) anyAlive = true
        }
        if (anyAlive) {
            for (p in players) if (!p.alive) {
                p.respawnT -= dt
                if (p.respawnT <= 0f) {
                    val s = World.spawns[Random.nextInt(World.spawns.size)]
                    p.alive = true; p.hp = 50f; p.x = s[0]; p.z = s[1]; p.tx = p.x; p.tz = p.z
                    if (p.id == myId) { cancelReload(); firing = false }
                    emit(GameEvent(Ev.ANNOUNCE, text = "${p.name} bangkit kembali!", i = 5))
                }
            }
        }
        // --- ambil item
        for (k in pickups.indices.reversed()) {
            val pk = pickups[k]
            for (p in players) {
                if (!p.alive || hypot(p.x - pk.x, p.z - pk.z) > 1.8f) continue
                val ok = if (pk.type == 2) p.hp < 100f else p.reserve[pk.type] < CAP[pk.type]
                if (!ok) continue
                val amt: Int
                if (pk.type == 2) { p.hp = min(100f, p.hp + HEAL); amt = HEAL.toInt() } else { amt = AMMO_AMT[pk.type]; addAmmo(p, pk.type, amt) }
                pickups.removeAt(k)
                emit(GameEvent(Ev.PICKUP, pid = p.id, i = pk.type, a = amt.toFloat(), target = p.id))
                break
            }
        }
        interpolate(dt)
        // --- selesai?
        if (!anyAlive || (limit() > 0f && time >= limit())) { over = true; emit(GameEvent(Ev.OVER)) }
    }

    /** Haluskan posisi pemain lain (dan musuh pada klien). */
    private fun interpolate(dt: Float) {
        val k = min(1f, dt * 14f)
        for (p in players) if (p.id != myId) {
            val dx = p.tx - p.x; val dz = p.tz - p.z
            p.walk += hypot(dx, dz) * 1.7f
            p.x += dx * k; p.z += dz * k
            var dy = p.tyaw - p.yaw
            while (dy > 180f) dy -= 360f
            while (dy < -180f) dy += 360f
            p.yaw += dy * k
        }
        if (role == Role.CLIENT) for (e in enemies) {
            val ox = e.x; val oz = e.z
            e.x += (e.tx - e.x) * k; e.z += (e.tz - e.z) * k
            val moved = hypot(e.x - ox, e.z - oz)
            e.walk += moved * 2.2f
            e.moveAmt += ((if (dt > 0f && moved / dt > .3f) 1f else 0f) - e.moveAmt) * min(1f, dt * 8f)
            e.flash = max(0f, e.flash - dt); e.bob += dt * 6f; e.muzzle = max(0f, e.muzzle - dt); e.aimT = max(0f, e.aimT - dt)
            if (e.type != 3) faceNearest(e)
        }
    }

    // ------------------------------------------------------------------ jaringan: pesan dari klien (di host)
    @Synchronized fun onClientState(pid: Int, d: DataInputStream) {
        val p = players.firstOrNull { it.id == pid } ?: return
        p.tx = d.readFloat(); p.tz = d.readFloat(); p.tyaw = d.readFloat(); p.pitch = d.readFloat()
        p.weapon = d.readByte().toInt().coerceIn(0, 1)
        p.reserve[0] = d.readShort().toInt(); p.reserve[1] = d.readShort().toInt()
    }
    @Synchronized fun onClientShot(pid: Int, weapon: Int) {
        val p = players.firstOrNull { it.id == pid } ?: return
        p.flash = .08f
        emit(GameEvent(Ev.SHOT, pid = pid, x = p.x, z = p.z, a = weapon.toFloat()))
    }
    @Synchronized fun removePlayer(pid: Int) {
        players.removeAll { it.id == pid }
        if (players.none { it.alive } && role == Role.HOST && !over) { over = true; emit(GameEvent(Ev.OVER)) }
    }

    @Synchronized fun writeState(d: DataOutputStream) {
        val p = me
        d.writeFloat(p.x); d.writeFloat(p.z); d.writeFloat(p.yaw); d.writeFloat(p.pitch)
        d.writeByte(p.weapon); d.writeShort(p.reserve[0]); d.writeShort(p.reserve[1])
    }

    // ------------------------------------------------------------------ jaringan: snapshot host -> klien
    @Synchronized fun writeSnapshot(d: DataOutputStream) {
        d.writeFloat(time); d.writeShort(wave); d.writeBoolean(over); d.writeFloat(ammoT); d.writeFloat(healthT)
        d.writeByte(players.size)
        for (p in players) {
            d.writeByte(p.id); d.writeUTF(p.name)
            d.writeFloat(p.x); d.writeFloat(p.z); d.writeFloat(p.yaw); d.writeFloat(p.pitch)
            d.writeShort(p.hp.toInt()); d.writeBoolean(p.alive); d.writeByte(p.weapon); d.writeInt(p.score); d.writeShort(p.kills)
            d.writeBoolean(p.flash > 0f)
        }
        d.writeShort(enemies.size)
        for (e in enemies) {
            d.writeInt(e.id); d.writeByte(e.type); d.writeFloat(e.x); d.writeFloat(e.z); d.writeFloat(e.hp); d.writeFloat(e.lift)
            d.writeBoolean(e.flash > 0f)
        }
        d.writeByte(pickups.size)
        for (k in pickups) { d.writeInt(k.id); d.writeByte(k.type); d.writeFloat(k.x); d.writeFloat(k.z) }
    }

    @Synchronized fun applySnapshot(d: DataInputStream) {
        time = d.readFloat(); wave = d.readShort().toInt(); val ov = d.readBoolean(); ammoT = d.readFloat(); healthT = d.readFloat()
        val seen = HashSet<Int>()
        val np = d.readUnsignedByte()
        for (i in 0 until np) {
            val id = d.readUnsignedByte(); val name = d.readUTF()
            val x = d.readFloat(); val z = d.readFloat(); val yaw = d.readFloat(); val pitch = d.readFloat()
            val hp = d.readShort().toFloat(); val alive = d.readBoolean(); val wp = d.readByte().toInt().coerceIn(0, 1)
            val sc = d.readInt(); val kl = d.readShort().toInt(); val fl = d.readBoolean()
            seen.add(id)
            val p = players.firstOrNull { it.id == id } ?: addPlayer(id, name)
            p.name = name
            val wasAlive = p.alive
            p.hp = hp; p.alive = alive; p.score = sc; p.kills = kl
            if (id == myId) {
                if (!wasAlive && alive) { p.x = x; p.z = z; p.tx = x; p.tz = z; cancelReload() }
                if (wasAlive && !alive) { firing = false; cancelReload() }
            } else {
                p.tx = x; p.tz = z; p.tyaw = yaw; p.pitch = pitch; p.weapon = wp
                if (fl) p.flash = .08f
            }
        }
        players.removeAll { it.id !in seen && it.id != myId }
        val ne = d.readUnsignedShort(); val es = HashSet<Int>()
        for (i in 0 until ne) {
            val id = d.readInt(); val type = d.readUnsignedByte(); val x = d.readFloat(); val z = d.readFloat()
            val hp = d.readFloat(); val lift = d.readFloat(); val fl = d.readBoolean()
            es.add(id)
            var e = enemies.firstOrNull { it.id == id }
            if (e == null) { e = Enemy(id, x, z, type, hp); enemies.add(e) }
            e.tx = x; e.tz = z; e.hp = hp; e.lift = lift; if (fl) e.flash = .1f
        }
        enemies.removeAll { it.id !in es }
        val nk = d.readUnsignedByte(); pickups.clear()
        for (i in 0 until nk) { val id = d.readInt(); val ty = d.readUnsignedByte(); val x = d.readFloat(); val z = d.readFloat(); pickups.add(Pickup(id, ty, x, z)) }
        if (ov && !over) over = true
    }

    fun writeEvent(d: DataOutputStream, ev: GameEvent) {
        d.writeByte(ev.type); d.writeByte(ev.pid); d.writeFloat(ev.x); d.writeFloat(ev.z); d.writeFloat(ev.a)
        d.writeInt(ev.i); d.writeUTF(ev.text); d.writeByte(ev.target)
    }
    fun readEvent(d: DataInputStream): GameEvent {
        val t = d.readUnsignedByte(); val pid = d.readByte().toInt(); val x = d.readFloat(); val z = d.readFloat(); val a = d.readFloat()
        val i = d.readInt(); val s = d.readUTF(); val tg = d.readByte().toInt()
        return GameEvent(t, pid, x, z, a, i, s, tg)
    }

    // ------------------------------------------------------------------ ringkasan
    @Synchronized fun summary(): String {
        val sb = StringBuilder()
        val extra = when (mode) { Mode.WAVE -> "Gelombang $wave"; Mode.BOSS -> "Boss #$wave"; else -> "Waktu ${time.toInt()}s" }
        sb.append("$extra\n")
        if (players.size > 1) {
            sb.append("Skor tim: ${teamScore()}\n")
            for (p in players.sortedByDescending { it.score }) sb.append("${p.name}: ${p.score} (${p.kills} kill)\n")
        } else sb.append("Skor: ${me.score}\n")
        sb.append("Akurasi kamu: ${if (shots > 0) hits * 100 / shots else 0}%")
        return sb.toString()
    }
}
