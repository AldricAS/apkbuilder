# Strike Zone 3D (Android, Kotlin + OpenGL ES 2.0)

Game tembak 3D orang pertama. Buka folder ini di Android Studio lalu Run.

## Yang baru di versi 1.1
- **Musuh sekarang manusia bersenjata** (bukan drone lagi), 3 model berbeda + boss:
  - **Prajurit** (helm hijau, senapan): seimbang, menembak dari jarak menengah-jauh.
  - **Pengintai** (topi & bandana merah, SMG): kecil, sangat cepat, menembak beruntun dari dekat.
  - **Berat** (zirah, helm besar, shotgun): lambat, tebal, damage besar tapi lemah dari jarak jauh. Mulai muncul di gelombang 3.
  - **Boss** (zirah emas, minigun, mata merah menyala): besar, muncul tiap kelipatan 5 gelombang & di mode Boss Rush.
- **Musuh pintar**: mendekat sampai jarak ideal, bergeser kiri-kanan (strafing), tidak menembak bila terhalang tembok,
  tidak bisa menembus tembok. Bila terhalang bangunan/tembok mereka **mencari jalan** (lewat pintu & celah) menuju pemain. Bisa **headshot** (damage 2x). Mati dengan animasi jatuh + darah.
- **Musuh menembak balik**: ada peluru pelacak (tracer), suara tembakan 3D, dan **garis merah di layar** yang menunjukkan arah tembakan yang mengenaimu.
- **Tingkat kesulitan** (Mudah / Normal / Sulit): atur di menu utama, di Pengaturan, atau di lobby (host). Memengaruhi HP musuh,
  damage, akurasi, kecepatan tembak & gerak, jumlah musuh, dan skor. Pada mabar, kesulitan mengikuti pengaturan host.
- **Nama & ikon aplikasi**: nama di `res/values/strings.xml` (`app_name`), ikon adaptive Android 8+ (plus ikon tema Android 13+).
  Ganti desain ikon lewat `python3 tools/make_icon.py`.

## Yang baru di versi 1.0
- **Sound effect realistis** (format OGG Vorbis mono untuk ukuran kecil; tools/gen_sfx.py menghasilkan WAV, konversi dengan ffmpeg -c:a libvorbis) (30 suara, di `app/src/main/assets/sfx/`): tembakan berlapis (crack + ledakan + dentuman + gema),
  suara reload mekanis (magasin lepas/masuk, bolt, pump, peluru shotgun masuk satu-satu), langkah kaki, hit/headshot,
  ledakan drone, dengung drone (makin dekat makin keras), detak jantung saat darah tipis, angin latar, dll.
  Suara musuh & tembakan teman bersifat 3D (volume menurut jarak, kiri/kanan menurut arah).
  Dibuat sendiri lewat `tools/gen_sfx.py` (sintesis, tanpa sample pihak ketiga) — jalankan ulang untuk mengubah suara.
- **Sistem amunisi & reload**: Repeater (magasin 30) dan Blaster (6 peluru, diisi satu-satu, boleh dipotong untuk menembak).
  Peluru cadangan terbatas. Tombol **R** = reload, otomatis reload saat magasin kosong.
- **Animasi reload**: senjata miring, magasin lepas & jatuh, tangan mengambil magasin baru, handle ditarik; shotgun memasukkan peluru satu per satu lalu pump.
- **Item di peta**: kotak peluru (senapan = kuning, shotgun = merah) dan paket darah (+30). Harus dicari keliling peta.
  Peluru baru spawn **tiap 2 menit**, paket darah **tiap 1 menit** (timer tampil di HUD).
- **Peta jauh lebih luas** (200 x 200 m): 6 bangunan berpintu, deretan tembok cover, halaman peti, plaza tengah, kabut jarak.
  Tembok memblokir peluru dan pemain; drone terbang melewati tembok tinggi. Ada **minimap** (item hanya terlihat radius 30 m).
- **Mabar LAN co-op (maks 4 pemain)**: Menu → "Mabar LAN". Satu orang *Buat Room*, teman *Gabung Room*
  (room muncul otomatis, atau ketik IP host). Harus satu WiFi / hotspot yang sama. Host menjalankan simulasi.
- Kontrol: joystick kiri (melayang), geser layar kanan untuk membidik, **tahan FIRE lalu geser jari = tembak sambil menggerakkan kamera**,
  **SCOPE** (zoom teropong, sensitivitas & sebaran peluru mengecil, jalan lebih pelan), R = reload, GANTI = ganti senjata.
- Tampilan menu baru: latar bergradasi, kartu mode, chip pilihan, panel lobby & pengaturan.

## Kontrol & mode
Wave Survival, Time Attack 60s, Target Practice 90s (papan target), Boss Rush (solo atau co-op). Pengaturan grafis, FPS, sensitivitas, volume di menu.

## Struktur kode (app/src/main/java/com/example/shooter3d)
Game.kt (logika, senjata, item, sinkron jaringan) · World.kt (peta, tabrakan, raycast) · GameRenderer.kt (render, animasi senjata, partikel)
· HudView.kt (HUD, minimap, kontrol sentuh) · Sfx.kt (audio) · Net.kt (TCP/UDP LAN) · LobbyActivity.kt · GameActivity.kt

Model 3D: Kenney Blaster Kit & Platformer Kit (CC0). Konversi model: `tools/glb2mesh.py`.

## Yang baru di versi 1.2
- **Tombol HUD dilonggarkan**: GANTI digeser naik-kiri dari FIRE supaya tidak saling menimpa; SCOPE & R ikut disesuaikan.
- **LARI + stamina** (tombol hijau di kanan, di atas SCOPE): tap untuk mulai lari (kecepatan x1.6), dorong joystick ke depan.
  Stamina habis dalam ~5 detik; bar biru di bawah HP. Saat habis muncul "CAPEK", tidak bisa lari sampai stamina pulih ke 30%.
  Lari berhenti otomatis bila berhenti jalan, menembak, scope, atau jongkok. Lari juga membuat suara langkah & jarak pandang musuh lebih besar.
- **JONGKOK** (tombol biru): tinggi mata turun, jalan x0.5, tembakan lebih rapat, musuh sulit melihat (jarak pandang x0.5)
  dan lebih sering meleset. Dengan jongkok kamu bisa bersembunyi di balik tembok rendah (tinggi 1,3 m) — untuk menembak harus berdiri.
- **AI musuh baru**: musuh TIDAK tahu posisimu. Tiga tahap: *patroli* (menyisir sekitar perkiraan kabur lokasimu) -> *curiga/mencari*
  (mendengar tembakan/langkah lari, kena tembak, atau teman melihatmu; memeriksa titik itu lalu menyisir sekitarnya) -> *mengejar & menembak*
  setelah benar-benar MELIHATmu (di kerucut pandang ~124°, dalam jarak pandang, tanpa terhalang tembok). Bila kehilangan jejak mereka
  ke titik terakhir melihatmu lalu mencari lagi. Minimap: cincin kuning = curiga, cincin merah = mengejar.

## Yang baru di versi 1.2.1 (perbaikan mabar)
- **Host tidak lagi membeku / keluar sendiri ke menu & klien tidak lagi sering putus.** Penyebab utama: pengiriman data ke teman
  dilakukan langsung dari thread game, jadi satu HP yang lambat/WiFi tersendat bisa membekukan game host sampai Android mematikan app.
  Sekarang tiap koneksi punya antrean kirim + thread sendiri (`Outbox` di Net.kt): snapshot lama dibuang, koneksi macet diputus sendiri.
- **Heartbeat & timeout** (PING tiap 2 dtk, timeout 12 dtk) + TCP keep-alive: koneksi mati terdeteksi cepat, tidak salah putus saat lobby sepi.
- **Exception jaringan tidak lagi bisa menjatuhkan app** (semua thread & callback jaringan dibungkus).
- **WiFi lock + wake lock** selama mabar supaya WiFi/CPU tidak masuk mode hemat daya.
- **Room tidak lagi ditutup** saat Activity dibuat ulang oleh sistem (rotasi/mode gelap/ukuran font berubah); sesi hanya ditutup saat benar-benar keluar.
