package com.example.shooter3d
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val gfx = Gfx.load(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF101820.toInt()); setPadding(60, 30, 60, 30) }
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 16f; setPadding(0, 20, 0, 4) }
        fun spinner(items: Array<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
            adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, items); setSelection(sel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { on(pos); gfx.save(this@SettingsActivity) }
                override fun onNothingSelected(p: AdapterView<*>?) {} } }
        l.addView(label("Kualitas grafis (resolusi, jarak pandang, dekorasi rumput & awan)"))
        l.addView(spinner(Gfx.QUALITY, gfx.quality) { gfx.quality = it })
        l.addView(label("Batas FPS"))
        l.addView(spinner(arrayOf("30", "60", "Tanpa batas"), Gfx.FPS.indexOf(gfx.fpsCap).coerceAtLeast(0)) { gfx.fpsCap = Gfx.FPS[it] })
        l.addView(CheckBox(this).apply { text = "Tampilkan FPS"; setTextColor(Color.WHITE); isChecked = gfx.showFps
            setOnCheckedChangeListener { _, c -> gfx.showFps = c; gfx.save(this@SettingsActivity) } })
        l.addView(label("Sensitivitas bidik"))
        l.addView(SeekBar(this).apply { max = 100; progress = ((gfx.sens - .05f) / .45f * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { gfx.sens = .05f + p / 100f * .45f; gfx.save(this@SettingsActivity) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} }) })
        l.addView(label("Volume suara"))
        l.addView(SeekBar(this).apply { max = 100; progress = (gfx.vol * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { gfx.vol = p / 100f; gfx.save(this@SettingsActivity) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} }) })
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
