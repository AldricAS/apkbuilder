package com.example.shooter3d
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setBackgroundColor(0xFF101820.toInt()); setPadding(80, 30, 80, 30) }
        l.addView(TextView(this).apply { text = "SHOOTER 3D"; textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 10, 0, 4) })
        l.addView(Ui.label(this, "Cari peluru & paket darah di peta, bertahan hidup!", 14f, 0xFF9FB3C8.toInt()).apply { gravity = Gravity.CENTER })
        fun add(v: android.view.View) { l.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 8, 0, 8) }) }
        Mode.values().forEach { m ->
            add(Ui.button(this, m.label) { startActivity(Intent(this, GameActivity::class.java).putExtra("mode", m.name).putExtra("role", "SOLO")) })
        }
        add(Ui.button(this, "Mabar LAN dengan Teman (Co-op)", 0xFF1F9D55.toInt()) { startActivity(Intent(this, LobbyActivity::class.java)) })
        add(Ui.button(this, "Pengaturan Grafis & Suara", 0xFF4A5568.toInt()) { startActivity(Intent(this, SettingsActivity::class.java)) })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(l) })
    }
}
