package com.example.shooter3d
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.DataInputStream

/** Lobby mabar LAN: buat room (host) atau gabung room teman. Semua pemain harus satu WiFi (atau HP host menyalakan hotspot). */
class LobbyActivity : Activity() {
    private lateinit var gfx: Gfx
    private lateinit var root: LinearLayout
    private var finder: Finder? = null
    private var rosterView: TextView? = null
    private var roomList: LinearLayout? = null
    private var status: TextView? = null
    private var nameEdit: EditText? = null
    private var modeSel = 0
    private val rooms = LinkedHashMap<String, String>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        gfx = Gfx.load(this)
        Session.clear()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF101820.toInt()); setPadding(80, 30, 80, 30) }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        showMenu()
    }

    private fun add(v: View) { root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 8, 0, 8) }) }
    private fun reset(title: String) {
        finder?.stop(); finder = null; root.removeAllViews()
        root.addView(TextView(this).apply { text = title; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
    }
    private fun saveName() { val n = nameEdit?.text?.toString()?.trim().orEmpty(); gfx.name = if (n.isEmpty()) "Pemain" else n.take(12); gfx.save(this) }

    // ------------------------------------------------------------------ menu awal
    private fun showMenu() {
        reset("Mabar LAN (Co-op)")
        add(Ui.label(this, "Semua pemain harus di jaringan WiFi yang sama (atau sambungkan ke hotspot HP host). Maksimal 4 pemain.", 14f, 0xFF9FB3C8.toInt()))
        add(Ui.label(this, "Nama kamu"))
        nameEdit = EditText(this).apply { setText(gfx.name); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); inputType = InputType.TYPE_CLASS_TEXT; setSingleLine() }
        add(nameEdit!!)
        add(Ui.label(this, "Mode (untuk host)"))
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@LobbyActivity, android.R.layout.simple_spinner_dropdown_item, Mode.values().map { it.label })
            setSelection(modeSel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { modeSel = pos }
                override fun onNothingSelected(p: AdapterView<*>?) {} }
        }
        add(sp)
        add(Ui.button(this, "Buat Room (jadi Host)", 0xFF1F9D55.toInt()) { saveName(); startHost() })
        add(Ui.button(this, "Gabung Room Teman") { saveName(); showJoin() })
        add(Ui.button(this, "Kembali", 0xFF4A5568.toInt()) { finish() })
    }

    // ------------------------------------------------------------------ HOST
    private fun startHost() {
        Session.mode = Mode.values()[modeSel]; Session.myId = 0
        Session.roster.clear(); Session.roster.add(Pair(0, gfx.name))
        val host = NetHost(object : HostListener {
            override fun onJoin(c: Conn) { runOnUiThread { joined(c) } }
            override fun onLeave(c: Conn) { runOnUiThread { left(c) } }
            override fun onMessage(c: Conn, type: Int, d: DataInputStream) {}
        })
        if (!host.start()) { Toast.makeText(this, "Gagal membuka port ${Proto.PORT}. Coba lagi.", Toast.LENGTH_LONG).show(); return }
        Session.host = host
        Session.beacon = Beacon(gfx.name, Session.mode.ordinal).also { it.start() }
        showHost()
    }

    private fun joined(c: Conn) {
        val host = Session.host ?: return
        Session.roster.removeAll { it.first == c.id }; Session.roster.add(Pair(c.id, c.name))
        c.send(Proto.pack(Proto.WELCOME) { it.writeByte(c.id); it.writeByte(Session.mode.ordinal) })
        broadcastRoster(host); refreshRoster()
    }
    private fun left(c: Conn) {
        val host = Session.host ?: return
        Session.roster.removeAll { it.first == c.id }; broadcastRoster(host); refreshRoster()
    }
    private fun broadcastRoster(host: NetHost) {
        Session.beacon?.players = Session.roster.size
        host.broadcast(Proto.pack(Proto.ROSTER) { d -> d.writeByte(Session.roster.size); for (p in Session.roster) { d.writeByte(p.first); d.writeUTF(p.second) } })
    }
    private fun refreshRoster() {
        rosterView?.text = Session.roster.joinToString("\n") { (if (it.first == 0) "★ " else "• ") + it.second + if (it.first == 0) "  (host)" else "" }
    }

    private fun showHost() {
        reset("Room: ${Session.mode.label}")
        val ips = Proto.localIps()
        add(Ui.label(this, "IP kamu: " + (if (ips.isEmpty()) "(tidak terdeteksi - nyalakan WiFi/hotspot)" else ips.joinToString("  /  ")) + "   port ${Proto.PORT}", 16f, 0xFFFFD166.toInt()))
        add(Ui.label(this, "Teman otomatis melihat room ini di layar \"Gabung Room\", atau ketik IP di atas.", 13f, 0xFF9FB3C8.toInt()))
        add(Ui.label(this, "Pemain di room:"))
        rosterView = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE) }; add(rosterView!!); refreshRoster()
        add(Ui.button(this, "MULAI GAME", 0xFF1F9D55.toInt()) { startHostGame() })
        add(Ui.button(this, "Batal", 0xFF4A5568.toInt()) { Session.clear(); showMenu() })
    }

    private fun startHostGame() {
        val host = Session.host ?: return
        Session.beacon?.stop()
        Session.inGame = true
        host.broadcast(Proto.pack(Proto.START) { it.writeByte(Session.mode.ordinal) })
        startActivity(Intent(this, GameActivity::class.java).putExtra("role", "HOST").putExtra("mode", Session.mode.name))
        finish()
    }

    // ------------------------------------------------------------------ KLIEN
    private fun showJoin() {
        reset("Gabung Room")
        rooms.clear()
        status = TextView(this).apply { textSize = 14f; setTextColor(0xFF9FB3C8.toInt()); text = "Mencari room di jaringan..." }; add(status!!)
        roomList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; add(roomList!!)
        add(Ui.label(this, "Atau ketik IP host:"))
        val ip = EditText(this).apply { hint = "contoh 192.168.1.5"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); inputType = InputType.TYPE_CLASS_TEXT; setSingleLine() }
        add(ip)
        add(Ui.button(this, "Sambung", 0xFF1F9D55.toInt()) { val a = ip.text.toString().trim(); if (a.isNotEmpty()) connect(a) })
        add(Ui.button(this, "Kembali", 0xFF4A5568.toInt()) { showMenu() })
        finder = Finder { addr, name, mode, n ->
            runOnUiThread {
                rooms[addr] = "$name  -  ${Mode.values()[mode.coerceIn(0, Mode.values().size - 1)].label}  ($n pemain)"
                val rl = roomList
                if (rl != null) {
                    rl.removeAllViews()
                    for ((a, label) in rooms) rl.addView(Ui.button(this, label, 0xFF2A6FDB.toInt()) { connect(a) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 6, 0, 6) })
                }
            }
        }.also { it.start() }
    }

    private fun connect(addr: String) {
        status?.text = "Menyambung ke $addr ..."
        val client = NetClient(object : ClientListener {
            override fun onMessage(type: Int, d: DataInputStream) {
                try {
                    when (type) {
                        Proto.WELCOME -> { Session.myId = d.readUnsignedByte(); Session.mode = Mode.values()[d.readUnsignedByte().coerceIn(0, Mode.values().size - 1)] }
                        Proto.ROSTER -> {
                            val n = d.readUnsignedByte(); val list = ArrayList<Pair<Int, String>>()
                            for (i in 0 until n) { val id = d.readUnsignedByte(); list.add(Pair(id, d.readUTF())) }
                            Session.roster.clear(); Session.roster.addAll(list)
                            runOnUiThread { showWaiting() }
                        }
                        Proto.START -> {
                            Session.mode = Mode.values()[d.readUnsignedByte().coerceIn(0, Mode.values().size - 1)]
                            runOnUiThread { Session.inGame = true; startActivity(Intent(this@LobbyActivity, GameActivity::class.java).putExtra("role", "CLIENT").putExtra("mode", Session.mode.name)); finish() }
                        }
                        Proto.FULL -> runOnUiThread { Toast.makeText(this@LobbyActivity, "Room sudah penuh", Toast.LENGTH_LONG).show(); Session.clear(); showMenu() }
                    }
                } catch (e: Exception) { }
            }
            override fun onClosed() { runOnUiThread { if (!Session.inGame && !isFinishing) { Toast.makeText(this@LobbyActivity, "Koneksi terputus", Toast.LENGTH_LONG).show(); Session.clear(); showMenu() } } }
        })
        Session.client = client
        client.connect(addr, gfx.name) { ok ->
            if (!ok) runOnUiThread { Session.client = null; status?.text = "Gagal menyambung ke $addr. Pastikan satu WiFi & host sudah membuat room." }
        }
    }

    private fun showWaiting() {
        reset("Terhubung!")
        add(Ui.label(this, "Menunggu host memulai game...", 16f, 0xFFFFD166.toInt()))
        add(Ui.label(this, "Pemain di room:"))
        rosterView = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE) }; add(rosterView!!); refreshRoster()
        add(Ui.button(this, "Keluar", 0xFF4A5568.toInt()) { Session.clear(); showMenu() })
    }

    override fun onDestroy() {
        finder?.stop()
        if (!Session.inGame) Session.clear()
        super.onDestroy()
    }
}
