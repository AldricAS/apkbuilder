package com.example.shooter3d
import android.app.Activity
import android.app.AlertDialog
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import java.io.DataInputStream

class GameActivity : Activity() {
    private lateinit var game: Game
    private lateinit var gl: GLSurfaceView
    private lateinit var gfx: Gfx
    private lateinit var sfx: Sfx
    private var role = Role.SOLO
    @Volatile private var running = true
    private var endShown = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        gfx = Gfx.load(this)
        role = Role.valueOf(intent.getStringExtra("role") ?: "SOLO")
        val mode = Mode.valueOf(intent.getStringExtra("mode") ?: "WAVE")
        val myId = if (role == Role.CLIENT) Session.myId else 0
        val roster: List<Pair<Int, String>> = if (role == Role.SOLO) listOf(Pair(0, gfx.name)) else ArrayList(Session.roster)
        game = Game(if (role == Role.SOLO) mode else Session.mode, role, myId, roster)
        sfx = Sfx(this, gfx.vol)
        if (role == Role.HOST) setupHost() else if (role == Role.CLIENT) setupClient()

        val dm = resources.displayMetrics
        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setRenderer(GameRenderer(this@GameActivity, game, gfx, sfx) { runOnUiThread { showEnd() } })
        }
        gl.holder.setFixedSize((maxOf(dm.widthPixels, dm.heightPixels) * gfx.resScale).toInt(), (minOf(dm.widthPixels, dm.heightPixels) * gfx.resScale).toInt())
        val root = FrameLayout(this)
        root.addView(gl); root.addView(HudView(this, game, gfx))
        setContentView(root)
        immersive()
    }

    // ------------------------------------------------------------------ jaringan
    private fun setupHost() {
        val host = Session.host ?: return
        game.netHook = { ev ->
            val bytes = Proto.pack(Proto.EVENT) { game.writeEvent(it, ev) }
            if (ev.target >= 0) host.sendTo(ev.target, bytes) else host.broadcast(bytes)
        }
        host.listener = object : HostListener {
            override fun onJoin(c: Conn) { c.close() }            // tidak menerima pemain baru di tengah permainan
            override fun onLeave(c: Conn) { if (running) game.removePlayer(c.id) }
            override fun onMessage(c: Conn, type: Int, d: DataInputStream) {
                try {
                    when (type) {
                        Proto.STATE -> game.onClientState(c.id, d)
                        Proto.SHOT -> game.onClientShot(c.id, d.readUnsignedByte())
                        Proto.HIT -> { val eid = d.readInt(); val dmg = d.readFloat().coerceIn(0f, 20f); val head = d.readBoolean(); game.applyHit(c.id, eid, dmg, head) }
                    }
                } catch (e: Exception) { }
            }
        }
        val t = Thread {
            while (running) {
                try { host.broadcast(Proto.pack(Proto.SNAP) { game.writeSnapshot(it) }) } catch (e: Exception) { }
                try { Thread.sleep(50) } catch (e: InterruptedException) { }
            }
        }
        t.isDaemon = true; t.start()
    }

    private fun setupClient() {
        val client = Session.client ?: return
        game.netOut = object : NetOut {
            override fun shot(weapon: Int) { client.send(Proto.pack(Proto.SHOT) { it.writeByte(weapon) }) }
            override fun hit(eid: Int, dmg: Float, head: Boolean) { client.send(Proto.pack(Proto.HIT) { it.writeInt(eid); it.writeFloat(dmg); it.writeBoolean(head) }) }
        }
        client.listener = object : ClientListener {
            override fun onMessage(type: Int, d: DataInputStream) {
                try {
                    when (type) {
                        Proto.SNAP -> game.applySnapshot(d)
                        Proto.EVENT -> game.receiveEvent(game.readEvent(d))
                    }
                } catch (e: Exception) { }
            }
            override fun onClosed() { if (running) runOnUiThread { if (!isFinishing) showLost() } }
        }
        val t = Thread {
            while (running && client.open) {
                try { client.send(Proto.pack(Proto.STATE) { game.writeState(it) }) } catch (e: Exception) { }
                try { Thread.sleep(50) } catch (e: InterruptedException) { }
            }
        }
        t.isDaemon = true; t.start()
    }

    // ------------------------------------------------------------------ dialog
    private fun showEnd() {
        if (endShown || isFinishing) return
        endShown = true; game.firing = false; game.moveX = 0f; game.moveY = 0f
        val b = AlertDialog.Builder(this).setTitle("Game Over").setMessage(game.summary()).setCancelable(false)
            .setNegativeButton("Menu") { _, _ -> finish() }
        if (role == Role.SOLO) b.setPositiveButton("Ulangi") { _, _ -> recreate() }
        b.show()
    }

    private fun showLost() {
        if (endShown) return
        endShown = true
        AlertDialog.Builder(this).setTitle("Terputus").setMessage("Koneksi ke host terputus.").setCancelable(false)
            .setPositiveButton("Menu") { _, _ -> finish() }.show()
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) immersive() }
    override fun onPause() { super.onPause(); gl.onPause(); game.firing = false; game.moveX = 0f; game.moveY = 0f }
    override fun onResume() { super.onResume(); gl.onResume() }
    override fun onDestroy() {
        running = false
        sfx.release()
        if (role != Role.SOLO) Session.clear()
        super.onDestroy()
    }
}
