package com.example.shooter3d
import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import kotlin.math.*
import kotlin.random.Random

/** Pemutar suara (SoundPool, latensi rendah) + suara 3D sederhana (volume menurut jarak, pan kiri/kanan menurut arah). */
class Sfx(ctx: Context, private val master: Float) {
    private val pool: SoundPool
    private val ids = HashMap<String, Int>()
    private val ready = HashSet<Int>()
    private var windStream = 0; private var humStream = 0
    private var beatT = 0f

    companion object {
        val NAMES = arrayOf("rifle_shot1", "rifle_shot2", "rifle_shot3", "shotgun_shot1", "shotgun_shot2", "mag_out", "mag_in", "bolt",
            "shell_in", "pump", "dry_click", "weapon_switch", "hit_metal", "hit_head", "drone_die", "boss_die", "player_hurt", "player_death",
            "heartbeat", "pickup_ammo", "pickup_health", "spawn_alert", "wave_start", "game_over", "ui_click", "step1", "step2", "step3",
            "ambient_wind", "drone_hum")
    }

    init {
        pool = SoundPool.Builder().setMaxStreams(28)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
        pool.setOnLoadCompleteListener { _, sid, status -> if (status == 0) synchronized(ready) { ready.add(sid) } }
        for (n in NAMES) {
            try { val fd = ctx.assets.openFd("sfx/$n.wav"); ids[n] = pool.load(fd, 1); fd.close() } catch (e: Exception) { }
        }
    }

    private fun isReady(name: String): Int {
        val id = ids[name] ?: return -1
        return synchronized(ready) { if (ready.contains(id)) id else -1 }
    }

    /** Putar suara non-spasial (suara milik pemain sendiri / UI). */
    fun play(name: String, vol: Float = 1f, rate: Float = 1f) {
        val id = isReady(name); if (id < 0) return
        val v = (vol * master).coerceIn(0f, 1f)
        pool.play(id, v, v, 1, 0, rate)
    }

    fun playVar(name: String, count: Int, vol: Float = 1f) = play(name + (1 + Random.nextInt(count)), vol, .96f + Random.nextFloat() * .08f)

    /** Putar suara di posisi dunia (sx, sz) relatif pendengar (lx, lz) yang menghadap yawDeg. */
    fun playAt(name: String, sx: Float, sz: Float, lx: Float, lz: Float, yawDeg: Float, base: Float = 1f, rate: Float = 1f) {
        val id = isReady(name); if (id < 0) return
        val dx = sx - lx; val dz = sz - lz; val d = hypot(dx, dz)
        val att = 1f / (1f + d * .09f)
        val y = Math.toRadians(yawDeg.toDouble()).toFloat()
        val pan = if (d < .5f) 0f else ((dx * cos(y) + dz * sin(y)) / d).coerceIn(-1f, 1f)   // +1 = kanan
        val l = if (pan > 0f) 1f - pan * .85f else 1f
        val r = if (pan < 0f) 1f + pan * .85f else 1f
        val v = base * att * master
        pool.play(id, (v * l).coerceIn(0f, 1f), (v * r).coerceIn(0f, 1f), 1, 0, rate)
    }

    /** Dipanggil tiap frame: angin latar, dengung drone terdekat (makin dekat makin keras), detak jantung saat darah tipis. */
    fun tick(dt: Float, hp: Float, alive: Boolean, nearestEnemy: Float, enemyPan: Float) {
        if (windStream == 0) { val id = isReady("ambient_wind"); if (id >= 0) windStream = pool.play(id, .32f * master, .32f * master, 0, -1, 1f) }
        if (humStream == 0) { val id = isReady("drone_hum"); if (id >= 0) humStream = pool.play(id, 0f, 0f, 0, -1, 1f) }
        if (humStream != 0) {
            val v = if (alive && nearestEnemy < 30f) ((1f - nearestEnemy / 30f) * (1f - nearestEnemy / 30f) * .5f * master) else 0f
            pool.setVolume(humStream, v * (if (enemyPan > 0f) 1f - enemyPan * .7f else 1f), v * (if (enemyPan < 0f) 1f + enemyPan * .7f else 1f))
            pool.setRate(humStream, 1f + (1f - (nearestEnemy / 30f).coerceIn(0f, 1f)) * .25f)
        }
        if (alive && hp < 30f) { beatT -= dt; if (beatT <= 0f) { beatT = if (hp < 15f) .7f else .95f; play("heartbeat", .75f) } } else beatT = 0f
    }

    fun release() { try { pool.release() } catch (e: Exception) { } }
}
