package com.example.shooter3d
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*
import kotlin.random.Random

object Perf { @Volatile var fps = 0 }

class GameRenderer(private val ctx: Context, private val g: Game, private val gfx: Gfx, private val sfx: Sfx, private val onOver: () -> Unit) : GLSurfaceView.Renderer {
    private class Particle(var x: Float, var y: Float, var z: Float, var vx: Float, var vy: Float, var vz: Float,
                           var life: Float, val maxLife: Float, val size: Float, val r: Float, val gg: Float, val b: Float)

    private var prog = 0; private var aPos = 0; private var aNorm = 0; private var aCol = 0
    private var uMvp = 0; private var uRot = 0; private var uCol = 0; private var uFlash = 0
    private var uFogS = 0; private var uFogE = 0; private var uFogK = 0; private var uFogC = 0
    private lateinit var cube: Mesh; private lateinit var drone: Mesh
    private lateinit var weapons: List<Mesh>; private lateinit var propMesh: Array<Mesh>
    private val proj = FloatArray(16); private val gunProj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16)
    private val ent = FloatArray(16); private val m = FloatArray(16); private val mvp = FloatArray(16); private val rot = FloatArray(16)
    private val gm0 = FloatArray(16); private val gm = FloatArray(16)
    private var last = 0L; private var frames = 0; private var fpsT = 0f; private var ended = false
    private var tanH = 1.4f

    private val enemiesL = ArrayList<Enemy>(); private val pickupsL = ArrayList<Pickup>(); private val playersL = ArrayList<Player>()
    private val evL = ArrayList<GameEvent>()
    private val parts = ArrayList<Particle>()
    private var pumpT = 0f; private var clock = 0f
    private val SKY = floatArrayOf(.55f, .75f, .95f)
    private val PIF = Math.PI.toFloat()

    // pose senjata orang pertama
    private var gx = 0f; private var gy = 0f; private var gz = 0f; private var gPitch = 0f; private var gRoll = 0f
    private var magY = -.075f; private var magVis = true; private var shellVis = false
    private val lh = FloatArray(3)

    companion object {
        const val BX = .26f; const val BY = -.22f; const val BZ = -.50f; const val GS = .28f
        val REST = floatArrayOf(-.02f, -.07f, -.27f)
        // keyframe tangan kiri (ruang lokal senjata) untuk reload Repeater: [waktu, x, y, z]
        val RIFLE_KEYS = arrayOf(
            floatArrayOf(0f, -.02f, -.07f, -.27f), floatArrayOf(.22f, 0f, -.15f, -.08f), floatArrayOf(.62f, 0f, -.22f, -.08f),
            floatArrayOf(.80f, 0f, -.58f, -.10f), floatArrayOf(1.00f, 0f, -.30f, -.07f), floatArrayOf(1.20f, 0f, -.13f, -.07f),
            floatArrayOf(1.30f, 0f, -.02f, -.30f), floatArrayOf(1.40f, .02f, .22f, -.02f), floatArrayOf(1.52f, .02f, .22f, .08f),
            floatArrayOf(1.60f, .02f, .22f, -.02f), floatArrayOf(1.85f, -.02f, -.07f, -.27f), floatArrayOf(2.3f, -.02f, -.07f, -.27f))
        // muzzle (koordinat model) tiap senjata
        val MUZZLE = arrayOf(floatArrayOf(0f, .45f, 1.18f), floatArrayOf(0f, .5f, .9f))
    }

    private fun shader(t: Int, s: String) = GLES20.glCreateShader(t).also { GLES20.glShaderSource(it, s); GLES20.glCompileShader(it) }

    private fun buildCube(): Mesh {
        val v = ArrayList<Float>()
        val ns = arrayOf(floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f))
        for (n in ns) {
            val u = if (abs(n[1]) > .5f) floatArrayOf(1f, 0f, 0f) else floatArrayOf(0f, 1f, 0f)
            val w = floatArrayOf(n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0])
            for ((a, b) in listOf(-1 to -1, 1 to -1, 1 to 1, -1 to -1, 1 to 1, -1 to 1)) {
                for (k in 0..2) v += n[k] * .5f + u[k] * .5f * a + w[k] * .5f * b
                for (k in 0..2) v += n[k]
                v += 1f; v += 1f; v += 1f
            }
        }
        val fb = ByteBuffer.allocateDirect(v.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(v.toFloatArray()); position(0) }
        return Mesh(fb, 36)
    }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        GLES20.glClearColor(SKY[0], SKY[1], SKY[2], 1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs = "uniform mat4 uMvp; uniform mat4 uRot; uniform float uFogS; uniform float uFogE; uniform float uFogK;" +
            "attribute vec3 aPos; attribute vec3 aNorm; attribute vec3 aCol; varying float vL; varying vec3 vC; varying float vF;" +
            "void main(){ vec3 n = normalize((uRot*vec4(aNorm,0.0)).xyz); vL = max(dot(n, normalize(vec3(.4,1.,.3))),0.0)*.7+.3; vC = aCol;" +
            "vec4 p = uMvp*vec4(aPos,1.0); gl_Position = p; vF = clamp((p.w-uFogS)/(uFogE-uFogS),0.0,1.0)*uFogK; }"
        val fs = "precision mediump float; uniform vec4 uCol; uniform float uFlash; uniform vec3 uFogC; varying float vL; varying vec3 vC; varying float vF;" +
            "void main(){ vec3 c = vC*uCol.rgb*vL; c = mix(c, uFogC, vF); gl_FragColor = vec4(mix(c, vec3(1.0), uFlash),1.0);}"
        prog = GLES20.glCreateProgram().also { GLES20.glAttachShader(it, shader(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(it, shader(GLES20.GL_FRAGMENT_SHADER, fs)); GLES20.glLinkProgram(it) }
        aPos = GLES20.glGetAttribLocation(prog, "aPos"); aNorm = GLES20.glGetAttribLocation(prog, "aNorm"); aCol = GLES20.glGetAttribLocation(prog, "aCol")
        uMvp = GLES20.glGetUniformLocation(prog, "uMvp"); uRot = GLES20.glGetUniformLocation(prog, "uRot")
        uCol = GLES20.glGetUniformLocation(prog, "uCol"); uFlash = GLES20.glGetUniformLocation(prog, "uFlash")
        uFogS = GLES20.glGetUniformLocation(prog, "uFogS"); uFogE = GLES20.glGetUniformLocation(prog, "uFogE")
        uFogK = GLES20.glGetUniformLocation(prog, "uFogK"); uFogC = GLES20.glGetUniformLocation(prog, "uFogC")
        cube = buildCube(); drone = MeshIO.load(ctx, "enemy-flying")
        weapons = listOf(MeshIO.load(ctx, "blaster-repeater"), MeshIO.load(ctx, "blaster"))
        propMesh = arrayOf(MeshIO.load(ctx, "wall-high"), MeshIO.load(ctx, "wall-low"), MeshIO.load(ctx, "grass"), MeshIO.load(ctx, "grass-small"), MeshIO.load(ctx, "cloud"), cube)
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        val asp = w.toFloat() / h
        Matrix.perspectiveM(proj, 0, 65f, asp, .4f, gfx.viewDist + 60f)
        Matrix.perspectiveM(gunProj, 0, 65f, asp, .05f, 10f)
        tanH = tan(Math.toRadians(32.5)).toFloat() * asp + .15f
    }

    private fun place(x: Float, y: Float, z: Float, yaw: Float, sx: Float, sy: Float, sz: Float) {
        Matrix.setIdentityM(ent, 0); Matrix.translateM(ent, 0, x, y, z); Matrix.rotateM(ent, 0, yaw, 0f, 1f, 0f); Matrix.scaleM(ent, 0, sx, sy, sz)
        Matrix.setIdentityM(rot, 0); Matrix.rotateM(rot, 0, yaw, 0f, 1f, 0f)
    }

    private fun draw(mesh: Mesh, model: FloatArray, vpm: FloatArray, r: Float, gg: Float, b: Float, flash: Float) {
        Matrix.multiplyMM(mvp, 0, vpm, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0); GLES20.glUniformMatrix4fv(uRot, 1, false, rot, 0)
        GLES20.glUniform4f(uCol, r, gg, b, 1f); GLES20.glUniform1f(uFlash, flash)
        mesh.buf.position(0); GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 36, mesh.buf); GLES20.glEnableVertexAttribArray(aPos)
        mesh.buf.position(3); GLES20.glVertexAttribPointer(aNorm, 3, GLES20.GL_FLOAT, false, 36, mesh.buf); GLES20.glEnableVertexAttribArray(aNorm)
        mesh.buf.position(6); GLES20.glVertexAttribPointer(aCol, 3, GLES20.GL_FLOAT, false, 36, mesh.buf); GLES20.glEnableVertexAttribArray(aCol)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, mesh.count)
    }

    private fun drawPartsM(list: List<Part>, base: FloatArray, vpm: FloatArray, flash: Float, tint: FloatArray?) {
        for (p in list) {
            System.arraycopy(base, 0, m, 0, 16); Matrix.translateM(m, 0, p.ox, p.oy, p.oz); Matrix.scaleM(m, 0, p.sx, p.sy, p.sz)
            if (tint == null) draw(cube, m, vpm, p.c[0], p.c[1], p.c[2], flash)
            else draw(cube, m, vpm, p.c[0] * tint[0], p.c[1] * tint[1], p.c[2] * tint[2], flash)
        }
    }

    private fun drawParts(list: List<Part>, x: Float, y: Float, z: Float, yaw: Float, flash: Float, tint: FloatArray?) {
        place(x, y, z, yaw, 1f, 1f, 1f); drawPartsM(list, ent, vp, flash, tint)
    }

    private fun fog(k: Float) { GLES20.glUniform1f(uFogK, k) }

    // ------------------------------------------------------------------ partikel
    private fun burst(x: Float, y: Float, z: Float, n: Int, speed: Float, r: Float, gg: Float, b: Float, size: Float, life: Float) {
        for (i in 0 until n) {
            if (parts.size > 260) return
            val a = Random.nextFloat() * 6.283f; val e = Random.nextFloat() * 1.4f - .2f; val s = speed * (.4f + Random.nextFloat() * .8f)
            parts += Particle(x, y, z, cos(a) * s, e * s + speed * .3f, sin(a) * s, life * (.6f + Random.nextFloat() * .6f), life, size * (.6f + Random.nextFloat() * .8f),
                (r + Random.nextFloat() * .15f).coerceAtMost(1f), gg, b)
        }
    }

    private fun updateParticles(dt: Float) {
        var i = parts.size - 1
        while (i >= 0) {
            val p = parts[i]; p.life -= dt
            if (p.life <= 0f) { parts.removeAt(i); i--; continue }
            p.vy -= 9f * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt
            if (p.y < .03f) { p.y = .03f; p.vy = -p.vy * .3f; p.vx *= .6f; p.vz *= .6f }
            i--
        }
    }

    // ------------------------------------------------------------------ suara & efek dari event
    private fun handleEvents(dt: Float) {
        evL.clear(); g.drainEvents(evL)
        val me = g.me
        for (ev in evL) {
            when (ev.type) {
                Ev.SHOT -> {
                    val w = ev.a.toInt()
                    if (ev.pid == g.myId) {
                        if (w == 0) sfx.playVar("rifle_shot", 3, 1f) else { sfx.playVar("shotgun_shot", 2, 1f); pumpT = .18f }
                    } else {
                        val nm = if (w == 0) "rifle_shot" + (1 + Random.nextInt(3)) else "shotgun_shot" + (1 + Random.nextInt(2))
                        sfx.playAt(nm, ev.x, ev.z, me.x, me.z, me.yaw, 1f, .97f + Random.nextFloat() * .06f)
                    }
                }
                Ev.HIT -> {
                    val head = ev.a > .5f
                    burst(ev.x, 1.5f, ev.z, if (head) 12 else 7, 3.5f, 1f, if (head) .9f else .65f, .2f, .09f, .35f)
                    if (ev.pid == g.myId) sfx.play(if (head) "hit_head" else "hit_metal", if (head) .9f else .75f, .95f + Random.nextFloat() * .1f)
                    else sfx.playAt("hit_metal", ev.x, ev.z, me.x, me.z, me.yaw, .8f)
                }
                Ev.KILL -> {
                    val big = ev.i == 2
                    burst(ev.x, 1.4f, ev.z, if (big) 90 else 36, if (big) 8f else 5f, 1f, .55f, .1f, if (big) .35f else .2f, if (big) 1.1f else .8f)
                    burst(ev.x, 1.4f, ev.z, if (big) 50 else 18, 3f, .25f, .25f, .27f, .22f, 1f)
                    sfx.playAt(if (big) "boss_die" else "drone_die", ev.x, ev.z, me.x, me.z, me.yaw, 1f, .95f + Random.nextFloat() * .1f)
                }
                Ev.HURT -> if (ev.pid == g.myId) sfx.play("player_hurt", 1f)
                Ev.DOWN -> if (ev.pid == g.myId) sfx.play("player_death", 1f)
                Ev.PICKUP -> if (ev.pid == g.myId) sfx.play(if (ev.i == 2) "pickup_health" else "pickup_ammo", .95f)
                Ev.ANNOUNCE -> when (ev.i) { 1 -> sfx.play("wave_start", .9f); 2, 3 -> sfx.play("spawn_alert", .9f); 5 -> sfx.play("pickup_health", .6f) }
                Ev.OVER -> sfx.play("game_over", 1f)
                Ev.DRY -> sfx.play("dry_click", .8f)
                Ev.RELOAD_SND -> when (ev.i) {
                    0 -> sfx.play("mag_out", .85f); 1 -> sfx.play("mag_in", .95f); 2 -> sfx.play("bolt", .95f)
                    3 -> sfx.play("shell_in", .85f, .94f + Random.nextFloat() * .12f); 4 -> sfx.play("pump", .95f)
                }
                Ev.STEP -> sfx.play("step" + (1 + Random.nextInt(3)), .5f, .92f + Random.nextFloat() * .16f)
                Ev.SWITCH -> sfx.play("weapon_switch", .8f)
                Ev.IMPACT -> burst(ev.x, ev.a, ev.z, 6, 2.5f, .55f, .5f, .4f, .07f, .45f)
            }
        }
        if (pumpT > 0f) { pumpT -= dt; if (pumpT <= 0f) sfx.play("pump", .85f) }
    }

    // ------------------------------------------------------------------ animasi senjata
    private fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
    private fun seg(t: Float, a: Float, b: Float) = smooth((t - a) / (b - a))

    private fun keyPos(t: Float, k: Array<FloatArray>, out: FloatArray) {
        if (t <= k[0][0]) { out[0] = k[0][1]; out[1] = k[0][2]; out[2] = k[0][3]; return }
        for (i in 1 until k.size) {
            if (t <= k[i][0]) {
                val a = k[i - 1]; val b = k[i]; val f = smooth((t - a[0]) / (b[0] - a[0]))
                out[0] = a[1] + (b[1] - a[1]) * f; out[1] = a[2] + (b[2] - a[2]) * f; out[2] = a[3] + (b[3] - a[3]) * f; return
            }
        }
        val l = k[k.size - 1]; out[0] = l[1]; out[1] = l[2]; out[2] = l[3]
    }

    private fun computePose() {
        val w = g.me.weapon
        gx = 0f; gy = 0f; gz = 0f; gPitch = 0f; gRoll = 0f; magY = -.075f; magVis = w == 0; shellVis = false
        lh[0] = REST[0]; lh[1] = REST[1]; lh[2] = REST[2]
        gx += sin(g.walkPhase) * .012f * g.walkAmt; gy += (abs(cos(g.walkPhase)) - .5f) * .014f * g.walkAmt
        gz += g.recoil * (if (w == 0) .045f else .11f); gPitch += g.recoil * (if (w == 0) 3.5f else 9f); gy += g.recoil * .01f
        if (g.switchT > 0f) { val p = g.switchT / .45f; gy -= .38f * p * p; gPitch -= 35f * p }
        if (g.reloading) {
            val t = g.rt
            if (w == 0) {
                val up = seg(t, 0f, .3f) - seg(t, 1.75f, 2.2f)
                gy += .11f * up; gx -= .11f * up; gRoll += 24f * up; gPitch += 10f * up
                val drop = seg(t, .30f, .66f)
                magVis = t < .66f || t > .72f
                magY = if (t < .7f) -.075f - drop * 1.0f else -.075f - (1f - seg(t, .72f, 1.2f)) * .5f
                val kick = seg(t, 1.15f, 1.22f) - seg(t, 1.22f, 1.34f); gz += .035f * kick; gPitch += 3f * kick
                keyPos(t, RIFLE_KEYS, lh)
            } else {
                val tot = g.rTotal; val up = seg(t, 0f, .3f) - seg(t, tot - .3f, tot)
                gy += .10f * up; gx -= .08f * up; gRoll -= 26f * up; gPitch += 12f * up
                val n = g.rSteps.size - 1
                val tLast = if (n >= 0) g.rSteps[n].t - .04f else .4f
                if (t < .38f) {
                    val s = seg(t, 0f, .38f)
                    lh[0] = REST[0] * (1f - s) + .02f * s; lh[1] = REST[1] * (1f - s) + -.10f * s; lh[2] = REST[2] * (1f - s) + -.04f * s
                } else if (t < tLast) {
                    val u = ((t - .38f) / .32f) % 1f; val s = sin(PIF * u)
                    lh[0] = .02f; lh[1] = -.10f - .38f * s; lh[2] = -.04f - .08f * s; shellVis = u > .35f
                } else {
                    val v = (t - tLast - .04f) / .35f
                    lh[2] = REST[2] + (if (v in 0f..1f) .12f * sin(PIF * v) else 0f)
                    val back = seg(t, tLast, tLast + .1f)
                    lh[0] = .02f * (1f - back) + REST[0] * back; lh[1] = -.10f * (1f - back) + REST[1] * back
                }
            }
        } else if (w == 1 && g.cd > 0f) {
            val e = Game.CD[1] - g.cd           // gerak pump setelah menembak
            if (e in .15f..0.55f) { val v = (e - .15f) / .4f; lh[2] = REST[2] + .12f * sin(PIF * v); gz += .01f * sin(PIF * v) }
        }
    }

    private fun drawGun() {
        computePose()
        val w = g.me.weapon
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT); fog(0f)
        Matrix.setIdentityM(gm0, 0); Matrix.translateM(gm0, 0, BX + gx, BY + gy, BZ + gz)
        Matrix.rotateM(gm0, 0, gRoll, 0f, 0f, 1f); Matrix.rotateM(gm0, 0, gPitch, 1f, 0f, 0f)
        // senjata (model menghadap +Z -> putar 180 derajat supaya laras mengarah ke depan)
        System.arraycopy(gm0, 0, gm, 0, 16); Matrix.rotateM(gm, 0, 180f, 0f, 1f, 0f)
        Matrix.setIdentityM(rot, 0); Matrix.rotateM(rot, 0, gRoll, 0f, 0f, 1f); Matrix.rotateM(rot, 0, gPitch, 1f, 0f, 0f); Matrix.rotateM(rot, 0, 180f, 0f, 1f, 0f)
        System.arraycopy(gm, 0, ent, 0, 16); Matrix.scaleM(ent, 0, GS, GS, GS)
        draw(weapons[w], ent, gunProj, 1f, 1f, 1f, 0f)
        // bagian lain memakai rotasi tanpa putaran 180
        Matrix.setIdentityM(rot, 0); Matrix.rotateM(rot, 0, gRoll, 0f, 0f, 1f); Matrix.rotateM(rot, 0, gPitch, 1f, 0f, 0f)
        // magasin Repeater
        if (w == 0 && magVis) { System.arraycopy(gm0, 0, ent, 0, 16); Matrix.translateM(ent, 0, 0f, magY, -.06f); drawPartsM(Models.mag, ent, gunProj, 0f, null) }
        // tangan kanan (pegang grip)
        System.arraycopy(gm0, 0, ent, 0, 16); Matrix.translateM(ent, 0, 0f, -.03f, .03f); drawPartsM(Models.hand, ent, gunProj, 0f, null)
        // tangan kiri (+ peluru shotgun di genggaman)
        System.arraycopy(gm0, 0, ent, 0, 16); Matrix.translateM(ent, 0, lh[0], lh[1], lh[2])
        drawPartsM(Models.hand, ent, gunProj, 0f, null)
        if (shellVis) { Matrix.translateM(ent, 0, 0f, .05f, -.06f); drawPartsM(Models.shellBit, ent, gunProj, 0f, null) }
        // kilatan moncong
        if (g.muzzle > 0f && !g.reloading) {
            val mz = MUZZLE[w]; System.arraycopy(gm, 0, ent, 0, 16)
            Matrix.translateM(ent, 0, mz[0] * GS, mz[1] * GS, mz[2] * GS + .02f)
            Matrix.rotateM(ent, 0, Random.nextFloat() * 360f, 0f, 0f, 1f)
            val s = if (w == 0) 1f else 1.7f; Matrix.scaleM(ent, 0, s, s, s)
            drawPartsM(Models.flash, ent, gunProj, .9f, null)
        }
    }

    // ------------------------------------------------------------------ frame
    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime(); val dt = ((now - last) / 1e9f).coerceAtMost(.05f); last = now
        clock += dt
        g.update(dt)
        handleEvents(dt)
        updateParticles(dt)
        g.copyWorld(enemiesL, pickupsL, playersL)
        val me = g.me

        // suara latar: dengung drone terdekat & detak jantung
        var nd = 999f; var pan = 0f
        val yr = Math.toRadians(me.yaw.toDouble()).toFloat()
        for (e in enemiesL) {
            if (e.type == 3) continue
            val dx = e.x - me.x; val dz = e.z - me.z; val d = hypot(dx, dz)
            if (d < nd) { nd = d; pan = if (d > .5f) (dx * cos(yr) + dz * sin(yr)) / d else 0f }
        }
        sfx.tick(dt, me.hp, me.alive, nd, pan)

        // ---- kamera
        val d = g.dir(me.yaw, if (me.alive) me.pitch else -25f)
        val bob = if (me.alive) sin(g.walkPhase * 2f) * .035f * g.walkAmt else 0f
        val ey = if (me.alive) 1.6f + bob else .45f
        val cx = me.x; val cz = me.z
        Matrix.setLookAtM(view, 0, cx, ey, cz, cx + d[0], ey + d[1], cz + d[2], 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        val fx = sin(yr); val fz = -cos(yr); val rx = cos(yr); val rz = sin(yr)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        val vd = gfx.viewDist
        GLES20.glUniform1f(uFogS, vd * .45f); GLES20.glUniform1f(uFogE, vd * .98f); GLES20.glUniform3f(uFogC, SKY[0], SKY[1], SKY[2]); fog(1f)

        // ---- tanah
        place(0f, -.1f, 0f, 0f, World.HALF * 2f + 220f, .2f, World.HALF * 2f + 220f); draw(cube, ent, vp, .27f, .37f, .24f, 0f)

        // ---- tempelan datar (jalan, plaza), bayangan blob, cincin item: tanpa depth test supaya tidak berkedip
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        for (dc in World.decals) {
            if (abs(dc.x - cx) > vd + dc.w * .5f || abs(dc.z - cz) > vd + dc.d * .5f) continue
            place(dc.x, .01f, dc.z, 0f, dc.w, .02f, dc.d); draw(cube, ent, vp, dc.c[0], dc.c[1], dc.c[2], 0f)
        }
        for (e in enemiesL) {
            val s = Game.R[e.type] * 1.5f * (1f - e.lift * .1f).coerceAtLeast(.4f)
            place(e.x, .02f, e.z, 0f, s, .02f, s); draw(cube, ent, vp, .13f, .2f, .11f, 0f)
        }
        for (p in playersL) { if (p.id == g.myId || !p.alive) continue; place(p.x, .02f, p.z, 0f, 1.1f, .02f, 1.1f); draw(cube, ent, vp, .13f, .2f, .11f, 0f) }
        for (k in pickupsL) {
            val pulse = 1f + .15f * sin(clock * 4f + k.id)
            val gc = Models.pickupGlow[k.type]
            place(k.x, .03f, k.z, clock * 30f, 1.7f * pulse, .02f, 1.7f * pulse); draw(cube, ent, vp, gc[0], gc[1], gc[2], 0f)
        }
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)

        // ---- tembok, peti, rumput, awan (dengan culling jarak & sudut pandang)
        val grassD = floatArrayOf(0f, 38f, 62f)[gfx.quality]
        val props = World.props
        for (i in 0 until props.size) {
            val p = props[i]
            val grass = p.kind == World.K_GRASS || p.kind == World.K_GRASS_S
            val cloud = p.kind == World.K_CLOUD
            if ((grass || cloud) && !gfx.decor) continue
            val dx = p.x - cx; val dz = p.z - cz
            val lim = if (cloud) 230f else if (grass) grassD else vd + p.rad
            if (dx * dx + dz * dz > lim * lim) continue
            val along = dx * fx + dz * fz
            if (along < -p.rad - 1f) continue
            if (!cloud && abs(dx * rx + dz * rz) - p.rad > (along + p.rad) * tanH) continue
            fog(if (cloud) 0f else 1f)
            place(p.x, p.y, p.z, p.yaw, p.sx, p.sy, p.sz); draw(propMesh[p.kind], ent, vp, p.c[0], p.c[1], p.c[2], 0f)
        }
        fog(1f)

        // ---- item di peta (berputar & melayang)
        for (k in pickupsL) {
            val dx = k.x - cx; val dz = k.z - cz
            if (dx * dx + dz * dz > vd * vd) continue
            val model = when (k.type) { 0 -> Models.ammoRifle; 1 -> Models.ammoShell; else -> Models.health }
            drawParts(model, k.x, .35f + sin(clock * 2.5f + k.id) * .12f, k.z, clock * 60f + k.id * 40f, 0f, null)
        }

        // ---- musuh
        for (e in enemiesL) {
            val yaw = Math.toDegrees(Math.atan2((cx - e.x).toDouble(), (cz - e.z).toDouble())).toFloat()
            if (e.type == 3) { drawParts(Models.target, e.x, 0f, e.z, yaw, e.flash * 10f, null); continue }
            val b = sin(e.bob) * .15f; val s = Models.scale[e.type]; val t = Models.tint[e.type]
            place(e.x, Game.Y0[e.type] + b + e.lift, e.z, yaw, s, s, s); draw(drone, ent, vp, t[0], t[1], t[2], if (e.flash > 0f) 1f else 0f)
        }

        // ---- pemain lain (mabar)
        for (p in playersL) {
            if (p.id == g.myId || !p.alive) continue
            val tint = Models.playerTint[p.id % Models.playerTint.size]
            val sway = sin(p.walk * 1.2f) * .05f
            drawParts(Models.player, p.x, abs(sway) * .3f, p.z, 180f - p.yaw, if (p.flash > 0f) .35f else 0f, tint)
        }

        // ---- partikel
        for (p in parts) {
            val k = (p.life / p.maxLife).coerceIn(0f, 1f); val s = p.size * (.3f + .7f * k)
            place(p.x, p.y, p.z, 0f, s, s, s); draw(cube, ent, vp, p.r, p.gg, p.b, if (k > .7f) .4f else 0f)
        }

        // ---- senjata orang pertama
        if (me.alive) drawGun()

        frames++; fpsT += dt; if (fpsT >= 1f) { Perf.fps = frames; frames = 0; fpsT = 0f }
        if (g.over && !ended) { ended = true; onOver() }
        if (gfx.fpsCap > 0) { val left = (1_000_000_000L / gfx.fpsCap - (System.nanoTime() - now)) / 1_000_000L; if (left > 0) Thread.sleep(left) }
    }
}
