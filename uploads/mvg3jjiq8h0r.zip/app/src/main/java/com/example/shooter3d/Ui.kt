package com.example.shooter3d
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.TextView

/** Helper tampilan sederhana (tombol bulat & label) supaya menu seragam. */
object Ui {
    fun button(c: Context, text: String, color: Int = 0xFF2A6FDB.toInt(), onClick: () -> Unit): Button = Button(c).apply {
        this.text = text; setTextColor(Color.WHITE); textSize = 16f; isAllCaps = false
        background = GradientDrawable().apply { setColor(color); cornerRadius = 28f }
        setPadding(40, 22, 40, 22)
        setOnClickListener { onClick() }
    }
    fun label(c: Context, text: String, size: Float = 16f, color: Int = Color.WHITE): TextView = TextView(c).apply {
        this.text = text; textSize = size; setTextColor(color); setPadding(0, 14, 0, 6)
    }
}
