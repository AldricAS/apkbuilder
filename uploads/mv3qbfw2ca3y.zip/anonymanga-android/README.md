# AnonyManga — Proyek Android (Capacitor)

## Yang dibutuhkan
- Node.js 18+ dan Android Studio (dengan JDK 17+ & Android SDK)

## Cara build APK
```bash
npm install
npx cap add android        # sekali saja, membuat folder android/
npx cap sync android
npx cap open android       # buka di Android Studio
```
Di Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Atau lewat terminal: `cd android && ./gradlew assembleDebug`
→ hasil: `android/app/build/outputs/apk/debug/app-debug.apk`

Kalau mengubah `www/index.html`, jalankan lagi `npx cap sync android`.

## Impor / Ekspor data
- **Ekspor**: file backup disimpan ke `Documents/AnonyManga/`, lalu muncul menu bagikan
  (bisa disimpan ke Google Drive, Files, WhatsApp, dll).
- **Impor**: tombol Impor membuka pemilih file Android, pilih file `.json` backup.
- Data (riwayat, bookmark, pengaturan) tersimpan di perangkat dan tetap ada setelah aplikasi ditutup.

## Catatan
- `CapacitorHttp` aktif, jadi permintaan ke server komik lewat jalur native (tidak kena blokir CORS) —
  biasanya proxy tidak diperlukan lagi di APK.
