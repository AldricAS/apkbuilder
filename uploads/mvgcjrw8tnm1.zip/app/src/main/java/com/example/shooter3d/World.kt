package com.example.shooter3d
import kotlin.math.*
import kotlin.random.Random

/** Penghalang sumbu-sejajar (AABB) di bidang XZ, tinggi h dari tanah. Dipakai untuk tabrakan pemain/drone & peluru. */
class Box(val x0: Float, val z0: Float, val x1: Float, val z1: Float, val h: Float)

/** Benda yang digambar. kind: lihat World.K_*. rad = radius kasar untuk culling. c = warna (kalikan) untuk kotak. */
class Prop(val kind: Int, val x: Float, val y: Float, val z: Float, val yaw: Float,
           val sx: Float, val sy: Float, val sz: Float, val rad: Float, val c: FloatArray)

/** Tempelan warna datar di tanah (jalan, plaza, petak rumput). */
class Decal(val x: Float, val z: Float, val w: Float, val d: Float, val c: FloatArray)

/**
 * Peta 200 x 200 m (jauh lebih luas dari versi lama yang radiusnya ~38 m).
 * Dibangun deterministik dari seed tetap, jadi HP host & HP teman membuat peta yang sama persis (mabar LAN).
 * Isi: tembok keliling, 6 bangunan berpintu, deretan tembok rendah (cover), halaman peti, plaza tengah, jalan, rumput, awan.
 */
object World {
    const val HALF = 100f
    const val K_WALLH = 0; const val K_WALLL = 1; const val K_GRASS = 2; const val K_GRASS_S = 3; const val K_CLOUD = 4; const val K_CRATE = 5

    val boxes = ArrayList<Box>()
    val props = ArrayList<Prop>()
    val decals = ArrayList<Decal>()
    /** Kandidat titik munculnya item (x, z). */
    val spots = ArrayList<FloatArray>()
    /** Titik awal pemain (x, z). */
    val spawns = ArrayList<FloatArray>()
    private var built = false
    private val WHITE = floatArrayOf(1f, 1f, 1f)
    private val WOOD = floatArrayOf(.66f, .47f, .26f)
    private val WOOD2 = floatArrayOf(.52f, .37f, .21f)
    private val MIL = floatArrayOf(.36f, .44f, .3f)
    private val METAL = floatArrayOf(.55f, .58f, .62f)

    @Synchronized fun build() {
        if (built) return
        built = true
        val rnd = Random(20261019)

        // ---- tembok keliling (tinggi 6 m, tebal 2 m)
        val e = HALF + 1f
        wall(-e, -HALF, e, -HALF, 2f, 6f, false); wall(-e, HALF, e, HALF, 2f, 6f, false)
        wall(-HALF, -e + 2f, -HALF, e - 2f, 2f, 6f, false); wall(HALF, -e + 2f, HALF, e - 2f, 2f, 6f, false)

        // ---- 16 sel @ 50 m. 12 sel luar: bangunan / deretan cover / halaman peti. 4 sel tengah: plaza terbuka.
        val types = ArrayList<Int>(); repeat(6) { types += 0 }; repeat(3) { types += 1 }; repeat(3) { types += 2 }
        types.shuffle(rnd)
        var k = 0
        for (i in 0 until 4) for (j in 0 until 4) {
            val cx = -75f + i * 50f; val cz = -75f + j * 50f
            if (abs(cx) < 30f && abs(cz) < 30f) { plaza(cx, cz, rnd); continue }
            when (types[k++]) {
                0 -> building(cx + rnd.nextFloat() * 8f - 4f, cz + rnd.nextFloat() * 8f - 4f, 18f + rnd.nextFloat() * 8f, 16f + rnd.nextFloat() * 8f, rnd)
                1 -> coverLines(cx, cz, rnd)
                else -> crateYard(cx, cz, rnd)
            }
        }

        // ---- titik muncul pemain (area tengah dikosongkan radius 9 m)
        spawns += floatArrayOf(0f, 4f); spawns += floatArrayOf(4f, 0f); spawns += floatArrayOf(-4f, 0f); spawns += floatArrayOf(0f, -4f)

        // ---- jalan & plaza & petak tanah (tempelan datar)
        repeat(16) {
            val g = rnd.nextBoolean()
            decals += Decal(rnd.nextFloat() * 180f - 90f, rnd.nextFloat() * 180f - 90f, 10f + rnd.nextFloat() * 22f, 10f + rnd.nextFloat() * 22f,
                if (g) floatArrayOf(.25f, .32f, .19f) else floatArrayOf(.4f, .38f, .26f))
        }
        decals += Decal(0f, 0f, 7f, HALF * 2f, floatArrayOf(.48f, .42f, .33f)); decals += Decal(0f, 0f, HALF * 2f, 7f, floatArrayOf(.48f, .42f, .33f))
        decals += Decal(0f, 0f, 26f, 26f, floatArrayOf(.58f, .57f, .54f))

        // ---- titik item: sebar di area terbuka (tidak di dalam/dekat penghalang)
        var tries = 0
        while (spots.size < 90 && tries < 4000) {
            tries++
            val x = rnd.nextFloat() * (HALF * 2 - 16f) - (HALF - 8f); val z = rnd.nextFloat() * (HALF * 2 - 16f) - (HALF - 8f)
            if (hypot(x, z) < 9f || blocked(x, z, 1.6f)) continue
            spots += floatArrayOf(x, z)
        }

        // ---- dekorasi: rumput & awan (digambar hanya jika kualitas grafis > Rendah)
        var g = 0
        while (g < 700) {
            val x = rnd.nextFloat() * (HALF * 2 - 4f) - (HALF - 2f); val z = rnd.nextFloat() * (HALF * 2 - 4f) - (HALF - 2f)
            if (blocked(x, z, 1f)) continue
            val small = g % 2 == 1
            props += Prop(if (small) K_GRASS_S else K_GRASS, x, 0f, z, rnd.nextFloat() * 360f, 2.5f, 2.5f, 2.5f, 1.2f, WHITE); g++
        }
        repeat(14) {
            props += Prop(K_CLOUD, rnd.nextFloat() * 300f - 150f, 32f + rnd.nextFloat() * 14f, rnd.nextFloat() * 300f - 150f, 0f, 16f, 14f, 16f, 18f, WHITE)
        }
    }

    // ------------------------------------------------------------------ pembangun
    /** Garis tembok lurus (sejajar sumbu X atau Z) dari (x0,z0) ke (x1,z1), dipasang dari tile model Kenney yang diskalakan. */
    private fun wall(x0: Float, z0: Float, x1: Float, z1: Float, thick: Float, height: Float, low: Boolean) {
        val alongX = abs(x1 - x0) >= abs(z1 - z0)
        val len = if (alongX) abs(x1 - x0) else abs(z1 - z0)
        if (len < 0.5f) return
        val meshLen = if (low) 2.2f else 1.5f; val meshH = if (low) .8f else 1.7f
        val n = max(1, (len / 4.5f).roundToInt())
        val tile = len / n
        val sL = tile / meshLen; val sH = height / meshH; val sT = thick / .7f
        val minX = min(x0, x1); val minZ = min(z0, z1)
        for (i in 0 until n) {
            val off = (i + .5f) * tile
            val px = if (alongX) minX + off else (x0 + x1) / 2f
            val pz = if (alongX) (z0 + z1) / 2f else minZ + off
            props += Prop(if (low) K_WALLL else K_WALLH, px, 0f, pz, if (alongX) 0f else 90f, sL, sH, sT, tile / 2f + thick, WHITE)
        }
        if (alongX) boxes += Box(minX, (z0 + z1) / 2f - thick / 2f, max(x0, x1), (z0 + z1) / 2f + thick / 2f, height)
        else boxes += Box((x0 + x1) / 2f - thick / 2f, minZ, (x0 + x1) / 2f + thick / 2f, max(z0, z1), height)
    }

    /** Tembok dengan celah pintu selebar 6 m. gapAt = posisi tengah celah di sepanjang garis; <0 berarti tanpa pintu. */
    private fun wallDoor(x0: Float, z0: Float, x1: Float, z1: Float, thick: Float, height: Float, gapAt: Float) {
        val alongX = abs(x1 - x0) >= abs(z1 - z0)
        if (gapAt < 0f) { wall(x0, z0, x1, z1, thick, height, false); return }
        if (alongX) { wall(x0, z0, gapAt - 3f, z1, thick, height, false); wall(gapAt + 3f, z0, x1, z1, thick, height, false) }
        else { wall(x0, z0, x1, gapAt - 3f, thick, height, false); wall(x0, gapAt + 3f, x1, z1, thick, height, false) }
    }

    private fun crate(x: Float, z: Float, s: Float, c: FloatArray, levels: Int = 1) {
        for (l in 0 until levels) props += Prop(K_CRATE, x, l * s + s / 2f, z, 0f, s, s, s, s, c)
        boxes += Box(x - s / 2f, z - s / 2f, x + s / 2f, z + s / 2f, s * levels)
    }

    private fun building(cx: Float, cz: Float, w: Float, d: Float, rnd: Random) {
        val x0 = cx - w / 2f; val x1 = cx + w / 2f; val z0 = cz - d / 2f; val z1 = cz + d / 2f; val t = 1f; val h = 3.8f
        // 4 sisi; minimal 2 sisi berpintu. Posisi celah acak tapi tidak menempel sudut.
        val doors = BooleanArray(4) { false }
        val first = rnd.nextInt(4); doors[first] = true; doors[(first + 2) % 4] = true; if (rnd.nextBoolean()) doors[(first + 1) % 4] = true
        fun gx() = x0 + 7f + rnd.nextFloat() * (w - 14f)
        fun gz() = z0 + 7f + rnd.nextFloat() * (d - 14f)
        wallDoor(x0 - t / 2f, z0, x1 + t / 2f, z0, t, h, if (doors[0]) gx() else -1f)
        wallDoor(x0 - t / 2f, z1, x1 + t / 2f, z1, t, h, if (doors[2]) gx() else -1f)
        wallDoor(x0, z0 + t / 2f, x0, z1 - t / 2f, t, h, if (doors[3]) gz() else -1f)
        wallDoor(x1, z0 + t / 2f, x1, z1 - t / 2f, t, h, if (doors[1]) gz() else -1f)
        // isi: peti & sekat rendah
        crate(x0 + 3f, z0 + 3f, 1.6f, WOOD, 2); crate(x1 - 3.5f, z1 - 3f, 1.8f, MIL)
        if (rnd.nextBoolean()) wall(cx - 3f, cz, cx + 3f, cz, .8f, 1.3f, true)
        crate(x1 - 2.6f, z0 + 2.6f, 1.4f, WOOD2)
        // titik item di dalam bangunan
        spots += floatArrayOf(cx + 2f, cz + 3f); spots += floatArrayOf(x0 + 3f, z1 - 3f); spots += floatArrayOf(x1 - 4.5f, cz - 2f)
    }

    private fun coverLines(cx: Float, cz: Float, rnd: Random) {
        repeat(5) {
            val x = cx + rnd.nextFloat() * 34f - 17f; val z = cz + rnd.nextFloat() * 34f - 17f; val len = 6f + rnd.nextFloat() * 8f
            if (rnd.nextBoolean()) wall(x - len / 2f, z, x + len / 2f, z, .8f, 1.3f, true) else wall(x, z - len / 2f, x, z + len / 2f, .8f, 1.3f, true)
        }
        repeat(3) { crate(cx + rnd.nextFloat() * 36f - 18f, cz + rnd.nextFloat() * 36f - 18f, 1.5f + rnd.nextFloat(), if (it == 1) MIL else WOOD) }
    }

    private fun crateYard(cx: Float, cz: Float, rnd: Random) {
        repeat(9) {
            val s = 1.4f + rnd.nextFloat() * 1.2f
            crate(cx + rnd.nextFloat() * 38f - 19f, cz + rnd.nextFloat() * 38f - 19f, s, when (it % 3) { 0 -> WOOD; 1 -> MIL; else -> METAL }, if (it % 4 == 0) 2 else 1)
        }
        wall(cx - 9f, cz + 14f, cx + 9f, cz + 14f, 1f, 3f, false)
    }

    private fun plaza(cx: Float, cz: Float, rnd: Random) {
        // beberapa cover di sekeliling titik tengah, area radius 9 m dari (0,0) tetap kosong
        repeat(3) {
            var x: Float; var z: Float; var tries = 0
            do { x = cx + rnd.nextFloat() * 36f - 18f; z = cz + rnd.nextFloat() * 36f - 18f; tries++ } while (hypot(x, z) < 15f && tries < 30)
            val len = 5f + rnd.nextFloat() * 5f
            if (rnd.nextBoolean()) wall(x - len / 2f, z, x + len / 2f, z, .8f, 1.3f, true) else wall(x, z - len / 2f, x, z + len / 2f, .8f, 1.3f, true)
        }
        repeat(2) {
            var x: Float; var z: Float; var tries = 0
            do { x = cx + rnd.nextFloat() * 36f - 18f; z = cz + rnd.nextFloat() * 36f - 18f; tries++ } while (hypot(x, z) < 15f && tries < 30)
            crate(x, z, 1.6f, if (it == 0) WOOD else METAL, 1)
        }
    }

    // ------------------------------------------------------------------ tabrakan & sinar
    /** Apakah titik (x,z) berada dalam jarak r dari suatu penghalang. */
    fun blocked(x: Float, z: Float, r: Float): Boolean {
        for (i in 0 until boxes.size) {
            val b = boxes[i]
            val dx = x - x.coerceIn(b.x0, b.x1); val dz = z - z.coerceIn(b.z0, b.z1)
            if (dx * dx + dz * dz < r * r) return true
        }
        return false
    }

    /** Apakah titik berada di atas penghalang yang lebih tinggi dari minH (drone terbang naik melewati tembok tinggi). */
    fun overTall(x: Float, z: Float, margin: Float, minH: Float): Boolean {
        for (i in 0 until boxes.size) {
            val b = boxes[i]
            if (b.h <= minH) continue
            if (x > b.x0 - margin && x < b.x1 + margin && z > b.z0 - margin && z < b.z1 + margin) return true
        }
        return false
    }

    /** Dorong lingkaran (px,pz,r) keluar dari semua penghalang yang lebih tinggi dari minH. Hasil di out[0], out[1]. */
    fun push(px: Float, pz: Float, r: Float, minH: Float, out: FloatArray) {
        var x = px; var z = pz
        for (pass in 0 until 2) {
            for (i in 0 until boxes.size) {
                val b = boxes[i]
                if (b.h <= minH) continue
                val dx = x - x.coerceIn(b.x0, b.x1); val dz = z - z.coerceIn(b.z0, b.z1)
                val d2 = dx * dx + dz * dz
                if (d2 >= r * r) continue
                if (d2 > 1e-6f) {
                    val d = sqrt(d2); val f = (r - d) / d; x += dx * f; z += dz * f
                } else {
                    val l = x - b.x0; val rr = b.x1 - x; val tp = z - b.z0; val bt = b.z1 - z
                    val m = min(min(l, rr), min(tp, bt))
                    if (m == l) x = b.x0 - r else if (m == rr) x = b.x1 + r else if (m == tp) z = b.z0 - r else z = b.z1 + r
                }
            }
        }
        out[0] = x.coerceIn(-HALF + 1.2f, HALF - 1.2f); out[1] = z.coerceIn(-HALF + 1.2f, HALF - 1.2f)
    }

    /** Jarak sinar (ox,oy,oz)+t*(dx,dy,dz) sampai kena penghalang pertama, atau maxT bila tidak kena (peluru tertahan tembok). */
    fun rayBlock(ox: Float, oy: Float, oz: Float, dx: Float, dy: Float, dz: Float, maxT: Float): Float {
        var best = maxT
        for (i in 0 until boxes.size) {
            val b = boxes[i]
            var t0 = 0f; var t1 = best
            if (abs(dx) < 1e-6f) { if (ox < b.x0 || ox > b.x1) continue }
            else {
                var a = (b.x0 - ox) / dx; var c = (b.x1 - ox) / dx
                if (a > c) { val s = a; a = c; c = s }
                if (a > t0) t0 = a; if (c < t1) t1 = c
                if (t0 > t1) continue
            }
            if (abs(dy) < 1e-6f) { if (oy < 0f || oy > b.h) continue }
            else {
                var a = (0f - oy) / dy; var c = (b.h - oy) / dy
                if (a > c) { val s = a; a = c; c = s }
                if (a > t0) t0 = a; if (c < t1) t1 = c
                if (t0 > t1) continue
            }
            if (abs(dz) < 1e-6f) { if (oz < b.z0 || oz > b.z1) continue }
            else {
                var a = (b.z0 - oz) / dz; var c = (b.z1 - oz) / dz
                if (a > c) { val s = a; a = c; c = s }
                if (a > t0) t0 = a; if (c < t1) t1 = c
                if (t0 > t1) continue
            }
            best = t0
        }
        return best
    }
}
