#!/usr/bin/env python3
"""
Generator model 3D realistis (pengganti model blocky Kenney).
Menulis berkas .mesh ke app/src/main/assets/models/ : int32 jumlah vertex, lalu per vertex pos(3) normal(3) warna(3) float32 LE.
Jalankan:  python3 tools/gen_models.py
Model:
  rifle.mesh        - senapan serbu gaya M4A1 (stok teleskopik, rail, red-dot, handguard M-LOK, flash hider)
  shotgun.mesh      - shotgun pump-action gaya Remington 870 (stok & forend kayu walnut, tabung magasin)
  wall-high.mesh    - tembok beton pracetak (T-wall) dengan tepi bevel & sambungan
  wall-low.mesh     - barikade karung pasir (3 lapis, susun bata)
  grass.mesh / grass-small.mesh - rumpun rumput dari helai tipis (warna bergradasi)
  cloud.mesh        - awan dari gumpalan bulat halus
  crate.mesh        - peti kayu dengan rangka & papan
  rbox.mesh         - kotak membulat halus (badan/anggota tubuh karakter)
  sphere.mesh       - bola halus (kepala, helm)
  cyl.mesh          - silinder halus (lengan bawah, laras)
"""
import math, random, struct, os

OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "models")

def C(r, g, b): return (r / 255.0, g / 255.0, b / 255.0)

class M:
    def __init__(s): s.v = []
    def tri(s, a, b, c, na, nb, nc, col):
        for p, n in ((a, na), (b, nb), (c, nc)): s.v.append((p, n, col))
    def save(s, name):
        with open(os.path.join(OUT, name + ".mesh"), "wb") as f:
            f.write(struct.pack("<i", len(s.v)))
            for p, n, c in s.v: f.write(struct.pack("<9f", *p, *n, *c))
        print(name, len(s.v))

def norm(v):
    l = math.sqrt(sum(x * x for x in v)) or 1.0
    return tuple(x / l for x in v)
def add(a, b): return tuple(x + y for x, y in zip(a, b))
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def mul(a, k): return tuple(x * k for x in a)
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def rotx(p, a):
    c, s = math.cos(a), math.sin(a); return (p[0], p[1]*c - p[2]*s, p[1]*s + p[2]*c)
def roty(p, a):
    c, s = math.cos(a), math.sin(a); return (p[0]*c + p[2]*s, p[1], -p[0]*s + p[2]*c)

def superq(m, center, size, e, col, seg=14, rx=0.0, ry=0.0, colfn=None):
    """Superellipsoid: e kecil (0.2) = kotak membulat, e=1 = elips. Normal dihitung dari gradien implisit."""
    hx, hy, hz = size[0]/2, size[1]/2, size[2]/2
    def sgnpow(x, p): return math.copysign(abs(x) ** p, x)
    def pt(u, v):
        cu, su = math.cos(u), math.sin(u); cv, sv = math.cos(v), math.sin(v)
        x = hx * sgnpow(cv, e) * sgnpow(cu, e); y = hy * sgnpow(sv, e); z = hz * sgnpow(cv, e) * sgnpow(su, e)
        # normal implisit superellipsoid
        n = (sgnpow(cv, 2-e) * sgnpow(cu, 2-e) / hx, sgnpow(sv, 2-e) / hy, sgnpow(cv, 2-e) * sgnpow(su, 2-e) / hz)
        return (x, y, z), norm(n)
    rows = seg; cols = seg * 2
    grid = [[pt(-math.pi + 2*math.pi*j/cols, -math.pi/2 + math.pi*i/rows) for j in range(cols+1)] for i in range(rows+1)]
    def tf(p, n):
        if rx: p = rotx(p, rx); n = rotx(n, rx)
        if ry: p = roty(p, ry); n = roty(n, ry)
        return add(p, center), n
    for i in range(rows):
        for j in range(cols):
            a = tf(*grid[i][j]); b = tf(*grid[i][j+1]); c = tf(*grid[i+1][j+1]); d = tf(*grid[i+1][j])
            cc = colfn(a[0]) if colfn else col
            m.tri(a[0], c[0], b[0], a[1], c[1], b[1], cc); m.tri(a[0], d[0], c[0], a[1], d[1], c[1], cc)

def box(m, center, size, col, rx=0.0, ry=0.0):
    """Kotak dengan normal datar; bevel tipis lewat superq e=.12 agar tepi menangkap sorotan."""
    superq(m, center, size, 0.12, col, seg=6, rx=rx, ry=ry)

def cyl(m, a, b, r, col, seg=18, cap=True, r2=None):
    """Silinder / kerucut terpancung dari titik a ke b."""
    r2 = r if r2 is None else r2
    ax = norm(sub(b, a)); up = (0, 1, 0) if abs(ax[1]) < .9 else (1, 0, 0)
    u = norm(cross(ax, up)); w = cross(ax, u)
    ring = []
    for k in range(seg + 1):
        t = 2 * math.pi * k / seg; d = add(mul(u, math.cos(t)), mul(w, math.sin(t)))
        ring.append(d)
    for k in range(seg):
        d0, d1 = ring[k], ring[k+1]
        p0 = add(a, mul(d0, r)); p1 = add(a, mul(d1, r)); q0 = add(b, mul(d0, r2)); q1 = add(b, mul(d1, r2))
        m.tri(p0, q1, q0, d0, d1, d0, col); m.tri(p0, p1, q1, d0, d1, d1, col)
        if cap:
            na = mul(ax, -1)
            m.tri(a, p1, p0, na, na, na, col); m.tri(b, q0, q1, ax, ax, ax, col)

# ------------------------------------------------------------------ warna material
BLACK = C(28, 29, 31); STEEL = C(48, 50, 54); PARK = C(38, 40, 38); FDE = C(150, 126, 92)
WALNUT = C(104, 62, 34); WALNUT2 = C(82, 48, 26); BRASS = C(196, 160, 82); GLASS = C(40, 70, 90)

def rifle():
    m = M()
    # stok teleskopik (FDE) + buffer tube
    cyl(m, (0, .5, -.15), (0, .5, -.62), .055, BLACK)
    superq(m, (0, .42, -.52), (.16, .3, .36), .25, FDE)
    box(m, (0, .26, -.6), (.15, .12, .18), FDE)
    box(m, (0, .45, -.71), (.17, .4, .04), BLACK)   # butt pad
    # lower receiver
    box(m, (0, .33, .12), (.17, .2, .56), PARK)
    box(m, (0, .24, .18), (.15, .12, .2), PARK)     # magwell
    # pistol grip (miring)
    superq(m, (0, .08, -.06), (.13, .36, .17), .3, BLACK, rx=.38)
    # trigger guard & trigger
    box(m, (0, .14, .02), (.06, .03, .22), BLACK); box(m, (0, .2, .04), (.025, .08, .03), STEEL)
    # upper receiver + rail atas
    box(m, (0, .5, .14), (.18, .16, .6), PARK)
    for i in range(9): box(m, (0, .6, -.1 + i * .065), (.14, .04, .035), BLACK)
    box(m, (-.1, .48, .12), (.04, .08, .3), STEEL)  # ejection port cover
    box(m, (0, .52, -.18), (.12, .06, .08), STEEL)  # charging handle
    # red-dot (Aimpoint) di atas rail
    box(m, (0, .66, .14), (.12, .05, .18), BLACK)
    cyl(m, (0, .75, .04), (0, .75, .26), .07, BLACK)
    cyl(m, (0, .75, .255), (0, .75, .265), .055, GLASS, cap=True)
    # handguard M-LOK (bulat bersegi)
    superq(m, (0, .46, .7), (.2, .22, .52), .45, BLACK, seg=16)
    for i in range(4): box(m, (.1, .46, .5 + i * .12), (.02, .05, .06), PARK); box(m, (-.1, .46, .5 + i * .12), (.02, .05, .06), PARK)
    for i in range(7): box(m, (0, .58, .48 + i * .065), (.12, .035, .035), BLACK)
    # gas block, front sight lipat, laras, flash hider
    cyl(m, (0, .45, .95), (0, .45, 1.1), .032, STEEL)
    box(m, (0, .55, .93), (.06, .12, .05), BLACK)
    cyl(m, (0, .45, 1.08), (0, .45, 1.18), .045, BLACK, seg=8)
    m.save("rifle")

def shotgun():
    m = M()
    # stok kayu (melengkung pakai superq + rotasi)
    superq(m, (0, .38, -.45), (.17, .3, .55), .35, WALNUT, rx=.12)
    box(m, (0, .38, -.72), (.17, .32, .04), BLACK)   # recoil pad
    superq(m, (0, .38, -.12), (.14, .2, .2), .4, WALNUT2, rx=.25)  # wrist
    # receiver baja
    box(m, (0, .48, .08), (.17, .26, .44), STEEL)
    box(m, (-.09, .5, .1), (.02, .1, .24), BLACK)  # ejection port
    box(m, (0, .26, .02), (.06, .05, .2), BLACK); box(m, (0, .31, .05), (.025, .08, .03), STEEL)  # trigger guard
    # laras + rib + bead sight
    cyl(m, (0, .55, .28), (0, .55, .9), .045, BLACK)
    box(m, (0, .605, .58), (.03, .015, .62), STEEL)
    cyl(m, (0, .625, .87), (0, .625, .885), .012, BRASS)
    # tabung magasin + cap
    cyl(m, (0, .42, .28), (0, .42, .84), .038, BLACK)
    cyl(m, (0, .42, .84), (0, .42, .88), .042, STEEL)
    # forend pump kayu bergerigi
    superq(m, (0, .4, .62), (.15, .14, .32), .4, WALNUT)
    for i in range(6): box(m, (0, .33, .5 + i * .045), (.12, .015, .02), WALNUT2)
    cyl(m, (0, .48, .3), (0, .48, .5), .015, STEEL, cap=False)  # action bar
    m.save("shotgun")

def wall_high():
    """Tembok beton T-wall: x +-.75, y 0..1.7, z +-.35."""
    m = M()
    con = C(178, 174, 166); con2 = C(160, 156, 150)
    superq(m, (0, .12, 0), (1.5, .24, .7), .18, con2, seg=8)       # pondasi
    superq(m, (0, .95, 0), (1.46, 1.5, .4), .14, con, seg=10)       # dinding
    superq(m, (0, 1.66, 0), (1.5, .08, .44), .2, con2, seg=6)      # capping
    for x in (-.5, .5): box(m, (x, 1.35, .205), (.08, .08, .02), C(120, 116, 110))  # titik angkat
    m.save("wall-high")

def wall_low():
    """Barikade karung pasir: x +-1.1, y 0..0.8, z +-.35."""
    m = M()
    random.seed(4)
    rows = 4; h = .2
    for r in range(rows):
        n = 5 if r % 2 == 0 else 4; w = 2.2 / 5
        off = 0 if r % 2 == 0 else w / 2
        for zz in (-.16, .16) if r < 2 else (0,):
            for i in range(n):
                x = -1.1 + w / 2 + off + i * w
                shade = random.uniform(.85, 1.05)
                col = tuple(min(1, c * shade) for c in C(152, 132, 96))
                superq(m, (x, h / 2 + r * h * .92, zz), (w * 1.02, h * 1.05, .34 if r < 2 else .5), .55, col, seg=6,
                       ry=random.uniform(-.05, .05))
    m.save("wall-low")

def grass(name, rad, hgt, blades):
    m = M(); random.seed(len(name))
    for _ in range(blades):
        a = random.uniform(0, 2 * math.pi); d = random.uniform(0, rad)
        bx, bz = math.cos(a) * d, math.sin(a) * d
        hh = hgt * random.uniform(.5, 1.0); lean = random.uniform(-.35, .35); ang = random.uniform(0, math.pi)
        wv = .018
        base = C(54, 74, 34); tip = random.choice([C(128, 146, 72), C(112, 138, 60), C(150, 150, 86)])
        dx, dz = math.cos(ang) * wv, math.sin(ang) * wv
        p0 = (bx - dx, 0, bz - dz); p1 = (bx + dx, 0, bz + dz)
        tp = (bx + lean * hh * math.sin(ang), hh, bz - lean * hh * math.cos(ang))
        n = norm(cross(sub(p1, p0), sub(tp, p0)))
        n = norm((n[0], abs(n[1]) + .6, n[2]))
        mid = add(mul(add(p0, p1), .5), mul(sub(tp, mul(add(p0, p1), .5)), .5))
        m.tri(p0, p1, mid, n, n, n, base); m.tri(p0, mid, p1, n, n, n, base)
        m.tri(mid, tp, add(mid, (dx * .5, 0, dz * .5)), n, n, n, tip); m.tri(mid, add(mid, (dx * .5, 0, dz * .5)), tp, n, n, n, tip)
    m.save(name)

def cloud():
    m = M(); random.seed(9)
    for _ in range(9):
        cx, cz = random.uniform(-.3, .3), random.uniform(-.3, .3); s = random.uniform(.3, .5)
        superq(m, (cx, .35 + random.uniform(0, .25), cz), (s * 1.3, s * .7, s), 1.0, (1, 1, 1), seg=10)
    m.save("cloud")

def crate():
    """Peti kayu militer, ukuran 1x1x1 berpusat 0."""
    m = M()
    superq(m, (0, 0, 0), (.96, .96, .96), .08, (1, 1, 1), seg=6)
    fr = (.78, .78, .78)
    for a in (-.47, .47):
        for b in (-.47, .47):
            box(m, (a, 0, b), (.08, 1.0, .08), fr); box(m, (a, b, 0), (.08, .08, 1.0), fr); box(m, (0, a, b), (1.0, .08, .08), fr)
    for s in (-1, 1):
        box(m, (0, 0, s * .49), (.9, .07, .03), fr); box(m, (s * .49, 0, 0), (.03, .07, .9), fr)
    m.save("crate")

def prims():
    m = M(); superq(m, (0, 0, 0), (1, 1, 1), .35, (1, 1, 1), seg=10); m.save("rbox")
    m = M(); superq(m, (0, 0, 0), (1, 1, 1), 1.0, (1, 1, 1), seg=14); m.save("sphere")
    m = M(); cyl(m, (0, -.5, 0), (0, .5, 0), .5, (1, 1, 1), seg=16); m.save("cyl")

if __name__ == "__main__":
    rifle(); shotgun(); wall_high(); wall_low()
    grass("grass", .26, .34, 70); grass("grass-small", .13, .26, 30)
    cloud(); crate(); prims()
