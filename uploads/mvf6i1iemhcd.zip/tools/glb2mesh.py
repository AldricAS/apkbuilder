#!/usr/bin/env python3
"""Konversi .glb (glTF binary) -> .mesh sederhana: int32 jumlah vertex, lalu per vertex 9 float (pos, normal, rgb).
Warna diambil dengan sampling tekstur colormap pada UV tiap vertex. Pemakaian: glb2mesh.py in.glb out.mesh colormap.png"""
import sys, json, struct, numpy as np
from PIL import Image

def node_matrix(n):
    if 'matrix' in n: return np.array(n['matrix'], float).reshape(4, 4).T
    t = np.array(n.get('translation', [0, 0, 0]), float); q = n.get('rotation', [0, 0, 0, 1]); s = n.get('scale', [1, 1, 1])
    x, y, z, w = q
    R = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
    M = np.eye(4); M[:3, :3] = R * np.array(s); M[:3, 3] = t; return M

def convert(src, dst, tex):
    d = open(src, 'rb').read()
    jl, _ = struct.unpack_from('<II', d, 12); js = json.loads(d[20:20+jl])
    bin_ = d[20+jl+8:]
    img = np.array(Image.open(tex).convert('RGB')); H, W = img.shape[:2]
    def acc(i):
        a = js['accessors'][i]; bv = js['bufferViews'][a['bufferView']]
        nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[a['type']]
        dt = {5126: '<f4', 5123: '<u2', 5125: '<u4', 5121: 'u1'}[a['componentType']]
        off = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        return np.frombuffer(bin_, dt, a['count'] * nc, off).reshape(a['count'], nc)
    out = []
    def walk(ni, parent):
        n = js['nodes'][ni]; M = parent @ node_matrix(n)
        if 'mesh' in n:
            for p in js['meshes'][n['mesh']]['primitives']:
                at = p['attributes']; P = acc(at['POSITION']).astype(float); N = acc(at['NORMAL']).astype(float); UV = acc(at['TEXCOORD_0'])
                idx = acc(p['indices']).ravel() if 'indices' in p else np.arange(len(P))
                P4 = np.c_[P, np.ones(len(P))] @ M.T; Pw = P4[:, :3]
                Nw = N @ np.linalg.inv(M[:3, :3]); Nw /= (np.linalg.norm(Nw, axis=1, keepdims=True) + 1e-9)
                px = np.clip((UV[:, 0] * W).astype(int), 0, W-1); py = np.clip((UV[:, 1] * H).astype(int), 0, H-1)
                C = img[py, px] / 255.0
                out.append(np.c_[Pw, Nw, C][idx])
        for c in n.get('children', []): walk(c, M)
    for r in js['scenes'][0]['nodes']: walk(r, np.eye(4))
    V = np.vstack(out).astype('<f4')
    open(dst, 'wb').write(struct.pack('<i', len(V)) + V.tobytes())
    lo, hi = V[:, :3].min(0), V[:, :3].max(0)
    print(f"{dst}: {len(V)} vertex, min {lo.round(2)}, max {hi.round(2)}")

if __name__ == '__main__': convert(*sys.argv[1:4])
