# Shooter 3D (Android, Kotlin + OpenGL ES 2.0)
Buka folder ini di Android Studio -> Sync -> Run.
Mode: Wave Survival, Time Attack, Target Practice, Boss Rush.
Kontrol: geser layar = bidik, FIRE = tembak, GANTI SENJATA = Rifle/Shotgun/Sniper. Headshot = damage x2.
Model 3D: blaster, drone musuh, tembok, rumput, awan = Kenney (CC0, github.com/KenneyNL/Starter-Kit-FPS), dikonversi dengan tools/glb2mesh.py. Target dibuat sendiri.
Pengaturan Grafis (menu utama): kualitas Rendah/Sedang/Tinggi, batas FPS, tampilkan FPS, sensitivitas.
Atribusi (tidak wajib untuk CC0): Kenney - www.kenney.nl
Tambah model baru: python3 tools/glb2mesh.py model.glb app/src/main/assets/models/nama.mesh colormap.png
