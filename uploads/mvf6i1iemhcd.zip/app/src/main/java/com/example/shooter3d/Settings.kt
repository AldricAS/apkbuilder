package com.example.shooter3d
import android.content.Context

/** Pengaturan grafis & kontrol (disimpan di SharedPreferences). */
class Gfx(var quality: Int, var fpsCap: Int, var showFps: Boolean, var sens: Float) {
    val resScale get() = floatArrayOf(.5f, .75f, 1f)[quality]
    val viewDist get() = floatArrayOf(45f, 70f, 110f)[quality]
    val decor get() = quality > 0
    fun save(c: Context) = c.getSharedPreferences("gfx", 0).edit()
        .putInt("q", quality).putInt("fps", fpsCap).putBoolean("showFps", showFps).putFloat("sens", sens).apply()
    companion object {
        val QUALITY = arrayOf("Rendah", "Sedang", "Tinggi")
        val FPS = intArrayOf(30, 60, 0) // 0 = tanpa batas
        fun load(c: Context): Gfx { val p = c.getSharedPreferences("gfx", 0)
            return Gfx(p.getInt("q", 1), p.getInt("fps", 60), p.getBoolean("showFps", false), p.getFloat("sens", .2f)) }
    }
}
