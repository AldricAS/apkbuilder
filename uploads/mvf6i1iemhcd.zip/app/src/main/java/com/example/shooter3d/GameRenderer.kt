package com.example.shooter3d
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*
import kotlin.random.Random

class GameRenderer(private val ctx: Context, private val g: Game, private val gfx: Gfx, private val onHud: (String, Boolean) -> Unit) : GLSurfaceView.Renderer {
    private class Pl(val m: Mesh, val x: Float, val y: Float, val z: Float, val yaw: Float, val s: Float)
    private var prog = 0; private var aPos = 0; private var aNorm = 0; private var aCol = 0
    private var uMvp = 0; private var uRot = 0; private var uCol = 0; private var uFlash = 0
    private lateinit var cube: Mesh; private lateinit var drone: Mesh; private lateinit var weapons: List<Mesh>
    private val arena = ArrayList<Pl>()
    private val proj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16)
    private val ent = FloatArray(16); private val m = FloatArray(16); private val mvp = FloatArray(16); private val rot = FloatArray(16)
    private var last = 0L; private var hudT = 0f; private var ended = false; private var fps = 0; private var frames = 0; private var fpsT = 0f

    private fun shader(t: Int, s: String) = GLES20.glCreateShader(t).also { GLES20.glShaderSource(it, s); GLES20.glCompileShader(it) }

    private fun buildCube(): Mesh {
        val v = ArrayList<Float>()
        val ns = arrayOf(floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f))
        for (n in ns) {
            val u = if (abs(n[1]) > .5f) floatArrayOf(1f, 0f, 0f) else floatArrayOf(0f, 1f, 0f)
            val w = floatArrayOf(n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0])
            for ((a, b) in listOf(-1 to -1, 1 to -1, 1 to 1, -1 to -1, 1 to 1, -1 to 1)) {
                for (k in 0..2) v += n[k] * .5f + u[k] * .5f * a + w[k] * .5f * b
                for (k in 0..2) v += n[k]
                v += 1f; v += 1f; v += 1f
            }
        }
        val fb = ByteBuffer.allocateDirect(v.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(v.toFloatArray()); position(0) }
        return Mesh(fb, 36)
    }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        GLES20.glClearColor(.55f, .75f, .95f, 1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs = "uniform mat4 uMvp; uniform mat4 uRot; attribute vec3 aPos; attribute vec3 aNorm; attribute vec3 aCol; varying float vL; varying vec3 vC;" +
            "void main(){ vec3 n = normalize((uRot*vec4(aNorm,0.0)).xyz); vL = max(dot(n, normalize(vec3(.4,1.,.3))),0.0)*.7+.3; vC = aCol; gl_Position = uMvp*vec4(aPos,1.0);}"
        val fs = "precision mediump float; uniform vec4 uCol; uniform float uFlash; varying float vL; varying vec3 vC;" +
            "void main(){ vec3 c = vC*uCol.rgb*vL; gl_FragColor = vec4(mix(c, vec3(1.0), uFlash),1.0);}"
        prog = GLES20.glCreateProgram().also { GLES20.glAttachShader(it, shader(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(it, shader(GLES20.GL_FRAGMENT_SHADER, fs)); GLES20.glLinkProgram(it) }
        aPos = GLES20.glGetAttribLocation(prog, "aPos"); aNorm = GLES20.glGetAttribLocation(prog, "aNorm"); aCol = GLES20.glGetAttribLocation(prog, "aCol")
        uMvp = GLES20.glGetUniformLocation(prog, "uMvp"); uRot = GLES20.glGetUniformLocation(prog, "uRot")
        uCol = GLES20.glGetUniformLocation(prog, "uCol"); uFlash = GLES20.glGetUniformLocation(prog, "uFlash")
        cube = buildCube(); drone = MeshIO.load(ctx, "enemy-flying")
        weapons = listOf(MeshIO.load(ctx, "blaster-repeater"), MeshIO.load(ctx, "blaster"))
        // Arena dari model CC0 Kenney
        val wallH = MeshIO.load(ctx, "wall-high"); val wallL = MeshIO.load(ctx, "wall-low")
        val rnd = Random(7)
        for (i in 0 until 24) { val a = i * 2 * PI.toFloat() / 24
            arena += Pl(wallH, cos(a) * 38f, 0f, sin(a) * 38f, Math.toDegrees((-a).toDouble()).toFloat() + 90f, 6f) }
        repeat(10) { val a = rnd.nextFloat() * 6.28f; val d = 12f + rnd.nextFloat() * 14f
            arena += Pl(wallL, cos(a) * d, 0f, sin(a) * d, rnd.nextFloat() * 360f, 2.5f) }
        if (gfx.decor) {
            val gr = MeshIO.load(ctx, "grass"); val gs = MeshIO.load(ctx, "grass-small"); val cl = MeshIO.load(ctx, "cloud")
            repeat(120) { val a = rnd.nextFloat() * 6.28f; val d = 5f + rnd.nextFloat() * 32f
                arena += Pl(if (it % 2 == 0) gr else gs, cos(a) * d, 0f, sin(a) * d, rnd.nextFloat() * 360f, 2.5f) }
            repeat(8) { val a = rnd.nextFloat() * 6.28f; val d = 30f + rnd.nextFloat() * 30f
                arena += Pl(cl, cos(a) * d, 22f + rnd.nextFloat() * 8f, sin(a) * d, 0f, 14f) }
        }
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h); Matrix.perspectiveM(proj, 0, 65f, w.toFloat() / h, .1f, gfx.viewDist + 40f)
    }

    private fun place(x: Float, y: Float, z: Float, yaw: Float, sx: Float, sy: Float, sz: Float) {
        Matrix.setIdentityM(ent, 0); Matrix.translateM(ent, 0, x, y, z); Matrix.rotateM(ent, 0, yaw, 0f, 1f, 0f); Matrix.scaleM(ent, 0, sx, sy, sz)
        Matrix.setIdentityM(rot, 0); Matrix.rotateM(rot, 0, yaw, 0f, 1f, 0f)
    }

    private fun draw(mesh: Mesh, model: FloatArray, vpm: FloatArray, r: Float, gg: Float, b: Float, flash: Float) {
        Matrix.multiplyMM(mvp, 0, vpm, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0); GLES20.glUniformMatrix4fv(uRot, 1, false, rot, 0)
        GLES20.glUniform4f(uCol, r, gg, b, 1f); GLES20.glUniform1f(uFlash, flash)
        mesh.buf.position(0); GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 36, mesh.buf); GLES20.glEnableVertexAttribArray(aPos)
        mesh.buf.position(3); GLES20.glVertexAttribPointer(aNorm, 3, GLES20.GL_FLOAT, false, 36, mesh.buf); GLES20.glEnableVertexAttribArray(aNorm)
        mesh.buf.position(6); GLES20.glVertexAttribPointer(aCol, 3, GLES20.GL_FLOAT, false, 36, mesh.buf); GLES20.glEnableVertexAttribArray(aCol)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, mesh.count)
    }

    private fun drawParts(parts: List<Part>, x: Float, y: Float, z: Float, yaw: Float, vpm: FloatArray, flash: Float) {
        place(x, y, z, yaw, 1f, 1f, 1f)
        for (p in parts) {
            System.arraycopy(ent, 0, m, 0, 16); Matrix.translateM(m, 0, p.ox, p.oy, p.oz); Matrix.scaleM(m, 0, p.sx, p.sy, p.sz)
            draw(cube, m, vpm, p.c[0], p.c[1], p.c[2], flash)
        }
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime(); val dt = ((now - last) / 1e9f).coerceAtMost(.05f); last = now
        g.update(dt)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        val d = g.dir()
        Matrix.setLookAtM(view, 0, 0f, 1.6f, 0f, d[0], 1.6f + d[1], d[2], 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        place(0f, -.1f, 0f, 0f, 90f, .2f, 90f); draw(cube, ent, vp, .27f, .37f, .24f, 0f)
        val vd2 = gfx.viewDist * gfx.viewDist
        for (p in arena) {
            if (p.x * p.x + p.z * p.z > vd2 && p.y == 0f) continue
            place(p.x, p.y, p.z, p.yaw, p.s, p.s, p.s); draw(p.m, ent, vp, 1f, 1f, 1f, 0f)
        }
        for (e in ArrayList(g.enemies)) {
            val yaw = Math.toDegrees(Math.atan2((-e.x).toDouble(), (-e.z).toDouble())).toFloat()
            if (e.type == 3) { drawParts(Models.target, e.x, 0f, e.z, yaw, vp, e.flash * 10f); continue }
            val bob = sin(e.bob) * .15f; val s = Models.scale[e.type]; val t = Models.tint[e.type]
            place(e.x, Game.Y0[e.type] + bob, e.z, yaw, s, s, s); draw(drone, ent, vp, t[0], t[1], t[2], if (e.flash > 0f) 1f else 0f)
        }
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
        place(.3f, -.3f, -.6f + g.recoil * .1f, 0f, .3f, .3f, .3f); draw(weapons[g.weapon], ent, proj, 1f, 1f, 1f, 0f)
        frames++; fpsT += dt; if (fpsT >= 1f) { fps = frames; frames = 0; fpsT = 0f }
        hudT -= dt
        if (hudT <= 0f || (g.over && !ended)) { hudT = .15f
            val over = g.over && !ended; if (over) ended = true
            onHud(if (over) g.summary() else g.hud() + if (gfx.showFps) "   ${fps} FPS" else "", over) }
        if (gfx.fpsCap > 0) { val left = (1_000_000_000L / gfx.fpsCap - (System.nanoTime() - now)) / 1_000_000L; if (left > 0) Thread.sleep(left) }
    }
}
