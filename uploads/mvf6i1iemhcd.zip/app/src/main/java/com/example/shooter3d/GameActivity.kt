package com.example.shooter3d
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.*

class GameActivity : Activity() {
    private lateinit var game: Game
    private lateinit var gl: GLSurfaceView
    private lateinit var hud: TextView
    private lateinit var gfx: Gfx

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        gfx = Gfx.load(this)
        game = Game(Mode.valueOf(intent.getStringExtra("mode")!!))
        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        hud = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setShadowLayer(4f, 0f, 0f, Color.BLACK); setPadding(24, 12, 24, 12) }
        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setRenderer(GameRenderer(this@GameActivity, game, gfx) { s, over -> runOnUiThread { hud.text = s; if (over) showEnd(s) } })
        }
        gl.holder.setFixedSize((maxOf(dm.widthPixels, dm.heightPixels) * gfx.resScale).toInt(), (minOf(dm.widthPixels, dm.heightPixels) * gfx.resScale).toInt())
        var lx = 0f; var ly = 0f
        gl.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
                MotionEvent.ACTION_MOVE -> { game.yaw += (e.x - lx) * gfx.sens; game.pitch = (game.pitch - (e.y - ly) * gfx.sens).coerceIn(-60f, 60f); lx = e.x; ly = e.y }
            }; true
        }
        val cross = TextView(this).apply { text = "+"; textSize = 30f; setTextColor(Color.RED); gravity = Gravity.CENTER }
        val fire = Button(this).apply { text = "FIRE"
            setOnTouchListener { _, e -> when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> game.firing = true
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> game.firing = false }; true } }
        val sw = Button(this).apply { text = "GANTI SENJATA"; setOnClickListener { game.weapon = (game.weapon + 1) % 2 } }
        root.addView(gl); root.addView(hud); root.addView(cross, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(fire, FrameLayout.LayoutParams(320, 200, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, 40, 40) })
        root.addView(sw, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(40, 0, 0, 40) })
        setContentView(root)
    }

    private fun showEnd(s: String) {
        game.firing = false
        AlertDialog.Builder(this).setTitle("Game Over").setMessage(s).setCancelable(false)
            .setPositiveButton("Ulangi") { _, _ -> recreate() }.setNegativeButton("Menu") { _, _ -> finish() }.show()
    }
    override fun onPause() { super.onPause(); gl.onPause() }
    override fun onResume() { super.onResume(); gl.onResume() }
}
