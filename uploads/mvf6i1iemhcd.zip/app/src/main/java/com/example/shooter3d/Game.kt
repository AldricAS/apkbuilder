package com.example.shooter3d
import kotlin.math.*
import kotlin.random.Random

enum class Mode(val label: String) {
    WAVE("Wave Survival"), TIME("Time Attack 60s"), TARGET("Target Practice 90s"), BOSS("Boss Rush")
}
class Enemy(var x: Float, var z: Float, val type: Int, var hp: Float) { var flash = 0f; var bob = Random.nextFloat() * 6f }

class Game(val mode: Mode) {
    @Volatile var yaw = 0f
    @Volatile var pitch = 0f
    @Volatile var firing = false
    @Volatile var weapon = 0
    val enemies = ArrayList<Enemy>()
    var hp = 100f; var score = 0; var wave = 0; var time = 0f; var over = false
    var shots = 0; var hits = 0; var cd = 0f; var recoil = 0f; var spawnT = 0f; var waveDelay = 0f

    companion object {
        val H = floatArrayOf(1.2f, .8f, 3.5f, 1.6f)
        val Y0 = floatArrayOf(1f, 1.2f, .8f, 0f)
        val R = floatArrayOf(.8f, .55f, 2.4f, .7f)
        val SPEED = floatArrayOf(2.5f, 5f, 1.4f, 0f)
        val DPS = floatArrayOf(8f, 6f, 25f, 0f)
        val PTS = intArrayOf(10, 15, 100, 5)
        val HP = floatArrayOf(2f, 1f, 25f, 1f)
        val NAMES = arrayOf("Repeater", "Blaster")
        val CD = floatArrayOf(.1f, .7f)
        val DMG = floatArrayOf(1f, 1f)
        val PELLETS = intArrayOf(1, 6)
        val SPREAD = floatArrayOf(.012f, .06f)
    }

    private fun limit() = when (mode) { Mode.TIME -> 60f; Mode.TARGET -> 90f; else -> 0f }

    private fun spawn(type: Int, hp: Float = HP[type]) {
        val a = Random.nextFloat() * 6.283f
        val d = if (type == 3) 8f + Random.nextFloat() * 14f else 28f
        enemies += Enemy(cos(a) * d, sin(a) * d, type, hp)
    }

    fun dir(yawDeg: Float = yaw, pitchDeg: Float = pitch): FloatArray {
        val y = Math.toRadians(yawDeg.toDouble()).toFloat(); val p = Math.toRadians(pitchDeg.toDouble()).toFloat()
        return floatArrayOf(sin(y) * cos(p), sin(p), -cos(y) * cos(p))
    }

    fun update(dt: Float) {
        if (over) return
        time += dt; cd -= dt; recoil = max(0f, recoil - dt * 6f)
        if (firing && cd <= 0f) shoot()
        when (mode) {
            Mode.WAVE -> if (enemies.isEmpty()) { waveDelay -= dt; if (waveDelay <= 0f) {
                wave++; waveDelay = 2f
                repeat(3 + wave * 2) { spawn(if (Random.nextInt(4) == 0) 1 else 0) }
                if (wave % 5 == 0) spawn(2) } }
            Mode.TIME -> { spawnT -= dt; if (spawnT <= 0f) { spawnT = .7f; spawn(if (Random.nextInt(3) == 0) 1 else 0) } }
            Mode.TARGET -> while (enemies.size < 6) spawn(3)
            Mode.BOSS -> if (enemies.isEmpty()) { wave++; spawn(2, HP[2] + wave * 5f); repeat(max(0, wave - 2)) { spawn(0) } }
        }
        for (e in enemies) {
            e.flash = max(0f, e.flash - dt); e.bob += dt * 6f
            if (e.type == 3) continue
            val d = hypot(e.x, e.z)
            if (d > 2.5f) { val s = SPEED[e.type] * dt; e.x -= e.x / d * s; e.z -= e.z / d * s }
            else hp -= DPS[e.type] * dt
        }
        if (hp <= 0f || (limit() > 0f && time >= limit())) over = true
    }

    private fun shoot() {
        cd = CD[weapon]; recoil = 1f; shots++; var hitAny = false
        repeat(PELLETS[weapon]) {
            val sp = SPREAD[weapon] * 57f
            val d = dir(yaw + (Random.nextFloat() - .5f) * sp * 2, pitch + (Random.nextFloat() - .5f) * sp * 2)
            var best: Enemy? = null; var bt = 1e9f
            for (e in enemies) {
                val oy = Y0[e.type] + H[e.type] / 2 - 1.6f
                val tca = e.x * d[0] + oy * d[1] + e.z * d[2]
                if (tca < 0f) continue
                val d2 = e.x * e.x + oy * oy + e.z * e.z - tca * tca
                if (d2 < R[e.type] * R[e.type] && tca < bt) { bt = tca; best = e }
            }
            best?.let { e ->
                hitAny = true
                val head = 1.6f + d[1] * bt > Y0[e.type] + H[e.type] * .6f
                e.hp -= DMG[weapon] * (if (head) 2f else 1f); e.flash = .1f
                if (e.hp <= 0f) { enemies.remove(e); score += PTS[e.type] * (if (head) 2 else 1) }
            }
        }
        if (hitAny) hits++
    }

    fun hud(): String {
        val extra = when (mode) {
            Mode.WAVE -> "Wave $wave"; Mode.BOSS -> "Boss #$wave"
            else -> "Waktu ${max(0f, limit() - time).toInt()}s" }
        return "HP ${max(0, hp.toInt())}   Skor $score   $extra   [${NAMES[weapon]}]"
    }
    fun summary() = "Skor: $score\nAkurasi: ${if (shots > 0) hits * 100 / shots else 0}%"
}
