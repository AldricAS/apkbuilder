package com.example.shooter3d
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(0xFF101820.toInt()); setPadding(60, 20, 60, 20) }
        l.addView(TextView(this).apply { text = "SHOOTER 3D"; textSize = 32f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        Mode.values().forEach { m ->
            l.addView(Button(this).apply { text = m.label
                setOnClickListener { startActivity(Intent(this@MainActivity, GameActivity::class.java).putExtra("mode", m.name)) } })
        }
        l.addView(Button(this).apply { text = "Pengaturan Grafis"; setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) } })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(l) })
    }
}
