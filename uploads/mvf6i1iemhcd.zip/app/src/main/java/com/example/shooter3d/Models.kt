package com.example.shooter3d
import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/** Kotak berwarna (dipakai untuk lantai & target buatan sendiri). */
class Part(val ox: Float, val oy: Float, val oz: Float, val sx: Float, val sy: Float, val sz: Float, val c: FloatArray)
fun col(r: Int, g: Int, b: Int) = floatArrayOf(r / 255f, g / 255f, b / 255f)

/** Mesh dari folder assets/models (berkas .mesh) (hasil tools/glb2mesh.py): per vertex pos(3) normal(3) warna(3). */
class Mesh(val buf: FloatBuffer, val count: Int)
object MeshIO {
    fun load(c: Context, name: String): Mesh {
        val bb = ByteBuffer.wrap(c.assets.open("models/$name.mesh").readBytes()).order(ByteOrder.LITTLE_ENDIAN)
        val n = bb.int
        val fb = ByteBuffer.allocateDirect(n * 36).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (i in 0 until n * 9) fb.put(bb.float)
        fb.position(0); return Mesh(fb, n)
    }
}

object Models {
    /** Target latihan (buatan sendiri dari kotak). */
    val target = listOf(
        Part(0f, .7f, 0f, .1f, 1.4f, .1f, col(90, 90, 90)),
        Part(0f, 1.5f, 0f, 1.4f, 1.4f, .1f, col(240, 240, 240)),
        Part(0f, 1.5f, .06f, 1.0f, 1.0f, .1f, col(220, 30, 30)),
        Part(0f, 1.5f, .12f, .55f, .55f, .1f, col(240, 240, 240)),
        Part(0f, 1.5f, .18f, .2f, .2f, .1f, col(220, 30, 30)))
    /** Skala model drone (enemy-flying) per tipe: 0 grunt, 1 runner, 2 boss. Tint warna per tipe. */
    val scale = floatArrayOf(1.4f, .9f, 4f, 1f)
    val tint = arrayOf(floatArrayOf(1f, 1f, 1f), floatArrayOf(1f, .75f, .35f), floatArrayOf(1f, .35f, .35f))
}
