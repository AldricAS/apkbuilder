#!/usr/bin/env bash
# Dijalankan DI DALAM Ubuntu (proot). Proyek ter-bind di /work.
set -uo pipefail
say() { printf '\n\033[1;35m--> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m[x] %s\033[0m\n' "$*"; exit 1; }


# Jalankan perintah panjang sambil mencetak "masih jalan" tiap 60 detik supaya kelihatan tidak hang.
beat() {
  local label="$1"; shift
  ( local n=0; while true; do sleep 60; n=$((n+1)); echo "   [masih jalan ${n} menit] $label  ($(date +%H:%M:%S))"; done ) &
  local hb=$!
  "$@"; local rc=$?
  kill $hb >/dev/null 2>&1; wait $hb 2>/dev/null
  return $rc
}

export DEBIAN_FRONTEND=noninteractive
export ANDROID_HOME=/root/android-sdk ANDROID_SDK_ROOT=/root/android-sdk
export PATH=/root/flutter/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH
export GRADLE_OPTS="-Xmx1536m -Dorg.gradle.daemon=false"
export FLUTTER_SUPPRESS_ANALYTICS=true CI=true

say "Paket sistem"
if ! command -v java >/dev/null || ! command -v git >/dev/null || ! command -v unzip >/dev/null; then
  apt-get update -y && apt-get install -y --no-install-recommends \
    openjdk-17-jdk-headless git curl unzip xz-utils zip ca-certificates libglu1-mesa aapt \
    || die "apt-get gagal"
fi

say "Flutter SDK"
if [ ! -x /root/flutter/bin/flutter ]; then
  git clone --depth 1 -b stable https://github.com/flutter/flutter.git /root/flutter || die "Gagal mengunduh Flutter"
fi
git config --global --add safe.directory '*' >/dev/null 2>&1
echo "Menyiapkan alat Flutter (langkah ini PALING LAMA di build pertama: kompilasi tool di HP bisa 10-25 menit tanpa output)."
beat "menyiapkan flutter tool" flutter --version || die "Flutter tidak bisa dijalankan di Ubuntu arm64 ini"

say "Android SDK"
if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  mkdir -p "$ANDROID_HOME/cmdline-tools" && cd /tmp || exit 1
  curl -fL -o clt.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip || die "Gagal mengunduh cmdline-tools"
  unzip -q -o clt.zip -d "$ANDROID_HOME/cmdline-tools" && mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm -f clt.zip
fi
yes | sdkmanager --licenses >/dev/null 2>&1
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" || die "sdkmanager gagal memasang SDK"
flutter config --android-sdk "$ANDROID_HOME" --no-analytics >/dev/null 2>&1
say "Mengunduh artefak Flutter untuk Android"
beat "flutter precache" flutter precache --android --no-ios --no-web --no-linux --no-macos --no-windows --no-fuchsia || die "flutter precache gagal"

say "Menyalin proyek ke /root/build (menghindari masalah izin pada folder bind)"
rm -rf /root/build && mkdir -p /root/build
(cd /work && tar --exclude=./build --exclude=./.dart_tool --exclude=./backend/node_modules --exclude=./dist -cf - .) | tar -xf - -C /root/build
cd /root/build || exit 1

say "Scaffold Android"
bash ./tool/setup_android.sh || die "setup_android gagal"

# aapt2 bawaan Gradle hanya x86_64. Pakai aapt2 arm64 dari apt jika ada.
AAPT2=$(command -v aapt2 || true)
if [ -n "$AAPT2" ]; then
  grep -q aapt2FromMavenOverride android/gradle.properties || echo "android.aapt2FromMavenOverride=$AAPT2" >> android/gradle.properties
  echo "aapt2 override: $AAPT2"
else
  echo "[!] aapt2 arm64 tidak ditemukan; build kemungkinan gagal di tahap aapt2."
fi

say "Build APK ($MODE)"
bash ./build-apk.sh "$MODE" || die "build-apk.sh gagal"

mkdir -p /work/dist && rm -f /work/dist/*.apk
for f in build/app/outputs/flutter-apk/*"$MODE"*.apk; do
  [ -f "$f" ] && cp "$f" "/work/dist/yumeplay-$(basename "$f" | sed 's/^app-//')"
done
ls /work/dist/*.apk >/dev/null 2>&1 || die "APK tidak ditemukan setelah build"
