#!/usr/bin/env bash
# Dijalankan di TERMUX (host). Menyiapkan Ubuntu (proot-distro) lalu membangun APK di dalamnya.
# Pemakaian:  npm run apk
set -uo pipefail
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"
MODE="${1:-debug}"

say() { printf '\n\033[1;35m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m[x] %s\033[0m\n' "$*"; exit 1; }

[ "$(uname -m)" = "aarch64" ] || die "Arsitektur $(uname -m) tidak didukung skrip ini (butuh aarch64)."
FREE_KB=$(df -k "$HOME" | awk 'NR==2{print $4}')
[ "${FREE_KB:-0}" -gt 9000000 ] || die "Ruang kosong kurang dari ~9 GB. Kosongkan penyimpanan dulu."

say "1/4 Menyiapkan proot-distro"
command -v proot-distro >/dev/null || { pkg update -y && pkg install -y proot-distro curl || die "Gagal memasang proot-distro"; }

say "2/4 Menyiapkan Ubuntu (sekali saja, ~1 GB)"
if ! proot-distro login ubuntu -- true >/dev/null 2>&1; then
  proot-distro install ubuntu || die "Gagal memasang Ubuntu"
fi

# Cegah Android menidurkan Termux saat layar mati (penyebab build "macet")
command -v termux-wake-lock >/dev/null && termux-wake-lock && trap 'termux-wake-unlock >/dev/null 2>&1' EXIT
echo "Wake-lock aktif. Biarkan Termux tetap terbuka; matikan penghemat baterai untuk Termux."

say "3/4 Build di dalam Ubuntu (pertama kali bisa 20-60 menit: unduh Flutter + Android SDK)"
proot-distro login ubuntu --shared-tmp --bind "$PROJECT:/work" -- \
  env MODE="$MODE" SKIP_CHECKS="${SKIP_CHECKS:-1}" APP_NAME="${APP_NAME:-YumePlay}" ORG="${ORG:-com.yumeplay}" \
      API_BASE_URL="${API_BASE_URL:-}" API_TOKEN="${API_TOKEN:-}" \
  bash /work/tool/inside-ubuntu.sh
STATUS=$?
[ $STATUS -eq 0 ] || die "Build gagal (kode $STATUS). Baca error paling atas yang berwarna merah/\"FAILURE\" di log. Jangan abaikan; kirim potongan log itu untuk dibantu."

say "4/4 Menyalin hasil"
APK=$(ls "$PROJECT"/dist/*.apk 2>/dev/null | head -n1)
[ -n "$APK" ] || die "Build selesai tetapi tidak ada APK di $PROJECT/dist"
if [ -d "$HOME/storage/downloads" ]; then
  cp "$APK" "$HOME/storage/downloads/" && echo "Disalin ke folder Download HP: $(basename "$APK")"
else
  echo "Jalankan 'termux-setup-storage' sekali, lalu ulangi 'npm run apk' agar APK masuk ke folder Download."
fi
echo "APK: $APK ($(du -h "$APK" | cut -f1))"
