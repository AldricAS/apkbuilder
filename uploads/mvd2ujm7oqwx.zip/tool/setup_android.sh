#!/usr/bin/env bash
# Membuat scaffolding Android (jika belum ada) dan menerapkan nama aplikasi / package name.
# Pakai:  APP_NAME="YumePlay" ORG="com.contoh" ./tool/setup_android.sh
set -euo pipefail
cd "$(dirname "$0")/.."

APP_NAME="${APP_NAME:-YumePlay}"
ORG="${ORG:-com.yumeplay}"

command -v flutter >/dev/null || { echo "flutter tidak ditemukan di PATH"; exit 1; }

if [ ! -d android ]; then
  flutter create --platforms=android --org "$ORG" --project-name yumeplay .
fi

MANIFEST=android/app/src/main/AndroidManifest.xml
# Nama aplikasi yang tampil di launcher
sed -i "s|android:label=\"[^\"]*\"|android:label=\"$APP_NAME\"|" "$MANIFEST"

# Izin internet (release manifest bawaan flutter create TIDAK menyertakannya)
grep -q 'android.permission.INTERNET' "$MANIFEST" || \
  sed -i 's|<application|<uses-permission android:name="android.permission.INTERNET"/>\n    <application|' "$MANIFEST"

# url_launcher di Android 11+ perlu <queries> untuk membuka https
grep -q '<queries>' "$MANIFEST" || \
  sed -i 's|</manifest>|    <queries>\n        <intent>\n            <action android:name="android.intent.action.VIEW"/>\n            <data android:scheme="https"/>\n        </intent>\n    </queries>\n</manifest>|' "$MANIFEST"

# Izinkan HTTP polos HANYA di build debug (uji backend lokal). Release tetap wajib HTTPS.
DEBUG_DIR=android/app/src/debug
mkdir -p "$DEBUG_DIR"
cat > "$DEBUG_DIR/AndroidManifest.xml" <<'XML'
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET"/>
    <application android:usesCleartextTraffic="true"/>
</manifest>
XML

# Izinkan HTTP polos HANYA ke localhost (backend yang jalan di HP yang sama lewat Termux).
# Alamat lain tetap wajib HTTPS.
mkdir -p android/app/src/main/res/xml
cat > android/app/src/main/res/xml/network_security_config.xml <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="false">127.0.0.1</domain>
        <domain includeSubdomains="false">localhost</domain>
    </domain-config>
</network-security-config>
XML
grep -q 'networkSecurityConfig' "$MANIFEST" || \
  sed -i 's|<application|<application android:networkSecurityConfig="@xml/network_security_config"|' "$MANIFEST"

# Hemat RAM saat Gradle
GP=android/gradle.properties
grep -q 'org.gradle.jvmargs' "$GP" && sed -i 's|^org.gradle.jvmargs=.*|org.gradle.jvmargs=-Xmx1536m -XX:MaxMetaspaceSize=512m|' "$GP" || echo 'org.gradle.jvmargs=-Xmx1536m -XX:MaxMetaspaceSize=512m' >> "$GP"
grep -q 'org.gradle.daemon' "$GP" || echo 'org.gradle.daemon=false' >> "$GP"

echo "Selesai. Application ID: $(grep -m1 -E 'applicationId' android/app/build.gradle* || true)"
echo "Ganti package name: hapus folder android/ lalu jalankan ulang dengan ORG=... yang baru."
