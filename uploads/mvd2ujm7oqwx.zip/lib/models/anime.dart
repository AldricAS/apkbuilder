/// Model data ternormalisasi (sama dengan backend/src/models/normalize.js).
/// Field yang tidak disediakan sumber tetap null; UI tidak boleh mengisi data karangan.

String? _s(dynamic v) {
  if (v == null) return null;
  final t = v.toString().trim();
  return t.isEmpty ? null : t;
}

double? _d(dynamic v) {
  if (v is num) return v.toDouble();
  return v == null ? null : double.tryParse(v.toString());
}

List<String> _strs(dynamic v) =>
    v is List ? v.map((e) => e.toString()).toList() : const <String>[];

class AlsoOn {
  final String id, source, key;
  const AlsoOn(this.id, this.source, this.key);
  factory AlsoOn.fromJson(Map<String, dynamic> j) =>
      AlsoOn(j['id'].toString(), j['source'].toString(), j['key'].toString());
  Map<String, dynamic> toJson() => {'id': id, 'source': source, 'key': key};
}

class AnimeSummary {
  final String id, source, key, title;
  final String? poster, status, type, year, episodeInfo;
  final double? rating;
  final List<String> genres;
  final List<AlsoOn> alsoOn;

  const AnimeSummary({
    required this.id,
    required this.source,
    required this.key,
    required this.title,
    this.poster,
    this.status,
    this.type,
    this.year,
    this.episodeInfo,
    this.rating,
    this.genres = const [],
    this.alsoOn = const [],
  });

  factory AnimeSummary.fromJson(Map<String, dynamic> j) => AnimeSummary(
        id: j['id'].toString(),
        source: j['source'].toString(),
        key: j['key'].toString(),
        title: _s(j['title']) ?? '(tanpa judul)',
        poster: _s(j['poster']),
        status: _s(j['status']),
        type: _s(j['type']),
        year: _s(j['year']),
        episodeInfo: _s(j['episodeInfo']),
        rating: _d(j['rating']),
        genres: _strs(j['genres']),
        alsoOn: (j['alsoOn'] is List)
            ? (j['alsoOn'] as List).map((e) => AlsoOn.fromJson(Map<String, dynamic>.from(e))).toList()
            : const [],
      );

  Map<String, dynamic> toJson() => {
        'id': id, 'source': source, 'key': key, 'title': title, 'poster': poster,
        'status': status, 'type': type, 'year': year, 'episodeInfo': episodeInfo,
        'rating': rating, 'genres': genres, 'alsoOn': alsoOn.map((e) => e.toJson()).toList(),
      };
}

class EpisodeItem {
  final double? number;
  final String? title, date;
  final String ref;
  final bool streamable;
  const EpisodeItem({this.number, this.title, required this.ref, this.date, this.streamable = true});

  factory EpisodeItem.fromJson(Map<String, dynamic> j) => EpisodeItem(
        number: _d(j['number']),
        title: _s(j['title']),
        ref: j['ref'].toString(),
        date: _s(j['date']),
        streamable: j['streamable'] != false,
      );

  String get label {
    final n = number;
    final ns = n == null ? null : (n == n.roundToDouble() ? n.toInt().toString() : n.toString());
    if (ns != null && (title == null || title!.toLowerCase().contains('episode') == false)) {
      return title == null ? 'Episode $ns' : 'Ep $ns · $title';
    }
    return title ?? (ns != null ? 'Episode $ns' : 'Episode');
  }
}

class RelatedItem {
  final String? title, relation, key;
  final String source;
  const RelatedItem({this.title, this.relation, this.key, required this.source});
}

class AnimeDetail {
  final AnimeSummary base;
  final String? cover, altTitles, synopsis, studio, trailer, sourceUrl;
  final int? totalEpisodes;
  final List<EpisodeItem> episodes;
  final List<RelatedItem> related;

  const AnimeDetail({
    required this.base,
    this.cover,
    this.altTitles,
    this.synopsis,
    this.studio,
    this.trailer,
    this.sourceUrl,
    this.totalEpisodes,
    this.episodes = const [],
    this.related = const [],
  });

  factory AnimeDetail.fromJson(Map<String, dynamic> j) => AnimeDetail(
        base: AnimeSummary.fromJson(j),
        cover: _s(j['cover']),
        altTitles: _s(j['altTitles']),
        synopsis: _s(j['synopsis']),
        studio: _s(j['studio']),
        trailer: _s(j['trailer']),
        sourceUrl: _s(j['sourceUrl']),
        totalEpisodes: j['totalEpisodes'] is num ? (j['totalEpisodes'] as num).toInt() : int.tryParse('${j['totalEpisodes']}'),
        episodes: (j['episodes'] as List? ?? const [])
            .map((e) => EpisodeItem.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        related: (j['related'] as List? ?? const [])
            .map((e) => Map<String, dynamic>.from(e))
            .map((m) => RelatedItem(
                title: _s(m['title']), relation: _s(m['relation']), key: _s(m['key']), source: '${j['source']}'))
            .toList(),
      );
}

enum StreamKind { hls, direct, dash, embed, download, unknown }

StreamKind _kind(String? k) => StreamKind.values.firstWhere((e) => e.name == k, orElse: () => StreamKind.unknown);

class StreamSource {
  final StreamKind kind;
  final String url;
  final String? label, server, resolution;
  final bool playable;
  const StreamSource({required this.kind, required this.url, this.label, this.server, this.resolution, required this.playable});

  factory StreamSource.fromJson(Map<String, dynamic> j) => StreamSource(
        kind: _kind(j['kind']?.toString()),
        url: j['url'].toString(),
        label: _s(j['label']),
        server: _s(j['server']),
        resolution: _s(j['resolution']),
        playable: j['playable'] == true,
      );

  int get height => int.tryParse(RegExp(r'(\d{3,4})').firstMatch(resolution ?? label ?? '')?.group(1) ?? '') ?? 0;
  String get title => [server ?? label, resolution].whereType<String>().join(' · ');
}

class EpisodePayload {
  final String source, animeKey;
  final double? number;
  final String? title, prevRef, nextRef, note;
  final List<StreamSource> sources;
  const EpisodePayload({
    required this.source,
    required this.animeKey,
    this.number,
    this.title,
    this.prevRef,
    this.nextRef,
    this.note,
    this.sources = const [],
  });

  factory EpisodePayload.fromJson(Map<String, dynamic> j) => EpisodePayload(
        source: j['source'].toString(),
        animeKey: j['animeKey'].toString(),
        number: _d(j['number']),
        title: _s(j['title']),
        prevRef: _s(j['prevRef']),
        nextRef: _s(j['nextRef']),
        note: _s(j['note']),
        sources: (j['sources'] as List? ?? const [])
            .map((e) => StreamSource.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );

  List<StreamSource> get playable {
    final l = sources.where((s) => s.playable).toList();
    l.sort((a, b) => b.height.compareTo(a.height));
    return l;
  }

  List<StreamSource> get external => sources.where((s) => !s.playable).toList();
}

class SourceError {
  final String source, code, message;
  const SourceError(this.source, this.code, this.message);
  factory SourceError.fromJson(Map<String, dynamic> j) =>
      SourceError('${j['source']}', '${j['code']}', '${j['message']}');
}

class HomeSection {
  final String key, title, source;
  final List<AnimeSummary> items;
  const HomeSection({required this.key, required this.title, required this.source, required this.items});
}

class HomeData {
  final List<HomeSection> sections;
  final List<SourceError> errors;
  const HomeData(this.sections, this.errors);
}

class PagedResult {
  final List<AnimeSummary> items;
  final int page;
  final bool hasMore;
  final List<SourceError> errors;
  const PagedResult(this.items, this.page, this.hasMore, this.errors);
}

class SourceInfo {
  final String id, name;
  final Map<String, dynamic> capabilities;
  const SourceInfo(this.id, this.name, this.capabilities);
  bool can(String c) => capabilities[c] == true;
}

/// Entri riwayat tontonan.
class HistoryEntry {
  final AnimeSummary anime;
  final String episodeRef;
  final double? episodeNumber;
  final int positionMs, durationMs;
  final int updatedAt;
  const HistoryEntry({
    required this.anime,
    required this.episodeRef,
    this.episodeNumber,
    this.positionMs = 0,
    this.durationMs = 0,
    required this.updatedAt,
  });

  double get progress => durationMs <= 0 ? 0 : (positionMs / durationMs).clamp(0.0, 1.0);

  factory HistoryEntry.fromJson(Map<String, dynamic> j) => HistoryEntry(
        anime: AnimeSummary.fromJson(Map<String, dynamic>.from(j['anime'])),
        episodeRef: j['episodeRef'].toString(),
        episodeNumber: _d(j['episodeNumber']),
        positionMs: (j['positionMs'] as num?)?.toInt() ?? 0,
        durationMs: (j['durationMs'] as num?)?.toInt() ?? 0,
        updatedAt: (j['updatedAt'] as num?)?.toInt() ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'anime': anime.toJson(), 'episodeRef': episodeRef, 'episodeNumber': episodeNumber,
        'positionMs': positionMs, 'durationMs': durationMs, 'updatedAt': updatedAt,
      };
}
