import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/app_config.dart';
import '../data/api_client.dart';
import '../data/local_store.dart';
import '../models/anime.dart';
import '../repositories/anime_repository.dart';

/// Di-override di main() dengan instance SharedPreferences yang sudah siap.
final sharedPrefsProvider = Provider<SharedPreferences>((_) => throw UnimplementedError());
final storeProvider = Provider<LocalStore>((ref) => LocalStore(ref.watch(sharedPrefsProvider)));

// ---------- Pengaturan ----------
class Settings {
  final String themeMode, userName, baseUrl;
  final List<String> sources; // kosong = semua sumber
  final bool autoNext, resume;
  const Settings({
    required this.themeMode,
    required this.userName,
    required this.baseUrl,
    required this.sources,
    required this.autoNext,
    required this.resume,
  });
  ThemeMode get mode =>
      themeMode == 'light' ? ThemeMode.light : themeMode == 'system' ? ThemeMode.system : ThemeMode.dark;
  Settings copy({String? themeMode, String? userName, String? baseUrl, List<String>? sources, bool? autoNext, bool? resume}) =>
      Settings(
        themeMode: themeMode ?? this.themeMode,
        userName: userName ?? this.userName,
        baseUrl: baseUrl ?? this.baseUrl,
        sources: sources ?? this.sources,
        autoNext: autoNext ?? this.autoNext,
        resume: resume ?? this.resume,
      );
}

class SettingsNotifier extends StateNotifier<Settings> {
  final LocalStore _s;
  SettingsNotifier(this._s)
      : super(Settings(
          themeMode: _s.themeMode,
          userName: _s.userName,
          baseUrl: _s.baseUrl,
          sources: _s.enabledSources,
          autoNext: _s.autoNext,
          resume: _s.resume,
        ));

  void setTheme(String v) { _s.setString('theme', v); state = state.copy(themeMode: v); }
  void setUserName(String v) { _s.setString('user_name', v); state = state.copy(userName: v); }
  void setBaseUrl(String v) {
    final t = v.trim().replaceAll(RegExp(r'/+$'), '');
    _s.setString('base_url', t);
    state = state.copy(baseUrl: t);
  }
  void setSources(List<String> v) { _s.setStrings('sources', v); state = state.copy(sources: v); }
  void setAutoNext(bool v) { _s.setBool('auto_next', v); state = state.copy(autoNext: v); }
  void setResume(bool v) { _s.setBool('resume', v); state = state.copy(resume: v); }
}

final settingsProvider = StateNotifierProvider<SettingsNotifier, Settings>((ref) => SettingsNotifier(ref.watch(storeProvider)));

final apiClientProvider = Provider<ApiClient>((ref) =>
    ApiClient(baseUrl: ref.watch(settingsProvider.select((s) => s.baseUrl)), token: AppConfig.apiToken));
final repoProvider = Provider<AnimeRepository>((ref) => AnimeRepository(ref.watch(apiClientProvider)));

final sourcesInfoProvider = FutureProvider<List<SourceInfo>>((ref) => ref.watch(repoProvider).sources());

// ---------- Home ----------
final homeProvider = FutureProvider<HomeData>((ref) {
  final src = ref.watch(settingsProvider.select((s) => s.sources));
  return ref.watch(repoProvider).home(src);
});

// ---------- Daftar berhalaman (ongoing/completed/latest) & pencarian ----------
class PagedState {
  final List<AnimeSummary> items;
  final int page;
  final bool hasMore, loading, initialDone;
  final String? error;
  final List<SourceError> errors;
  const PagedState({
    this.items = const [],
    this.page = 0,
    this.hasMore = true,
    this.loading = false,
    this.initialDone = false,
    this.error,
    this.errors = const [],
  });
}

typedef PageFetcher = Future<PagedResult> Function(int page);

class PagedNotifier extends StateNotifier<PagedState> {
  final PageFetcher fetch;
  PagedNotifier(this.fetch) : super(const PagedState());

  Future<void> refresh() async {
    state = const PagedState();
    await loadMore();
  }

  Future<void> loadMore() async {
    if (state.loading || !state.hasMore) return;
    state = PagedState(
        items: state.items, page: state.page, hasMore: state.hasMore, loading: true,
        initialDone: state.initialDone, errors: state.errors);
    try {
      final r = await fetch(state.page + 1);
      if (!mounted) return;
      final seen = state.items.map((e) => e.id).toSet();
      final merged = [...state.items, ...r.items.where((e) => seen.add(e.id))];
      state = PagedState(
          items: merged, page: r.page, hasMore: r.hasMore && r.items.isNotEmpty,
          initialDone: true, errors: r.errors);
    } catch (e) {
      if (!mounted) return;
      state = PagedState(
          items: state.items, page: state.page, hasMore: false, initialDone: true, error: e.toString());
    }
  }
}

final listProvider = StateNotifierProvider.family<PagedNotifier, PagedState, String>((ref, kind) {
  final repo = ref.watch(repoProvider);
  final src = ref.watch(settingsProvider.select((s) => s.sources));
  final n = PagedNotifier((p) => repo.list(kind, p, src));
  Future.microtask(n.loadMore);
  return n;
});

class SearchQuery {
  final String q;
  const SearchQuery(this.q);
  @override
  bool operator ==(Object o) => o is SearchQuery && o.q == q;
  @override
  int get hashCode => q.hashCode;
}

final searchProvider = StateNotifierProvider.autoDispose.family<PagedNotifier, PagedState, SearchQuery>((ref, sq) {
  final repo = ref.watch(repoProvider);
  final src = ref.watch(settingsProvider.select((s) => s.sources));
  final n = PagedNotifier((p) => repo.search(sq.q, p, src));
  Future.microtask(n.loadMore);
  return n;
});

// ---------- Detail & episode ----------
class AnimeRef {
  final String source, key;
  const AnimeRef(this.source, this.key);
  @override
  bool operator ==(Object o) => o is AnimeRef && o.source == source && o.key == key;
  @override
  int get hashCode => Object.hash(source, key);
}

final detailProvider = FutureProvider.family<AnimeDetail, AnimeRef>(
    (ref, a) => ref.watch(repoProvider).detail(a.source, a.key));

class EpisodeRef {
  final String source, key, ref;
  const EpisodeRef(this.source, this.key, this.ref);
  @override
  bool operator ==(Object o) => o is EpisodeRef && o.source == source && o.key == key && o.ref == ref;
  @override
  int get hashCode => Object.hash(source, key, ref);
}

final episodeProvider = FutureProvider.autoDispose.family<EpisodePayload, EpisodeRef>(
    (ref, e) => ref.watch(repoProvider).episode(e.source, e.key, e.ref));

// ---------- Favorit ----------
class FavoritesNotifier extends StateNotifier<List<AnimeSummary>> {
  final LocalStore _s;
  FavoritesNotifier(this._s) : super(_s.favorites());
  bool has(String id) => state.any((e) => e.id == id);
  void toggle(AnimeSummary a) {
    state = has(a.id) ? state.where((e) => e.id != a.id).toList() : [a, ...state];
    _s.saveFavorites(state);
  }
}

final favoritesProvider =
    StateNotifierProvider<FavoritesNotifier, List<AnimeSummary>>((ref) => FavoritesNotifier(ref.watch(storeProvider)));

// ---------- Riwayat tontonan ----------
class HistoryNotifier extends StateNotifier<List<HistoryEntry>> {
  final LocalStore _s;
  HistoryNotifier(this._s) : super(_s.history());

  HistoryEntry? of(String animeId) {
    for (final e in state) {
      if (e.anime.id == animeId) return e;
    }
    return null;
  }

  void upsert(HistoryEntry e) {
    state = [e, ...state.where((x) => x.anime.id != e.anime.id)];
    _s.saveHistory(state);
  }

  Future<void> clear() async {
    state = [];
    await _s.clearHistory();
  }
}

final historyProvider =
    StateNotifierProvider<HistoryNotifier, List<HistoryEntry>>((ref) => HistoryNotifier(ref.watch(storeProvider)));

// ---------- Riwayat pencarian ----------
class SearchHistoryNotifier extends StateNotifier<List<String>> {
  final LocalStore _s;
  SearchHistoryNotifier(this._s) : super(_s.searchHistory());
  void add(String q) {
    final t = q.trim();
    if (t.length < 2) return;
    state = [t, ...state.where((x) => x.toLowerCase() != t.toLowerCase())].take(AppConfig.maxSearchHistory).toList();
    _s.saveSearchHistory(state);
  }
  void remove(String q) { state = state.where((x) => x != q).toList(); _s.saveSearchHistory(state); }
}

final searchHistoryProvider = StateNotifierProvider<SearchHistoryNotifier, List<String>>(
    (ref) => SearchHistoryNotifier(ref.watch(storeProvider)));
