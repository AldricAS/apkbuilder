import 'package:flutter/material.dart';
import '../core/format.dart';
import '../core/theme.dart';
import '../models/anime.dart';
import 'poster_image.dart';

class SourceBadge extends StatelessWidget {
  final String source;
  const SourceBadge(this.source, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
        decoration: BoxDecoration(
            color: YumeColors.glass,
            border: Border.all(color: YumeColors.glassBorder),
            borderRadius: BorderRadius.circular(8)),
        child: Text(sourceName(source),
            style: const TextStyle(fontSize: 10, color: YumeColors.accentSoft, fontWeight: FontWeight.w600)),
      );
}

/// Kartu poster vertikal (dipakai di baris horizontal dan grid).
class AnimeCard extends StatelessWidget {
  final AnimeSummary anime;
  final double? width;
  final VoidCallback onTap;
  const AnimeCard({super.key, required this.anime, required this.onTap, this.width = 122});

  @override
  Widget build(BuildContext context) {
    final sub = [anime.episodeInfo, anime.status].whereType<String>().join(' · ');
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: width,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Stack(fit: StackFit.expand, children: [
              PosterImage(url: anime.poster, cacheWidth: 300),
              Positioned(left: 6, top: 6, child: SourceBadge(anime.source)),
              if (anime.rating != null)
                Positioned(
                  right: 6, bottom: 6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: const Color(0xCC14151B), borderRadius: BorderRadius.circular(8)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.star_rounded, size: 12, color: YumeColors.accentSoft),
                      const SizedBox(width: 2),
                      Text(anime.rating!.toStringAsFixed(1),
                          style: const TextStyle(fontSize: 10.5, color: Colors.white, fontWeight: FontWeight.w600)),
                    ]),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 7),
          Text(anime.title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.2)),
          if (sub.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11, color: YumeColors.textDim)),
            ),
        ]),
      ),
    );
  }
}

/// Baris horizontal berjudul.
class AnimeRow extends StatelessWidget {
  final String title;
  final String? trailing;
  final VoidCallback? onTrailing;
  final List<AnimeSummary> items;
  final void Function(AnimeSummary) onTap;
  const AnimeRow({super.key, required this.title, required this.items, required this.onTap, this.trailing, this.onTrailing});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 8, 10),
        child: Row(children: [
          Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 17))),
          if (trailing != null) TextButton(onPressed: onTrailing, child: Text(trailing!)),
        ]),
      ),
      SizedBox(
        height: 214,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: items.length > 15 ? 15 : items.length, // batasi poster yang dibangun
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (_, i) => AnimeCard(anime: items[i], onTap: () => onTap(items[i])),
        ),
      ),
    ]);
  }
}

class MessageBox extends StatelessWidget {
  final String message;
  final IconData icon;
  final String? action;
  final VoidCallback? onAction;
  const MessageBox({super.key, required this.message, this.icon = Icons.cloud_off_rounded, this.action, this.onAction});
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 40, color: YumeColors.textDim),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: YumeColors.textDim, height: 1.4)),
            if (action != null) ...[
              const SizedBox(height: 14),
              FilledButton.tonal(onPressed: onAction, child: Text(action!)),
            ],
          ]),
        ),
      );
}

/// Banner kecil untuk sumber yang gagal; sumber lain tetap tampil.
class SourceErrorBanner extends StatelessWidget {
  final List<SourceError> errors;
  const SourceErrorBanner(this.errors, {super.key});
  @override
  Widget build(BuildContext context) {
    if (errors.isEmpty) return const SizedBox.shrink();
    final names = errors.map((e) => sourceName(e.source)).join(', ');
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: YumeColors.surfaceHigh, borderRadius: BorderRadius.circular(12),
          border: Border.all(color: YumeColors.glassBorder)),
      child: Row(children: [
        const Icon(Icons.info_outline_rounded, size: 18, color: YumeColors.accentSoft),
        const SizedBox(width: 10),
        Expanded(child: Text('Sumber tidak tersedia saat ini: $names. Data dari sumber lain tetap ditampilkan.',
            style: const TextStyle(fontSize: 12.5, height: 1.35))),
      ]),
    );
  }
}
