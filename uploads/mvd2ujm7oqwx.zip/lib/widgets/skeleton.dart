import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Skeleton ringan: satu AnimationController, hanya opacity (tanpa shader/blur).
class SkeletonPulse extends StatefulWidget {
  final Widget child;
  const SkeletonPulse({super.key, required this.child});
  @override
  State<SkeletonPulse> createState() => _SkeletonPulseState();
}

class _SkeletonPulseState extends State<SkeletonPulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) =>
      FadeTransition(opacity: Tween(begin: 0.45, end: 1.0).animate(_c), child: widget.child);
}

Widget _box(double w, double h, [double r = 12]) => Container(
    width: w, height: h,
    decoration: BoxDecoration(color: YumeColors.surfaceHigh, borderRadius: BorderRadius.circular(r)));

class PosterRowSkeleton extends StatelessWidget {
  const PosterRowSkeleton({super.key});
  @override
  Widget build(BuildContext context) => SkeletonPulse(
        child: SizedBox(
          height: 210,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: 4,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, __) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _box(122, 165, 14), const SizedBox(height: 8), _box(100, 12, 6), const SizedBox(height: 6), _box(60, 10, 6),
            ]),
          ),
        ),
      );
}

class GridSkeleton extends StatelessWidget {
  const GridSkeleton({super.key});
  @override
  Widget build(BuildContext context) => SkeletonPulse(
        child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, childAspectRatio: 0.52, crossAxisSpacing: 10, mainAxisSpacing: 14),
          itemCount: 9,
          itemBuilder: (_, __) => Container(
              decoration: BoxDecoration(color: YumeColors.surfaceHigh, borderRadius: BorderRadius.circular(14))),
        ),
      );
}
