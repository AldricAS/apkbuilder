import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Poster dengan cache dan dekode berukuran kecil (hemat RAM). Tanpa URL = placeholder, bukan gambar karangan.
class PosterImage extends StatelessWidget {
  final String? url;
  final double? width, height;
  final int cacheWidth;
  final BorderRadius radius;
  const PosterImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.cacheWidth = 360,
    this.radius = const BorderRadius.all(Radius.circular(14)),
  });

  @override
  Widget build(BuildContext context) {
    final placeholder = Container(
      width: width,
      height: height,
      color: YumeColors.surfaceHigh,
      alignment: Alignment.center,
      child: const Icon(Icons.image_not_supported_outlined, color: YumeColors.textDim, size: 22),
    );
    return ClipRRect(
      borderRadius: radius,
      child: (url == null || !url!.startsWith('http'))
          ? placeholder
          : CachedNetworkImage(
              imageUrl: url!,
              width: width,
              height: height,
              fit: BoxFit.cover,
              memCacheWidth: cacheWidth,
              fadeInDuration: const Duration(milliseconds: 120),
              placeholder: (_, __) => Container(width: width, height: height, color: YumeColors.surfaceHigh),
              errorWidget: (_, __, ___) => placeholder,
            ),
    );
  }
}
