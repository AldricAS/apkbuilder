/// Konfigurasi build. Nilai diganti lewat --dart-define, bukan dengan mengedit kode.
///
/// flutter build apk --dart-define=API_BASE_URL=https://api.contoh.com \
///                   --dart-define=APP_NAME=YumePlay
class AppConfig {
  static const appName = String.fromEnvironment('APP_NAME', defaultValue: 'YumePlay');

  /// Alamat backend. Sengaja TIDAK ada default ke localhost: APK untuk perangkat lain
  /// harus diberi URL publik. Pengguna juga bisa mengubahnya di Profil > Server.
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');

  /// Token klien opsional (sama dengan CLIENT_TOKEN backend). BUKAN rahasia sejati,
  /// karena ikut terbawa di APK. Jangan pernah mengisinya dengan secret sumber (mis. x-proxy-secret).
  static const apiToken = String.fromEnvironment('API_TOKEN', defaultValue: '');

  static const requestTimeout = Duration(seconds: 45);
  static const maxHistory = 60;
  static const maxSearchHistory = 12;
}
