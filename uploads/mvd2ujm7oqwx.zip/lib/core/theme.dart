import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

/// Palet: abu-kehitaman bertingkat + aksen ungu kebiruan.
class YumeColors {
  static const bg = Color(0xFF14151B);
  static const surface = Color(0xFF1D1F28);
  static const surfaceHigh = Color(0xFF272A36);
  static const accent = Color(0xFF8189FF);
  static const accentSoft = Color(0xFFB4B9FF);
  static const text = Color(0xFFE9EAF2);
  static const textDim = Color(0xFF9A9DB0);
  static const glass = Color(0xB31D1F28); // surface 70%
  static const glassBorder = Color(0x1FFFFFFF);
  static const danger = Color(0xFFFF7A8A);
}

class YumeTheme {
  static const _transitions = PageTransitionsTheme(builders: {
    TargetPlatform.android: CupertinoPageTransitionsBuilder(),
    TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
  });

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: YumeColors.accent,
      brightness: Brightness.dark,
    ).copyWith(
      surface: YumeColors.surface,
      primary: YumeColors.accent,
      onSurface: YumeColors.text,
    );
    return _base(scheme, YumeColors.bg, YumeColors.surfaceHigh);
  }

  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(seedColor: const Color(0xFF5B63E6));
    return _base(scheme, const Color(0xFFF3F3F8), const Color(0xFFE6E7F1));
  }

  static ThemeData _base(ColorScheme scheme, Color bg, Color chip) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      pageTransitionsTheme: _transitions,
      splashFactory: InkRipple.splashFactory,
      appBarTheme: AppBarTheme(
        backgroundColor: bg,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
            color: scheme.onSurface, fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: -0.2),
      ),
      textTheme: const TextTheme(
        titleLarge: TextStyle(fontWeight: FontWeight.w700, letterSpacing: -0.3),
        titleMedium: TextStyle(fontWeight: FontWeight.w600, letterSpacing: -0.1),
        bodyMedium: TextStyle(height: 1.4),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: chip,
        selectedColor: scheme.primary.withOpacity(0.28),
        side: BorderSide.none,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        labelStyle: TextStyle(color: scheme.onSurface, fontSize: 12.5),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: chip,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
    );
  }
}
