String sourceName(String id) {
  switch (id) {
    case 'kuramanime': return 'Kuramanime';
    case 'nanimeid': return 'Nanimeid';
    case 'samehadaku': return 'SameHadaku';
    case 'alqanime': return 'Alqanime';
    case 'animein': return 'Animein';
    default: return id;
  }
}

String fmtDuration(Duration d) {
  String two(int n) => n.toString().padLeft(2, '0');
  final h = d.inHours;
  final m = d.inMinutes.remainder(60);
  final s = d.inSeconds.remainder(60);
  return h > 0 ? '$h:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
}

String fmtEpisodeNumber(double? n) {
  if (n == null) return '';
  return n == n.roundToDouble() ? n.toInt().toString() : n.toString();
}
