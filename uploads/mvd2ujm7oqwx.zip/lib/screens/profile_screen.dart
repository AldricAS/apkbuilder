import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../core/app_config.dart';
import '../core/theme.dart';
import '../providers/providers.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  Future<void> _editText(BuildContext c, String title, String initial, String hint, void Function(String) save) async {
    final ctl = TextEditingController(text: initial);
    final v = await showDialog<String>(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: ctl, autofocus: true, decoration: InputDecoration(hintText: hint)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(c, ctl.text), child: const Text('Simpan')),
        ],
      ),
    );
    if (v != null) save(v.trim());
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    final favs = ref.watch(favoritesProvider).length;
    final hist = ref.watch(historyProvider).length;
    final sources = ref.watch(sourcesInfoProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Profil')),
      body: ListView(padding: const EdgeInsets.only(bottom: 32), children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            CircleAvatar(
              radius: 32, backgroundColor: YumeColors.surfaceHigh,
              child: Text(s.userName.isEmpty ? '?' : s.userName[0].toUpperCase(),
                  style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: YumeColors.accent)),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s.userName, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                const Text('Profil lokal di perangkat ini', style: TextStyle(color: YumeColors.textDim, fontSize: 12.5)),
              ]),
            ),
            IconButton(
                onPressed: () => _editText(context, 'Nama pengguna', s.userName, 'Nama', (v) { if (v.isNotEmpty) n.setUserName(v); }),
                icon: const Icon(Icons.edit_outlined)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            _Stat(label: 'Favorit', value: favs),
            const SizedBox(width: 12),
            _Stat(label: 'Riwayat tontonan', value: hist),
          ]),
        ),
        const _Header('Tampilan'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'dark', label: Text('Gelap'), icon: Icon(Icons.dark_mode_outlined)),
              ButtonSegment(value: 'light', label: Text('Terang'), icon: Icon(Icons.light_mode_outlined)),
              ButtonSegment(value: 'system', label: Text('Sistem'), icon: Icon(Icons.phone_android_rounded)),
            ],
            selected: {s.themeMode},
            onSelectionChanged: (v) => n.setTheme(v.first),
          ),
        ),
        const _Header('Pemutar'),
        SwitchListTile(
            title: const Text('Putar episode berikutnya otomatis'),
            value: s.autoNext, onChanged: n.setAutoNext),
        SwitchListTile(
            title: const Text('Lanjutkan dari posisi terakhir'),
            value: s.resume, onChanged: n.setResume),
        const _Header('Sumber scraper'),
        sources.when(
          loading: () => const Padding(padding: EdgeInsets.all(16), child: LinearProgressIndicator()),
          error: (e, _) => ListTile(
              leading: const Icon(Icons.cloud_off_rounded),
              title: const Text('Daftar sumber tidak bisa dimuat'),
              subtitle: Text('$e'),
              trailing: IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () => ref.invalidate(sourcesInfoProvider))),
          data: (list) => Column(children: [
            for (final src in list)
              CheckboxListTile(
                title: Text(src.name),
                subtitle: Text(_caps(src.capabilities), style: const TextStyle(fontSize: 12)),
                value: s.sources.isEmpty || s.sources.contains(src.id),
                onChanged: (v) {
                  final current = s.sources.isEmpty ? list.map((e) => e.id).toList() : List<String>.from(s.sources);
                  v == true ? current.add(src.id) : current.remove(src.id);
                  if (current.isEmpty) return; // minimal satu sumber
                  final uniq = current.toSet().toList();
                  n.setSources(uniq.length == list.length ? [] : uniq);
                  ref.invalidate(homeProvider);
                },
              ),
          ]),
        ),
        const _Header('Server'),
        ListTile(
          leading: const Icon(Icons.dns_outlined),
          title: const Text('Alamat backend'),
          subtitle: Text(s.baseUrl.isEmpty ? 'Belum diatur' : s.baseUrl),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => _editText(context, 'Alamat backend', s.baseUrl, 'https://api.contoh.com', (v) {
            n.setBaseUrl(v);
            ref.invalidate(homeProvider);
            ref.invalidate(sourcesInfoProvider);
          }),
        ),
        const _Header('Data'),
        ListTile(
          leading: const Icon(Icons.cleaning_services_outlined),
          title: const Text('Hapus cache gambar'),
          onTap: () async {
            await DefaultCacheManager().emptyCache();
            PaintingBinding.instance.imageCache.clear();
            PaintingBinding.instance.imageCache.clearLiveImages();
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cache gambar dihapus')));
          },
        ),
        ListTile(
          leading: const Icon(Icons.history_toggle_off_rounded),
          title: const Text('Hapus riwayat'),
          subtitle: const Text('Riwayat tontonan dan pencarian. Favorit tidak ikut terhapus.'),
          onTap: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (c) => AlertDialog(
                title: const Text('Hapus riwayat?'),
                content: const Text('Riwayat tontonan dan pencarian akan dihapus permanen.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
                  FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Hapus')),
                ],
              ),
            );
            if (ok == true) {
              await ref.read(historyProvider.notifier).clear();
              ref.invalidate(searchHistoryProvider);
            }
          },
        ),
        const _Header('Tentang'),
        FutureBuilder<PackageInfo>(
          future: PackageInfo.fromPlatform(),
          builder: (_, snap) => ListTile(
            leading: const Icon(Icons.info_outline_rounded),
            title: Text(AppConfig.appName),
            subtitle: Text(snap.hasData ? 'Versi ${snap.data!.version} (${snap.data!.buildNumber})' : 'Versi …'),
          ),
        ),
      ]),
    );
  }

  String _caps(Map<String, dynamic> c) {
    final names = {
      'home': 'beranda', 'latest': 'terbaru', 'ongoing': 'ongoing', 'completed': 'completed',
      'search': 'cari', 'detail': 'detail', 'episode': 'episode',
    };
    final on = names.entries.where((e) => c[e.key] == true).map((e) => e.value).join(', ');
    final extra = [
      if (c['downloadOnly'] == true) 'hanya unduhan',
      if (c['unverifiedShape'] == true) 'format belum terverifikasi',
    ].join(' · ');
    return extra.isEmpty ? on : '$on · $extra';
  }
}

class _Header extends StatelessWidget {
  final String t;
  const _Header(this.t);
  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 22, 16, 8),
      child: Text(t, style: const TextStyle(fontSize: 13, color: YumeColors.accentSoft, fontWeight: FontWeight.w700)));
}

class _Stat extends StatelessWidget {
  final String label;
  final int value;
  const _Stat({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: YumeColors.surface, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: YumeColors.glassBorder)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$value', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(color: YumeColors.textDim, fontSize: 12.5)),
          ]),
        ),
      );
}
