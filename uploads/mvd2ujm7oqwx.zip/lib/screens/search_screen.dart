import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/format.dart';
import '../core/theme.dart';
import '../models/anime.dart';
import '../providers/providers.dart';
import '../widgets/anime_card.dart';
import '../widgets/poster_image.dart';
import 'nav.dart';

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});
  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _ctl = TextEditingController();
  final _sc = ScrollController();
  Timer? _debounce;
  String _q = '';
  // filter lokal (hanya memakai data yang benar-benar ada pada hasil)
  String? _fSource, _fStatus, _fGenre, _fYear;

  @override
  void initState() {
    super.initState();
    _sc.addListener(() {
      if (_q.isNotEmpty && _sc.position.pixels > _sc.position.maxScrollExtent - 400) {
        ref.read(searchProvider(SearchQuery(_q)).notifier).loadMore();
      }
    });
  }

  @override
  void dispose() { _debounce?.cancel(); _ctl.dispose(); _sc.dispose(); super.dispose(); }

  void _onChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      final q = v.trim();
      setState(() { _q = q.length >= 2 ? q : ''; _fSource = _fStatus = _fGenre = _fYear = null; });
      if (q.length >= 2) ref.read(searchHistoryProvider.notifier).add(q);
    });
  }

  void _run(String q) {
    _ctl.text = q;
    _ctl.selection = TextSelection.collapsed(offset: q.length);
    setState(() { _q = q; _fSource = _fStatus = _fGenre = _fYear = null; });
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cari Anime')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          child: TextField(
            controller: _ctl,
            onChanged: _onChanged,
            textInputAction: TextInputAction.search,
            onSubmitted: (v) { _debounce?.cancel(); if (v.trim().length >= 2) _run(v.trim()); ref.read(searchHistoryProvider.notifier).add(v); },
            decoration: InputDecoration(
              hintText: 'Judul anime…',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _ctl.text.isEmpty ? null : IconButton(
                  icon: const Icon(Icons.close_rounded),
                  onPressed: () { _ctl.clear(); setState(() => _q = ''); }),
            ),
          ),
        ),
        Expanded(child: _q.isEmpty ? _history() : _results()),
      ]),
    );
  }

  Widget _history() {
    final h = ref.watch(searchHistoryProvider);
    if (h.isEmpty) return const MessageBox(message: 'Ketik minimal 2 huruf untuk mencari di semua sumber aktif.', icon: Icons.search_rounded);
    return ListView(padding: const EdgeInsets.symmetric(horizontal: 16), children: [
      const Padding(padding: EdgeInsets.only(top: 8, bottom: 6), child: Text('Pencarian terakhir', style: TextStyle(color: YumeColors.textDim))),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final q in h)
          InputChip(label: Text(q), onPressed: () => _run(q), onDeleted: () => ref.read(searchHistoryProvider.notifier).remove(q)),
      ]),
    ]);
  }

  List<AnimeSummary> _filtered(List<AnimeSummary> all) => all.where((a) {
        if (_fSource != null && a.source != _fSource && !a.alsoOn.any((o) => o.source == _fSource)) return false;
        if (_fStatus != null && a.status?.toLowerCase() != _fStatus) return false;
        if (_fGenre != null && !a.genres.contains(_fGenre)) return false;
        if (_fYear != null && a.year != _fYear) return false;
        return true;
      }).toList();

  Widget _results() {
    final st = ref.watch(searchProvider(SearchQuery(_q)));
    if (!st.initialDone && st.error == null) return const Center(child: CircularProgressIndicator());
    if (st.items.isEmpty) {
      return MessageBox(
        icon: st.error != null ? Icons.cloud_off_rounded : Icons.search_off_rounded,
        message: st.error ?? (st.errors.isNotEmpty
            ? 'Tidak ada hasil, dan ${st.errors.length} sumber gagal dihubungi.'
            : 'Tidak ada hasil untuk "$_q".'),
      );
    }
    final items = _filtered(st.items);
    final sources = {for (final a in st.items) ...[a.source, ...a.alsoOn.map((o) => o.source)]}.toList()..sort();
    final statuses = {for (final a in st.items) if (a.status != null) a.status!.toLowerCase()}.toList()..sort();
    final genres = {for (final a in st.items) ...a.genres}.toList()..sort();
    final years = {for (final a in st.items) if (a.year != null) a.year!}.toList()..sort();

    Widget chips(String label, List<String> opts, String? cur, void Function(String?) set, {String Function(String)? name}) {
      if (opts.isEmpty) return const SizedBox.shrink();
      return PopupMenuButton<String?>(
        onSelected: (v) => setState(() => set(v == '' ? null : v)),
        itemBuilder: (_) => [
          const PopupMenuItem(value: '', child: Text('Semua')),
          for (final o in opts) PopupMenuItem(value: o, child: Text(name?.call(o) ?? o)),
        ],
        child: Chip(
          label: Text(cur == null ? label : '$label: ${name?.call(cur) ?? cur}'),
          backgroundColor: cur == null ? null : YumeColors.accent.withOpacity(0.3),
          avatar: const Icon(Icons.expand_more_rounded, size: 16),
        ),
      );
    }

    return Column(children: [
      SizedBox(
        height: 42,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
          chips('Sumber', sources, _fSource, (v) => _fSource = v, name: sourceName), const SizedBox(width: 8),
          chips('Status', statuses, _fStatus, (v) => _fStatus = v), const SizedBox(width: 8),
          chips('Genre', genres, _fGenre, (v) => _fGenre = v), const SizedBox(width: 8),
          chips('Tahun', years, _fYear, (v) => _fYear = v),
        ]),
      ),
      SourceErrorBanner(st.errors),
      Expanded(
        child: items.isEmpty
            ? const MessageBox(message: 'Tidak ada hasil yang cocok dengan filter.', icon: Icons.filter_alt_off_rounded)
            : ListView.builder(
                controller: _sc,
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                itemCount: items.length + 1,
                itemBuilder: (_, i) {
                  if (i == items.length) {
                    return Padding(padding: const EdgeInsets.all(16),
                        child: Center(child: st.loading ? const CircularProgressIndicator(strokeWidth: 2.4) : const SizedBox.shrink()));
                  }
                  return _ResultTile(anime: items[i], onTap: () => openAnime(context, items[i]));
                },
              ),
      ),
    ]);
  }
}

class _ResultTile extends StatelessWidget {
  final AnimeSummary anime;
  final VoidCallback onTap;
  const _ResultTile({required this.anime, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final meta = [anime.type, anime.status, anime.year, anime.episodeInfo].whereType<String>().join(' · ');
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(children: [
          PosterImage(url: anime.poster, width: 62, height: 88, cacheWidth: 200, radius: BorderRadius.circular(10)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(anime.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14.5)),
              if (meta.isNotEmpty)
                Padding(padding: const EdgeInsets.only(top: 3),
                    child: Text(meta, style: const TextStyle(color: YumeColors.textDim, fontSize: 12))),
              const SizedBox(height: 6),
              Wrap(spacing: 6, runSpacing: 4, children: [
                SourceBadge(anime.source),
                for (final o in anime.alsoOn) SourceBadge(o.source),
                if (anime.rating != null)
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.star_rounded, size: 14, color: YumeColors.accentSoft),
                    Text(' ${anime.rating!.toStringAsFixed(1)}', style: const TextStyle(fontSize: 12)),
                  ]),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}
