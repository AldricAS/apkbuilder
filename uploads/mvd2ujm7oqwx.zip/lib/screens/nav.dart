import 'package:flutter/material.dart';
import '../models/anime.dart';
import 'detail_screen.dart';

void openAnime(BuildContext context, AnimeSummary a) {
  Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => DetailScreen(summary: a)));
}
