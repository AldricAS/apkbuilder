import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../providers/providers.dart';
import '../widgets/anime_card.dart';
import '../widgets/skeleton.dart';
import 'nav.dart';

class OngoingScreen extends StatelessWidget {
  const OngoingScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Jelajah'),
          bottom: const TabBar(
            indicatorColor: YumeColors.accent,
            dividerColor: Colors.transparent,
            tabs: [Tab(text: 'Ongoing'), Tab(text: 'Terbaru'), Tab(text: 'Completed')],
          ),
        ),
        body: const TabBarView(children: [
          _PagedGrid(kind: 'ongoing'),
          _PagedGrid(kind: 'latest'),
          _PagedGrid(kind: 'completed'),
        ]),
      ),
    );
  }
}

class _PagedGrid extends ConsumerStatefulWidget {
  final String kind;
  const _PagedGrid({required this.kind});
  @override
  ConsumerState<_PagedGrid> createState() => _PagedGridState();
}

class _PagedGridState extends ConsumerState<_PagedGrid> with AutomaticKeepAliveClientMixin {
  final _sc = ScrollController();
  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _sc.addListener(() {
      if (_sc.position.pixels > _sc.position.maxScrollExtent - 500) {
        ref.read(listProvider(widget.kind).notifier).loadMore();
      }
    });
  }

  @override
  void dispose() { _sc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final st = ref.watch(listProvider(widget.kind));
    final notifier = ref.read(listProvider(widget.kind).notifier);

    if (!st.initialDone && st.error == null) return const GridSkeleton();
    if (st.items.isEmpty) {
      return MessageBox(
        message: st.error ?? 'Tidak ada data. Sumber aktif mungkin tidak mendukung daftar "${widget.kind}" atau sedang gagal.',
        action: 'Muat ulang',
        onAction: notifier.refresh,
      );
    }
    return RefreshIndicator(
      color: YumeColors.accent,
      onRefresh: notifier.refresh,
      child: CustomScrollView(
        controller: _sc,
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: SourceErrorBanner(st.errors)),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverGrid.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, childAspectRatio: 0.52, crossAxisSpacing: 10, mainAxisSpacing: 14),
              itemCount: st.items.length,
              itemBuilder: (_, i) => AnimeCard(anime: st.items[i], width: null, onTap: () => openAnime(context, st.items[i])),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 24),
              child: Center(
                child: st.loading
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4))
                    : st.error != null
                        ? TextButton(onPressed: notifier.loadMore, child: const Text('Gagal memuat. Coba lagi'))
                        : const SizedBox.shrink(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
