import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/format.dart';
import '../core/theme.dart';
import '../models/anime.dart';
import '../player/player_screen.dart';
import '../providers/providers.dart';
import '../widgets/anime_card.dart';
import '../widgets/poster_image.dart';
import 'nav.dart';

class DetailScreen extends ConsumerStatefulWidget {
  final AnimeSummary summary;
  const DetailScreen({super.key, required this.summary});
  @override
  ConsumerState<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends ConsumerState<DetailScreen> {
  bool _expanded = false;
  bool _descending = true;

  AnimeRef get _ref => AnimeRef(widget.summary.source, widget.summary.key);

  void _play(AnimeDetail d, EpisodeItem ep) {
    if (!ep.streamable) {
      _showDownloads(d, ep);
      return;
    }
    final idx = d.episodes.indexWhere((e) => e.ref == ep.ref);
    Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => PlayerScreen(detail: d, index: idx < 0 ? 0 : idx)));
  }

  /// Sumber tanpa streaming (mis. Alqanime): tampilkan tautan unduhan, buka di browser.
  Future<void> _showDownloads(AnimeDetail d, EpisodeItem ep) async {
    final key = EpisodeRef(d.base.source, d.base.key, ep.ref);
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => Consumer(builder: (c, ref, _) {
        final async = ref.watch(episodeProvider(key));
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(c).size.height * 0.7),
            child: async.when(
              loading: () => const SizedBox(height: 160, child: Center(child: CircularProgressIndicator())),
              error: (e, _) => SizedBox(height: 200, child: MessageBox(message: '$e')),
              data: (p) => ListView(shrinkWrap: true, padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
                Text(ep.label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(p.note ?? 'Tautan unduhan dari sumber. Dibuka di browser.',
                    style: const TextStyle(color: YumeColors.textDim, fontSize: 12.5)),
                const SizedBox(height: 8),
                for (final s in p.sources)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.download_rounded),
                    title: Text(s.title.isEmpty ? s.url : s.title),
                    onTap: () => launchUrl(Uri.parse(s.url), mode: LaunchMode.externalApplication),
                  ),
              ]),
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(detailProvider(_ref));
    final fav = ref.watch(favoritesProvider.select((l) => l.any((e) => e.id == widget.summary.id)));
    final history = ref.watch(historyProvider.select((l) {
      for (final e in l) {
        if (e.anime.id == widget.summary.id) return e;
      }
      return null;
    }));
    final s = widget.summary;

    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 250,
          backgroundColor: YumeColors.bg,
          actions: [
            IconButton(
              tooltip: 'Favorit',
              icon: Icon(fav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  color: fav ? YumeColors.accent : null),
              onPressed: () => ref.read(favoritesProvider.notifier).toggle(s),
            ),
          ],
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(fit: StackFit.expand, children: [
              PosterImage(
                  url: async.valueOrNull?.cover ?? s.poster, cacheWidth: 700, radius: BorderRadius.zero),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Color(0x6614151B), Color(0xFF14151B)], stops: [0.2, 1]),
                ),
              ),
            ]),
          ),
        ),
        SliverToBoxAdapter(child: _header(context, s, async.valueOrNull)),
        ...async.when(
          loading: () => [const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())))],
          error: (e, _) => [SliverToBoxAdapter(child: SizedBox(height: 260, child: MessageBox(
              message: '$e', action: 'Coba lagi', onAction: () => ref.invalidate(detailProvider(_ref)))))],
          data: (d) => _body(context, d, history),
        ),
      ]),
    );
  }

  Widget _header(BuildContext context, AnimeSummary s, AnimeDetail? d) {
    final meta = <String>[
      if (d?.base.type != null || s.type != null) (d?.base.type ?? s.type)!,
      if ((d?.base.status ?? s.status) != null) (d?.base.status ?? s.status)!,
      if ((d?.base.year ?? s.year) != null) (d?.base.year ?? s.year)!,
      if (d?.studio != null) d!.studio!,
      if (d?.totalEpisodes != null) '${d!.totalEpisodes} episode',
    ];
    final rating = d?.base.rating ?? s.rating;
    final genres = (d?.base.genres.isNotEmpty ?? false) ? d!.base.genres : s.genres;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(s.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800, height: 1.15, letterSpacing: -0.4)),
        if (d?.altTitles != null)
          Padding(padding: const EdgeInsets.only(top: 4),
              child: Text(d!.altTitles!, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: YumeColors.textDim, fontSize: 13))),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [
          SourceBadge(s.source),
          if (rating != null)
            Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.star_rounded, size: 16, color: YumeColors.accentSoft),
              Text(' ${rating.toStringAsFixed(1)}', style: const TextStyle(fontWeight: FontWeight.w700)),
            ]),
          if (meta.isNotEmpty) Text(meta.join(' · '), style: const TextStyle(color: YumeColors.textDim, fontSize: 12.5)),
        ]),
        if (genres.isNotEmpty) ...[
          const SizedBox(height: 10),
          Wrap(spacing: 6, runSpacing: 6, children: [for (final g in genres) Chip(label: Text(g), visualDensity: VisualDensity.compact)]),
        ],
        if (s.alsoOn.isNotEmpty) ...[
          const SizedBox(height: 14),
          const Text('Tersedia juga di', style: TextStyle(color: YumeColors.textDim, fontSize: 12.5)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, children: [
            for (final o in s.alsoOn)
              ActionChip(
                label: Text(sourceName(o.source)),
                onPressed: () => openAnime(context, AnimeSummary(id: o.id, source: o.source, key: o.key, title: s.title, poster: s.poster)),
              ),
          ]),
        ],
      ]),
    );
  }

  List<Widget> _body(BuildContext context, AnimeDetail d, HistoryEntry? history) {
    final eps = [...d.episodes]..sort((a, b) => (a.number ?? 0).compareTo(b.number ?? 0));
    final shown = _descending ? eps.reversed.toList() : eps;
    final firstStreamable = eps.where((e) => e.streamable).cast<EpisodeItem?>().firstOrNull;
    EpisodeItem? resume;
    if (history != null) {
      for (final e in eps) {
        if (e.ref == history.episodeRef) resume = e;
      }
    }
    final start = resume ?? firstStreamable;

    return [
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: start == null ? null : () => _play(d, start),
                icon: const Icon(Icons.play_arrow_rounded),
                label: Text(start == null
                    ? 'Tidak ada episode yang bisa ditonton'
                    : resume != null ? 'Lanjutkan ${resume.label}' : 'Mulai Menonton'),
                style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              ),
            ),
            if (d.synopsis != null) ...[
              const SizedBox(height: 18),
              const Text('Sinopsis', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              AnimatedSize(
                duration: const Duration(milliseconds: 180),
                alignment: Alignment.topCenter,
                child: Text(d.synopsis!, maxLines: _expanded ? null : 4, overflow: _expanded ? null : TextOverflow.ellipsis,
                    style: const TextStyle(height: 1.45, color: YumeColors.textDim)),
              ),
              if (d.synopsis!.length > 200)
                TextButton(onPressed: () => setState(() => _expanded = !_expanded), child: Text(_expanded ? 'Lebih sedikit' : 'Selengkapnya')),
            ],
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: Text('Episode (${eps.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
              TextButton.icon(
                onPressed: () => setState(() => _descending = !_descending),
                icon: Icon(_descending ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded, size: 16),
                label: Text(_descending ? 'Terbaru dulu' : 'Terlama dulu'),
              ),
            ]),
          ]),
        ),
      ),
      if (eps.isEmpty)
        const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(24), child: Text('Sumber ini tidak menyediakan daftar episode.', style: TextStyle(color: YumeColors.textDim))))
      else
        SliverList.builder(
          itemCount: shown.length,
          itemBuilder: (_, i) {
            final e = shown[i];
            final current = history?.episodeRef == e.ref;
            return ListTile(
              dense: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 20),
              leading: Icon(e.streamable ? Icons.play_circle_outline_rounded : Icons.download_rounded,
                  color: current ? YumeColors.accent : YumeColors.textDim),
              title: Text(e.label, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: current ? FontWeight.w700 : FontWeight.w500)),
              subtitle: e.date != null ? Text(e.date!, style: const TextStyle(fontSize: 11.5)) : (!e.streamable ? const Text('Hanya tautan unduhan', style: TextStyle(fontSize: 11.5)) : null),
              onTap: () => _play(d, e),
            );
          },
        ),
      if (d.related.any((r) => r.key != null && r.title != null))
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Terkait', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final r in d.related.where((r) => r.key != null && r.title != null))
                  ActionChip(
                    label: Text(r.relation == null ? r.title! : '${r.title!} (${r.relation})'),
                    onPressed: () => openAnime(context, AnimeSummary(id: '${r.source}:${r.key}', source: r.source, key: r.key!, title: r.title!)),
                  ),
              ]),
            ]),
          ),
        ),
      const SliverToBoxAdapter(child: SizedBox(height: 40)),
    ];
  }
}
