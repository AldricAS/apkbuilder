import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../widgets/anime_card.dart';
import 'nav.dart';

class FavoritesScreen extends ConsumerWidget {
  const FavoritesScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favs = ref.watch(favoritesProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Favorit')),
      body: favs.isEmpty
          ? const MessageBox(icon: Icons.favorite_border_rounded, message: 'Belum ada favorit. Buka detail anime lalu ketuk tombol Favorit.')
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, childAspectRatio: 0.52, crossAxisSpacing: 10, mainAxisSpacing: 14),
              itemCount: favs.length,
              itemBuilder: (_, i) => AnimeCard(anime: favs[i], width: null, onTap: () => openAnime(context, favs[i])),
            ),
    );
  }
}
