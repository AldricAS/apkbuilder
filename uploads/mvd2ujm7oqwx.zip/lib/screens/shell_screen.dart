import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'favorites_screen.dart';
import 'home_screen.dart';
import 'ongoing_screen.dart';
import 'profile_screen.dart';
import 'search_screen.dart';

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key});
  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int _index = 0;
  final _built = <int>{0}; // tab dibangun saat pertama dibuka (hemat RAM)

  void go(int i) => setState(() { _index = i; _built.add(i); });

  Widget _tab(int i) {
    if (!_built.contains(i)) return const SizedBox.shrink();
    switch (i) {
      case 0: return HomeScreen(onSearch: () => go(2));
      case 1: return const OngoingScreen();
      case 2: return const SearchScreen();
      case 3: return const FavoritesScreen();
      default: return const ProfileScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: List.generate(5, _tab)),
      bottomNavigationBar: _NavBar(index: _index, onTap: go),
    );
  }
}

class _NavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const _NavBar({required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;
    Widget item(int i, IconData icon, IconData active, String label) {
      final sel = index == i;
      return Expanded(
        child: InkResponse(
          onTap: () => onTap(i),
          radius: 32,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(sel ? active : icon, size: 24, color: sel ? YumeColors.accent : YumeColors.textDim),
            const SizedBox(height: 3),
            Text(label,
                style: TextStyle(fontSize: 10.5, fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                    color: sel ? YumeColors.accent : YumeColors.textDim)),
          ]),
        ),
      );
    }

    final searchSel = index == 2;
    return Container(
      padding: EdgeInsets.only(top: 8, bottom: bottom + 8),
      decoration: const BoxDecoration(
        color: YumeColors.glass,
        border: Border(top: BorderSide(color: YumeColors.glassBorder)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        item(0, Icons.home_outlined, Icons.home_rounded, 'Home'),
        item(1, Icons.play_circle_outline_rounded, Icons.play_circle_rounded, 'Ongoing'),
        // Tombol Search di tengah: lingkaran aksen yang sedikit menonjol
        Expanded(
          child: Transform.translate(
            offset: const Offset(0, -14),
            child: GestureDetector(
              onTap: () => onTap(2),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 54, height: 54,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: searchSel ? YumeColors.accent : YumeColors.surfaceHigh,
                    border: Border.all(color: YumeColors.accent, width: 1.6),
                    boxShadow: const [BoxShadow(color: Color(0x668189FF), blurRadius: 10, offset: Offset(0, 3))],
                  ),
                  child: Icon(Icons.search_rounded, size: 27,
                      color: searchSel ? YumeColors.bg : YumeColors.accentSoft),
                ),
                const SizedBox(height: 3),
                Text('Search',
                    style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700,
                        color: searchSel ? YumeColors.accent : YumeColors.textDim)),
              ]),
            ),
          ),
        ),
        item(3, Icons.favorite_border_rounded, Icons.favorite_rounded, 'Favorit'),
        item(4, Icons.person_outline_rounded, Icons.person_rounded, 'Profil'),
      ]),
    );
  }
}
