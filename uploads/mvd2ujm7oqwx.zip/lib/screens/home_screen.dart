import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/app_config.dart';
import '../core/format.dart';
import '../core/theme.dart';
import '../models/anime.dart';
import '../providers/providers.dart';
import '../widgets/anime_card.dart';
import '../widgets/poster_image.dart';
import '../widgets/skeleton.dart';
import 'nav.dart';

class HomeScreen extends ConsumerWidget {
  final VoidCallback onSearch;
  const HomeScreen({super.key, required this.onSearch});

  Future<void> _refresh(WidgetRef ref) async {
    ref.invalidate(homeProvider);
    ref.read(listProvider('ongoing').notifier).refresh();
    ref.read(listProvider('completed').notifier).refresh();
    await ref.read(homeProvider.future).catchError((_) => const HomeData([], []));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final home = ref.watch(homeProvider);
    final ongoing = ref.watch(listProvider('ongoing'));
    final completed = ref.watch(listProvider('completed'));
    final history = ref.watch(historyProvider);

    final sections = home.valueOrNull?.sections ?? const <HomeSection>[];
    final featured = <AnimeSummary>[
      for (final s in sections) ...s.items.where((a) => a.poster != null).take(2),
    ].take(5).toList();

    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 30, height: 30,
            decoration: BoxDecoration(color: YumeColors.accent, borderRadius: BorderRadius.circular(9)),
            child: const Icon(Icons.play_arrow_rounded, color: YumeColors.bg, size: 22),
          ),
          const SizedBox(width: 10),
          const Text(AppConfig.appName),
        ]),
        actions: [
          IconButton(onPressed: () => _refresh(ref), icon: const Icon(Icons.refresh_rounded), tooltip: 'Muat ulang'),
          IconButton(onPressed: onSearch, icon: const Icon(Icons.search_rounded), tooltip: 'Cari'),
        ],
      ),
      body: RefreshIndicator(
        color: YumeColors.accent,
        onRefresh: () => _refresh(ref),
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            if (home.hasError)
              SizedBox(
                height: 360,
                child: MessageBox(
                  message: home.error.toString(),
                  action: 'Coba lagi',
                  onAction: () => ref.invalidate(homeProvider),
                ),
              ),
            if (home.valueOrNull != null) SourceErrorBanner(home.value!.errors),
            if (home.isLoading && !home.hasValue) ...[
              const Padding(padding: EdgeInsets.all(16), child: SkeletonPulse(child: _BannerBox())),
              const PosterRowSkeleton(),
            ],
            if (featured.isNotEmpty) _Banner(items: featured),
            if (history.isNotEmpty) _HistoryRow(history: history),
            for (final s in sections)
              AnimeRow(
                title: '${_cap(s.title)} · ${sourceName(s.source)}',
                items: s.items,
                onTap: (a) => openAnime(context, a),
              ),
            _listRow(context, ref, 'Anime Ongoing', ongoing, 'ongoing'),
            _listRow(context, ref, 'Anime Completed', completed, 'completed'),
            if (home.hasValue && sections.isEmpty && ongoing.initialDone && ongoing.items.isEmpty)
              const SizedBox(height: 220, child: MessageBox(message: 'Tidak ada data dari sumber yang aktif saat ini.')),
          ],
        ),
      ),
    );
  }

  Widget _listRow(BuildContext context, WidgetRef ref, String title, PagedState st, String kind) {
    if (!st.initialDone && st.error == null) return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 20, 16, 10), child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600))),
      const PosterRowSkeleton(),
    ]);
    // Sumber yang mendukung kind ini mungkin tidak ada/gagal: baris disembunyikan (tidak diisi data palsu).
    return AnimeRow(title: title, items: st.items, onTap: (a) => openAnime(context, a));
  }
}

class _BannerBox extends StatelessWidget {
  const _BannerBox();
  @override
  Widget build(BuildContext context) => Container(
      height: 190, decoration: BoxDecoration(color: YumeColors.surfaceHigh, borderRadius: BorderRadius.circular(20)));
}

class _Banner extends StatefulWidget {
  final List<AnimeSummary> items;
  const _Banner({required this.items});
  @override
  State<_Banner> createState() => _BannerState();
}

class _BannerState extends State<_Banner> {
  final _c = PageController(viewportFraction: 0.92);
  int _i = 0;
  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      const SizedBox(height: 8),
      SizedBox(
        height: 200,
        child: PageView.builder(
          controller: _c,
          itemCount: widget.items.length,
          onPageChanged: (v) => setState(() => _i = v),
          itemBuilder: (_, i) {
            final a = widget.items[i];
            return GestureDetector(
              onTap: () => openAnime(context, a),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Stack(fit: StackFit.expand, children: [
                    PosterImage(url: a.poster, cacheWidth: 700, radius: BorderRadius.zero),
                    const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                            colors: [Color(0x00000000), Color(0xE614151B)], stops: [0.35, 1]),
                      ),
                    ),
                    Positioned(left: 14, right: 14, bottom: 14,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                        SourceBadge(a.source),
                        const SizedBox(height: 6),
                        Text(a.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Colors.white, height: 1.15)),
                      ]),
                    ),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
      const SizedBox(height: 8),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (var k = 0; k < widget.items.length; k++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: k == _i ? 18 : 6, height: 6,
            decoration: BoxDecoration(
                color: k == _i ? YumeColors.accent : YumeColors.surfaceHigh, borderRadius: BorderRadius.circular(3)),
          ),
      ]),
    ]);
  }
}

class _HistoryRow extends StatelessWidget {
  final List<HistoryEntry> history;
  const _HistoryRow({required this.history});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
        child: Text('Terakhir Ditonton', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 17)),
      ),
      SizedBox(
        height: 112,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: history.length > 10 ? 10 : history.length,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (_, i) {
            final h = history[i];
            return GestureDetector(
              onTap: () => openAnime(context, h.anime),
              child: Container(
                width: 250,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: YumeColors.surface, borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: YumeColors.glassBorder)),
                child: Row(children: [
                  PosterImage(url: h.anime.poster, width: 64, height: 94, cacheWidth: 200, radius: BorderRadius.circular(10)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(h.anime.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 3),
                      Text(h.episodeNumber != null ? 'Episode ${fmtEpisodeNumber(h.episodeNumber)}' : 'Lanjutkan',
                          style: const TextStyle(fontSize: 11.5, color: YumeColors.textDim)),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(3),
                        child: LinearProgressIndicator(
                            value: h.progress, minHeight: 4,
                            backgroundColor: YumeColors.surfaceHigh, color: YumeColors.accent),
                      ),
                    ]),
                  ),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }
}

String _cap(String t) => t.isEmpty ? t : '${t[0].toUpperCase()}${t.substring(1)}';
