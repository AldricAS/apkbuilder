import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import '../core/format.dart';
import '../core/theme.dart';
import '../models/anime.dart';
import '../providers/providers.dart';

enum _Status { loading, ready, noPlayable, error }

/// Pemutar: hanya sumber `playable` (HLS / video langsung) yang diputar oleh video_player.
/// Embed dan tautan unduhan TIDAK diputar di sini; keduanya ditawarkan untuk dibuka di browser.
class PlayerScreen extends ConsumerStatefulWidget {
  final AnimeDetail detail;
  final int index; // indeks pada detail.episodes
  const PlayerScreen({super.key, required this.detail, required this.index});
  @override
  ConsumerState<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends ConsumerState<PlayerScreen> {
  late final List<EpisodeItem> _eps; // hanya yang bisa di-stream, urut naik
  late int _pos;
  VideoPlayerController? _ctrl;
  EpisodePayload? _payload;
  int _srcIdx = 0;
  _Status _status = _Status.loading;
  String? _error;
  bool _fullscreen = false, _controls = true, _advancing = false;
  double _volume = 1;
  Timer? _hideTimer;
  int _lastSaveMs = 0;
  int _loadToken = 0; // membatalkan pemuatan lama bila pengguna berpindah episode

  AnimeSummary get _anime => widget.detail.base;
  EpisodeItem get _ep => _eps[_pos];

  @override
  void initState() {
    super.initState();
    final all = widget.detail.episodes.where((e) => e.streamable).toList()
      ..sort((a, b) => (a.number ?? 0).compareTo(b.number ?? 0));
    _eps = all.isEmpty ? [widget.detail.episodes[widget.index]] : all;
    final target = widget.detail.episodes[widget.index].ref;
    _pos = _eps.indexWhere((e) => e.ref == target);
    if (_pos < 0) _pos = 0;
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadEpisode());
  }

  @override
  void dispose() {
    _saveProgress(force: true);
    _hideTimer?.cancel();
    _ctrl?.removeListener(_onTick);
    _ctrl?.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  // ---------- Pemuatan ----------
  Future<void> _loadEpisode() async {
    final token = ++_loadToken;
    await _disposeCtrl();
    if (!mounted) return;
    setState(() { _status = _Status.loading; _error = null; _payload = null; _srcIdx = 0; });
    try {
      final key = EpisodeRef(_anime.source, _anime.key, _ep.ref);
      ref.invalidate(episodeProvider(key));
      final p = await ref.read(episodeProvider(key).future).timeout(const Duration(seconds: 50));
      if (!mounted || token != _loadToken) return;
      _payload = p;
      if (p.playable.isEmpty) {
        setState(() => _status = _Status.noPlayable);
        return;
      }
      await _openSource(0, token: token);
    } on TimeoutException {
      if (mounted && token == _loadToken) setState(() { _status = _Status.error; _error = 'Waktu habis saat mengambil sumber video.'; });
    } catch (e) {
      if (mounted && token == _loadToken) setState(() { _status = _Status.error; _error = '$e'; });
    }
  }

  Future<void> _disposeCtrl() async {
    final c = _ctrl;
    _ctrl = null;
    c?.removeListener(_onTick);
    await c?.dispose();
  }

  Future<void> _openSource(int i, {int? token, Duration? seekTo}) async {
    token ??= ++_loadToken;
    final src = _payload!.playable[i];
    await _disposeCtrl();
    if (!mounted || token != _loadToken) return;
    setState(() { _status = _Status.loading; _srcIdx = i; _error = null; });
    final c = VideoPlayerController.networkUrl(Uri.parse(src.url));
    try {
      await c.initialize().timeout(const Duration(seconds: 25));
      if (!mounted || token != _loadToken) { await c.dispose(); return; }
      var start = seekTo;
      if (start == null && ref.read(settingsProvider).resume) {
        final h = ref.read(historyProvider.notifier).of(_anime.id);
        if (h != null && h.episodeRef == _ep.ref && h.progress < 0.95 && h.positionMs > 3000) {
          start = Duration(milliseconds: h.positionMs);
        }
      }
      if (start != null && start < c.value.duration) await c.seekTo(start);
      await c.setVolume(_volume);
      c.addListener(_onTick);
      _ctrl = c;
      _advancing = false;
      await c.play();
      setState(() => _status = _Status.ready);
      _kickHide();
    } on TimeoutException {
      await c.dispose();
      if (mounted && token == _loadToken) setState(() { _status = _Status.error; _error = 'Video terlalu lama dimuat (timeout).'; });
    } catch (e) {
      await c.dispose();
      if (mounted && token == _loadToken) {
        setState(() { _status = _Status.error; _error = 'Format video tidak kompatibel atau sumber tidak tersedia.\n${_short(e)}'; });
      }
    }
  }

  String _short(Object e) => e.toString().split('\n').first;

  // ---------- Progres ----------
  void _onTick() {
    final v = _ctrl?.value;
    if (v == null) return;
    if (v.hasError && _status == _Status.ready) {
      setState(() { _status = _Status.error; _error = 'Pemutaran gagal: ${v.errorDescription ?? 'kesalahan tidak diketahui'}'; });
      return;
    }
    _saveProgress();
    final done = v.duration > Duration.zero && v.position >= v.duration - const Duration(milliseconds: 500) && !v.isPlaying;
    if (done && !_advancing) {
      _advancing = true;
      if (ref.read(settingsProvider).autoNext && _pos < _eps.length - 1) _go(_pos + 1);
    }
  }

  void _saveProgress({bool force = false}) {
    final v = _ctrl?.value;
    if (v == null || !v.isInitialized) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (!force && now - _lastSaveMs < 5000) return;
    _lastSaveMs = now;
    ref.read(historyProvider.notifier).upsert(HistoryEntry(
          anime: _anime,
          episodeRef: _ep.ref,
          episodeNumber: _ep.number,
          positionMs: v.position.inMilliseconds,
          durationMs: v.duration.inMilliseconds,
          updatedAt: now,
        ));
  }

  void _go(int pos) {
    if (pos < 0 || pos >= _eps.length) return;
    _saveProgress(force: true);
    setState(() => _pos = pos);
    _loadEpisode();
  }

  // ---------- UI ----------
  void _kickHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && (_ctrl?.value.isPlaying ?? false)) setState(() => _controls = false);
    });
  }

  void _toggleControls() {
    setState(() => _controls = !_controls);
    if (_controls) _kickHide();
  }

  Future<void> _toggleFullscreen() async {
    final next = !_fullscreen;
    setState(() => _fullscreen = next);
    if (next) {
      await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    }
  }

  Future<void> _pickSource() async {
    final p = _payload;
    if (p == null) return;
    final pos = _ctrl?.value.position;
    final i = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const Padding(padding: EdgeInsets.fromLTRB(20, 0, 20, 8), child: Text('Kualitas & server', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
          for (var k = 0; k < p.playable.length; k++)
            ListTile(
              leading: Icon(k == _srcIdx ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                  color: k == _srcIdx ? YumeColors.accent : null),
              title: Text(p.playable[k].title.isEmpty ? 'Sumber ${k + 1}' : p.playable[k].title),
              subtitle: Text(p.playable[k].kind == StreamKind.hls ? 'HLS' : 'Video langsung', style: const TextStyle(fontSize: 12)),
              onTap: () => Navigator.pop(c, k),
            ),
        ]),
      ),
    );
    if (i != null && i != _srcIdx) _openSource(i, seekTo: pos);
  }

  @override
  Widget build(BuildContext context) {
    final video = _videoArea();
    if (_fullscreen) {
      return PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) { if (!didPop) _toggleFullscreen(); },
        child: Scaffold(backgroundColor: Colors.black, body: video),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(_anime.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
      ),
      body: Column(children: [
        AspectRatio(aspectRatio: 16 / 9, child: video),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_ep.label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(sourceName(_anime.source), style: const TextStyle(fontSize: 12, color: YumeColors.textDim)),
              ]),
            ),
            IconButton(tooltip: 'Episode sebelumnya', onPressed: _pos > 0 ? () => _go(_pos - 1) : null, icon: const Icon(Icons.skip_previous_rounded)),
            IconButton(tooltip: 'Episode berikutnya', onPressed: _pos < _eps.length - 1 ? () => _go(_pos + 1) : null, icon: const Icon(Icons.skip_next_rounded)),
          ]),
        ),
        const Divider(height: 1),
        Expanded(
          child: ListView.builder(
            itemCount: _eps.length,
            itemBuilder: (_, i) => ListTile(
              dense: true,
              selected: i == _pos,
              selectedColor: YumeColors.accent,
              leading: Icon(i == _pos ? Icons.equalizer_rounded : Icons.play_arrow_rounded),
              title: Text(_eps[i].label, maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: i == _pos ? null : () => _go(i),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _videoArea() {
    switch (_status) {
      case _Status.loading:
        return const ColoredBox(color: Colors.black, child: Center(child: CircularProgressIndicator(color: YumeColors.accent)));
      case _Status.error:
        return ColoredBox(
          color: Colors.black,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.error_outline_rounded, color: YumeColors.danger, size: 34),
                  const SizedBox(height: 8),
                  Text(_error ?? 'Gagal memutar', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
                    FilledButton.tonal(onPressed: _loadEpisode, child: const Text('Coba lagi')),
                    if ((_payload?.playable.length ?? 0) > 1) OutlinedButton(onPressed: _pickSource, child: const Text('Ganti server')),
                    if (_fullscreen) OutlinedButton(onPressed: _toggleFullscreen, child: const Text('Keluar')),
                  ]),
                ]),
              ),
            ),
          ),
        );
      case _Status.noPlayable:
        return _noPlayable();
      case _Status.ready:
        final c = _ctrl!;
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _toggleControls,
          child: Stack(fit: StackFit.expand, children: [
            const ColoredBox(color: Colors.black),
            Center(child: AspectRatio(aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio, child: VideoPlayer(c))),
            ValueListenableBuilder<VideoPlayerValue>(
              valueListenable: c,
              builder: (_, v, __) => v.isBuffering
                  ? const Center(child: CircularProgressIndicator(color: YumeColors.accent))
                  : const SizedBox.shrink(),
            ),
            AnimatedOpacity(
              opacity: _controls ? 1 : 0,
              duration: const Duration(milliseconds: 150),
              child: IgnorePointer(ignoring: !_controls, child: _controlsOverlay(c)),
            ),
          ]),
        );
    }
  }

  /// Tidak ada HLS/video langsung: tawarkan embed/unduhan di browser. Tidak berpura-pura memutar iframe.
  Widget _noPlayable() {
    final ext = _payload?.external ?? const <StreamSource>[];
    return ColoredBox(
      color: YumeColors.surface,
      child: ListView(padding: const EdgeInsets.all(14), children: [
        const Text('Tidak ada sumber yang bisa diputar langsung', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(_payload?.note ?? 'Sumber ini hanya berupa halaman embed atau tautan unduhan.',
            style: const TextStyle(fontSize: 12.5, color: YumeColors.textDim)),
        const SizedBox(height: 8),
        if (ext.isEmpty) const Text('Sumber tidak mengembalikan tautan apa pun.', style: TextStyle(fontSize: 12.5)),
        for (final s in ext.take(12))
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: Icon(s.kind == StreamKind.download ? Icons.download_rounded : Icons.open_in_new_rounded),
            title: Text(s.title.isEmpty ? s.url : s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(s.kind == StreamKind.download ? 'Unduhan' : 'Halaman embed', style: const TextStyle(fontSize: 11.5)),
            onTap: () => launchUrl(Uri.parse(s.url), mode: LaunchMode.externalApplication),
          ),
      ]),
    );
  }

  Widget _controlsOverlay(VideoPlayerController c) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [Color(0x99000000), Color(0x00000000), Color(0xCC000000)], stops: [0, 0.5, 1]),
      ),
      child: Column(children: [
        Row(children: [
          if (_fullscreen)
            IconButton(color: Colors.white, icon: const Icon(Icons.arrow_back_rounded), onPressed: _toggleFullscreen),
          Expanded(child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(_fullscreen ? '${_anime.title} · ${_ep.label}' : '', maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontSize: 13.5)),
          )),
          IconButton(color: Colors.white, tooltip: 'Kualitas & server', icon: const Icon(Icons.settings_outlined), onPressed: _pickSource),
        ]),
        const Spacer(),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton(iconSize: 34, color: Colors.white, onPressed: _pos > 0 ? () => _go(_pos - 1) : null, icon: const Icon(Icons.skip_previous_rounded)),
          const SizedBox(width: 12),
          ValueListenableBuilder<VideoPlayerValue>(
            valueListenable: c,
            builder: (_, v, __) => IconButton(
              iconSize: 52, color: Colors.white,
              icon: Icon(v.isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded),
              onPressed: () { v.isPlaying ? c.pause() : c.play(); _kickHide(); },
            ),
          ),
          const SizedBox(width: 12),
          IconButton(iconSize: 34, color: Colors.white, onPressed: _pos < _eps.length - 1 ? () => _go(_pos + 1) : null, icon: const Icon(Icons.skip_next_rounded)),
        ]),
        const Spacer(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 4, 4),
          child: ValueListenableBuilder<VideoPlayerValue>(
            valueListenable: c,
            builder: (_, v, __) {
              final total = v.duration.inMilliseconds.toDouble();
              final cur = v.position.inMilliseconds.clamp(0, total <= 0 ? 0 : total.toInt()).toDouble();
              return Row(children: [
                Text(fmtDuration(v.position), style: const TextStyle(color: Colors.white, fontSize: 11.5)),
                Expanded(
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(trackHeight: 3, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6)),
                    child: Slider(
                      value: total <= 0 ? 0 : cur,
                      max: total <= 0 ? 1 : total,
                      activeColor: YumeColors.accent,
                      inactiveColor: Colors.white24,
                      onChangeStart: (_) => _hideTimer?.cancel(),
                      onChanged: total <= 0 ? null : (x) => c.seekTo(Duration(milliseconds: x.toInt())),
                      onChangeEnd: (_) => _kickHide(),
                    ),
                  ),
                ),
                Text(fmtDuration(v.duration), style: const TextStyle(color: Colors.white, fontSize: 11.5)),
                PopupMenuButton<double>(
                  tooltip: 'Volume',
                  icon: Icon(_volume == 0 ? Icons.volume_off_rounded : Icons.volume_up_rounded, color: Colors.white, size: 22),
                  itemBuilder: (_) => [
                    PopupMenuItem(enabled: false, child: StatefulBuilder(builder: (ctx, set) => SizedBox(
                      width: 160,
                      child: Slider(
                        value: _volume, activeColor: YumeColors.accent,
                        onChanged: (x) { set(() {}); setState(() => _volume = x); c.setVolume(x); },
                      ),
                    ))),
                  ],
                ),
                IconButton(
                  color: Colors.white, tooltip: 'Layar penuh',
                  icon: Icon(_fullscreen ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded),
                  onPressed: _toggleFullscreen,
                ),
              ]);
            },
          ),
        ),
      ]),
    );
  }
}
