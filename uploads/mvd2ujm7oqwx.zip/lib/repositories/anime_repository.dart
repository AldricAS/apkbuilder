import '../data/api_client.dart';
import '../models/anime.dart';

List<SourceError> _errors(Map<String, dynamic> j) => (j['errors'] as List? ?? const [])
    .map((e) => SourceError.fromJson(Map<String, dynamic>.from(e)))
    .toList();

List<AnimeSummary> _items(dynamic l) =>
    (l as List? ?? const []).map((e) => AnimeSummary.fromJson(Map<String, dynamic>.from(e))).toList();

/// Satu-satunya pintu ke backend. Tidak pernah membuat data sendiri.
class AnimeRepository {
  final ApiClient api;
  AnimeRepository(this.api);

  String? _sources(List<String> s) => s.isEmpty ? null : s.join(',');

  Future<List<SourceInfo>> sources() async {
    final j = await api.get('/api/sources');
    return (j['sources'] as List)
        .map((e) => Map<String, dynamic>.from(e))
        .map((m) => SourceInfo('${m['id']}', '${m['name']}', Map<String, dynamic>.from(m['capabilities'] ?? {})))
        .toList();
  }

  Future<HomeData> home(List<String> sources) async {
    final j = await api.get('/api/home', {'sources': _sources(sources)}..removeWhere((k, v) => v == null));
    final sections = (j['sections'] as List? ?? const []).map((e) {
      final m = Map<String, dynamic>.from(e);
      return HomeSection(key: '${m['key']}', title: '${m['title']}', source: '${m['source']}', items: _items(m['items']));
    }).toList();
    return HomeData(sections, _errors(j));
  }

  Future<PagedResult> list(String kind, int page, List<String> sources) async {
    final j = await api.get('/api/list', {
      'kind': kind,
      'page': page,
      if (sources.isNotEmpty) 'sources': sources.join(','),
    });
    return PagedResult(_items(j['items']), page, j['hasMore'] == true, _errors(j));
  }

  Future<PagedResult> search(String q, int page, List<String> sources) async {
    final j = await api.get('/api/search', {
      'q': q,
      'page': page,
      if (sources.isNotEmpty) 'sources': sources.join(','),
    });
    return PagedResult(_items(j['results']), page, j['hasMore'] == true, _errors(j));
  }

  Future<AnimeDetail> detail(String source, String key) async {
    final j = await api.get('/api/anime', {'source': source, 'key': key});
    return AnimeDetail.fromJson(Map<String, dynamic>.from(j['anime']));
  }

  Future<EpisodePayload> episode(String source, String key, String ref) async {
    final j = await api.get('/api/episode', {'source': source, 'key': key, 'ref': ref});
    return EpisodePayload.fromJson(Map<String, dynamic>.from(j['episode']));
  }
}
