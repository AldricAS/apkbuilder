import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/app_config.dart';
import '../models/anime.dart';

/// Penyimpanan lokal (SharedPreferences, JSON). Bertahan setelah aplikasi ditutup/perangkat restart.
class LocalStore {
  final SharedPreferences _p;
  LocalStore(this._p);

  static const _fav = 'favorites_v1';
  static const _hist = 'history_v1';
  static const _search = 'search_history_v1';

  List<T> _list<T>(String key, T Function(Map<String, dynamic>) f) {
    final raw = _p.getString(key);
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List).map((e) => f(Map<String, dynamic>.from(e))).toList();
    } catch (_) {
      return []; // data rusak: mulai bersih, jangan crash
    }
  }

  Future<void> _save(String key, List<Map<String, dynamic>> v) => _p.setString(key, jsonEncode(v));

  // Favorit
  List<AnimeSummary> favorites() => _list(_fav, AnimeSummary.fromJson);
  Future<void> saveFavorites(List<AnimeSummary> l) => _save(_fav, l.map((e) => e.toJson()).toList());

  // Riwayat tontonan (satu entri per anime, terbaru di depan)
  List<HistoryEntry> history() => _list(_hist, HistoryEntry.fromJson);
  Future<void> saveHistory(List<HistoryEntry> l) =>
      _save(_hist, l.take(AppConfig.maxHistory).map((e) => e.toJson()).toList());

  // Riwayat pencarian
  List<String> searchHistory() => _p.getStringList(_search) ?? [];
  Future<void> saveSearchHistory(List<String> l) =>
      _p.setStringList(_search, l.take(AppConfig.maxSearchHistory).toList());

  // Preferensi
  String get themeMode => _p.getString('theme') ?? 'dark';
  String get userName => _p.getString('user_name') ?? 'Pengguna';
  String get baseUrl => _p.getString('base_url') ?? AppConfig.apiBaseUrl;
  List<String> get enabledSources => _p.getStringList('sources') ?? [];
  bool get autoNext => _p.getBool('auto_next') ?? true;
  bool get resume => _p.getBool('resume') ?? true;

  Future<void> setString(String k, String v) => _p.setString(k, v);
  Future<void> setBool(String k, bool v) => _p.setBool(k, v);
  Future<void> setStrings(String k, List<String> v) => _p.setStringList(k, v);

  Future<void> clearHistory() async {
    await _p.remove(_hist);
    await _p.remove(_search);
  }
}
