import 'package:dio/dio.dart';
import '../core/app_config.dart';

class ApiException implements Exception {
  final String message;
  final String? code;
  ApiException(this.message, {this.code});
  @override
  String toString() => message;
}

/// Klien HTTP ke backend adapter. Timeout dan retry dibatasi (1x untuk kegagalan jaringan).
class ApiClient {
  final Dio _dio;
  final String baseUrl;

  ApiClient({required this.baseUrl, String token = ''})
      : _dio = Dio(BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 12),
          receiveTimeout: AppConfig.requestTimeout,
          headers: {if (token.isNotEmpty) 'Authorization': 'Bearer $token'},
          responseType: ResponseType.json,
        ));

  bool get configured => baseUrl.isNotEmpty;

  Future<Map<String, dynamic>> get(String path, [Map<String, dynamic>? query]) async {
    if (!configured) {
      throw ApiException('Alamat server belum diatur. Buka Profil > Server.', code: 'no_server');
    }
    for (var attempt = 0;; attempt++) {
      try {
        final r = await _dio.get<dynamic>(path, queryParameters: query);
        final d = r.data;
        if (d is Map<String, dynamic>) return d;
        throw ApiException('Respons server tidak valid');
      } on DioException catch (e) {
        final transient = e.type == DioExceptionType.connectionError ||
            e.type == DioExceptionType.connectionTimeout;
        if (transient && attempt < 1) {
          await Future<void>.delayed(const Duration(milliseconds: 600));
          continue;
        }
        throw _map(e);
      }
    }
  }

  ApiException _map(DioException e) {
    final data = e.response?.data;
    if (data is Map && data['error'] is Map) {
      final err = data['error'] as Map;
      return ApiException('${err['message']}', code: '${err['code']}');
    }
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
        return ApiException('Server terlalu lama merespons', code: 'timeout');
      case DioExceptionType.connectionError:
        return ApiException('Tidak bisa terhubung ke server. Periksa jaringan dan alamat server.', code: 'network');
      default:
        return ApiException('Permintaan gagal (${e.response?.statusCode ?? 'tanpa respons'})');
    }
  }
}
