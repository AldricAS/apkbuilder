#!/usr/bin/env bash
# Build APK. Tidak menyembunyikan error; keberhasilan diperiksa dari keberadaan file APK.
# Pakai:  API_BASE_URL=https://api.contoh.com ./build-apk.sh [debug|release]
set -uo pipefail
cd "$(dirname "$0")"
MODE="${1:-debug}"
APP_NAME="${APP_NAME:-YumePlay}"

if [ -z "${API_BASE_URL:-}" ]; then
  echo "[!] API_BASE_URL kosong. APK tetap dibuat, tetapi pengguna harus mengisi alamat server di Profil > Server."
fi

[ -d android ] || bash ./tool/setup_android.sh || exit 1

flutter pub get || { echo "[x] flutter pub get gagal"; exit 1; }
if [ "${SKIP_CHECKS:-0}" != "1" ]; then
  flutter analyze || { echo "[x] flutter analyze menemukan masalah"; exit 1; }
  flutter test || { echo "[x] flutter test gagal"; exit 1; }
fi

DEFINES=(--dart-define=APP_NAME="$APP_NAME" --dart-define=API_BASE_URL="${API_BASE_URL:-}")
[ -n "${API_TOKEN:-}" ] && DEFINES+=(--dart-define=API_TOKEN="$API_TOKEN")

# --split-per-abi memperkecil APK; --target-platform arm64 cukup untuk hampir semua HP modern
flutter build apk "--$MODE" --split-per-abi --target-platform android-arm64 "${DEFINES[@]}"
STATUS=$?

OUT=$(ls build/app/outputs/flutter-apk/*"$MODE"*.apk 2>/dev/null | head -n1)
if [ $STATUS -ne 0 ] || [ -z "$OUT" ]; then
  echo "[x] Build GAGAL (kode $STATUS). Baca error di atas; lihat README bagian 'Error umum'."
  exit 1
fi
echo "[ok] APK: $OUT ($(du -h "$OUT" | cut -f1))"
