'use strict'
const path = require('path')
const { inWorker, withTimeout } = require('../utils/runScraper')

const ALL = ['kuramanime', 'nanimeid', 'samehadaku', 'alqanime', 'animein']

/** Pemanggil scraper: fungsi sinkron -> worker thread; async -> langsung dengan timeout. */
function makeCall(timeoutMs) {
  return function call(file, fn, args, { sync }) {
    if (sync) return inWorker(file, fn, args, timeoutMs)
    const mod = require(path.join(__dirname, '..', 'scrapers', file))
    if (typeof mod[fn] !== 'function') throw new Error('fungsi scraper tidak ada: ' + fn)
    return withTimeout(Promise.resolve().then(() => mod[fn](...args)), timeoutMs)
  }
}

/** @param {{call?:Function, enabled?:string[], timeoutMs?:number}} opts */
function buildRegistry(opts = {}) {
  const call = opts.call || makeCall(opts.timeoutMs || 40000)
  const enabled = (opts.enabled && opts.enabled.length ? opts.enabled : ALL).filter(s => ALL.includes(s))
  const adapters = {}
  for (const id of enabled) adapters[id] = require('./adapters/' + id).create({ call })
  return {
    ids: enabled,
    get: (id) => adapters[id],
    describe: () => enabled.map(id => ({ id, name: adapters[id].name, capabilities: adapters[id].capabilities })),
  }
}

module.exports = { buildRegistry, ALL }
