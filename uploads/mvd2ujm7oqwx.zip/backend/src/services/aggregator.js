'use strict'
const { HttpError } = require('../utils/validate')

const norm = (t) => String(t || '').toLowerCase().replace(/[^a-z0-9]+/g, '')

const score = (x) => (x.poster ? 2 : 0) + (x.rating ? 1 : 0) + (x.genres && x.genres.length ? 1 : 0)

/** Gabungkan hasil beberapa sumber; judul identik (setelah dinormalisasi) dijadikan satu entri + alsoOn. */
function mergeResults(perSource) {
  const groups = new Map()
  for (const items of perSource) {
    for (const it of items) {
      const k = norm(it.title)
      if (!k) continue
      if (!groups.has(k)) groups.set(k, [])
      groups.get(k).push(it)
    }
  }
  const out = []
  for (const list of groups.values()) {
    list.sort((a, b) => score(b) - score(a))
    const [primary, ...rest] = list
    out.push({ ...primary, alsoOn: rest.map(r => ({ id: r.id, source: r.source, key: r.key })) })
  }
  return out
}

function errInfo(source, e) {
  return { source, code: e.code || 'error', message: e.message || String(e) }
}

/** Jalankan satu operasi di banyak sumber; kegagalan satu sumber tidak menggagalkan yang lain. */
async function fanOut(registry, sources, fn) {
  const settled = await Promise.allSettled(sources.map(s => fn(registry.get(s))))
  const ok = []; const errors = []
  settled.forEach((r, i) => {
    if (r.status === 'fulfilled') ok.push({ source: sources[i], value: r.value })
    else errors.push(errInfo(sources[i], r.reason))
  })
  return { ok, errors }
}

async function search(registry, sources, q, page) {
  const capable = sources.filter(s => registry.get(s).capabilities.search)
  const { ok, errors } = await fanOut(registry, capable, a => a.search(q, page))
  const results = mergeResults(ok.map(o => o.value.items))
  const hasMore = ok.some(o => o.value.hasMore)
  return { query: q, page, hasMore, results, errors, sourcesOk: ok.map(o => o.source) }
}

async function home(registry, sources) {
  const capable = sources.filter(s => registry.get(s).capabilities.home)
  const { ok, errors } = await fanOut(registry, capable, a => a.home())
  const sections = []
  for (const o of ok) for (const s of o.value.sections) sections.push({ ...s, source: o.source, key: `${o.source}:${s.key}` })
  return { sections, errors, sourcesOk: ok.map(o => o.source) }
}

async function list(registry, sources, kind, page) {
  const capable = sources.filter(s => registry.get(s).capabilities[kind])
  if (!capable.length) throw new HttpError(400, 'unsupported', 'Tidak ada sumber aktif yang mendukung: ' + kind)
  const { ok, errors } = await fanOut(registry, capable, a => a.list(kind, page))
  const items = []
  const seen = new Set()
  for (const o of ok) for (const it of o.value.items) if (!seen.has(it.id)) { seen.add(it.id); items.push(it) }
  return { kind, page, hasMore: ok.some(o => o.value.hasMore), items, errors, sourcesOk: ok.map(o => o.source) }
}

module.exports = { search, home, list, mergeResults, norm }
