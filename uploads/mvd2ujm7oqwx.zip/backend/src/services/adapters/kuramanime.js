'use strict'
const N = require('../../models/normalize')
const { classifyUrl } = require('../../utils/classify')
const { upstreamError } = require('./helpers')

const FILE = 'kuramanime.js'

function create({ call }) {
  const run = async (...args) => {
    const r = await call(FILE, 'run', args, { sync: false })
    if (r && r.error) {
      const msg = r.error === 'cloudflare_blocked'
        ? 'Kuramanime memblokir permintaan (Cloudflare). Sumber ini tidak bisa dipakai dari server ini saat ini.'
        : 'Kuramanime gagal: ' + r.error + (r.detail ? ' (' + r.detail + ')' : '')
      throw upstreamError(r.error, msg)
    }
    return r
  }
  const toSummary = (x, status) => N.summary({
    source: 'kuramanime', key: x.path, title: x.title, poster: x.poster, status,
  })

  return {
    id: 'kuramanime',
    name: 'Kuramanime',
    capabilities: { home: true, latest: false, ongoing: true, completed: true, search: true, detail: true, episode: true },

    async home() {
      const r = await run('ongoing', 1)
      return { sections: [{ key: 'ongoing', title: 'Ongoing', items: r.results.map(x => toSummary(x, 'Ongoing')) }] }
    },

    async list(kind, page) {
      if (kind === 'ongoing' || kind === 'completed') {
        const r = await run(kind === 'ongoing' ? 'ongoing' : 'finished', page)
        const items = r.results.map(x => toSummary(x, kind === 'ongoing' ? 'Ongoing' : 'Completed'))
        return { items, page, hasMore: items.length > 0 }
      }
      throw upstreamError('unsupported', 'Kuramanime tidak mendukung daftar: ' + kind)
    },

    async search(q, page) {
      const r = await run('search', q, page)
      const items = r.results.map(x => toSummary(x, null))
      return { items, page, hasMore: items.length > 0 }
    },

    async detail(key) {
      const r = await run('anime', key)
      return N.detail({
        source: 'kuramanime', key, title: r.title, poster: r.poster,
        totalEpisodes: r.episodes.length || null,
        episodes: r.episodes.map(e => ({ number: e.number, title: e.title, ref: e.number })),
        sourceUrl: null,
      })
    },

    async episode(key, ref) {
      const r = await run('episode', key, ref)
      const sources = []
      const seen = new Set()
      const add = (o) => { if (o.url && !seen.has(o.url)) { seen.add(o.url); sources.push(o) } }
      for (const s of r.sources || []) {
        add({ kind: classifyUrl(s.src), url: s.src, resolution: s.resolution, server: s.server })
      }
      for (const e of r.embeds || []) add({ kind: classifyUrl(e, 'embed'), url: e, label: 'Embed' })
      for (const d of r.downloads || []) add({ kind: 'download', url: d.url, label: d.title })
      return N.episodePayload({
        source: 'kuramanime', animeKey: key, number: ref, title: r.title, sources,
        note: sources.length ? r.note : (r.note || 'Tidak ada sumber yang berhasil diekstrak'),
      })
    },
  }
}

module.exports = { create }
