'use strict'
const N = require('../../models/normalize')
const V = require('../../utils/validate')
const { classifyUrl } = require('../../utils/classify')
const { animeSlugFromUrl, episodeNumberFromText, infoGet, yearFrom } = require('./helpers')

const FILE = 'SameHadaku.js'

/** Slug anime dari URL halaman anime; bila yang ada URL episode, turunkan slug (heuristik, ditandai keyDerived). */
function keyFromUrl(url) {
  const direct = animeSlugFromUrl(url)
  if (direct) return { key: direct, derived: false }
  const m = String(url || '').match(/samehadaku\.how\/([^\/?#]+)/)
  if (!m) return null
  const slug = m[1].replace(/-episode-\d+.*$/i, '')
  return slug ? { key: slug, derived: true } : null
}

function create({ call }) {
  const run = (fn, args) => call(FILE, fn, args, { sync: true })

  const card = (o) => {
    const k = keyFromUrl(o.url)
    if (!k) return null
    return N.summary({
      source: 'samehadaku', key: k.key, keyDerived: k.derived, title: o.title, poster: o.image || o.thumb,
      status: o.status, type: o.type, rating: o.rating || o.score, genres: o.genres, episodeInfo: o.episodeInfo,
    })
  }
  const compact = (list) => {
    const seen = new Set(); const out = []
    for (const x of list) if (x && !seen.has(x.key)) { seen.add(x.key); out.push(x) }
    return out
  }
  const latestItems = (eps) => compact(eps.map(e => card({
    url: e.anime_url, title: e.title, image: e.image, episodeInfo: e.episode ? 'Episode ' + e.episode : null,
  })))

  return {
    id: 'samehadaku',
    name: 'SameHadaku',
    capabilities: { home: true, latest: true, ongoing: false, completed: false, search: true, detail: true, episode: true },

    async home() {
      const h = await run('scrapeHome', [])
      const sections = [
        { key: 'latest', title: 'Episode Terbaru', items: latestItems(h.latest_episode || []) },
        { key: 'top', title: 'Top 10', items: compact((h.top10 || []).map(t => card({ url: t.url, title: t.title, image: t.image, rating: t.rating }))) },
        { key: 'movie', title: 'Movie', items: compact((h.project_movie || []).map(m => card({ url: m.url, title: m.title, image: m.image, genres: m.genres, type: 'Movie' }))) },
      ].filter(s => s.items.length)
      return { sections }
    },

    async list(kind, page) {
      if (kind !== 'latest') throw new V.HttpError(400, 'unsupported', 'SameHadaku hanya mendukung daftar: latest')
      const r = await run('scrapeLatest', [])
      return { items: latestItems(r.episodes || []), page: 1, hasMore: false }
    },

    async search(q) {
      const r = await run('searchAnime', [q])
      const items = compact((r.results || []).map(x => card({ url: x.url, title: x.title, thumb: x.thumb, score: x.score, type: x.type, status: x.status })))
      return { items, page: 1, hasMore: false }
    },

    async detail(key) {
      const a = await run('scrapeAnime', [key])
      const info = a.info || {}
      return N.detail({
        source: 'samehadaku', key, title: a.title, poster: a.thumb, synopsis: a.sinopsis, genres: a.genres,
        status: infoGet(info, /status/i), type: infoGet(info, /^type|tipe/i), studio: infoGet(info, /studio/i),
        year: yearFrom(infoGet(info, /released|rilis|tahun|year/i)),
        rating: infoGet(info, /rating|score|skor/i),
        altTitles: infoGet(info, /synonym|english|japanese|alt/i),
        totalEpisodes: a.total_episodes || null,
        episodes: (a.episodes || []).map(e => ({
          number: episodeNumberFromText(e.title) ?? episodeNumberFromText(e.url), title: e.title, ref: e.url, date: e.date,
        })),
        sourceUrl: a.source,
      })
    },

    async episode(key, ref) {
      const url = V.samehadakuEpisodeUrl(ref)
      const e = await run('scrapeEpisode', [url])
      const sources = []
      for (const s of e.servers || []) {
        if (s.embed_url) sources.push({ kind: classifyUrl(s.embed_url, 'embed'), url: s.embed_url, label: s.name, server: s.name })
      }
      for (const g of e.downloads || []) {
        for (const it of g.items || []) {
          for (const l of it.links || []) {
            sources.push({ kind: 'download', url: l.url, label: `${g.format} · ${l.host}`, resolution: it.resolution })
          }
        }
      }
      const nav = e.navigation || {}
      return N.episodePayload({
        source: 'samehadaku', animeKey: key, number: e.episode_number, title: e.title, sources,
        prevRef: nav.prev, nextRef: nav.next,
        note: sources.length ? 'Sumber berupa halaman embed/unduhan, bukan video langsung (kecuali bertanda playable).' : 'Tidak ada server/unduhan ditemukan',
      })
    },
  }
}

module.exports = { create, keyFromUrl }
