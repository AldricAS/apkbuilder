'use strict'
const N = require('../../models/normalize')
const { classifyUrl } = require('../../utils/classify')
const { pick } = require('./helpers')

const FILE = 'nanimeid.js'

/** Mirror/unduhan dari nanimeid bisa berupa string atau objek; bentuk pastinya tidak terdokumentasi. */
function toItems(list, forcedHint) {
  const out = []
  for (const x of Array.isArray(list) ? list : []) {
    if (typeof x === 'string') { out.push({ url: x }); continue }
    const url = pick(x, 'url', 'embed_url', 'src', 'link', 'stream_url', 'href')
    if (!url) continue
    out.push({
      url,
      label: pick(x, 'name', 'label', 'server', 'title', 'host'),
      resolution: pick(x, 'quality', 'resolution', 'res'),
    })
  }
  return out.map(o => ({
    kind: classifyUrl(o.url, forcedHint),
    url: o.url, label: o.label ? String(o.label) : null, resolution: o.resolution ? String(o.resolution) : null,
  }))
}

function create({ call }) {
  const run = (fn, args) => call(FILE, fn, args, { sync: false })
  const toSummary = (x) => N.summary({
    source: 'nanimeid', key: x.slug, title: x.title, poster: x.poster, status: x.status, type: x.type,
    rating: x.rating, year: x.release_year, genres: x.genres,
    episodeInfo: x.episodes_count ? x.episodes_count + ' episode' : null,
  })

  return {
    id: 'nanimeid',
    name: 'Nanimeid',
    capabilities: { home: false, latest: false, ongoing: false, completed: false, search: true, detail: true, episode: true },

    async search(q, page) {
      const r = await run('cmdExplore', [q, page])
      return { items: (r.data || []).map(toSummary), page: r.page || page, hasMore: r.last_page ? page < r.last_page : (r.data || []).length > 0 }
    },

    async detail(key) {
      const a = await run('cmdAnimeDetail', [key])
      return N.detail({
        source: 'nanimeid', key, title: a.title, poster: a.poster, status: a.status, type: a.type, rating: a.rating,
        year: a.release_year, studio: a.studio, genres: a.genres, synopsis: a.synopsis, trailer: a.trailer_url,
        totalEpisodes: a.episodes_count || a.total_episodes || null,
        episodes: (a.episodes || []).map(e => ({ number: e.number, title: e.title, ref: e.number })),
      })
    },

    async episode(key, ref) {
      const r = await run('cmdAnimeEpisode', [key, ref])
      const sources = []
      const v = r.episode && r.episode.video_url
      if (typeof v === 'string' && v) sources.push({ kind: classifyUrl(v), url: v, label: 'Utama' })
      sources.push(...toItems(r.mirror_streams, 'embed'))
      sources.push(...toItems(r.download_urls, 'download'))
      const nums = (r.all_episodes || []).map(e => Number(e.number)).filter(Number.isFinite).sort((a, b) => a - b)
      const cur = Number(ref)
      const idx = nums.indexOf(cur)
      return N.episodePayload({
        source: 'nanimeid', animeKey: key, number: r.episode && r.episode.number, title: r.episode && r.episode.title,
        sources,
        prevRef: idx > 0 ? nums[idx - 1] : null,
        nextRef: idx >= 0 && idx < nums.length - 1 ? nums[idx + 1] : null,
        note: sources.length ? null : 'Tidak ada mirror/unduhan pada episode ini',
      })
    },
  }
}

module.exports = { create, toItems }
