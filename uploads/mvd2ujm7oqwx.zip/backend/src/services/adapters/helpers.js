'use strict'
const { HttpError } = require('../../utils/validate')

const pick = (o, ...names) => {
  if (!o || typeof o !== 'object') return undefined
  for (const n of names) if (o[n] !== undefined && o[n] !== null && o[n] !== '') return o[n]
  return undefined
}

/** Ambil slug dari URL ".../anime/<slug>/" . Mengembalikan null bila bukan halaman anime. */
function animeSlugFromUrl(url) {
  const m = String(url || '').match(/\/anime\/([^\/?#]+)/)
  return m ? m[1] : null
}

/** Nomor episode dari teks judul ("Episode 12", "Ep 3", "- 07"). null bila tidak ada. */
function episodeNumberFromText(text) {
  const t = String(text || '')
  const m = t.match(/(?:episode|eps?\.?)\s*(\d+(?:\.\d)?)/i) || t.match(/\bE(\d{1,4})\b/) || t.match(/[-–]\s*(\d{1,4})\s*$/)
  return m ? parseFloat(m[1]) : null
}

/** Cari value info (objek key->value) dengan pencocokan key longgar, hanya jika benar-benar ada. */
function infoGet(info, ...patterns) {
  if (!info || typeof info !== 'object') return null
  for (const k of Object.keys(info)) {
    if (patterns.some(p => p.test(k)) && info[k]) return info[k]
  }
  return null
}

function yearFrom(text) {
  const m = String(text || '').match(/(19|20)\d{2}/)
  return m ? m[0] : null
}

function upstreamError(code, message) {
  return new HttpError(502, code, message)
}

module.exports = { pick, animeSlugFromUrl, episodeNumberFromText, infoGet, yearFrom, upstreamError }
