'use strict'
// CATATAN: tidak ada contoh respons nyata untuk Animein di berkas yang diberikan (animein.js hanya mencetak
// JSON mentah). Normalisasi di sini bersifat defensif (mencoba beberapa nama field umum) dan BELUM
// diverifikasi terhadap respons live. Lihat README bagian "Belum terverifikasi".
const N = require('../../models/normalize')
const { classifyUrl } = require('../../utils/classify')
const { pick, upstreamError } = require('./helpers')

const FILE = 'animein.js'
const SITE = 'https://animeinweb.com'

const abs = (u) => {
  if (!u) return null
  const s = String(u)
  if (/^https?:\/\//i.test(s)) return s
  if (s.startsWith('//')) return 'https:' + s
  if (s.startsWith('/')) return SITE + s
  return null // path relatif tak jelas: jangan ditebak
}

const isItem = (x) => x && typeof x === 'object' && pick(x, 'id', 'movie_id') !== undefined && pick(x, 'title', 'name', 'judul', 'movie_title') !== undefined

function toSummary(x) {
  const genre = pick(x, 'genres', 'genre')
  const genres = Array.isArray(genre)
    ? genre.map(g => (typeof g === 'string' ? g : pick(g, 'name', 'title'))).filter(Boolean)
    : (typeof genre === 'string' ? genre.split(',').map(s => s.trim()).filter(Boolean) : [])
  return N.summary({
    source: 'animein', key: pick(x, 'id', 'movie_id'),
    title: pick(x, 'title', 'name', 'judul', 'movie_title'),
    poster: abs(pick(x, 'image', 'poster', 'cover', 'thumbnail', 'image_url', 'poster_url', 'img')),
    status: pick(x, 'status'), type: pick(x, 'type'),
    rating: pick(x, 'rating', 'score'), year: pick(x, 'year', 'release_year'),
    episodeInfo: pick(x, 'episode', 'latest_episode', 'episode_text', 'total_episode'), genres,
  })
}

/** Cari daftar objek anime pertama di dalam struktur respons yang tidak diketahui. */
function findList(data) {
  if (Array.isArray(data)) return data.filter(isItem)
  if (!data || typeof data !== 'object') return []
  for (const k of ['movie', 'movies', 'list', 'data', 'items', 'result', 'results']) {
    if (Array.isArray(data[k])) return data[k].filter(isItem)
  }
  for (const v of Object.values(data)) if (Array.isArray(v) && v.some(isItem)) return v.filter(isItem)
  return []
}

/** Telusuri respons stream: kumpulkan semua URL http beserta resolusi/label dari objek terdekat. */
function collectStreams(node, ctx = {}, out = [], depth = 0) {
  if (depth > 6 || node === null || node === undefined) return out
  if (typeof node === 'string') {
    if (/^https?:\/\//i.test(node)) out.push({ url: node, ...ctx })
    return out
  }
  if (Array.isArray(node)) { node.forEach(n => collectStreams(n, ctx, out, depth + 1)); return out }
  if (typeof node === 'object') {
    const next = {
      resolution: pick(node, 'resolution', 'quality', 'res', 'label') ?? ctx.resolution,
      server: pick(node, 'server', 'name', 'provider') ?? ctx.server,
    }
    for (const [k, v] of Object.entries(node)) {
      if (typeof v === 'string' && /^https?:\/\//i.test(v) && /(url|src|link|file|stream|hls|m3u8|mp4|embed)/i.test(k)) {
        out.push({ url: v, resolution: next.resolution, server: next.server, field: k })
      } else if (typeof v === 'object') collectStreams(v, next, out, depth + 1)
    }
  }
  return out
}

function create({ call }) {
  const run = (fn, args) => call(FILE, fn, args, { sync: false })

  return {
    id: 'animein',
    name: 'Animein',
    capabilities: { home: true, latest: false, ongoing: false, completed: false, search: true, detail: true, episode: true, unverifiedShape: true },

    async home() {
      const d = await run('home', [])
      const sections = []
      if (d && typeof d === 'object' && !Array.isArray(d)) {
        for (const [k, v] of Object.entries(d)) {
          if (Array.isArray(v)) {
            const items = v.filter(isItem).map(toSummary)
            if (items.length) sections.push({ key: k, title: k.replace(/[_-]+/g, ' '), items })
          }
        }
      }
      if (!sections.length) {
        const items = findList(d).map(toSummary)
        if (items.length) sections.push({ key: 'home', title: 'Beranda', items })
      }
      return { sections }
    },

    async search(q, page) {
      const d = await run('search', [q, page - 1])
      const items = findList(d).map(toSummary)
      return { items, page, hasMore: items.length > 0 }
    },

    async detail(key) {
      const d = await run('detail', [key])
      const root = (d && (d.movie || d.detail || d.data)) || d || {}
      const base = isItem(root) ? toSummary(root) : null
      if (!base) throw upstreamError('unrecognized_shape', 'Format detail Animein tidak dikenali')
      const genreRaw = pick(root, 'genres', 'genre')
      const eps = []
      for (let p = 0; p < 30; p++) {
        const r = await run('episodes', [key, p])
        const list = (r && r.episode) || []
        if (!list.length) break
        eps.push(...list)
      }
      return N.detail({
        ...base, source: 'animein', key,
        synopsis: pick(root, 'synopsis', 'description', 'sinopsis', 'overview'),
        studio: pick(root, 'studio'),
        cover: abs(pick(root, 'banner', 'cover', 'backdrop')),
        altTitles: pick(root, 'alternative', 'alt_title', 'title_alt', 'synonyms'),
        totalEpisodes: eps.length || null,
        genres: base.genres.length ? base.genres : (Array.isArray(genreRaw) ? genreRaw.map(g => (typeof g === 'string' ? g : pick(g, 'name'))).filter(Boolean) : []),
        episodes: eps.map(e => ({ number: pick(e, 'index', 'number'), title: pick(e, 'title', 'name'), ref: e.id })),
      })
    },

    async episode(key, ref) {
      const d = await run('stream', [String(ref)])
      const found = collectStreams(d)
      const seen = new Set()
      const sources = []
      for (const f of found) {
        if (seen.has(f.url)) continue
        seen.add(f.url)
        const kind = classifyUrl(f.url, /embed/i.test(f.field || '') ? 'embed' : undefined)
        if (kind === 'unknown') continue
        sources.push({ kind, url: f.url, resolution: f.resolution ? String(f.resolution) : null, server: f.server ? String(f.server) : null, label: f.field || null })
      }
      return N.episodePayload({
        source: 'animein', animeKey: key, number: null, title: null, sources,
        note: sources.length ? 'Respons stream Animein dibaca secara heuristik; verifikasi kualitas/format.' : 'Tidak ada URL media yang dikenali dari respons stream Animein',
      })
    },
  }
}

module.exports = { create, findList, collectStreams, toSummary }
