'use strict'
const N = require('../../models/normalize')
const { episodeNumberFromText, infoGet, yearFrom, upstreamError } = require('./helpers')
const { animeSlugFromUrl } = require('./helpers')

const FILE = 'alqanime.js'

function create({ call }) {
  const run = (fn, args) => call(FILE, fn, args, { sync: true })
  const card = (x) => N.summary({
    source: 'alqanime', key: x.slug, title: x.title || x.short_title, poster: x.thumbnail, status: x.status,
    type: x.type, rating: x.rating, episodeInfo: x.episode_info,
  })
  const cards = (list) => (list || []).filter(x => x.slug).map(card)

  return {
    id: 'alqanime',
    name: 'Alqanime',
    // Alqanime hanya menyediakan tautan unduhan, bukan streaming
    capabilities: { home: true, latest: true, ongoing: false, completed: false, search: true, detail: true, episode: true, downloadOnly: true },

    async home() {
      const h = await run('cmdHome', [])
      return { sections: (h.sections || []).map((s, i) => ({ key: 'sec' + i, title: s.title, items: cards(s.anime) })).filter(s => s.items.length) }
    },

    async list(kind, page) {
      if (kind !== 'latest') throw upstreamError('unsupported', 'Alqanime hanya mendukung daftar: latest')
      const r = await run('cmdList', [page])
      const last = r.pagination && r.pagination.last_page
      return { items: cards(r.anime), page, hasMore: last ? page < last : !!(r.pagination && r.pagination.next_page_url) }
    },

    async search(q) {
      const r = await run('cmdSearch', [q])
      return { items: cards(r.anime), page: 1, hasMore: false }
    },

    async detail(key) {
      const a = await run('cmdAnime', [key])
      const info = a.info || {}
      return N.detail({
        source: 'alqanime', key, title: a.title, poster: a.thumbnail, cover: a.cover, rating: a.rating,
        synopsis: a.synopsis, altTitles: a.alternative_titles, trailer: a.trailer,
        genres: (a.genres || []).map(g => g.name),
        status: infoGet(info, /status/i), type: infoGet(info, /^(type|tipe)/i), studio: infoGet(info, /studio/i),
        year: yearFrom(infoGet(info, /released|rilis|tahun|year|musim|season/i)),
        totalEpisodes: infoGet(info, /episode/i) || null,
        episodes: (a.episodes || []).map((e, i) => ({
          number: episodeNumberFromText(e.title), title: e.title, ref: i, streamable: false,
        })),
        related: (a.related || []).map(r => ({ title: r.title, relation: r.relation, key: animeSlugFromUrl(r.url) || String(r.url).replace(/^https:\/\/alqanime\.net\//, '').replace(/\/$/, '') })),
        sourceUrl: a.source,
      })
    },

    async episode(key, ref) {
      const a = await run('cmdAnime', [key])
      const ep = (a.episodes || [])[Number(ref)]
      if (!ep) throw upstreamError('not_found', 'Episode tidak ditemukan')
      const sources = []
      for (const q of ep.downloads || []) {
        for (const l of q.links || []) sources.push({ kind: 'download', url: l.url, label: l.host, resolution: q.resolution })
      }
      return N.episodePayload({
        source: 'alqanime', animeKey: key, number: episodeNumberFromText(ep.title), title: ep.title, sources,
        note: 'Alqanime hanya menyediakan tautan unduhan; tidak ada streaming langsung.',
      })
    },
  }
}

module.exports = { create }
