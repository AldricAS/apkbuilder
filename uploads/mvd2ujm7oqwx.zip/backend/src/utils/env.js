'use strict'
const fs = require('fs')
const path = require('path')

/** Loader .env minimal (tanpa dependensi). Variabel yang sudah ada di environment tidak ditimpa. */
function loadEnv(file = path.join(__dirname, '..', '..', '.env')) {
  let text
  try { text = fs.readFileSync(file, 'utf8') } catch (_) { return false }
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/)
    if (!m || line.trim().startsWith('#')) continue
    let v = m[2]
    if (/^(['"]).*\1$/.test(v)) v = v.slice(1, -1)
    if (process.env[m[1]] === undefined) process.env[m[1]] = v
  }
  return true
}

const int = (name, def) => {
  const n = parseInt(process.env[name], 10)
  return Number.isFinite(n) && n > 0 ? n : def
}

module.exports = { loadEnv, int }
