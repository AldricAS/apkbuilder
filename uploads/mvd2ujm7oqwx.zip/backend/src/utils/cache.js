'use strict'

/** Cache TTL kecil dengan batas entri (LRU sederhana) + dedup request yang sedang berjalan. */
class TtlCache {
  constructor(ttlMs, maxEntries) {
    this.ttl = ttlMs
    this.max = maxEntries
    this.map = new Map()
    this.inflight = new Map()
  }
  get(key) {
    const e = this.map.get(key)
    if (!e) return undefined
    if (e.exp < Date.now()) { this.map.delete(key); return undefined }
    this.map.delete(key); this.map.set(key, e) // refresh urutan
    return e.val
  }
  set(key, val, ttl = this.ttl) {
    this.map.set(key, { val, exp: Date.now() + ttl })
    while (this.map.size > this.max) this.map.delete(this.map.keys().next().value)
  }
  /** Ambil dari cache; jika kosong jalankan fn sekali walau dipanggil bersamaan. Hanya hasil sukses yang disimpan. */
  async wrap(key, fn, ttl) {
    const hit = this.get(key)
    if (hit !== undefined) return { value: hit, cached: true }
    if (this.inflight.has(key)) return { value: await this.inflight.get(key), cached: false }
    const p = (async () => { const v = await fn(); this.set(key, v, ttl); return v })()
    this.inflight.set(key, p)
    try { return { value: await p, cached: false } } finally { this.inflight.delete(key) }
  }
  clear() { this.map.clear() }
  get size() { return this.map.size }
}

module.exports = { TtlCache }
