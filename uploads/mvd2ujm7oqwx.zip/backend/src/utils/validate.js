'use strict'

class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code }
}
const bad = (msg) => new HttpError(400, 'bad_request', msg)

const SAFE_SLUG = /^[A-Za-z0-9][A-Za-z0-9._-]{0,200}$/
const KURA_KEY = /^(?:\d{1,9}\/)?[A-Za-z0-9][A-Za-z0-9._-]{0,200}$/

function page(v, def = 1) {
  if (v === undefined || v === null || v === '') return def
  const n = Number(v)
  if (!Number.isInteger(n) || n < 1 || n > 500) throw bad('page harus bilangan bulat 1-500')
  return n
}

function query(v) {
  const q = String(v || '').trim()
  if (q.length < 2) throw bad('q minimal 2 karakter')
  if (q.length > 80) throw bad('q maksimal 80 karakter')
  // buang karakter kontrol; sisanya aman karena scraper memakai encodeURIComponent / execFile tanpa shell
  return q.replace(/[\u0000-\u001f\u007f]/g, ' ')
}

function episodeNumber(v) {
  const s = String(v ?? '').trim()
  if (!/^\d{1,5}(\.\d)?$/.test(s)) throw bad('ep harus berupa nomor episode')
  return s
}

/**
 * Validasi key anime per sumber. Mengembalikan key yang sudah bersih.
 * Mencegah path traversal dan SSRF: key tidak boleh berisi skema/host sembarang.
 */
function animeKey(source, v) {
  const key = String(v || '').trim()
  if (!key) throw bad('key wajib diisi')
  const ok = source === 'kuramanime' ? KURA_KEY.test(key) : SAFE_SLUG.test(key)
  if (!ok) throw bad('key tidak valid untuk sumber ' + source)
  return key
}

const SAMEHADAKU_HOST = /^https:\/\/v2\.samehadaku\.how\/[A-Za-z0-9._\-\/]*$/

/** Key episode SameHadaku berupa URL; hanya host sumber yang diizinkan. */
function samehadakuEpisodeUrl(v) {
  const u = String(v || '').trim()
  if (!SAMEHADAKU_HOST.test(u) || u.length > 300) throw bad('episode url tidak valid')
  return u
}

function sourceList(v, allowed) {
  if (!v) return allowed.slice()
  const list = String(v).split(',').map(s => s.trim()).filter(Boolean)
  for (const s of list) if (!allowed.includes(s)) throw bad('sumber tidak dikenal: ' + s)
  return [...new Set(list)]
}

function oneSource(v, allowed) {
  const s = String(v || '').trim()
  if (!allowed.includes(s)) throw bad('source tidak dikenal atau nonaktif: ' + s)
  return s
}

module.exports = { HttpError, bad, page, query, episodeNumber, animeKey, samehadakuEpisodeUrl, sourceList, oneSource }
