'use strict'
const { Worker } = require('worker_threads')
const path = require('path')
const { HttpError } = require('./validate')

const WORKER_FILE = path.join(__dirname, '..', 'scrapers', 'worker.js')

/** Pesan error singkat tanpa dump perintah curl. */
function cleanMsg(msg) {
  const s = String(msg || '')
  if (/^Command failed: curl/.test(s)) return 'curl gagal: situs tidak terjangkau, timeout, atau diblokir'
  return s.split('\n')[0].slice(0, 200)
}

/** Jalankan fungsi scraper sinkron di worker dengan timeout keras. */
function inWorker(file, fn, args, timeoutMs) {
  return new Promise((resolve, reject) => {
    const w = new Worker(WORKER_FILE, { workerData: { file, fn, args } })
    const timer = setTimeout(() => {
      w.terminate()
      reject(new HttpError(504, 'timeout', 'sumber terlalu lama merespons'))
    }, timeoutMs)
    w.once('message', m => {
      clearTimeout(timer); w.terminate()
      m.ok ? resolve(m.value) : reject(new HttpError(502, 'upstream_error', cleanMsg(m.error)))
    })
    w.once('error', e => { clearTimeout(timer); reject(new HttpError(502, 'upstream_error', e.message)) })
  })
}

/** Jalankan fungsi scraper async biasa dengan timeout. */
function withTimeout(promise, timeoutMs) {
  let t
  const timeout = new Promise((_, rej) => {
    t = setTimeout(() => rej(new HttpError(504, 'timeout', 'sumber terlalu lama merespons')), timeoutMs)
  })
  return Promise.race([promise, timeout])
    .catch(e => { throw e instanceof HttpError ? e : new HttpError(502, 'upstream_error', String(e && e.message || e)) })
    .finally(() => clearTimeout(t))
}

module.exports = { inWorker, withTimeout }
