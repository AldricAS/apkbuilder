'use strict'

const DOWNLOAD_HOSTS = /(pixeldrain|mediafire|kuramadrive\.com\/(?:kdrive|kturbo)|mega\.nz|drive\.google|gofile|krakenfiles|zippyshare|terabox|acefile|racaty|archive\.org\/download|1drv|dropbox|userscloud|sfile)/i

/**
 * Bedakan jenis URL media. Tidak pernah menganggap halaman embed/unduhan sebagai video langsung.
 * @returns {'hls'|'direct'|'dash'|'embed'|'download'|'unknown'}
 */
function classifyUrl(url, hint) {
  const u = String(url || '')
  if (!/^https?:\/\//i.test(u)) return 'unknown'
  if (hint === 'embed' || hint === 'download') {
    if (hint === 'download') return 'download'
    if (/\.m3u8(\?|$)/i.test(u)) return 'hls'
    if (/\.(mp4|webm|mkv)(\?|$)/i.test(u)) return 'direct'
    return 'embed'
  }
  if (/\.m3u8(\?|$)/i.test(u)) return 'hls'
  if (/\.mpd(\?|$)/i.test(u)) return 'dash'
  if (/\.(mp4|webm|mkv|m4v)(\?|$)/i.test(u)) return 'direct'
  if (DOWNLOAD_HOSTS.test(u)) return 'download'
  if (/(embed|player|stream|iframe)/i.test(u)) return 'embed'
  return 'unknown'
}

/** Hanya hls & direct yang bisa diputar langsung oleh video_player Flutter (dash tidak dijamin). */
const playable = (kind) => kind === 'hls' || kind === 'direct'

module.exports = { classifyUrl, playable }
