'use strict'
// Model data ternormalisasi. Semua adapter WAJIB mengeluarkan bentuk ini.
// Field yang tidak disediakan sumber bernilai null / [] (tidak pernah diisi data karangan).

const str = (v) => (v === undefined || v === null || String(v).trim() === '' ? null : String(v).trim())
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : null }
const arr = (v) => (Array.isArray(v) ? v.filter(x => x !== null && x !== undefined && x !== '') : [])

/** Ringkasan anime untuk kartu/list. */
function summary(o) {
  return {
    id: `${o.source}:${o.key}`,
    source: o.source,
    key: String(o.key),
    title: str(o.title) || '(tanpa judul)',
    poster: str(o.poster),
    status: str(o.status),
    type: str(o.type),
    rating: num(o.rating),
    year: str(o.year),
    episodeInfo: str(o.episodeInfo),
    genres: arr(o.genres).map(String),
    // true bila key dihitung dari URL episode (heuristik), bukan dari halaman anime
    keyDerived: !!o.keyDerived,
  }
}

function episodeItem(o) {
  return {
    number: num(o.number),
    title: str(o.title),
    // ref dipakai untuk memanggil /api/episode (nomor, id, atau URL tergantung sumber)
    ref: String(o.ref ?? o.number ?? ''),
    date: str(o.date),
    // false bila episode hanya punya link unduhan (tanpa streaming)
    streamable: o.streamable !== false,
  }
}

function detail(o) {
  return {
    ...summary(o),
    cover: str(o.cover) || str(o.poster),
    altTitles: str(o.altTitles),
    synopsis: str(o.synopsis),
    studio: str(o.studio),
    totalEpisodes: o.totalEpisodes ?? null,
    trailer: str(o.trailer),
    episodes: arr(o.episodes).map(episodeItem),
    related: arr(o.related).map(r => ({ title: str(r.title), relation: str(r.relation), source: o.source, key: str(r.key) })),
    sourceUrl: str(o.sourceUrl),
  }
}

/** kind: hls | direct | dash | embed | download | unknown */
function streamSource(o) {
  return {
    kind: o.kind,
    url: String(o.url),
    label: str(o.label),
    server: str(o.server),
    resolution: str(o.resolution),
    playable: o.kind === 'hls' || o.kind === 'direct',
  }
}

function episodePayload(o) {
  return {
    source: o.source,
    animeKey: String(o.animeKey),
    number: num(o.number),
    title: str(o.title),
    sources: arr(o.sources).map(streamSource),
    prevRef: str(o.prevRef),
    nextRef: str(o.nextRef),
    note: str(o.note),
  }
}

module.exports = { summary, detail, episodeItem, episodePayload, streamSource, str, num, arr }
