'use strict'
const V = require('../utils/validate')
const agg = require('../services/aggregator')
const { TtlCache } = require('../utils/cache')

/** Bangun tabel rute. Setiap handler menerima (URLSearchParams) dan mengembalikan objek JSON. */
function buildRoutes({ registry, cache }) {
  const ids = registry.ids
  const src = (p) => V.oneSource(p.get('source'), ids)
  const srcs = (p) => V.sourceList(p.get('sources'), ids)
  const cached = async (key, fn, ttl) => {
    const { value, cached: hit } = await cache.wrap(key, fn, ttl)
    return { ...value, _cache: hit ? 'hit' : 'miss' }
  }

  return {
    '/health': async () => ({ ok: true, time: new Date().toISOString(), sources: ids, cacheEntries: cache.size }),

    '/api/sources': async () => ({ sources: registry.describe() }),

    '/api/home': (p) => {
      const s = srcs(p)
      return cached(`home|${s}`, () => agg.home(registry, s))
    },

    // kind: latest | ongoing | completed
    '/api/list': (p) => {
      const kind = String(p.get('kind') || '')
      if (!['latest', 'ongoing', 'completed'].includes(kind)) throw V.bad('kind harus latest|ongoing|completed')
      const s = srcs(p); const pg = V.page(p.get('page'))
      return cached(`list|${kind}|${s}|${pg}`, () => agg.list(registry, s, kind, pg))
    },

    '/api/search': (p) => {
      const q = V.query(p.get('q')); const s = srcs(p); const pg = V.page(p.get('page'))
      return cached(`search|${q.toLowerCase()}|${s}|${pg}`, () => agg.search(registry, s, q, pg), 120000)
    },

    '/api/anime': (p) => {
      const source = src(p); const key = V.animeKey(source, p.get('key'))
      return cached(`anime|${source}|${key}`, async () => ({ anime: await registry.get(source).detail(key) }))
    },

    // ep = nomor episode / id / URL tergantung sumber (gunakan field `ref` dari daftar episode)
    '/api/episode': (p) => {
      const source = src(p); const key = V.animeKey(source, p.get('key'))
      const ref = String(p.get('ref') ?? '')
      if (!ref || ref.length > 300) throw V.bad('ref wajib diisi')
      if (source === 'kuramanime' || source === 'nanimeid') V.episodeNumber(ref)
      // sumber streaming sering memberi token sementara: cache pendek
      return cached(`ep|${source}|${key}|${ref}`, async () => ({ episode: await registry.get(source).episode(key, ref) }), 60000)
    },
  }
}

module.exports = { buildRoutes, TtlCache }
