/**
* Animein 
* credit : sakaxabeII
*/
const BASE = "https://animeinweb.com";
const PROXY = BASE + "/api/proxy/3/2";

const HEADERS = {
  "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/154.0.0.0 Mobile Safari/537.36",
  "Accept": "application/json",
  "Referer": "https://animeinweb.com/",
  "x-proxy-secret": process.env.ANIMEIN_PROXY_SECRET || ""
};

async function get(path, params = {}) {
  if (!HEADERS["x-proxy-secret"]) throw new Error("ANIMEIN_PROXY_SECRET belum diset di backend/.env");
  const url = new URL(PROXY + "/" + path.replace(/^\//, ""));
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, v);
  }

  const res = await fetch(url, { headers: HEADERS, signal: AbortSignal.timeout(30000) });
  if (!res.ok) throw new Error("HTTP " + res.status);

  const json = await res.json();
  if (json.error || json.status !== 200) {
    throw new Error("API error: " + JSON.stringify(json));
  }
  return json.data || {};
}


async function home(day, limit = 30) {
  day = day || ["MINGGU", "SENIN", "SELASA", "RABU", "KAMIS", "JUMAT", "SABTU"][new Date().getDay()];
  const data = await get("home/data", { day, limit });
  return data;
}

async function search(keyword, page = 0) {
  if (!keyword) {
    throw new Error("Pakai: node animein.js search <nama anime>");
  }
  const data = await get("explore/movie", {
    page: page,
    sort: "views",
    keyword: keyword
  });
  return data;
}

async function detail(id) {
  if (!id) {
    throw new Error("Pakai: node animein.js detail <id>");
  }
  const data = await get("movie/detail/" + id);
  return data;
}

async function episodes(id, page = 0) {
  if (!id) {
    throw new Error("Pakai: node animein.js eps <id> [page]");
  }
  const data = await get("movie/episode/" + id, { page: page });
  return data;
}

async function findEpisodeId(animeId, episodeNumber) {
  let page = 0;
  while (page < 30) {
    const data = await get("movie/episode/" + animeId, { page: page });
    const list = data.episode || [];
    if (list.length === 0) break;

    const found = list.find(e => Number(e.index) === Number(episodeNumber));
    if (found) return found.id;

    page++;
  }
  return null;
}

async function stream(arg1, arg2) {
  if (!arg1) {
    throw new Error("stream butuh anime_id+episode atau episode_id");
  }

  let episodeId = arg1;

  if (arg2) {
    episodeId = await findEpisodeId(arg1, arg2);
    if (!episodeId) {
      throw new Error("Episode " + arg2 + " tidak ditemukan di anime " + arg1);
    }
  }

  const data = await get("episode/streamnew/" + episodeId);
  return data;
}

const args = process.argv.slice(2);
const cmd = args[0];

module.exports = { home, search, detail, episodes, findEpisodeId, stream };

if (require.main === module) (async () => {
  try {
    if (cmd === "home") {
      console.log(JSON.stringify(await home(), null, 2));
    } else if (cmd === "search") {
      console.log(JSON.stringify(await search(args.slice(1).join(" ")), null, 2));
    } else if (cmd === "detail") {
      console.log(JSON.stringify(await detail(args[1]), null, 2));
    } else if (cmd === "eps") {
      console.log(JSON.stringify(await episodes(args[1], args[2] || 0), null, 2));
    } else if (cmd === "stream") {
      console.log(JSON.stringify(await stream(args[1], args[2]), null, 2));
    } else {
      console.log(JSON.stringify({
        usage: {
          home: "node animein.js home",
          search: "node animein.js search <nama anime>",
          detail: "node animein.js detail <id>",
          eps: "node animein.js eps <id> [page]",
          stream: "node animein.js stream <anime_id> <episode_number>   atau   node animein.js stream <episode_id>"
        }
      }, null, 2));
    }
  } catch (err) {
    console.log(JSON.stringify({ error: err.message }, null, 2));
  }
})();