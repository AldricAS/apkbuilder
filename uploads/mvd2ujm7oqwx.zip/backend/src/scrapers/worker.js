'use strict'
// Menjalankan satu fungsi scraper SINKRON (execFileSync curl) di thread terpisah
// supaya event loop server tidak terblokir. Modul/fungsi dipilih dari whitelist di registry,
// bukan dari input pengguna.
const { parentPort, workerData } = require('worker_threads')
const path = require('path')

try {
  const mod = require(path.join(__dirname, workerData.file))
  const fn = mod[workerData.fn]
  if (typeof fn !== 'function') throw new Error('fungsi scraper tidak ditemukan: ' + workerData.fn)
  Promise.resolve(fn(...workerData.args))
    .then(v => parentPort.postMessage({ ok: true, value: v }))
    .catch(e => parentPort.postMessage({ ok: false, error: String(e && e.message || e) }))
} catch (e) {
  parentPort.postMessage({ ok: false, error: String(e && e.message || e) })
}
