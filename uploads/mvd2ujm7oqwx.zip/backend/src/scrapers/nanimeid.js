/**
 * nanimeid.js
 * Creator: xDonzCode
 * Type: CommonJs
 * Base: https://nanimeid(.)lol
 * Sumber: https://whatsapp.com/channel/0029VbDT59vC1Fu4nO1w6t2d
 * Sumber: https://whatsapp.com/channel/0029Vb8kHBk7T8beomv2wd0y
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const Sitex = 'nanimeid.lol';
const Int_v = 'a353dcb713b44b27d3233f391a538800'; 
/* Jangan Diubah Diatas Kalo Gamau Error Deks */

/* https request */
function request(pathname, opts = {}) {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        hostname: Sitex,
        path: pathname,
        method: opts.method || 'GET',
        headers: {
          Accept: 'text/html, application/xhtml+xml',
          'X-Requested-With': 'XMLHttpRequest',
          'X-Inertia': 'true',
          'X-Inertia-Version': Int_v,
          'User-Agent':
            'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36',
          Referer: `https://${Sitex}${pathname}`,
          ...(opts.headers || {}),
        },
      },
      (res) => {
        let data = '';
        res.on('data', (c) => (data += c));
        res.on('end', () =>
          resolve({ status: res.statusCode, headers: res.headers, body: data })
        );
      }
    );
    req.on('error', reject);
    req.setTimeout(30000, () => req.destroy(new Error('timeout')));
    req.end();
  });
}

async function fetchJSON(pathname) {
  const res = await request(pathname);
  if (res.status !== 200) throw new Error(`HTTP ${res.status} on ${pathname}`);
  try {
    return JSON.parse(res.body);
  } catch {
    throw new Error(`Invalid JSON from ${pathname}`);
  }
}

function downloadFile(url, dest) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    https
      .get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
        if (res.statusCode !== 200) {
          file.close();
          fs.unlink(dest, () => {});
          return reject(new Error(`HTTP ${res.statusCode} on ${url}`));
        }
        res.pipe(file);
        file.on('finish', () => file.close(() => resolve(dest)));
      })
      .on('error', (err) => {
        file.close();
        fs.unlink(dest, () => {});
        reject(err);
      });
  });
}

/* Manga */

/* list manga [page] */
async function cmdMangaList(page = 1) {
  const json = await fetchJSON(`/manga?page=${page}`);
  const m = json.props.mangas;
  const out = {
    page: m.current_page,
    total: m.total,
    last_page: m.last_page,
    count: m.data.length,
    data: m.data.map((x) => ({
      id: x.id,
      title: x.title,
      slug: x.slug,
      type: x.type,
      status: x.status,
      rating: x.rating,
      views: x.views_count,
      poster: x.poster,
      genres: x.genres.map((g) => g.name),
      last_chapter: x.last_chapter
        ? { title: x.last_chapter.title, slug: x.last_chapter.slug }
        : null,
    })),
  };
  return out;
}

/* detail manga <slug> */
async function cmdMangaDetail(slug) {
  if (!slug) throw new Error('Usage: node nanimeid.js manga <slug>');
  const json = await fetchJSON(`/manga/${slug}`);
  const m = json.props.manga;
  const out = {
    id: m.id,
    title: m.title,
    slug: m.slug,
    type: m.type,
    status: m.status,
    author: m.author,
    artist: m.artist,
    release_year: m.release_year,
    rating: m.rating,
    views: m.views_count,
    synopsis: m.synopsis,
    poster: m.poster,
    source_url: m.source_url,
    genres: m.genres.map((g) => g.name),
    total_chapters: m.chapters.length,
    chapters: m.chapters.map((c) => ({
      id: c.id,
      title: c.title,
      number: c.chapter_number,
      slug: c.slug,
    })),
  };
  return out;
}

/* chapter manga <slug> <number> */
async function cmdMangaChapter(slug, number) {
  if (!slug || !number)
    throw new Error('Usage: node nanimeid.js chapter <slug> <number>');
  const json = await fetchJSON(`/manga/${slug}/chapter/${number}`);
  const p = json.props;
  const out = {
    manga: { id: p.manga.id, title: p.manga.title, slug: p.manga.slug },
    chapter: {
      id: p.chapter.id,
      title: p.chapter.title,
      number: p.chapter.chapter_number,
    },
    prev: p.prev ? { number: p.prev.chapter_number, slug: p.prev.slug } : null,
    next: p.next ? { number: p.next.chapter_number, slug: p.next.slug } : null,
    total_images: p.chapter.images.length,
    images: p.chapter.images.map((img) => img.image_path),
  };
  return out;
}

/* download manga <slug> <number> [outdir] */
async function cmdMangaDownload(slug, number, outdir) {
  if (!slug || !number)
    throw new Error('Usage: node nanimeid.js download <slug> <number> [dir]');
  const json = await fetchJSON(`/manga/${slug}/chapter/${number}`);
  const p = json.props;
  const images = p.chapter.images.map((img) => img.image_path);
  const dir = outdir || path.join(process.cwd(), 'downloads', `${slug}-ch${number}`);
  fs.mkdirSync(dir, { recursive: true });

  const results = [];
  for (let i = 0; i < images.length; i++) {
    const url = images[i];
    const ext = path.extname(new URL(url).pathname) || '.webp';
    const filename = String(i + 1).padStart(3, '0') + ext;
    const dest = path.join(dir, filename);
    try {
      await downloadFile(url, dest);
      results.push({ order: i + 1, file: filename, ok: true });
      process.stderr.write(`[${i + 1}/${images.length}] ${filename}\n`);
    } catch (e) {
      results.push({ order: i + 1, file: filename, ok: false, error: e.message });
      process.stderr.write(`[${i + 1}/${images.length}] FAILED\n`);
    }
  }
  const out = {
    manga: { title: p.manga.title, slug: p.manga.slug },
    chapter: { number: p.chapter.chapter_number, title: p.chapter.title },
    output_dir: dir,
    total: images.length,
    success: results.filter((r) => r.ok).length,
    failed: results.filter((r) => !r.ok).length,
    files: results,
  };
  return out;
}

/* Anime */

/* search anime <query> (pakai /api/search - ringan & cepat) */
async function cmdAnimeSearch(query) {
  if (!query) throw new Error('Usage: node nanimeid.js search <query>');
  const res = await request(`/api/search?q=${encodeURIComponent(query)}`, {
    headers: { Accept: 'application/json' },
  });
  if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
  const data = JSON.parse(res.body);
  return { query, count: data.length, data };
}

/* explore <query> [page] (pakai /explore - hasil lengkap + pagination) */
async function cmdExplore(query, page = 1) {
  if (!query) throw new Error('Usage: node nanimeid.js explore <query> [page]');
  const json = await fetchJSON(`/explore?search=${encodeURIComponent(query)}&page=${page}`);
  const a = json.props.animes;
  const out = {
    query,
    page: a.current_page,
    total: a.total,
    last_page: a.last_page,
    count: a.data.length,
    data: a.data.map((x) => ({
      id: x.id,
      anilist_id: x.anilist_id,
      title: x.title,
      slug: x.slug,
      type: x.type,
      status: x.status,
      episodes_count: x.episodes_count,
      rating: x.rating,
      release_year: x.release_year,
      studio: x.studio,
      poster: x.poster,
      trailer_url: x.trailer_url,
      genres: x.genres.map((g) => g.name),
      synopsis: x.synopsis,
    })),
  };
  return out;
}

/* anime <slug> (detail + daftar episode) */
async function cmdAnimeDetail(slug) {
  if (!slug) throw new Error('Usage: node nanimeid.js anime <slug>');
  const json = await fetchJSON(`/anime/${slug}`);
  const a = json.props.anime;
  const out = {
    id: a.id,
    anilist_id: a.anilist_id,
    title: a.title,
    slug: a.slug,
    type: a.type,
    status: a.status,
    rating: a.rating,
    release_year: a.release_year,
    studio: a.studio,
    episodes_count: a.episodes_count,
    views: a.views_count,
    synopsis: a.synopsis,
    poster: a.poster,
    trailer_url: a.trailer_url,
    genres: a.genres.map((g) => g.name),
    total_episodes: a.episodes.length,
    episodes: a.episodes.map((e) => ({
      id: e.id,
      number: e.number,
      title: e.title,
    })),
  };
  return out;
}

/* episode <slug> <number> (detail + mirror + download links) */
async function cmdAnimeEpisode(slug, number) {
  if (!slug || !number)
    throw new Error('Usage: node nanimeid.js episode <slug> <number>');
  const json = await fetchJSON(`/anime/${slug}/episode/${number}`);
  const p = json.props;
  const e = p.episode;
  const out = {
    anime: { id: p.anime.id, title: p.anime.title, slug: p.anime.slug },
    episode: {
      id: e.id,
      title: e.title,
      number: e.number,
      video_url: e.video_url,
    },
    mirror_streams: e.mirror_streams || [],
    download_urls: e.download_urls || [],
    total_episodes: p.allEpisodes.length,
    all_episodes: p.allEpisodes.map((x) => ({ number: x.number, title: x.title })),
  };
  return out;
}

/* Main */
async function main() {
  const [cmd, ...args] = process.argv.slice(2);

  try {
    switch (cmd) {
      // Manga
      case 'list':
        await cmdMangaList(parseInt(args[0]) || 1);
        break;
      case 'manga':
        await cmdMangaDetail(args[0]);
        break;
      case 'chapter':
        await cmdMangaChapter(args[0], args[1]);
        break;
      case 'download':
        await cmdMangaDownload(args[0], args[1], args[2]);
        break;

      // Anime
      case 'search':
        await cmdAnimeSearch(args.join(' '));
        break;
      case 'explore':
        await cmdExplore(args[0], parseInt(args[1]) || 1);
        break;
      case 'anime':
        await cmdAnimeDetail(args[0]);
        break;
      case 'episode':
        await cmdAnimeEpisode(args[0], args[1]);
        break;

      default:
        console.log(`nanimeid.js — by xDonzCode

MANGA:
  node nanimeid.js list [page]                 List manga (default: 1)
  node nanimeid.js manga <slug>                Detail manga + daftar chapter
  node nanimeid.js chapter <slug> <n>          Info chapter + URL gambar
  node nanimeid.js download <slug> <n> [dir]   Download gambar chapter

ANIME:
  node nanimeid.js search <query>              Cari anime/manga (light endpoint)
  node nanimeid.js explore <query> [page]      Explore anime (full + pagination)
  node nanimeid.js anime <slug>                Detail anime + daftar episode
  node nanimeid.js episode <slug> <n>          Mirror stream + link download

Contoh:
  node nanimeid.js search Tokyo
  node nanimeid.js explore Tokyo 1
  node nanimeid.js anime tokyo-esp
  node nanimeid.js episode tokyo-esp 1
  node nanimeid.js manga obshchaka
  node nanimeid.js chapter obshchaka 1
  node nanimeid.js download obshchaka 1
`);
        process.exit(1);
    }
  } catch (e) {
    process.stdout.write(JSON.stringify({ error: true, message: e.message }) + '\n');
    process.exit(1);
  }
}

if (require.main === module) main();

module.exports = {
  request,
  fetchJSON,
  downloadFile,
  cmdMangaList,
  cmdMangaDetail,
  cmdMangaChapter,
  cmdMangaDownload,
  cmdAnimeSearch,
  cmdExplore,
  cmdAnimeDetail,
  cmdAnimeEpisode,
};