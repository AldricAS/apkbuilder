#!/usr/bin/env node
/**
 * alqanime.js
 * Creator: xDonzCode
 * Type: CommonJs
 * Base: https://alqanime(.)net
 * Sumber: https://whatsapp.com/channel/0029VbDT59vC1Fu4nO1w6t2d    
 * Sumber: https://whatsapp.com/channel/0029Vb8kHBk7T8beomv2wd0y
 */ 
 
 
const { execFileSync } = require("node:child_process");

const CREATOR = "xDonzCode";
const BASE = "https://alqanime.net";
const UA = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

function curl(url) {
  return execFileSync("curl", [
    ...(process.env.CURL_INSECURE === "1" ? ["-k"] : []),
    "-sL", "--compressed",
    "--max-time", "40",
    "-H", `User-Agent: ${UA}`,
    "-H", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "-H", "Accept-Language: id-ID,id;q=0.9,en;q=0.8",
    "-H", `Referer: ${BASE}/`,
    url,
  ], { maxBuffer: 50 * 1024 * 1024, timeout: 45000 }).toString("utf8");
}

function decodeEntities(s) {
  return (s || "")
    .replace(/&quot;/g, '"').replace(/&#039;/g, "'")
    .replace(/&#8217;/g, "'").replace(/&#8211;/g, "–")
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">").replace(/&nbsp;/g, " ")
    .replace(/&#8230;/g, "…")
    .replace(/&#8220;/g, '"').replace(/&#8221;/g, '"')
    .trim();
}

function stripTags(s) {
  return decodeEntities((s || "").replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim();
}

function dedupe(arr, key = "url") {
  const seen = new Set();
  return arr.filter(x => {
    const k = x[key];
    if (!k || seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

function parseAnimeCard(block) {
  const urlMatch = block.match(/<a\s+href="(https:\/\/alqanime\.net\/[^"]+)"[^>]*itemprop="url"/)
                || block.match(/<a\s+href="(https:\/\/alqanime\.net\/[^"]+)"/);
  if (!urlMatch) return null;

  const url = urlMatch[1];

  const imgMatch = block.match(/<img[^>]+src="([^"]+)"[^>]*class="[^"]*wp-post-image[^"]*"/)
                || block.match(/<img[^>]+src="([^"]+)"/);

  const titleMatch = block.match(/<h2[^>]*itemprop="headline"[^>]*>([\s\S]*?)<\/h2>/)
                  || block.match(/<span class="ntitle">([^<]+)<\/span>/)
                  || block.match(/<div class="eggtitle">([^<]+)<\/div>/);

  const ntitleMatch = block.match(/<span class="ntitle">([^<]+)<\/span>/)
                   || block.match(/<div class="eggtitle">([^<]+)<\/div>/);

  const statusMatch = block.match(/<span class="epx">([^<]+)<\/span>/)
                   || block.match(/<div class="status[^"]*">([^<]+)<\/div>/);

  const typeMatch = block.match(/<div class="typez[^"]*">([^<]+)<\/div>/)
                 || block.match(/<div class="eggtype[^"]*">([^<]+)<\/div>/);

  const ratingMatch = block.match(/<div class="numscore">([\d.]+)<\/div>/);
  const episodeMatch = block.match(/<div class="eggepisode">([^<]+)<\/div>/);

  return {
    title: titleMatch ? stripTags(titleMatch[1]) : null,
    short_title: ntitleMatch ? stripTags(ntitleMatch[1]) : null,
    url,
    slug: url.replace(/^https:\/\/alqanime\.net\//, "").replace(/\/$/, ""),
    thumbnail: imgMatch ? imgMatch[1] : null,
    status: statusMatch ? stripTags(statusMatch[1]) : null,
    type: typeMatch ? stripTags(typeMatch[1]) : null,
    rating: ratingMatch ? ratingMatch[1] : null,
    episode_info: episodeMatch ? stripTags(episodeMatch[1]) : null,
  };
}

function findAllAnime(html) {
  const out = [];
  const blocks = html.split(/<article\s+class="bs[^"]*"/).slice(1);
  for (const block of blocks) {
    const full = '<article class="bs" ' + block;
    const p = parseAnimeCard(full);
    if (p && p.title && p.url) out.push(p);
  }
  return dedupe(out, "url");
}

function parsePagination(html) {
  const current = (html.match(/<span class=['"]page-numbers current['"]>(\d+)<\/span>/) || [])[1];
  const next = (html.match(/<a class=['"]page-numbers next['"][^>]*href=['"]([^'"]+)['"]/) || [])[1];
  const last = (html.match(/<a class=['"]page-numbers last['"][^>]*href=['"]([^'"]+)['"]/) || [])[1];
  const lastPageMatch = last && last.match(/\/page\/(\d+)\//);

  return {
    current_page: current ? parseInt(current) : 1,
    next_page_url: next || null,
    last_page_url: last || null,
    last_page: lastPageMatch ? parseInt(lastPageMatch[1]) : null,
  };
}

function cmdHome() {
  const html = curl(BASE + "/");
  const sections = [];

  const hotMatch = html.match(/<div class="releases hothome"><h2>([^<]+)<\/h2>[\s\S]*?<div class="listupd[^"]*">([\s\S]*?)<\/div>\s*<\/div>/);
  if (hotMatch) {
    const anime = findAllAnime(hotMatch[2]);
    if (anime.length) sections.push({ title: stripTags(hotMatch[1]), anime });
  }

  const latestMatch = html.match(/<div class="releases latesthome"><h3>([^<]+)<\/h3>[\s\S]*?<div class="listupd">([\s\S]*?)<div class="pagination"/);
  if (latestMatch) {
    const anime = findAllAnime(latestMatch[2]);
    if (anime.length) sections.push({ title: stripTags(latestMatch[1]), anime });
  }

  if (sections.length === 0) {
    const anime = findAllAnime(html);
    if (anime.length) sections.push({ title: "All", anime });
  }

  return {
    creator: CREATOR,
    source: BASE + "/",
    type: "home",
    scraped_at: new Date().toISOString(),
    total_sections: sections.length,
    sections,
  };
}

function cmdList(page = 1) {
  const url = page === 1 ? BASE + "/" : `${BASE}/page/${page}/`;
  const html = curl(url);
  const anime = findAllAnime(html);
  const pagination = parsePagination(html);

  return {
    creator: CREATOR,
    source: url,
    type: "list",
    page: parseInt(page),
    scraped_at: new Date().toISOString(),
    total: anime.length,
    pagination,
    anime,
  };
}

function cmdSearch(keyword) {
  const url = `${BASE}/?s=${encodeURIComponent(keyword)}`;
  const html = curl(url);
  const anime = findAllAnime(html);

  return {
    creator: CREATOR,
    source: url,
    type: "search",
    keyword,
    scraped_at: new Date().toISOString(),
    total: anime.length,
    anime,
  };
}

function cmdSeason(slug, page = 1) {
  const url = `${BASE}/advanced-search/?season%5B%5D=${encodeURIComponent(slug)}`;
  const html = curl(url);
  const anime = findAllAnime(html);

  return {
    creator: CREATOR,
    source: url,
    type: "season",
    season: slug,
    page: parseInt(page),
    scraped_at: new Date().toISOString(),
    total: anime.length,
    anime,
  };
}

function cmdAnime(animeUrl) {
  if (!/^https?:\/\//.test(animeUrl)) {
    animeUrl = `${BASE}/${animeUrl.replace(/^\/+|\/+$/g, "")}/`;
  }
  const html = curl(animeUrl);

  const titleMatch = html.match(/<h1[^>]*class="[^"]*entry-title[^"]*"[^>]*>([\s\S]*?)<\/h1>/)
                  || html.match(/<h1[^>]*itemprop="name"[^>]*>([\s\S]*?)<\/h1>/);
  const title = titleMatch ? stripTags(titleMatch[1]) : null;

  const thumbMatch = html.match(/<div class="thumb"[^>]*itemprop="image"[^>]*>[\s\S]*?<img[^>]+src="([^"]+)"/)
                  || html.match(/<img[^>]+class="[^"]*wp-post-image[^"]*"[^>]+src="([^"]+)"/);
  const thumbnail = thumbMatch ? thumbMatch[1] : null;

  const coverMatch = html.match(/<div class="bigcover">[\s\S]*?<div class="ime">[\s\S]*?<img[^>]+src="([^"]+)"/);
  const cover = coverMatch ? coverMatch[1] : thumbnail;

  const alterMatch = html.match(/<span class="alter">([\s\S]*?)<\/span>/);
  const alternative_titles = alterMatch ? stripTags(alterMatch[1]) : null;

  const synopsisMatch = html.match(/<div class="bixbox synp">[\s\S]*?<div class="entry-content"[^>]*itemprop="description"[^>]*>([\s\S]*?)<\/div>/)
                     || html.match(/<div class="entry-content"[^>]*itemprop="description"[^>]*>([\s\S]*?)<\/div>/);
  const synopsis = synopsisMatch ? stripTags(synopsisMatch[1]) : null;

  const info = {};
  const speBlock = html.match(/<div class="spe">([\s\S]*?)<\/div>\s*<div class="genxed"/);
  if (speBlock) {
    const spans = [...speBlock[1].matchAll(/<span[^>]*>(?:<b>|<b[^>]*>)([^<]+):?\s*<\/b>\s*([\s\S]*?)<\/span>/g)];
    for (const m of spans) {
      const key = m[1].replace(/:/g, "").trim();
      let val = stripTags(m[2]);
      const aMatch = m[2].match(/<a[^>]*>([^<]+)<\/a>/);
      if (aMatch) val = stripTags(aMatch[1]);
      info[key] = val;
    }
  }

  const genres = [...html.matchAll(/<div class="genxed">([\s\S]*?)<\/div>/g)]
    .flatMap(m => [...m[1].matchAll(/<a[^>]+href="[^"]*\/tag\/([^"\/]+)\/"[^>]*>([^<]+)<\/a>/g)])
    .map(m => ({ slug: m[1], name: decodeEntities(m[2]) }));
  const uniqGenres = dedupe(genres, "slug");

  const casts = [...html.matchAll(/<a class="casts"[^>]*>([^<]+)<\/a>/g)]
    .map(m => decodeEntities(m[1]).trim());

  const scoreMatch = html.match(/<strong>Score\s*([\d.]+)<\/strong>/)
                  || html.match(/itemprop="ratingValue"\s*content="([\d.]+)"/);
  const rating = scoreMatch ? scoreMatch[1] : null;

  const bookmarkMatch = html.match(/<div class="bmc">Diikuti\s*(\d+)\s*orang<\/div>/);
  const bookmark_count = bookmarkMatch ? parseInt(bookmarkMatch[1]) : 0;

  const trailerMatch = html.match(/<a[^>]+data-fancybox[^>]+href="([^"]+)"/);
  const trailer = trailerMatch ? trailerMatch[1] : null;

  const episodes = [];
  const dlBlocks = html.split(/<div class="soraddl dlone">/).slice(1);

  for (const block of dlBlocks) {
    const epTitleMatch = block.match(/<h3>([^<]+)<\/h3>/);
    const episodeTitle = epTitleMatch ? stripTags(epTitleMatch[1]) : null;

    const downloads = [];
    const rows = block.split(/<tr>/).slice(1);
    for (const row of rows) {
      const resMatch = row.match(/<div class="res">([^<]+)<\/div>/);
      const resolution = resMatch ? stripTags(resMatch[1]) : null;

      const links = [];
      const linkRegex = /<a[^>]+href="([^"]+)"[^>]*>([^<]+)<\/a>/g;
      let lm;
      while ((lm = linkRegex.exec(row)) !== null) {
        links.push({ host: stripTags(lm[2]), url: lm[1] });
      }

      if (resolution && links.length) {
        downloads.push({ resolution, links });
      }
    }

    if (episodeTitle && downloads.length) {
      episodes.push({ title: episodeTitle, downloads });
    }
  }

  const allLinks = [];
  for (const ep of episodes) {
    for (const q of ep.downloads) {
      for (const l of q.links) {
        allLinks.push({
          episode: ep.title,
          resolution: q.resolution,
          host: l.host,
          url: l.url,
        });
      }
    }
  }

  const related = [];
  const relatedBlock = html.match(/<ul class="relatedlist">([\s\S]*?)<\/ul>/);
  if (relatedBlock) {
    const items = [...relatedBlock[1].matchAll(/<a[^>]+href="([^"]+)"[^>]*>[\s\S]*?<span class="relatitle">([^<]+)<\/span>[\s\S]*?<span class="relrelation">([^<]+)<\/span>[\s\S]*?<\/a>/g)];
    for (const m of items) {
      related.push({
        title: stripTags(m[2]),
        relation: stripTags(m[3]),
        url: m[1],
      });
    }
  }

  const postedMatch = html.match(/<time itemprop="datePublished" datetime="([^"]+)"[^>]*>([^<]+)<\/time>/);
  const modifiedMatch = html.match(/<time itemprop="dateModified" datetime="([^"]+)"[^>]*>([^<]+)<\/time>/);

  return {
    creator: CREATOR,
    source: animeUrl,
    type: "anime_detail",
    scraped_at: new Date().toISOString(),
    title,
    alternative_titles,
    thumbnail,
    cover,
    rating,
    synopsis,
    genres: uniqGenres,
    casts,
    info,
    trailer,
    bookmark_count,
    posted: postedMatch ? { datetime: postedMatch[1], text: postedMatch[2] } : null,
    modified: modifiedMatch ? { datetime: modifiedMatch[1], text: modifiedMatch[2] } : null,
    total_episodes: episodes.length,
    total_links: allLinks.length,
    episodes,
    related,
  };
}

function cmdDownload(slug, quality = "1080p") {
  const detail = cmdAnime(slug);

  const links = [];
  for (const ep of detail.episodes) {
    const q = ep.downloads.find(d => d.resolution === quality);
    if (q) {
      for (const l of q.links) {
        links.push({
          episode: ep.title,
          resolution: q.resolution,
          host: l.host,
          url: l.url,
        });
      }
    }
  }

  return {
    creator: CREATOR,
    source: detail.source,
    type: "download_links",
    anime_title: detail.title,
    quality,
    scraped_at: new Date().toISOString(),
    total_episodes: detail.episodes.length,
    total_links: links.length,
    links,
  };
}

function cmdSchedule() {
  const url = `${BASE}/jadwal-rilis/`;
  const html = curl(url);

  const days = [];
  const dayBlocks = html.split(/<div class="bixbox">/).slice(1);

  for (const block of dayBlocks) {
    const titleMatch = block.match(/<h[23][^>]*>([^<]+)<\/h[23]>/);
    if (!titleMatch) continue;

    const dayName = stripTags(titleMatch[1]);
    if (!/senin|selasa|rabu|kamis|jumat|sabtu|minggu|monday|tuesday|wednesday|thursday|friday|saturday|sunday/i.test(dayName)) continue;

    const anime = findAllAnime(block);
    if (anime.length) {
      days.push({ day: dayName, total: anime.length, anime });
    }
  }

  return {
    creator: CREATOR,
    source: url,
    type: "schedule",
    scraped_at: new Date().toISOString(),
    total_days: days.length,
    days,
  };
}

function showUsage() {
  console.error(`
🎬 Alqanime Scraper — by ${CREATOR}

Usage:
  node alqanime.js home                          → homepage
  node alqanime.js list [page]                   → daftar anime
  node alqanime.js search "keyword"              → cari anime
  node alqanime.js season <slug>                 → filter musim (fall-2026, dll)
  node alqanime.js anime <url|slug>              → detail anime + download links
  node alqanime.js download <slug> [quality]     → ambil link download
  node alqanime.js schedule                      → jadwal rilis

Contoh:
  node alqanime.js home
  node alqanime.js list 2
  node alqanime.js search "tensei"
  node alqanime.js season fall-2026
  node alqanime.js anime "kikansha-no-mahou-wa-tokubetsu-desu-2nd-season"
  node alqanime.js download "kikansha-no-mahou-wa-tokubetsu-desu-2nd-season" 1080p
  node alqanime.js schedule
`);
}

function main() {
  const [mode, ...rest] = process.argv.slice(2);

  if (!mode) { showUsage(); process.exit(1); }

  let result;
  try {
    switch (mode) {
      case "home":
        result = cmdHome(); break;

      case "list":
        result = cmdList(rest[0] || 1); break;

      case "search": case "cari":
        if (!rest[0]) throw new Error("Butuh keyword");
        result = cmdSearch(rest.join(" ")); break;

      case "season": case "musim":
        if (!rest[0]) throw new Error("Butuh slug season (contoh: fall-2026)");
        result = cmdSeason(rest[0]); break;

      case "anime": case "detail":
        if (!rest[0]) throw new Error("Butuh URL/slug");
        result = cmdAnime(rest[0]); break;

      case "download": case "dl":
        if (!rest[0]) throw new Error("Butuh URL/slug anime");
        result = cmdDownload(rest[0], rest[1] || "1080p"); break;

      case "schedule": case "jadwal":
        result = cmdSchedule(); break;

      default:
        console.error("[!] Mode tidak dikenal:", mode);
        showUsage();
        process.exit(1);
    }

    console.log(JSON.stringify(result, null, 2));
  } catch (e) {
    console.error("[!] Error:", e.message);
    process.exit(1);
  }
}

if (require.main === module) main();

module.exports = { BASE, cmdHome, cmdList, cmdSearch, cmdSeason, cmdAnime, cmdDownload, cmdSchedule };
