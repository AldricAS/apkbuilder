#!/usr/bin/env node
/**
 * samehadaku.js
 *
 * Creator: xDonzCode
 * Saluran: https://whatsapp.com/channel/0029VbDT59vC1Fu4nO1w6t2d
 * Saluran 2 : https://whatsapp.com/channel/0029Vb8kHBk7T8beomv2wd0y
 * Source : https://v2(.)samehadaku(.)ow/
 *
 * Usage:
 *   node samehadaku.js home                  → scrape homepage
 *   node samehadaku.js search "Tokyo"        → cari anime
 *   node samehadaku.js query "Tokyo"         → alias search
 *   node samehadaku.js anime "one-piece"     → detail anime (list episode)
 *   node samehadaku.js episode "https://v2.samehadaku.how/tokyo-revengers-season-3-episode-12/" → detail episode
 *   node samehadaku.js latest                → episode terbaru
 *
 * Output: JSON ke stdout
 */

const { execFileSync } = require("node:child_process");

const CREATOR = "xDonzCode";
const BASE    = "https://v2.samehadaku.how";
const AJAX    = `${BASE}/wp-admin/admin-ajax.php`;

const UA = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

// ---------- Fetch pakai curl ----------
function fetchHTML(url) {
  return execFileSync("curl", [
    ...(process.env.CURL_INSECURE === "1" ? ["-k"] : []),
    "-sL", "--compressed", "--max-time", "30",
    "-H", `User-Agent: ${UA}`,
    "-H", "Accept-Language: id-ID,id;q=0.9,en;q=0.8",
    url,
  ], { timeout: 35000, maxBuffer: 20 * 1024 * 1024 }).toString("utf8");
}

function fetchJSON(url) {
  const raw = fetchHTML(url);
  try {
    return JSON.parse(raw);
  } catch {
    throw new Error(`Response bukan JSON: ${raw.slice(0, 200)}`);
  }
}

// ---------- Helper ----------
function decodeEntities(s) {
  return (s || "")
    .replace(/&#8211;/g, "–")
    .replace(/&#8217;/g, "'")
    .replace(/&#039;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#038;/g, "&")
    .replace(/&nbsp;/g, " ")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .trim();
}

function stripTags(s) {
  return decodeEntities((s || "").replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim();
}

// ---------- 1. HOME ----------
function scrapeHome() {
  const html = fetchHTML(BASE + "/");

  // Top 10
  const top10 = [];
  const topBlock = html.match(/<div class="topten-animesu">([\s\S]*?)<\/div>\s*<button/);
  if (topBlock) {
    const items = topBlock[1].split("<li>").slice(1);
    for (const it of items) {
      const url    = (it.match(/href="([^"]+)"/) || [])[1];
      const title  = (it.match(/title="([^"]+)"/) || [])[1];
      const rating = (it.match(/<i class="fa fa-star">★<\/i>\s*([\d.]+)/) || [])[1];
      const img    = (it.match(/<img src="([^"]+)"/) || [])[1];
      const rank   = (it.match(/<b>TOP<\/b>\s*<b>(\d+)<\/b>/) || [])[1];
      if (url && title) {
        top10.push({
          rank: rank ? parseInt(rank) : null,
          title: decodeEntities(title),
          url,
          rating: rating || null,
          image: img || null,
        });
      }
    }
  }

  // Latest Episode
  const latest = scrapeLatestFromHome(html);

  // Project Movie
  const movie = [];
  const movieBlock = html.match(/id="sdw_getpostanime-4"([\s\S]*?)<\/aside>/);
  if (movieBlock) {
    const items = movieBlock[1].split("<li>").slice(1);
    for (const it of items) {
      const url   = (it.match(/<h2><a[^>]+href="([^"]+)"/) || [])[1];
      const title = (it.match(/<h2><a[^>]*>([\s\S]*?)<\/a>/) || [])[1];
      const img   = (it.match(/<img src="([^"]+)"/) || [])[1];
      const genres = [...it.matchAll(/<a href="[^"]*\/genre\/[^"]*"[^>]*>([^<]+)<\/a>/g)].map(m => decodeEntities(m[1]));
      const date = (it.match(/<span>([A-Za-z]{3} \d{1,2}, \d{4}|\s*[A-Za-z]{3} \d{1,2}, \d{4})<\/span>/) || [])[1];

      if (url && title) {
        movie.push({
          title: stripTags(title),
          url,
          image: img || null,
          genres,
          date: date ? date.trim() : null,
        });
      }
    }
  }

  return {
    creator: CREATOR,
    source: BASE + "/",
    type: "home",
    scraped_at: new Date().toISOString(),
    top10,
    latest_episode: latest,
    project_movie: movie,
  };
}

// ---------- Helper: Latest dari HTML home ----------
function scrapeLatestFromHome(html) {
  const latest = [];
  const latestBlock = html.match(/<div class="post-show">([\s\S]*?)<\/div>\s*<\/div>/);
  if (!latestBlock) return latest;

  const items = latestBlock[1].split("<li itemscope").slice(1);
  for (const it of items) {
    const animeUrl = (it.match(/<h2[^>]*>[\s\S]*?<a href="([^"]+)"/) || [])[1];
    const epUrl    = (it.match(/<div class="thumb">[\s\S]*?<a href="([^"]+)"/) || [])[1];
    const title    = (it.match(/<h2[^>]*>[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/) || [])[1];
    const epNum    = (it.match(/<b>Episode<\/b>\s*(\d+)/) || [])[1];
    const img      = (it.match(/<img src="([^"]+)"/) || [])[1];
    const author   = (it.match(/<span itemprop="name">([^<]+)<\/span>/) || [])[1];
    const released = (it.match(/<b>Released on:<\/b>\s*([^<]+)/) || [])[1];

    if (animeUrl && title) {
      latest.push({
        title: stripTags(title),
        episode: epNum ? parseInt(epNum) : null,
        anime_url: animeUrl,
        episode_url: epUrl || null,
        image: img || null,
        author: author ? author.trim() : null,
        released: released ? released.trim() : null,
      });
    }
  }
  return latest;
}

// ---------- 2. SEARCH ----------
function searchAnime(keyword) {
  const url = `${AJAX}?action=samehada_live_search&s=${encodeURIComponent(keyword)}`;
  const json = fetchJSON(url);

  return {
    creator: CREATOR,
    source: BASE + "/",
    type: "search",
    keyword,
    scraped_at: new Date().toISOString(),
    total: json.data?.length || 0,
    results: (json.data || []).map(d => ({
      id: d.id,
      title: decodeEntities(d.title),
      url: d.url,
      thumb: d.thumb,
      score: d.score || null,
      type: d.type,
      status: d.status,
    })),
  };
}

// ---------- 3. DETAIL ANIME (list episode) ----------
function scrapeAnime(slug) {
  const url = `${BASE}/anime/${slug.replace(/^\/+|\/+$/g, "")}/`;
  const html = fetchHTML(url);

  // Title — di halaman anime
  const title =
    stripTags((html.match(/<h1[^>]*class="entry-title"[^>]*>([\s\S]*?)<\/h1>/) || [])[1]) ||
    stripTags((html.match(/<h1[^>]*itemprop="name"[^>]*>([\s\S]*?)<\/h1>/) || [])[1]);

  // Thumb
  const thumb =
    (html.match(/<div class="thumb"[^>]*>[\s\S]*?<img[^>]+src="([^"]+)"/) || [])[1] ||
    (html.match(/<img[^>]+class="anmsa"[^>]+src="([^"]+)"/) || [])[1];

  // Sinopsis
  const sinopsis = stripTags((html.match(/<div class="desc">[\s\S]*?<p>([\s\S]*?)<\/p>/) || [])[1]);

  // Info
  const info = {};
  const infoBlock = html.match(/<div class="infox">([\s\S]*?)<\/div>\s*<\/div>/);
  if (infoBlock) {
    const spans = infoBlock[1].split("<span>").slice(1);
    for (const sp of spans) {
      const m = sp.match(/<b>([^<]+)<\/b>\s*:?\s*([\s\S]*?)<\/span>/);
      if (m) {
        const key = m[1].replace(/:/g, "").trim();
        const val = stripTags(m[2]);
        info[key] = val;
      }
    }
  }

  // Genre
  const genres = [...html.matchAll(/<a href="[^"]*\/genre\/[^"]*"[^>]*>([^<]+)<\/a>/g)]
    .map(m => decodeEntities(m[1]))
    .filter((v, i, a) => a.indexOf(v) === i);

  // Episode list — pakai <div class="lstepsiode">
  const episodes = [];
  const epBlock = html.match(/<div class="lstepsiode[^"]*">([\s\S]*?)<\/div>\s*<\/div>/);
  if (epBlock) {
    const items = epBlock[1].split("<li").slice(1);
    for (const it of items) {
      const epUrl = (it.match(/<a href="([^"]+)"/) || [])[1];
      const epTitle = stripTags((it.match(/<a[^>]*>([\s\S]*?)<\/a>/) || [])[1]);
      const date = (it.match(/<span class="date">([^<]+)<\/span>/) || [])[1];
      const img = (it.match(/<img[^>]+src="([^"]+)"/) || [])[1];
      if (epUrl) {
        episodes.push({
          title: epTitle,
          url: epUrl,
          date: date ? date.trim() : null,
          image: img || null,
        });
      }
    }
  }

  return {
    creator: CREATOR,
    source: url,
    type: "anime",
    scraped_at: new Date().toISOString(),
    title,
    thumb,
    sinopsis,
    genres,
    info,
    total_episodes: episodes.length,
    episodes,
  };
}

// ---------- 4. DETAIL EPISODE ----------
function scrapeEpisode(url) {
  if (!/^https?:\/\//.test(url)) {
    url = `${BASE}/` + url.replace(/^\/+/, "");
  }
  const html = fetchHTML(url);

  // Title — pakai itemprop="name"
  const title = stripTags((html.match(/<h1[^>]*itemprop="name"[^>]*>([\s\S]*?)<\/h1>/) || [])[1]);

  // Deskripsi
  const description = stripTags(
    (html.match(/<div class="entry-content entry-content-single"[^>]*itemprop="description"[^>]*>([\s\S]*?)<\/div>/) || [])[1]
  );

  // Episode number
  const episodeNumber = (html.match(/<span itemprop="episodeNumber">(\d+)<\/span>/) || [])[1];

  // Waktu
  const timePost = (html.match(/<span class="time-post">[\s\S]*?<\/i>\s*([^<]+)/) || [])[1];

  // Server / player
  const servers = [];
  const serverMatches = [...html.matchAll(/<div id="player-option-(\d+)"[^>]*data-embed="([^"]*)"[^>]*>[\s\S]*?<span>([^<]+)<\/span>/g)];
  for (const m of serverMatches) {
    const embedRaw = decodeEntities(m[2]);
    const iframeMatch = embedRaw.match(/src="([^"]+)"/);
    servers.push({
      nume: parseInt(m[1]),
      name: m[3].trim(),
      embed_url: iframeMatch ? iframeMatch[1] : null,
      embed_html: embedRaw,
    });
  }

  // Download links
  const downloads = [];
  const dlBlocks = [...html.matchAll(/<div class="download-eps"[^>]*>([\s\S]*?)<\/div>\s*<\/div>/g)];
  for (const block of dlBlocks) {
    const quality = stripTags((block[1].match(/<p><b>([^<]+)<\/b><\/p>/) || [])[1]);
    const rows = block[1].split("<li>").slice(1);
    const items = [];
    for (const r of rows) {
      const res = stripTags((r.match(/<strong>([^<]+)<\/strong>/) || [])[1]);
      const links = [...r.matchAll(/<a href="([^"]+)"[^>]*>([^<]+)<\/a>/g)].map(x => ({
        host: x[2].trim(),
        url: x[1],
      }));
      if (res) items.push({ resolution: res, links });
    }
    if (quality) downloads.push({ format: quality, items });
  }

  // Prev / Next episode
  const prevMatch = html.match(/<div class="nvs">\s*<a href="([^"]+)"/);
  const nextMatch = html.match(/<div class="nvs rght">\s*<a href="([^"]+)"/);
  const allEpUrl = (html.match(/<div class="nvs nvsc">\s*<a href="([^"]+)"/) || [])[1];

  // Info anime
  const animeTitle = stripTags(
    (html.match(/<h2[^>]*itemprop="partOfSeries"[^>]*>([\s\S]*?)<\/h2>/) || [])[1]
  );
  const animeThumb = (html.match(/<div class="thumb"[^>]*itemprop="image"[^>]*>[\s\S]*?<img[^>]+src="([^"]+)"/) || [])[1];

  // Episode lainnya
  const otherEpisodes = [];
  const otherBlock = html.match(/<div class="lstepsiode listeps">([\s\S]*?)<\/div>\s*<\/div>/);
  if (otherBlock) {
    const items = otherBlock[1].split("<li").slice(1);
    for (const it of items) {
      const epUrl = (it.match(/<a href="([^"]+)"/) || [])[1];
      const epTitle = stripTags((it.match(/<a[^>]*>([\s\S]*?)<\/a>/) || [])[1]);
      const date = (it.match(/<span class="date">([^<]+)<\/span>/) || [])[1];
      const img = (it.match(/<img[^>]+src="([^"]+)"/) || [])[1];
      const active = /<li class="active"/.test(it);
      if (epUrl) {
        otherEpisodes.push({
          title: epTitle,
          url: epUrl,
          date: date ? date.trim() : null,
          image: img || null,
          current: active,
        });
      }
    }
  }

  return {
    creator: CREATOR,
    source: url,
    type: "episode",
    scraped_at: new Date().toISOString(),
    title,
    description,
    episode_number: episodeNumber ? parseInt(episodeNumber) : null,
    time_post: timePost ? timePost.trim() : null,
    anime: {
      title: animeTitle,
      thumb: animeThumb,
      url: allEpUrl,
    },
    servers,
    downloads,
    navigation: {
      prev: prevMatch ? prevMatch[1] : null,
      next: nextMatch ? nextMatch[1] : null,
      all_episodes: allEpUrl || null,
    },
    other_episodes: otherEpisodes,
  };
}

// ---------- 5. LATEST ONLY ----------
function scrapeLatest() {
  const html = fetchHTML(BASE + "/");
  const latest = scrapeLatestFromHome(html);
  return {
    creator: CREATOR,
    source: BASE + "/",
    type: "latest",
    scraped_at: new Date().toISOString(),
    total: latest.length,
    episodes: latest,
  };
}

// ---------- Main ----------
function main() {
  const [mode, arg] = process.argv.slice(2);

  if (!mode) {
    console.error(`
Usage:
  node samehadaku.js home                                  → scrape homepage
  node samehadaku.js search "Tokyo"                        → cari anime
  node samehadaku.js query "Tokyo"                         → alias search
  node samehadaku.js anime "one-piece"                     → detail anime
  node samehadaku.js episode "https://v2.samehadaku.how/tokyo-revengers-season-3-episode-12/"  → detail episode
  node samehadaku.js latest                                → episode terbaru
`);
    process.exit(1);
  }

  let result;
  switch (mode) {
    case "home":
    case "beranda":
      result = scrapeHome();
      break;

    case "search":
    case "query":
    case "cari":
      if (!arg) { console.error("[!] Butuh keyword."); process.exit(1); }
      result = searchAnime(arg);
      break;

    case "anime":
    case "detail":
      if (!arg) { console.error("[!] Butuh slug."); process.exit(1); }
      result = scrapeAnime(arg);
      break;

    case "episode":
    case "ep":
      if (!arg) { console.error("[!] Butuh URL episode."); process.exit(1); }
      result = scrapeEpisode(arg);
      break;

    case "latest":
    case "terbaru":
      result = scrapeLatest();
      break;

    default:
      console.error(`[!] Mode tidak dikenal: ${mode}`);
      process.exit(1);
  }

  console.log(JSON.stringify(result, null, 2));
}

if (require.main === module) {
  try {
    main();
  } catch (err) {
    console.error("[!] Error:", err.message);
    process.exit(1);
  }
}

module.exports = { BASE, scrapeHome, searchAnime, scrapeAnime, scrapeEpisode, scrapeLatest };