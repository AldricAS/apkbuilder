/**
 * Kuramanime Scrape
 * Base : https://v20.kuramanime.ing
 * Credit : Sakaxabell
 *
 * npm i omnify-bypass
 *
 * Usage :
 *   node kuramanime.js --ongoing [page]
 *   node kuramanime.js --search <q>
 *   node kuramanime.js --anime <id/slug>
 *   node kuramanime.js --episode <id/slug> <ep>
 */

const https = require('https')
const { URL } = require('url')

const BASE = process.env.KURA_BASE || 'https://v20.kuramanime.ing'
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
const FALLBACK_AUTH = process.env.KURA_FALLBACK_AUTH || 'kJuHHkaqcBFXiGMHQf6bJw8YAyDcwGD8Ur'

let bypassFn = null
try {
  const mod = require('omnify-bypass')
  if (typeof mod.fetch === 'function') bypassFn = mod.fetch
  else if (typeof mod.get === 'function') bypassFn = mod.get
  else if (typeof mod.fetchWithBot === 'function') bypassFn = mod.fetchWithBot
} catch (_) {}

function plainReq(method, url, headers, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url)
    const payload = body || null
    const h = Object.assign({
      'User-Agent': UA,
      Accept: '*/*',
      Referer: BASE + '/'
    }, headers || {})
    if (payload) {
      h['Content-Type'] = h['Content-Type'] || 'application/x-www-form-urlencoded'
      h['Content-Length'] = Buffer.byteLength(payload)
    }
    const r = https.request({
      hostname: u.hostname,
      path: u.pathname + u.search,
      method,
      headers: h,
      timeout: 35000
    }, res => {
      let d = ''
      res.setEncoding('utf8')
      res.on('data', c => d += c)
      res.on('end', () => resolve({ status: res.statusCode, body: d, headers: res.headers }))
    })
    r.on('error', reject)
    r.on('timeout', () => { r.destroy(); reject(new Error('timeout')) })
    if (payload) r.write(payload)
    r.end()
  })
}

async function extractBody(res) {
  if (res == null) return { status: 0, body: '' }
  if (typeof res === 'string') return { status: 200, body: res }
  if (Buffer.isBuffer(res)) return { status: 200, body: res.toString('utf8') }
  const status = res.status || res.statusCode || 200
  if (typeof res.text === 'function') {
    try { return { status, body: String(await res.text() || '') } } catch (_) {}
  }
  const body = res.body || res.data || res.html || res.content || ''
  return { status, body: String(body || '') }
}

async function getHtml(path) {
  const url = path.startsWith('http') ? path : BASE + path
  if (bypassFn) {
    try {
      const res = await bypassFn(url)
      const { status, body } = await extractBody(res)
      return { status, body, via: 'omnify', len: body.length }
    } catch (e) {
      return { status: 0, body: '', via: 'omnify-error:' + e.message, len: 0 }
    }
  }
  const r = await plainReq('GET', url)
  return { status: r.status, body: r.body, via: 'plain', len: (r.body || '').length }
}

function strip(s) {
  return String(s || '').replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim()
}

function isCf(html, status, len) {
  if (len > 8000 && /animeList|changeServer|csrf-token|episode|kuramadrive/i.test(html || '')) return false
  if (status === 403) return true
  if (len < 6000 && /Just a moment|Verify you are human|cf-browser-verification/i.test(html || '')) return true
  return false
}

function parseList(html) {
  const out = []
  const re = /href=["']([^"']*\/anime\/[^"']+)["'][\s\S]{0,1200}?<(?:h5|h4|h3)[^>]*>([\s\S]*?)<\/(?:h5|h4|h3)>/gi
  let m
  const seen = {}
  while ((m = re.exec(html)) && out.length < 40) {
    const href = m[1]
    const fullMatch = href.match(/\/anime\/(\d+)\/([^/"'?]+)/) || href.match(/\/anime\/([^/"'?]+)/)
    let id = null, slug = ''
    if (fullMatch && fullMatch[2]) { id = fullMatch[1]; slug = fullMatch[2] }
    else if (fullMatch) { slug = fullMatch[1] }
    if (!slug || seen[slug]) continue
    seen[slug] = 1
    const pathKey = id ? (id + '/' + slug) : slug
    const chunk = html.slice(Math.max(0, m.index - 200), m.index + 800)
    const img = (chunk.match(/(?:src|data-src)=["']([^"']+\.(?:jpg|jpeg|png|webp)[^"']*)["']/i) || [])[1]
    out.push({
      title: strip(m[2]), id, slug, path: pathKey,
      poster: img || null,
      url: href.startsWith('http') ? href : BASE + href
    })
  }
  return out
}

function parseDetail(html, slug) {
  const title = strip((html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1] || '')
  const poster = (html.match(/(?:src|data-src)=["']([^"']+\.(?:jpg|png|webp)[^"']*)["']/i) || [])[1]
  const episodes = []
  const seen = {}
  const dc = (html.match(/id=["']episodeLists["'][^>]*data-content=["']([^"']+)["']/i) || [])[1]
  const blob = dc ? dc.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>') : html
  const er = /href=["']([^"']*\/episode\/(\d+)[^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi
  let em
  while ((em = er.exec(blob))) {
    if (seen[em[2]]) continue
    seen[em[2]] = 1
    episodes.push({ number: +em[2], title: strip(em[3]), url: em[1].startsWith('http') ? em[1] : BASE + em[1] })
  }
  episodes.sort((a, b) => a.number - b.number)
  return { title: title || slug, slug, poster: poster || null, episodes, first: episodes[0] || null, latest: episodes[episodes.length - 1] || null }
}

function parseEpisodePage(html) {
  const title = strip((html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1] || '')
  const csrf = (html.match(/name=["']csrf-token["'][^>]*content=["']([^"']+)["']/i)
    || html.match(/content=["']([^"']+)["'][^>]*name=["']csrf-token["']/i) || [])[1] || null
  const dataKk = (html.match(/data-kk=["']([^"']+)["']/i) || [])[1] || null
  const servers = []
  const optRe = /<option[^>]+value=["']([^"']+)["'][^>]*>([\s\S]*?)<\/option>/gi
  let m
  while ((m = optRe.exec(html))) {
    const v = m[1].trim()
    if (!v || /pilih|select/i.test(v)) continue
    servers.push({ id: v, label: strip(m[2]) || v })
  }
  const sources = []
  const srcRe = /<source[^>]+src=["']([^"']+)["'][^>]*(?:size=["'](\d+)["'])?/gi
  while ((m = srcRe.exec(html))) sources.push({ src: m[1], resolution: m[2] ? m[2] + 'p' : null })
  const embeds = []
  const iRe = /<iframe[^>]+src=["']([^"']+)["']/gi
  while ((m = iRe.exec(html))) embeds.push(m[1])
  const inputs = {}
  const inRe = /<input[^>]+(?:id|name)=["']([^"']+)["'][^>]*value=["']([^"']*)["']/gi
  while ((m = inRe.exec(html))) inputs[m[1]] = m[2]
  const inRe2 = /<input[^>]+value=["']([^"']*)["'][^>]*(?:id|name)=["']([^"']+)["']/gi
  while ((m = inRe2.exec(html))) if (!inputs[m[2]]) inputs[m[2]] = m[1]
  return { title, csrf, dataKk, servers, sources, embeds, inputs }
}

async function fetchAssets(dataKk) {
  if (!dataKk) return null
  const r = await getHtml('/assets/js/' + dataKk + '.js')
  if (!r.body || r.len < 10) {
    try {
      const pr = await plainReq('GET', BASE + '/assets/js/' + dataKk + '.js')
      if (pr.body) r.body = pr.body
    } catch (_) {}
  }
  const body = r.body || ''
  const cfg = (key) => {
    const m = body.match(new RegExp('\\b' + key + '\\s*:\\s*[\'"]([^\'"]+)[\'"]'))
    return m ? m[1] : ''
  }
  const a = {
    prefixAuthRoute: cfg('MIX_PREFIX_AUTH_ROUTE_PARAM'),
    authRouteParam: cfg('MIX_AUTH_ROUTE_PARAM'),
    authKey: cfg('MIX_AUTH_KEY'),
    authToken: cfg('MIX_AUTH_TOKEN'),
    pageTokenKey: cfg('MIX_PAGE_TOKEN_KEY'),
    streamServerKey: cfg('MIX_STREAM_SERVER_KEY')
  }
  a.fuckId = (a.authKey && a.authToken) ? (a.authKey + ':' + a.authToken) : ''
  a.found = !!(a.authRouteParam && a.pageTokenKey)
  return a
}

async function fetchPageToken(csrf, assets) {
  if (!assets || !assets.authRouteParam) return null
  const headers = {
    'User-Agent': UA,
    'X-Fuck-ID': assets.fuckId,
    'X-Request-ID': Math.random().toString(36).slice(2, 8),
    'X-Request-Index': '0',
    'X-CSRF-TOKEN': csrf || '',
    'X-Requested-With': 'XMLHttpRequest',
    Accept: '*/*',
    Referer: BASE + '/'
  }
  const routes = []
  if (assets.authRouteParam) routes.push('assets/' + assets.authRouteParam)
  if (assets.prefixAuthRoute) routes.push((assets.prefixAuthRoute + assets.authRouteParam).replace(/^\/+/, ''))
  for (const route of [...new Set(routes)]) {
    try {
      const pr = await plainReq('GET', BASE + '/' + route.replace(/^\/+/, ''), headers)
      const text = (pr.body || '').trim()
      if (pr.status === 200 && text && !text.startsWith('<') && text.length < 800) return text
    } catch (_) {}
    const r = await getHtml('/' + route.replace(/^\/+/, ''))
    const text = (r.body || '').trim()
    if (r.status === 200 && text && !text.startsWith('<') && text.length < 800) return text
  }
  return null
}

async function fetchAuthToken(tokenAuthJs, referer) {
  const path = tokenAuthJs || '/storage/leviathan.js'
  let body = ''
  try {
    const r = await getHtml(path.startsWith('http') ? path : path)
    body = r.body || ''
  } catch (_) {}
  if (!body || body.startsWith('<')) {
    try {
      const r = await plainReq('GET', path.startsWith('http') ? path : BASE + path, {
        Referer: referer, 'X-Requested-With': 'XMLHttpRequest', Accept: '*/*'
      })
      body = r.body || ''
    } catch (_) {}
  }
  let m = body.match(/Authorization['"]?\s*[:=]\s*['"]Bearer\s+([^'"]+)['"]/i)
  if (m) return m[1]
  m = body.match(/Bearer\s+([A-Za-z0-9._\-]{16,})/)
  if (m) return m[1]
  return FALLBACK_AUTH
}


function cleanSources(list) {
  const out = []
  const seen = {}
  for (const s of list || []) {
    let u = String(s.src || '').replace(/&amp;/g, '&').replace(/&quot;/g, '"')
    if (!u || seen[u]) continue
    if (/manifest\.json$/i.test(u)) continue
    if (/kuramanime\.ing\/(assets|misc|storage)/i.test(u)) continue
    seen[u] = 1
    let res = s.resolution
    const rm = u.match(/(\d{3,4})p/i)
    if (!res && rm) res = rm[1] + 'p'
    out.push({ src: u, resolution: res || null, server: s.server || null })
  }
  // prefer higher res first
  out.sort((a, b) => parseInt(b.resolution || 0) - parseInt(a.resolution || 0))
  return out
}
function cleanDownloads(list) {
  const out = []
  const seen = {}
  for (const d of list || []) {
    let u = String(d.url || '').replace(/&amp;/g, '&')
    if (!u || seen[u]) continue
    seen[u] = 1
    let title = d.title || u
    if (/pixeldrain\.com\/d\/(\w+)/i.test(u)) title = 'pixeldrain/' + RegExp.$1
    else if (/kuramadrive\.com\/(kdrive|kturbo)\/(\w+)/i.test(u)) title = RegExp.$1 + '/' + RegExp.$2
    out.push({ title, url: u })
  }
  return out
}

function parseStreamHtml(html, server) {
  const sources = []
  const embeds = []
  const downloads = []
  const seen = {}
  function addSrc(u, res) {
    if (!u || seen[u]) return
    seen[u] = 1
    sources.push({ src: u, resolution: res || null, server })
  }
  function addEmb(u) {
    if (!u || seen[u]) return
    seen[u] = 1
    embeds.push(u)
  }
  function addDl(u, title) {
    if (!u || seen[u]) return
    seen[u] = 1
    downloads.push({ title: title || u, url: u })
  }
  let m
  const srcRe = /<source[^>]+src=["']([^"']+)["'][^>]*(?:size=["'](\d+)["'])?/gi
  while ((m = srcRe.exec(html))) addSrc(m[1], m[2] ? m[2] + 'p' : null)
  const vRe = /<video[^>]+src=["']([^"']+)["']/gi
  while ((m = vRe.exec(html))) addSrc(m[1])
  const iRe = /<iframe[^>]+src=["']([^"']+)["']/gi
  while ((m = iRe.exec(html))) addEmb(m[1])
  // any mp4/m3u8/mpd direct
  const uRe = /https?:\/\/[^\s"'<>\\]+/gi
  while ((m = uRe.exec(html))) {
    const u = m[0].replace(/[.,);]+$/, '')
    if (/\.(mp4|m3u8|mpd)(\?|$)/i.test(u) || /\/hls\/|\/dash\/|playlist|manifest/i.test(u)) addSrc(u)
    else if (/pixeldrain|mediafire|kuramadrive|dood|filemoon|mega\.nz|archive/i.test(u)) addDl(u)
    else if (/embed|player|stream/i.test(u) && !/kuramanime\.ing/i.test(u)) addEmb(u)
  }
  // data-src
  const dsRe = /data-src=["'](https?:\/\/[^"']+)["']/gi
  while ((m = dsRe.exec(html))) {
    if (/\.(mp4|m3u8)/i.test(m[1])) addSrc(m[1])
    else addEmb(m[1])
  }
  return { sources, embeds, downloads }
}

async function postStream(pageUrl, pageToken, server, assets, csrf, auth) {
  const ptKey = (assets && assets.pageTokenKey) || 'pageToken'
  const ssKey = (assets && assets.streamServerKey) || 'stream_server'
  const link = pageUrl + '?' + encodeURIComponent(ptKey) + '=' + encodeURIComponent(pageToken || '') +
    '&' + encodeURIComponent(ssKey) + '=' + encodeURIComponent(server) + '&page=1'
  const headers = {
    Accept: 'text/html, */*; q=0.01',
    'X-Requested-With': 'XMLHttpRequest',
    'X-CSRF-TOKEN': csrf || '',
    Origin: BASE,
    Referer: pageUrl,
    'Content-Type': 'application/x-www-form-urlencoded',
    'User-Agent': UA
  }
  if (assets && assets.fuckId) headers['X-Fuck-ID'] = assets.fuckId

  const authVariants = []
  if (auth) {
    authVariants.push(auth)
    if (!/^Bearer\s/i.test(auth)) authVariants.push('Bearer ' + auth)
  } else authVariants.push('')

  let best = { status: 0, sources: [], embeds: [], downloads: [], link, htmlLen: 0 }
  for (const a of authVariants) {
    const body = 'authorization=' + encodeURIComponent(a)
    try {
      const r = await plainReq('POST', link, headers, body)
      const parsed = parseStreamHtml(r.body || '', server)
      const hit = (parsed.sources.length + parsed.embeds.length + parsed.downloads.length)
      const cur = Object.assign({
        status: r.status,
        htmlLen: (r.body || '').length,
        link,
        authForm: a.slice(0, 20),
        preview: (r.body || '').includes('player') || (r.body || '').includes('<source')
          ? 'has-player-or-source'
          : ((r.body || '').match(/https?:\/\/[^\s"']{20,80}/) || [''])[0]
      }, parsed)
      if (hit > 0) return cur
      if (cur.htmlLen > best.htmlLen) best = cur
    } catch (e) {
      best.error = e.message
    }
  }
  return best
}

async function resolveEpisode(animePath, ep) {
  const basePath = '/anime/' + String(animePath).replace(/^\/+/, '').replace(/^anime\//, '')
  const epPath = basePath + '/episode/' + ep
  const pageUrl = BASE + epPath

  const page = await getHtml(epPath)
  if (String(page.via).indexOf('omnify-error') === 0) {
    return { error: 'omnify_failed', detail: page.via }
  }
  if (isCf(page.body, page.status, page.len)) {
    return { error: 'cloudflare_blocked', via: page.via, len: page.len }
  }

  const meta = parseEpisodePage(page.body)
  meta.pageUrl = pageUrl
  meta.via = page.via
  meta.len = page.len
  meta.anime = animePath
  meta.episode = ep

  if (meta.sources.length) {
    meta.note = 'direct source'
    return meta
  }

  const assets = await fetchAssets(meta.dataKk)
  meta.assetsOk = !!(assets && assets.found)
  meta.mix = assets ? {
    pageTokenKey: assets.pageTokenKey,
    streamServerKey: assets.streamServerKey,
    authRoute: assets.authRouteParam,
    hasFuckId: !!assets.fuckId
  } : null

  const pageToken = await fetchPageToken(meta.csrf, assets)
  meta.hasPageToken = !!pageToken

  const tokenAuthJs = (meta.inputs && meta.inputs.tokenAuthJs) || '/storage/leviathan.js'
  const auth = await fetchAuthToken(tokenAuthJs, pageUrl)
  meta.hasAuth = !!auth

  // check-episode (Cloudstream mirror)
  const checkEp = meta.inputs && meta.inputs.checkEp
  if (checkEp) {
    try {
      const cr = await plainReq('GET', checkEp, {
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': meta.csrf || '',
        Referer: pageUrl,
        Accept: '*/*'
      })
      meta.checkEpStatus = cr.status
      meta.checkEpBody = (cr.body || '').slice(0, 120)
    } catch (e) {
      meta.checkEpError = e.message
    }
  }

  const serverList = (meta.servers && meta.servers.length)
    ? meta.servers.map(s => s.id)
    : ['kuramadrive']

  meta.streamTries = []
  for (const server of serverList.slice(0, 4)) {
    const result = await postStream(pageUrl, pageToken || '', server, assets, meta.csrf, auth)
    meta.streamTries.push({
      server,
      status: result.status,
      htmlLen: result.htmlLen,
      sources: (result.sources || []).length,
      embeds: (result.embeds || []).length,
      downloads: (result.downloads || []).length,
      error: result.error || null
    })
    if (result.sources && result.sources.length) {
      meta.sources = cleanSources(result.sources)
      meta.embeds = result.embeds
      meta.downloads = cleanDownloads(result.downloads)
      meta.note = 'OK POST ' + server
      // strip bulky fields
      delete meta.inputs
      delete meta.streamTries
      return meta
    }
    if (result.embeds && result.embeds.length) {
      meta.embeds = result.embeds
      meta.downloads = result.downloads
      meta.note = 'embed POST ' + server
      return meta
    }
    if (result.downloads && result.downloads.length) {
      meta.downloads = result.downloads
      meta.note = 'downloads POST ' + server
      return meta
    }
  }

  meta.note = 'POST done, sources masih kosong'
  return meta
}

async function run(cmd, a, b) {
  let path
  if (cmd === 'ongoing') path = '/anime/ongoing?order_by=popular&page=' + (a || 1)
  else if (cmd === 'finished') path = '/anime/finished?order_by=popular&page=' + (a || 1)
  else if (cmd === 'search') path = '/anime?order_by=popular&search=' + encodeURIComponent(a) + '&page=' + (b || 1)
  else if (cmd === 'anime') path = '/anime/' + String(a).replace(/^\/+/, '').replace(/^anime\//, '')
  else if (cmd === 'episode') return resolveEpisode(a, b)
  else if (cmd === 'home') path = '/'
  else throw new Error('cmd unknown')

  const r = await getHtml(path)
  if (String(r.via).indexOf('omnify-error') === 0) return { error: 'omnify_failed', detail: r.via }
  if (isCf(r.body, r.status, r.len)) return { error: 'cloudflare_blocked', via: r.via, len: r.len }

  if (cmd === 'ongoing' || cmd === 'finished') return { type: cmd, page: +(a || 1), via: r.via, results: parseList(r.body) }
  if (cmd === 'search') return { query: a, page: +(b || 1), via: r.via, results: parseList(r.body) }
  if (cmd === 'anime') return Object.assign({ via: r.via }, parseDetail(r.body, a))
  if (cmd === 'home') return { via: r.via, recent: parseList(r.body) }
}

function usage() {
  console.log('node kuramanime.js --ongoing | --search <q> | --anime <id/slug> | --episode <id/slug> <ep>')
}

async function main() {
  const args = process.argv.slice(2)
  if (!args.length) return usage()
  try {
    let out
    if (args[0] === '--ongoing') out = await run('ongoing', args[1])
    else if (args[0] === '--finished') out = await run('finished', args[1])
    else if (args[0] === '--search' && args[1]) {
      const rest = args.slice(1)
      let page = 1
      if (rest.length > 1 && /^\d+$/.test(rest[rest.length - 1])) page = rest.pop()
      out = await run('search', rest.join(' '), page)
    } else if (args[0] === '--anime' && args[1]) out = await run('anime', args[1])
    else if (args[0] === '--episode' && args[1] && args[2]) out = await run('episode', args[1], args[2])
    else if (args[0] === '--home') out = await run('home')
    else return usage()
    console.log(JSON.stringify(out, null, 2))
  } catch (e) {
    console.error(JSON.stringify({ error: e.message }, null, 2))
    process.exit(1)
  }
}
if (require.main === module) main()

module.exports = { run }
