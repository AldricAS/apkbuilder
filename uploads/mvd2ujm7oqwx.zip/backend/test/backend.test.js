'use strict'
// Tes OFFLINE: scraper dipalsukan (stub) dengan bentuk output yang dibaca dari kode scraper asli.
// Ini menguji normalisasi, validasi, agregasi, dan rute. BUKAN tes terhadap situs sumber nyata.
const test = require('node:test')
const assert = require('node:assert')
const http = require('http')
const { buildRegistry } = require('../src/services/registry')
const { createServer } = require('../server')
const { classifyUrl } = require('../src/utils/classify')
const V = require('../src/utils/validate')
const { collectStreams } = require('../src/services/adapters/animein')
const { keyFromUrl } = require('../src/services/adapters/samehadaku')

const fixtures = {
  'kuramanime.js:run': ([cmd, a, b]) => {
    if (cmd === 'ongoing' || cmd === 'search') return { results: [{ title: 'Tokyo Ghoul', id: '12', slug: 'tokyo-ghoul', path: '12/tokyo-ghoul', poster: 'https://x/p.jpg' }] }
    if (cmd === 'anime') return { title: 'Tokyo Ghoul', slug: a, poster: null, episodes: [{ number: 1, title: 'Ep 1', url: 'u' }] }
    if (cmd === 'episode') return { title: 'Ep', sources: [{ src: 'https://cdn/x/720p/v.mp4', resolution: '720p', server: 'kuramadrive' }], embeds: ['https://e/embed/1'], downloads: [{ title: 'pixeldrain/abc', url: 'https://pixeldrain.com/d/abc' }], note: 'OK' }
  },
  'nanimeid.js:cmdExplore': ([q, p]) => ({ page: p, last_page: 3, data: [{ slug: 'tokyo-esp', title: 'Tokyo ESP', poster: 'p', status: 'Ongoing', episodes_count: 12, genres: ['Action'] }] }),
  'nanimeid.js:cmdAnimeDetail': ([k]) => ({ title: 'Tokyo ESP', episodes_count: 12, episodes: [{ number: 1, title: 'a' }, { number: 2, title: 'b' }], genres: ['Action'] }),
  'nanimeid.js:cmdAnimeEpisode': ([k, n]) => ({ episode: { number: 1, title: 'a', video_url: null }, mirror_streams: [{ name: 'M1', url: 'https://m/embed/1' }, 'https://h/v.m3u8'], download_urls: [{ host: 'mega', url: 'https://mega.nz/f' }], all_episodes: [{ number: 1 }, { number: 2 }] }),
  'SameHadaku.js:searchAnime': () => ({ results: [{ title: 'Tokyo Ghoul', url: 'https://v2.samehadaku.how/anime/tokyo-ghoul/', thumb: 't', score: '8.1', type: 'TV', status: 'Completed' }] }),
  'SameHadaku.js:scrapeHome': () => ({ top10: [], project_movie: [], latest_episode: [{ title: 'Foo', episode: 3, anime_url: 'https://v2.samehadaku.how/foo-episode-3/', image: 'i' }] }),
  'SameHadaku.js:scrapeEpisode': () => ({ title: 'T', episode_number: 3, servers: [{ name: 'Mega', embed_url: 'https://v/embed/9' }], downloads: [{ format: 'MKV', items: [{ resolution: '720p', links: [{ host: 'Gdrive', url: 'https://drive.google.com/x' }] }] }], navigation: { prev: null, next: 'n' } }),
  'alqanime.js:cmdSearch': () => ({ anime: [{ title: 'Tokyo Ghoul', slug: 'tokyo-ghoul-a', thumbnail: null, rating: '8.0' }] }),
  'alqanime.js:cmdAnime': () => ({ title: 'X', info: { Status: 'Completed', Released: 'Fall 2014' }, genres: [{ slug: 'a', name: 'Action' }], episodes: [{ title: 'Episode 1', downloads: [{ resolution: '720p', links: [{ host: 'Mega', url: 'https://mega.nz/a' }] }] }], related: [] }),
  'animein.js:search': () => ({ movie: [{ id: 5, title: 'Tokyo Ghoul', image: '/img/a.jpg' }] }),
  'animein.js:stream': () => ({ stream: [{ quality: '720p', url: 'https://c/a.m3u8' }, { quality: '480p', file: 'https://c/a.mp4' }] }),
}

function stubCall(failing = []) {
  return async (file, fn, args) => {
    if (failing.includes(file)) throw new V.HttpError(502, 'upstream_error', 'down')
    const f = fixtures[file + ':' + fn]
    if (!f) throw new Error('no fixture ' + file + ':' + fn)
    return f(args)
  }
}

function get(server, path) {
  return new Promise((resolve, reject) => {
    const { port } = server.address()
    http.get({ port, path }, res => { let d = ''; res.on('data', c => d += c); res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(d) })) }).on('error', reject)
  })
}
async function withServer(opts, fn) {
  const registry = buildRegistry({ call: stubCall(opts.failing) })
  const { server } = createServer({ registry, env: opts.env || {} })
  await new Promise(r => server.listen(0, '127.0.0.1', r))
  try { await fn(server) } finally { server.close() }
}

test('classifyUrl membedakan jenis tautan', () => {
  assert.equal(classifyUrl('https://a/b.m3u8?x=1'), 'hls')
  assert.equal(classifyUrl('https://a/b.mp4'), 'direct')
  assert.equal(classifyUrl('https://pixeldrain.com/d/x'), 'download')
  assert.equal(classifyUrl('https://a/embed/1'), 'embed')
  assert.equal(classifyUrl('https://a/page', 'embed'), 'embed')
  assert.equal(classifyUrl('ftp://a'), 'unknown')
})

test('validasi menolak input berbahaya', () => {
  assert.throws(() => V.animeKey('nanimeid', '../etc/passwd'))
  assert.throws(() => V.animeKey('nanimeid', 'a/b'))
  assert.equal(V.animeKey('kuramanime', '12/tokyo-ghoul'), '12/tokyo-ghoul')
  assert.throws(() => V.samehadakuEpisodeUrl('https://evil.com/x'))
  assert.throws(() => V.samehadakuEpisodeUrl('http://169.254.169.254/'))
  assert.ok(V.samehadakuEpisodeUrl('https://v2.samehadaku.how/foo-episode-1/'))
  assert.throws(() => V.page('0')); assert.throws(() => V.query('a'))
})

test('keyFromUrl samehadaku: langsung vs turunan', () => {
  assert.deepEqual(keyFromUrl('https://v2.samehadaku.how/anime/foo/'), { key: 'foo', derived: false })
  assert.deepEqual(keyFromUrl('https://v2.samehadaku.how/foo-episode-3/'), { key: 'foo', derived: true })
})

test('collectStreams animein membaca struktur tak dikenal', () => {
  const r = collectStreams({ a: [{ quality: '720p', url: 'https://c/a.m3u8' }], b: { file: 'https://c/a.mp4' } })
  assert.equal(r.length, 2); assert.equal(r[0].resolution, '720p')
})

test('search menggabungkan duplikat lintas sumber dan menandai sumber', async () => {
  await withServer({}, async s => {
    const r = await get(s, '/api/search?q=tokyo%20ghoul')
    assert.equal(r.status, 200)
    const tg = r.body.results.filter(x => x.title === 'Tokyo Ghoul')
    assert.equal(tg.length, 1, 'duplikat harus digabung')
    assert.ok(tg[0].alsoOn.length >= 3)
    assert.ok(r.body.results.some(x => x.title === 'Tokyo ESP'))
  })
})

test('satu sumber gagal tidak menggagalkan yang lain', async () => {
  await withServer({ failing: ['SameHadaku.js', 'alqanime.js'] }, async s => {
    const r = await get(s, '/api/search?q=tokyo')
    assert.equal(r.status, 200)
    assert.equal(r.body.errors.length, 2)
    assert.ok(r.body.results.length >= 1)
  })
})

test('semua sumber gagal -> hasil kosong + daftar error, bukan data karangan', async () => {
  await withServer({ failing: ['kuramanime.js', 'nanimeid.js', 'SameHadaku.js', 'alqanime.js', 'animein.js'] }, async s => {
    const r = await get(s, '/api/search?q=tokyo')
    assert.equal(r.body.results.length, 0); assert.equal(r.body.errors.length, 5)
  })
})

test('detail & episode ternormalisasi', async () => {
  await withServer({}, async s => {
    const d = await get(s, '/api/anime?source=nanimeid&key=tokyo-esp')
    assert.equal(d.body.anime.episodes.length, 2); assert.equal(d.body.anime.synopsis, null)
    const e = await get(s, '/api/episode?source=nanimeid&key=tokyo-esp&ref=1')
    const kinds = e.body.episode.sources.map(x => x.kind)
    assert.deepEqual(kinds.sort(), ['download', 'embed', 'hls'])
    assert.equal(e.body.episode.nextRef, '2')
    const k = await get(s, '/api/episode?source=kuramanime&key=12/tokyo-ghoul&ref=1')
    const direct = k.body.episode.sources.find(x => x.kind === 'direct')
    assert.ok(direct && direct.playable)
    assert.ok(k.body.episode.sources.every(x => x.kind !== 'embed' || !x.playable))
    const sh = await get(s, '/api/episode?source=samehadaku&key=foo&ref=' + encodeURIComponent('https://v2.samehadaku.how/foo-episode-3/'))
    assert.ok(sh.body.episode.sources.every(x => !x.playable))
    const al = await get(s, '/api/anime?source=alqanime&key=x')
    assert.equal(al.body.anime.episodes[0].streamable, false); assert.equal(al.body.anime.status, 'Completed')
    const an = await get(s, '/api/episode?source=animein&key=5&ref=99')
    assert.equal(an.body.episode.sources.filter(x => x.playable).length, 2)
  })
})

test('SSRF: URL episode samehadaku di luar host sumber ditolak', async () => {
  await withServer({}, async s => {
    const r = await get(s, '/api/episode?source=samehadaku&key=foo&ref=' + encodeURIComponent('http://127.0.0.1:22/'))
    assert.equal(r.status, 400)
  })
})

test('auth token, rute tak dikenal, dan home parsial', async () => {
  await withServer({ env: { CLIENT_TOKEN: 'abc' } }, async s => {
    assert.equal((await get(s, '/api/sources')).status, 401)
    assert.equal((await get(s, '/health')).status, 200)
  })
  await withServer({ failing: ['kuramanime.js'] }, async s => {
    assert.equal((await get(s, '/nope')).status, 404)
    const h = await get(s, '/api/home?sources=samehadaku,kuramanime')
    assert.equal(h.status, 200); assert.equal(h.body.errors.length, 1); assert.ok(h.body.sections.length >= 1)
    assert.equal((await get(s, '/api/home?sources=bogus')).status, 400)
  })
})
