'use strict'
const http = require('http')
const { loadEnv, int } = require('./src/utils/env')
loadEnv()
const { buildRegistry } = require('./src/services/registry')
const { buildRoutes } = require('./src/routes/api')
const { TtlCache } = require('./src/utils/cache')
const { HttpError } = require('./src/utils/validate')

function createServer(opts = {}) {
  const env = opts.env || process.env
  const registry = opts.registry || buildRegistry({
    enabled: String(env.ENABLED_SOURCES || '').split(',').map(s => s.trim()).filter(Boolean),
    timeoutMs: int('REQUEST_TIMEOUT_MS', 40000),
  })
  const cache = new TtlCache(int('CACHE_TTL_SECONDS', 300) * 1000, int('CACHE_MAX_ENTRIES', 300))
  const routes = buildRoutes({ registry, cache })
  const token = env.CLIENT_TOKEN || ''
  const corsOrigin = env.CORS_ORIGIN || ''
  const limitPerMin = int('RATE_LIMIT_PER_MINUTE', 90)
  const hits = new Map() // ip -> {count, reset}

  function limited(ip) {
    const now = Date.now()
    let h = hits.get(ip)
    if (!h || h.reset < now) { h = { count: 0, reset: now + 60000 }; hits.set(ip, h) }
    h.count++
    if (hits.size > 5000) for (const [k, v] of hits) if (v.reset < now) hits.delete(k)
    return h.count > limitPerMin
  }

  function send(res, status, body) {
    const data = JSON.stringify(body)
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(data),
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      ...(corsOrigin ? { 'Access-Control-Allow-Origin': corsOrigin, 'Access-Control-Allow-Headers': 'Authorization' } : {}),
    })
    res.end(data)
  }

  const server = http.createServer(async (req, res) => {
    try {
      if (req.method === 'OPTIONS') return send(res, 204, {})
      if (req.method !== 'GET') throw new HttpError(405, 'method_not_allowed', 'hanya GET')
      const ip = req.socket.remoteAddress || 'x'
      if (limited(ip)) throw new HttpError(429, 'rate_limited', 'terlalu banyak permintaan')
      const url = new URL(req.url, 'http://localhost')
      const handler = Object.prototype.hasOwnProperty.call(routes, url.pathname) ? routes[url.pathname] : null
      if (!handler) throw new HttpError(404, 'not_found', 'rute tidak ada')
      if (token && url.pathname !== '/health') {
        if (req.headers.authorization !== 'Bearer ' + token) throw new HttpError(401, 'unauthorized', 'token salah atau tidak ada')
      }
      send(res, 200, await handler(url.searchParams))
    } catch (e) {
      const status = e instanceof HttpError ? e.status : 500
      if (status === 500) console.error('[server]', e)
      send(res, status, { error: { code: e.code || 'internal', message: status === 500 ? 'kesalahan internal' : e.message } })
    }
  })
  server.requestTimeout = 120000
  return { server, registry, cache }
}

module.exports = { createServer }

if (require.main === module) {
  const port = int('PORT', 8787)
  const host = process.env.HOST || '0.0.0.0'
  const { server, registry } = createServer()
  server.listen(port, host, () => {
    console.log(`YumePlay backend di http://${host}:${port}  sumber: ${registry.ids.join(', ')}`)
    if (!process.env.ANIMEIN_PROXY_SECRET && registry.ids.includes('animein')) console.warn('[!] ANIMEIN_PROXY_SECRET kosong: sumber animein akan gagal.')
    if (!process.env.CLIENT_TOKEN) console.warn('[!] CLIENT_TOKEN kosong: API terbuka untuk siapa pun yang tahu alamatnya.')
  })
}
