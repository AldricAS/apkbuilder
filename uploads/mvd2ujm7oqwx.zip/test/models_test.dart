import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:yumeplay/data/local_store.dart';
import 'package:yumeplay/models/anime.dart';

void main() {
  group('parsing model dari JSON backend', () {
    test('AnimeSummary: field kosong tetap null, tidak dikarang', () {
      final a = AnimeSummary.fromJson({
        'id': 'nanimeid:x', 'source': 'nanimeid', 'key': 'x', 'title': 'X',
        'poster': null, 'rating': '7.5', 'genres': ['Action'], 'alsoOn': [
          {'id': 'alqanime:x', 'source': 'alqanime', 'key': 'x'}
        ],
      });
      expect(a.poster, isNull);
      expect(a.status, isNull);
      expect(a.rating, 7.5);
      expect(a.alsoOn.single.source, 'alqanime');
    });

    test('StreamSource: playable & pemilihan resolusi tertinggi', () {
      final p = EpisodePayload.fromJson({
        'source': 'kuramanime', 'animeKey': '1/x', 'number': 1,
        'sources': [
          {'kind': 'direct', 'url': 'https://a/480p.mp4', 'resolution': '480p', 'playable': true},
          {'kind': 'hls', 'url': 'https://a/1080.m3u8', 'resolution': '1080p', 'playable': true},
          {'kind': 'embed', 'url': 'https://e/1', 'playable': false},
          {'kind': 'download', 'url': 'https://d/1', 'playable': false},
        ],
      });
      expect(p.playable.first.resolution, '1080p');
      expect(p.playable.length, 2);
      expect(p.external.length, 2);
    });

    test('respons kosong tidak membuat crash', () {
      final d = AnimeDetail.fromJson({'id': 'a:b', 'source': 'a', 'key': 'b', 'title': 'T'});
      expect(d.episodes, isEmpty);
      expect(d.synopsis, isNull);
      expect(d.totalEpisodes, isNull);
    });

    test('EpisodeItem.label', () {
      expect(const EpisodeItem(number: 3, ref: '3').label, 'Episode 3');
      expect(const EpisodeItem(number: 3, title: 'Judul', ref: '3').label, 'Ep 3 · Judul');
    });
  });

  group('penyimpanan lokal bertahan setelah "dibuka kembali"', () {
    const anime = AnimeSummary(id: 's:k', source: 's', key: 'k', title: 'Judul');

    test('favorit & riwayat tersimpan lalu terbaca oleh instance baru', () async {
      SharedPreferences.setMockInitialValues({});
      final p1 = await SharedPreferences.getInstance();
      final s1 = LocalStore(p1);
      await s1.saveFavorites([anime]);
      await s1.saveHistory([
        const HistoryEntry(anime: anime, episodeRef: '2', episodeNumber: 2, positionMs: 61000, durationMs: 1400000, updatedAt: 1),
      ]);
      await s1.saveSearchHistory(['tokyo']);

      // simulasi aplikasi dibuka ulang: instance baru, prefs yang sama
      final s2 = LocalStore(await SharedPreferences.getInstance());
      expect(s2.favorites().single.id, 's:k');
      expect(s2.history().single.positionMs, 61000);
      expect(s2.searchHistory(), ['tokyo']);
    });

    test('data rusak tidak menyebabkan crash', () async {
      SharedPreferences.setMockInitialValues({'favorites_v1': '{bukan json'});
      final s = LocalStore(await SharedPreferences.getInstance());
      expect(s.favorites(), isEmpty);
    });

    test('hapus riwayat tidak menghapus favorit', () async {
      SharedPreferences.setMockInitialValues({});
      final s = LocalStore(await SharedPreferences.getInstance());
      await s.saveFavorites([anime]);
      await s.saveSearchHistory(['x']);
      await s.clearHistory();
      expect(s.favorites().length, 1);
      expect(s.searchHistory(), isEmpty);
    });
  });
}
