# YumePlay

Aplikasi streaming anime Android (Flutter) + backend adapter Node.js yang membungkus lima scraper
(`kuramanime.js`, `nanimeid.js`, `SameHadaku.js`, `alqanime.js`, `animein.js`).

> **Status jujur:** backend lolos 10 tes offline (scraper dipalsukan). Kode Flutter **belum pernah dikompilasi
> atau dijalankan** (tidak ada Flutter SDK di lingkungan pembuatan) dan **tidak ada scraper yang diuji ke situs
> nyata** (tidak ada akses jaringan). Lihat bagian "Status pengujian" sebelum menganggap apa pun sudah berfungsi.

## Struktur

```
lib/{core,models,data,repositories,services,providers,screens,widgets,player}   Flutter
backend/server.js                                                              HTTP server (tanpa dependensi npm)
backend/src/scrapers/      lima scraper (patch minimal, lihat di bawah) + worker.js
backend/src/services/      registry, aggregator, adapters/ (satu per sumber)
backend/src/{routes,models,utils}/
tool/setup_android.sh      membuat folder android/, mengatur nama app & package
build-apk.sh               analyze + test + build, memeriksa hasil
.github/workflows/build-apk.yml   build APK di GitHub (alternatif paling realistis)
```

`lib/services/` sengaja kosong: semua akses jaringan lewat `data/api_client.dart` + `repositories/`.

## Perubahan pada scraper asli

Logika parsing/HTTP tidak diubah. Perubahan (±115 baris total) hanya agar bisa di-`require()`:
`main()` dijalankan hanya jika dipanggil via CLI, fungsi diekspor, `console.log`/`process.stdout.write` diganti
`return`, timeout ditambahkan, dan:

- `animein.js`: `x-proxy-secret` **dipindah ke `ANIMEIN_PROXY_SECRET`** (server saja). Kamu harus mengisinya dari
  berkas asli. Jangan unggah `animein.js` asli ke repo publik; nilainya ada di sana.
- `curl -k` (mematikan verifikasi TLS) di SameHadaku/Alqanime kini **mati secara default**;
  set `CURL_INSECURE=1` hanya jika situs memang bermasalah sertifikat.
- `omnify-bypass` (modul opsional di kuramanime.js untuk melewati Cloudflare) **tidak dipasang**. Jika Cloudflare
  memblokir, API mengembalikan error `cloudflare_blocked` yang jujur, tanpa data pengganti. Kuramanime juga meniru
  header internal situs (`X-Fuck-ID`, token halaman); itu logika asli yang saya pertahankan, tetapi ia rapuh dan
  bisa putus kapan saja.

## Menjalankan backend

```bash
cd backend
cp .env.example .env      # isi ANIMEIN_PROXY_SECRET, CLIENT_TOKEN (opsional)
node server.js            # Node >= 18, curl harus terpasang (pkg install curl di Termux)
curl localhost:8787/health
curl "localhost:8787/api/search?q=tokyo"
npm test                  # tes offline
```

Endpoint (semua GET, JSON): `/health`, `/api/sources`, `/api/home`, `/api/list?kind=latest|ongoing|completed&page=`,
`/api/search?q=&sources=a,b&page=`, `/api/anime?source=&key=`, `/api/episode?source=&key=&ref=`.
Respons agregat memuat `errors[]` per sumber; satu sumber gagal tidak menggagalkan yang lain.

Keamanan: validasi input ketat per sumber (anti path-traversal), URL episode SameHadaku dibatasi ke host sumber (anti SSRF),
tidak ada pemanggilan shell dengan input pengguna (`execFile` + argumen tetap, dijalankan di worker thread), rate limit per IP,
cache TTL, token klien opsional. Tidak ada endpoint proxy video (akan menjadi open proxy).

**Untuk APK yang dipakai orang lain**, backend harus di-deploy ke alamat publik ber-HTTPS (VPS, Fly.io, Railway, dsb.), lalu
`API_BASE_URL` diisi alamat itu. `localhost`/IP LAN hanya untuk uji sendiri. Pengguna juga bisa mengubah alamat di Profil > Server.
`CLIENT_TOKEN` yang ikut di APK bukan rahasia sejati; pasang rate limit di reverse proxy.

## Sumber & kemampuan nyata

| Sumber | Home | Terbaru | Ongoing | Completed | Cari | Detail | Episode |
|---|---|---|---|---|---|---|---|
| Kuramanime | ✔ (ongoing) | – | ✔ | ✔ | ✔ | ✔ | direct/embed/unduhan bila berhasil diekstrak |
| Nanimeid | – | – | – | – | ✔ (paginasi) | ✔ | mirror + unduhan |
| SameHadaku | ✔ | ✔ | – | – | ✔ | ✔ | embed + unduhan |
| Alqanime | ✔ | ✔ | – | – | ✔ | ✔ | **hanya tautan unduhan** |
| Animein | ✔ | – | – | – | ✔ | ✔ | stream (format belum terverifikasi) |

Fitur manga Nanimeid hanya ada di scraper, belum dipakai UI.

Jenis sumber dibedakan: `hls` / `direct` (diputar `video_player`), `embed` dan `download` (dibuka di browser, **tidak** dianggap video langsung).
Jika sebuah episode tidak punya `hls`/`direct`, pemutar menampilkan daftar tautan, bukan memutar iframe.

## Belum terverifikasi (butuh uji dengan situs nyata)

1. **Semua scraper terhadap situs live.** Situs bisa berubah/down; regex HTML rapuh.
2. **Animein**: tidak ada contoh respons di berkas; normalisasi menebak nama field (`title/name`, `image/poster`, dst.) dan
   membaca stream dengan menelusuri semua URL di respons. Cek `node src/scrapers/animein.js home` lalu sesuaikan
   `backend/src/services/adapters/animein.js`.
3. **SameHadaku**: item "terbaru" memakai `anime_url` yang bisa berupa URL episode; slug anime diturunkan dengan menghapus `-episode-N`
   (heuristik, ditandai `keyDerived`).
4. **Nanimeid**: bentuk `mirror_streams`/`download_urls` tidak terdokumentasi; adapter menerima string maupun objek.
5. Poster Kuramanime diambil dari gambar pertama di halaman; bisa bukan poster.
6. Apakah URL video langsung butuh header `Referer` tertentu (banyak CDN begitu) belum diketahui; `video_player` tidak mengirimnya.

## Build APK

### Jalur yang direkomendasikan: GitHub Actions
Push proyek ke repo GitHub → tab Actions → "Build APK" → Run workflow (isi `api_base_url`) → unduh artefak `.apk`.
Ini menghindari semua masalah toolchain di HP.

### Di Termux (eksperimental, belum saya verifikasi)
Alasan realistis kenapa ini sulit: Flutter/Dart SDK untuk Linux memakai biner glibc, sedangkan Termux memakai bionic;
Android build-tools (`aapt2`) dan `gen_snapshot` tersedia untuk x86_64 dan dukungan arm64-nya bergantung versi.
Karena itu `flutter build apk` **mungkin tidak langsung berhasil**.

1. Cek lingkungan: `uname -m` (harus `aarch64`), `df -h ~` (≥ 10 GB bebas), `free -m` (≥ 3 GB RAM ideal).
2. `pkg update && pkg install git curl wget unzip zip nodejs proot-distro`
3. `proot-distro install ubuntu && proot-distro login ubuntu`
4. Di dalam Ubuntu: `apt update && apt install -y openjdk-17-jdk git curl unzip xz-utils zip libglu1-mesa`
5. Flutter: `git clone https://github.com/flutter/flutter.git -b stable ~/flutter && export PATH=$HOME/flutter/bin:$PATH && flutter doctor -v`
6. Android SDK: unduh *command-line tools* dari developer.android.com, taruh di `~/android-sdk/cmdline-tools/latest`, lalu
   `sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"` dan `flutter config --android-sdk ~/android-sdk`,
   `flutter doctor --android-licenses`.
7. Jika Gradle gagal menjalankan `aapt2` (error "Syntax error"/"cannot execute binary"), arahkan ke `aapt2` arm64 di
   `android/gradle.properties`: `android.aapt2FromMavenOverride=/path/ke/aapt2`.
8. Proyek: `cd /path/yumeplay && APP_NAME="YumePlay" ORG="com.contoh" ./tool/setup_android.sh`
9. `API_BASE_URL=https://api.contoh.com ./build-apk.sh debug`  (ganti `release` untuk rilis)
10. Hasil: `build/app/outputs/flutter-apk/app-arm64-v8a-debug.apk`. Salin ke `/sdcard/Download` (`termux-setup-storage` dulu), buka lewat file manager, izinkan "pasang dari sumber ini".

Jika langkah 5–9 gagal dan tidak ada solusi, pakai GitHub Actions atau PC.

### Penandatanganan release
`keytool -genkey -v -keystore ~/yume.jks -keyalg RSA -keysize 2048 -validity 10000 -alias yume`, buat `android/key.properties`,
lalu tambahkan blok `signingConfigs` di `android/app/build.gradle` mengikuti docs.flutter.dev/deployment/android.
Tanpa itu, release memakai kunci debug (cukup untuk uji, bukan untuk distribusi). Jangan commit `.jks`/`key.properties`.

### Error umum
`flutter analyze` gagal → baca pesan, perbaiki dulu (script berhenti sebelum build). Kehabisan memori → turunkan `-Xmx` di
`android/gradle.properties` dan tutup aplikasi lain. `Cleartext HTTP not permitted` → backend memakai `http://`; pakai HTTPS untuk release.

## Mengganti nama / logo / package

- Nama: `APP_NAME=...` saat `setup_android.sh` dan `build-apk.sh` (juga `--dart-define=APP_NAME`).
- Package name: `ORG=com.kamu` lalu hapus folder `android/` dan jalankan ulang `setup_android.sh`.
- Logo: tambahkan paket `flutter_launcher_icons` (belum dipasang) atau ganti `android/app/src/main/res/mipmap-*/ic_launcher.png`.

## Status pengujian

| Item | Status |
|---|---|
| Tes backend (normalisasi, validasi, agregasi, SSRF, auth, kegagalan parsial) | ✔ 10/10 lulus, **dengan scraper palsu** |
| Boot server sungguhan + scraper asli tanpa jaringan | ✔ gagal dengan baik, `errors[]` per sumber |
| Scraper terhadap situs nyata | ✘ tidak diuji (tanpa jaringan) |
| `flutter analyze` / `flutter test` (`test/models_test.dart`) | ✘ belum dijalankan (tanpa Flutter SDK) |
| Navigasi, favorit/riwayat setelah restart, pemutar | ✘ belum dijalankan di perangkat |
| Tidak ada secret server di kode Flutter/APK | ✔ diperiksa dengan grep (lihat bawah) |
| Tidak ada endpoint/data fiktif | ✔ UI hanya menampilkan data dari API; kosong = pesan |

Langkah pertama di mesin yang punya Flutter: `flutter pub get && flutter analyze && flutter test`. Perkirakan beberapa perbaikan kecil
(saya menulis kode tanpa kompilator). Pin yang disarankan: Flutter ≥ 3.24 (memakai `PopScope.onPopInvokedWithResult`).

## Catatan sumber

Situs-situs ini adalah situs pihak ketiga tidak resmi. Saya tidak bisa memastikan status lisensi kontennya; kamu yang
bertanggung jawab atas penggunaannya. Proyek ini tidak menambahkan upaya melewati DRM atau proteksi akses.

## Pemakaian pribadi tanpa server publik

Kelima scraper adalah kode JavaScript, jadi Flutter tidak bisa menjalankannya langsung. Untuk dipakai sendiri, jalankan
backend di Termux yang sama (`npm run backend`, biarkan terbuka) dan biarkan aplikasi memakai `http://127.0.0.1:8787`
(default `npm run apk`). Android hanya mengizinkan HTTP polos ke localhost; alamat lain wajib HTTPS.
