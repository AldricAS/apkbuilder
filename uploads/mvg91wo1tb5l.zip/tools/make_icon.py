#!/usr/bin/env python3
"""Membuat ikon aplikasi (semua ukuran) ke app/src/main/res/mipmap-*.

Jalankan:  python3 tools/make_icon.py        (butuh:  pip install pillow)
Ubah warna / bentuk di fungsi art() lalu jalankan ulang.
Hasil:
  mipmap-<dpi>/ic_launcher.png, ic_launcher_round.png      -> ikon biasa (Android 5-7)
  mipmap-<dpi>/ic_launcher_foreground.png / _background.png -> ikon adaptive (Android 8+)
  mipmap-<dpi>/ic_launcher_monochrome.png                   -> ikon tema (Android 13+)
  mipmap-anydpi-v26/ic_launcher.xml, ic_launcher_round.xml
  tools/icon_preview_512.png                                -> pratinjau / ikon Play Store
"""
import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "app", "src", "main", "res")
S = 1024  # kanvas kerja
FONTS = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
         "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
         "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "C:/Windows/Fonts/arialbd.ttf"]


def font(px):
    for f in FONTS:
        if os.path.exists(f):
            return ImageFont.truetype(f, px)
    return ImageFont.load_default()


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def background():
    """Gradasi gelap -> ungu (sama dengan latar menu) + cahaya biru di tengah."""
    n = 256
    g = Image.new("RGB", (n, n))
    px = g.load()
    stops = [(6, 10, 18), (17, 28, 51), (38, 20, 63)]
    for y in range(n):
        for x in range(n):
            t = (x + y) / (2 * n - 2)
            px[x, y] = lerp(stops[0], stops[1], t * 2) if t < .5 else lerp(stops[1], stops[2], (t - .5) * 2)
    g = g.resize((S, S), Image.BILINEAR).convert("RGBA")
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse((S * .12, S * .12, S * .88, S * .88), fill=(60, 130, 255, 90))
    glow = glow.filter(ImageFilter.GaussianBlur(S * .09))
    return Image.alpha_composite(g, glow)


def hole(im, draw_fn):
    """Lubangi (transparan) bagian gambar sesuai bentuk yang digambar draw_fn pada mask."""
    m = Image.new("L", im.size, 0); draw_fn(ImageDraw.Draw(m))
    im.putalpha(Image.composite(Image.new("L", im.size, 0), im.getchannel("A"), m))


def art(mono=False):
    """Gambar utama (latar transparan): bidikan + kepala prajurit blok + lencana 3D. Radius isi < 0.42 * S."""
    k = 2  # supersampling
    W = S * k
    im = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = W // 2
    ring = (255, 255, 255, 255) if mono else (140, 195, 255, 255)
    r = int(W * .355); lw = int(W * .034)
    d.ellipse((c - r, c - r, c + r, c + r), outline=ring, width=lw)
    for ang in range(4):                       # 4 garis bidik, menembus cincin
        x0, x1 = int(r * .88), int(r * 1.16)
        box = [(c - lw // 2, c - x1), (c + lw // 2, c - x0)]
        t = Image.new("RGBA", (W, W), (0, 0, 0, 0))
        ImageDraw.Draw(t).rectangle((box[0][0], box[0][1], box[1][0], box[1][1]), fill=ring)
        im = Image.alpha_composite(im, t.rotate(90 * ang, center=(c, c)))
    d = ImageDraw.Draw(im)
    # kepala prajurit (gaya blok seperti di game)
    hw = int(W * .15); top = int(W * .365); bot = int(W * .625)
    skin = (255, 255, 255, 255) if mono else (232, 190, 150, 255)
    helmet = (255, 255, 255, 255) if mono else (96, 124, 70, 255)
    d.rounded_rectangle((c - hw, top + int(W * .06), c + hw, bot), radius=int(W * .02), fill=skin)
    d.rounded_rectangle((c - hw - int(W * .018), top, c + hw + int(W * .018), top + int(W * .105)), radius=int(W * .035), fill=helmet)
    d.rectangle((c - hw - int(W * .018), top + int(W * .085), c + hw + int(W * .018), top + int(W * .105)),
                fill=(0, 0, 0, 0) if mono else (60, 80, 44, 255))
    # visor / kacamata (di mode mono dilubangi)
    vy = top + int(W * .135)
    vbox = (c - hw + int(W * .02), vy, c + hw - int(W * .02), vy + int(W * .04))
    if mono:
        hole(im, lambda dr: dr.rectangle(vbox, fill=255))
        d = ImageDraw.Draw(im)
    else:
        d.rectangle(vbox, fill=(18, 18, 24, 255))
    # titik merah di dahi = bidikan headshot
    if not mono:
        rr = int(W * .022)
        cy = int(W * .583); d.ellipse((c - rr, cy - rr, c + rr, cy + rr), fill=(255, 55, 55, 255))
    # lencana "3D"
    bw, bh = int(W * .22), int(W * .095); by = int(W * .672)
    d.rounded_rectangle((c - bw // 2, by, c + bw // 2, by + bh), radius=int(W * .03), fill=(255, 255, 255, 255) if mono else (76, 141, 255, 255))
    f = font(int(bh * .78))
    tb = d.textbbox((0, 0), "3D", font=f)
    tx = c - (tb[0] + tb[2]) // 2; ty = by + (bh - (tb[3] - tb[1])) // 2 - tb[1]
    if mono:
        hole(im, lambda dr: dr.text((tx, ty), "3D", font=f, fill=255))
    else:
        d.text((tx, ty), "3D", font=f, fill=(255, 255, 255, 255))
    return im.resize((S, S), Image.LANCZOS)


def with_shadow(a):
    alpha = a.getchannel("A").filter(ImageFilter.GaussianBlur(S * .012)).point(lambda v: int(v * .55))
    sh = Image.new("RGBA", (S, S), (0, 0, 0, 0)); sh.putalpha(alpha)
    off = Image.new("RGBA", (S, S), (0, 0, 0, 0)); off.paste(sh, (0, int(S * .012)))
    return Image.alpha_composite(off, a)


def scaled(img, f):
    """Perkecil gambar ke f * S dan taruh di tengah kanvas transparan S x S."""
    n = int(S * f); small = img.resize((n, n), Image.LANCZOS)
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0)); out.paste(small, ((S - n) // 2, (S - n) // 2), small)
    return out


def rounded(img, rad):
    m = Image.new("L", img.size, 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, img.size[0] - 1, img.size[1] - 1), radius=int(img.size[0] * rad), fill=255)
    out = Image.new("RGBA", img.size, (0, 0, 0, 0)); out.paste(img, (0, 0), m); return out


def circle(img):
    m = Image.new("L", img.size, 0); ImageDraw.Draw(m).ellipse((0, 0, img.size[0] - 1, img.size[1] - 1), fill=255)
    out = Image.new("RGBA", img.size, (0, 0, 0, 0)); out.paste(img, (0, 0), m); return out


def save(img, path, size):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.resize((size, size), Image.LANCZOS).save(path)


def main():
    bg = background()
    fg = with_shadow(art())
    mono = art(mono=True)
    legacy = Image.alpha_composite(bg, scaled(fg, 1.0))
    sq = rounded(legacy, .2)
    rd = circle(Image.alpha_composite(bg, scaled(fg, .94)))
    fg_ad = scaled(fg, .70)          # adaptive: isi harus di dalam zona aman (66/108 dari kanvas)
    mono_ad = scaled(mono, .70)
    dens = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
    for name, f in dens.items():
        d = os.path.join(RES, "mipmap-" + name)
        save(sq, os.path.join(d, "ic_launcher.png"), int(48 * f))
        save(rd, os.path.join(d, "ic_launcher_round.png"), int(48 * f))
        save(fg_ad, os.path.join(d, "ic_launcher_foreground.png"), int(108 * f))
        save(bg, os.path.join(d, "ic_launcher_background.png"), int(108 * f))
        save(mono_ad, os.path.join(d, "ic_launcher_monochrome.png"), int(108 * f))
    ad = os.path.join(RES, "mipmap-anydpi-v26"); os.makedirs(ad, exist_ok=True)
    xml = ('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
           '    <background android:drawable="@mipmap/ic_launcher_background"/>\n'
           '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n'
           '    <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>\n</adaptive-icon>\n')
    for n in ("ic_launcher.xml", "ic_launcher_round.xml"):
        open(os.path.join(ad, n), "w").write(xml)
    save(sq, os.path.join(HERE, "icon_preview_512.png"), 512)
    print("ikon dibuat di", os.path.abspath(RES))


if __name__ == "__main__":
    main()
