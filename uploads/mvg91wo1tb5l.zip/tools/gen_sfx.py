#!/usr/bin/env python3
"""Generator sound effect Shooter 3D (sintesis berlapis, tanpa sample pihak ketiga -> bebas lisensi).
Pemakaian: python3 tools/gen_sfx.py app/src/main/assets/sfx
Butuh: numpy, scipy. Semua berkas mono 16-bit WAV.

Teknik: tembakan = crack (transien frekuensi tinggi) + ledakan gas (noise lowpass) + punch (mid)
+ dentuman (sine meluncur turun) + saturasi + pantulan/gema outdoor. Suara mekanis (magasin, bolt, pump,
peluru masuk) = klik noise + resonansi logam teredam (damped sinusoid inharmonik)."""
import sys, os
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
OUT = sys.argv[1] if len(sys.argv) > 1 else "sfx"
os.makedirs(OUT, exist_ok=True)
R = np.random.default_rng(20261019)


# ------------------------------------------------------------------ blok dasar
def T(n, sr=SR): return np.arange(n) / sr
def noise(n, r=None): return (r or R).standard_normal(n)
def _f(x, kind, f, o, sr=SR):
    sos = signal.butter(o, f, btype=kind, fs=sr, output="sos"); return signal.sosfilt(sos, x)
def lp(x, f, o=4, sr=SR): return _f(x, "low", f, o, sr)
def hp(x, f, o=4, sr=SR): return _f(x, "high", f, o, sr)
def bp(x, lo, hi, o=3, sr=SR): return _f(x, "band", [lo, hi], o, sr)

def env(n, tau, atk=0.0004):
    t = T(n); return np.exp(-t / tau) * np.minimum(1.0, t / atk)

def hump(n, a, b):
    """Selubung halus (naik-turun) antara detik a..b, dipakai untuk suara gesekan logam."""
    t = T(n); e = np.zeros(n); m = (t >= a) & (t <= b)
    e[m] = np.sin(np.pi * (t[m] - a) / (b - a)) ** 2
    return e

def sweep(n, f0, f1, tau_f):
    t = T(n); f = f1 + (f0 - f1) * np.exp(-t / tau_f)
    return np.sin(2 * np.pi * np.cumsum(f) / SR)

def ping(n, f, tau, atk=0.0002):
    """Resonansi logam teredam: fundamental + partial inharmonik (seperti besi/kuningan)."""
    t = T(n); e = np.exp(-t / tau) * np.minimum(1.0, t / atk)
    return e * (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 2.76 * t + 0.7) * np.exp(-t / (tau * .6))
                + 0.25 * np.sin(2 * np.pi * f * 5.40 * t + 1.9) * np.exp(-t / (tau * .35)))

def A(*xs):
    n = max(len(x) for x in xs); o = np.zeros(n)
    for x in xs: o[: len(x)] += x
    return o

def put(buf, x, at):
    i = int(at * SR); j = min(len(buf), i + len(x))
    if i < len(buf): buf[i:j] += x[: j - i]
    return buf

def click(n, tau=0.004, lo=1800, hi=9000, r=None):
    return bp(noise(n, r), lo, hi, 3) * env(n, tau, 0.00008)

def reverb(x, rt60=0.9, wet=0.3, damp=5000, early=(), seed=5, tail_pad=None):
    r = np.random.default_rng(seed)
    n = int(rt60 * 1.2 * SR); t = T(n)
    ir = lp(noise(n, r), damp, 2) * np.exp(-6.9 * t / rt60)
    ir *= np.minimum(1, t / 0.012)                           # pre-delay halus
    for d, g in early:                                       # pantulan awal (tembok/bukit)
        k = int(d * SR)
        if k < n: ir[k] += g * 6.0
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
    tail = int(rt60 * 1.1 * SR) if tail_pad is None else int(tail_pad * SR)
    xp = np.concatenate([x, np.zeros(tail)])
    w = signal.fftconvolve(xp, ir)[: len(xp)]
    return xp + w * wet * (np.sqrt(np.sum(x ** 2)) / (np.sqrt(np.sum(w ** 2)) + 1e-9)) * 1.0

def finish(name, x, peak=0.9, fade=0.012, sr=SR, trim=True):
    x = x - np.mean(x)
    if trim:                                               # buang ekor sunyi
        a = np.abs(x); idx = np.where(a > a.max() * 0.002)[0]
        if len(idx): x = x[: min(len(x), idx[-1] + int(0.02 * sr))]
    f = int(fade * sr); x[-f:] *= np.linspace(1, 0, f)
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    wavfile.write(os.path.join(OUT, name + ".wav"), sr, (x * 32767).astype(np.int16))
    print(f"{name:16s} {len(x) / sr:5.2f}s  rms={np.sqrt(np.mean(x ** 2)):.3f}")
    return x


# ------------------------------------------------------------------ senjata
def rifle_shot(seed):
    r = np.random.default_rng(seed); n = int(0.9 * SR); j = r.random()
    crack = hp(noise(n, r), 1800) * env(n, .0035 + .001 * j, .00012) * 1.0
    air = bp(noise(n, r), 3800, 14000, 2) * env(n, .0016, .00008) * .8
    blast = lp(noise(n, r), 2600 + 500 * j) * env(n, .030, .0003) * 1.25
    punch = bp(noise(n, r), 220, 950) * env(n, .020, .0004) * 1.1
    boom = sweep(n, 175 + 20 * j, 52, .035) * env(n, .10, .0006) * 1.15
    sub = sweep(n, 90, 36, .06) * env(n, .14, .001) * .65
    dry = np.tanh((crack + air + blast + punch + boom + sub) * 1.5)
    dry = put(dry.copy(), click(int(.03 * SR), .006, 900, 4000, r) * .25, .042)          # gerak bolt setelah tembak
    return reverb(dry, rt60=.85, wet=.55, damp=4200, seed=seed,
                  early=[(.075 + .01 * j, .5), (.16, .32), (.27, .2), (.41, .12)])

def shotgun_shot(seed):
    r = np.random.default_rng(seed); n = int(1.2 * SR)
    crack = hp(noise(n, r), 1200) * env(n, .006, .00015) * 1.0
    air = bp(noise(n, r), 2500, 11000, 2) * env(n, .0035, .0001) * .7
    blast = lp(noise(n, r), 2000) * env(n, .060, .0004) * 1.5
    punch = bp(noise(n, r), 140, 700) * env(n, .045, .0005) * 1.4
    boom = sweep(n, 130, 34, .05) * env(n, .18, .0008) * 1.4
    sub = sweep(n, 70, 28, .08) * env(n, .22, .002) * .9
    shim = bp(noise(n, r), 2000, 6500, 2) * env(n, .12, .02) * .12                      # desis butiran peluru
    dry = np.tanh((crack + air + blast + punch + boom + sub + shim) * 1.4)
    return reverb(dry, rt60 = 1.15, wet=.6, damp=3600, seed=seed,
                  early=[(.09, .5), (.2, .36), (.33, .25), (.5, .15)])


# ------------------------------------------------------------------ mekanik reload
def mag_out(seed=11):
    r = np.random.default_rng(seed); n = int(.5 * SR); x = np.zeros(n)
    put(x, A(click(int(.03 * SR), .005, 1400, 7000, r) * .8, ping(int(.08 * SR), 1900, .012) * .35), 0.0)   # tombol lepas
    put(x, bp(noise(int(.2 * SR), r), 700, 3500, 3) * hump(int(.2 * SR), 0, .2) * .30, .035)             # magasin meluncur keluar
    put(x, ping(int(.12 * SR), 620, .030) * .22, .24)
    thud = A(sweep(int(.2 * SR), 170, 85, .03) * env(int(.2 * SR), .05, .0008) * .55, lp(noise(int(.2 * SR), r), 1100) * env(int(.2 * SR), .02, .0005) * .5)
    put(x, thud, .28)
    return lp(x, 9000, 2)

def mag_in(seed=12):
    r = np.random.default_rng(seed); n = int(.5 * SR); x = np.zeros(n)
    put(x, bp(noise(int(.2 * SR), r), 800, 3800, 3) * hump(int(.2 * SR), 0, .2) * .28, 0.0)
    m = int(.25 * SR)
    clack = (hp(noise(m, r), 1100) * env(m, .004, .00008) * 1.0 + ping(m, 1100, .015) * .5 + ping(m, 2300, .010) * .3
             + sweep(m, 210, 110, .03) * env(m, .06, .0006) * .8 + lp(noise(m, r), 1500) * env(m, .02, .0004) * .5)
    put(x, np.tanh(clack * 1.3), .2)
    put(x, A(click(int(.02 * SR), .003, 2000, 9000, r) * .35, ping(int(.06 * SR), 2900, .01) * .2), .275)   # kunci kedua
    return x

def bolt(seed=13):
    r = np.random.default_rng(seed); n = int(.55 * SR); x = np.zeros(n)
    k = int(.14 * SR); ratchet = bp(noise(k, r), 900, 5200, 3) * hump(k, 0, .14) * (0.55 + 0.45 * np.sign(np.sin(2 * np.pi * 70 * T(k))))
    put(x, ratchet * .32, 0.0)                                                                           # tarik handle (ratchet)
    put(x, A(click(int(.02 * SR), .003, 1800, 8000, r) * .5, ping(int(.06 * SR), 1500, .012) * .25), .15)
    m = int(.2 * SR)
    slam = (hp(noise(m, r), 1500) * env(m, .0032, .00008) * 1.0 + ping(m, 1250, .018) * .5 + ping(m, 2650, .011) * .3
            + sweep(m, 190, 100, .025) * env(m, .05, .0006) * .7)
    put(x, np.tanh(slam * 1.3), .27)                                                                    # lepas maju (clack keras)
    return x

def shell_in(seed=14):
    r = np.random.default_rng(seed); n = int(.22 * SR)
    x = (click(n, .003, 2500, 10000, r) * .7 + ping(n, 3300, .006) * .35 + ping(n, 5400, .004) * .2
         + sweep(n, 260, 150, .02) * env(n, .03, .0004) * .6 + lp(noise(n, r), 900) * env(n, .015, .0004) * .35)
    return put(np.zeros(int(.3 * SR)), x, 0) + put(np.zeros(int(.3 * SR)), ping(int(.1 * SR), 1900, .01) * .15, .09)

def pump(seed=15):
    r = np.random.default_rng(seed); n = int(.6 * SR); x = np.zeros(n)
    put(x, bp(noise(int(.13 * SR), r), 500, 3200, 3) * hump(int(.13 * SR), 0, .13) * .35, 0.0)
    put(x, A(ping(int(.1 * SR), 800, .02) * .35, click(int(.02 * SR), .004, 1200, 6000, r) * .5), .12)      # tarik ke belakang
    m = int(.25 * SR)
    clunk = (hp(noise(m, r), 1000) * env(m, .004, .0001) + ping(m, 700, .028) * .6 + ping(m, 1480, .016) * .38 + ping(m, 3100, .008) * .15
             + sweep(m, 160, 80, .03) * env(m, .08, .0006) * .9)
    put(x, np.tanh(clunk * 1.3), .27)                                                                    # dorong ke depan (chk!)
    return x

def dry_click(seed=16):
    r = np.random.default_rng(seed); n = int(.1 * SR)
    return click(n, .002, 1800, 9000, r) * .8 + ping(n, 3100, .008) * .35 + sweep(n, 220, 130, .015) * env(n, .02, .0003) * .3

def weapon_switch(seed=17):
    r = np.random.default_rng(seed); n = int(.45 * SR); x = np.zeros(n)
    put(x, bp(noise(int(.14 * SR), r), 300, 2500, 3) * hump(int(.14 * SR), 0, .14) * .35, 0.0)             # gesekan kain/logam
    put(x, A(click(int(.03 * SR), .004, 1200, 6000, r) * .6, ping(int(.12 * SR), 1300, .03) * .35, sweep(int(.12 * SR), 190, 100, .03) * env(int(.12 * SR), .05, .0005) * .5), .16)
    return x


# ------------------------------------------------------------------ dampak / musuh
def hit_metal(seed=21):
    r = np.random.default_rng(seed); n = int(.45 * SR)
    return (click(n, .004, 2000, 9000, r) * .6 + ping(n, 1300, .05) * .5 + ping(n, 2050, .035) * .35 + ping(n, 3400, .02) * .25
            + sweep(n, 180, 90, .02) * env(n, .03, .0004) * .4)

def hit_head(seed=22):
    r = np.random.default_rng(seed); n = int(.7 * SR); t = T(n)
    bell = (np.sin(2 * np.pi * 2640 * t) * np.exp(-t / .16) + .5 * np.sin(2 * np.pi * 3960 * t) * np.exp(-t / .12)
            + .25 * np.sin(2 * np.pi * 5280 * t) * np.exp(-t / .08)) * np.minimum(1, t / .0004)
    return click(n, .003, 2500, 11000, r) * .6 + ping(n, 1500, .04) * .4 + bell * .5 + sweep(n, 160, 80, .025) * env(n, .04, .0004) * .6

def drone_die(seed=23, big=False):
    r = np.random.default_rng(seed); n = int((1.5 if big else .9) * SR); k = 1.0 if big else .0
    boom = sweep(n, 150 - 40 * k, 38, .05) * env(n, .20 + .25 * k, .0008) * 1.2
    body = lp(noise(n, r), 3200 - 1500 * k) * env(n, .09 + .2 * k, .0006) * 1.0
    low = lp(noise(n, r), 700) * env(n, .22 + .3 * k, .002) * .8
    zap = hp(noise(n, r), 1800) * env(n, .08, .0004) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 95 * T(n)))) * .35
    x = np.tanh((boom + body + low + zap) * 1.3)
    for _ in range(26 if big else 12):                                                    # serpihan logam berjatuhan
        f = r.uniform(1100, 4800); at = r.uniform(.06, .75 if big else .5); m = int(.12 * SR)
        put(x, ping(m, f, r.uniform(.01, .035)) * r.uniform(.05, .22), at)
    return reverb(x, rt60=1.0 if big else .6, wet=.4, damp=4000, seed=seed, early=[(.12, .4), (.25, .25)])

def player_hurt(seed=24):
    r = np.random.default_rng(seed); n = int(.8 * SR); t = T(n)
    thud = sweep(n, 130, 55, .03) * env(n, .10, .0008) * 1.0 + lp(noise(n, r), 1300) * env(n, .04, .0005) * .9
    zap = bp(noise(n, r), 1500, 6000, 2) * env(n, .03, .0003) * .45
    ring = np.sin(2 * np.pi * 4200 * t) * np.exp(-t / .35) * .05 * np.minimum(1, t / .05)        # telinga berdenging
    return np.tanh((thud + zap) * 1.2) + ring

def player_death(seed=25):
    r = np.random.default_rng(seed); n = int(1.8 * SR); t = T(n)
    thud = sweep(n, 110, 40, .08) * env(n, .35, .001) * 1.1 + lp(noise(n, r), 800) * env(n, .12, .001) * .7
    drone = (np.sin(2 * np.pi * 52 * t) + .5 * np.sin(2 * np.pi * 104 * t)) * np.exp(-t / .9) * .25
    ring = np.sin(2 * np.pi * 3600 * t) * np.exp(-t / .6) * .05
    return reverb(np.tanh(thud * 1.2) + drone + ring, rt60=1.2, wet=.35, damp=2500, seed=seed)

def heartbeat():
    n = int(.95 * SR); x = np.zeros(n)
    def beat(f0, g):
        m = int(.2 * SR); return (sweep(m, f0, 38, .02) * env(m, .07, .004) + lp(noise(m, R), 180) * env(m, .05, .004) * .4) * g
    put(x, beat(78, 1.0), 0.0); put(x, beat(66, .7), .30)
    return x


# ------------------------------------------------------------------ item & UI
def pickup_ammo(seed=31):
    r = np.random.default_rng(seed); n = int(.6 * SR); x = np.zeros(n)
    for at, f, g in [(0, 2500, .5), (.045, 2900, .45), (.10, 2200, .5), (.15, 3300, .35)]:
        put(x, A(click(int(.03 * SR), .003, 2000, 9000, r) * g, ping(int(.1 * SR), f, .012) * g * .5), at)       # peluru bergemerincing
    m = int(.25 * SR)
    put(x, A(hp(noise(m, r), 800) * env(m, .004) * .5, ping(m, 950, .045) * .6, sweep(m, 150, 90, .03) * env(m, .06, .0005) * .6), .21)  # tutup kotak
    return x

def pickup_health(seed=32):
    n = int(1.7 * SR); t = T(n); x = np.zeros(n)
    def bell(f, at, g):
        m = int(.9 * SR); tt = T(m)
        s = (np.sin(2 * np.pi * f * tt) + .35 * np.sin(2 * np.pi * f * 2 * tt) + .12 * np.sin(2 * np.pi * f * 3.01 * tt)) * np.exp(-tt / .28) * np.minimum(1, tt / .004)
        put(x, s * g, at)
    bell(1046.5, 0, .55); bell(1568.0, .11, .5); bell(2093.0, .22, .38)
    put(x, bp(noise(int(.3 * SR), R), 3000, 9000, 2) * hump(int(.3 * SR), 0, .3) * .05, 0.0)
    return x

def spawn_alert(seed=33):
    r = np.random.default_rng(seed); n = int(1.2 * SR); t = T(n); x = np.zeros(n)
    m = int(.5 * SR); put(x, sweep(m, 90, 42, .06) * env(m, .22, .003) * .9 + lp(noise(m, r), 500) * env(m, .08, .002) * .5, 0.0)   # peti jatuh
    for at in (.38, .56):
        mm = int(.12 * SR); tt = T(mm); put(x, np.sin(2 * np.pi * 1320 * tt) * np.minimum(1, tt / .005) * np.minimum(1, (.12 - tt) / .02) * .35, at)
    return reverb(x, rt60=.8, wet=.35, damp=3500, seed=seed)

def wave_start(seed=34):
    n = int(1.6 * SR); t = T(n)
    f = 98 * (1 + .12 * np.minimum(1, t / .9))
    ph = 2 * np.pi * np.cumsum(f) / SR
    horn = sum(np.sin(k * ph) / k ** .8 for k in range(1, 9)); horn = lp(horn, 1800, 2)
    e = np.minimum(1, t / .25) * np.exp(-np.maximum(0, t - .9) / .3)
    return reverb(horn * e, rt60=1.1, wet=.4, damp=2800, seed=seed)

def game_over(seed=35):
    n = int(2.4 * SR); t = T(n); x = np.zeros(n)
    for at, f in [(0, 220), (.35, 185), (.7, 147), (1.05, 110)]:
        m = int(1.2 * SR); tt = T(m)
        s = (np.sin(2 * np.pi * f * tt) + .5 * np.sin(2 * np.pi * f * 2 * tt) + .25 * np.sin(2 * np.pi * f * 3 * tt)) * np.exp(-tt / .5) * np.minimum(1, tt / .02)
        put(x, lp(s, 2000, 2) * .6, at)
    put(x, sweep(int(1.5 * SR), 80, 34, .15) * env(int(1.5 * SR), .55, .004) * .9, 1.05)
    return reverb(x, rt60=1.4, wet=.35, damp=2800, seed=seed)

def ui_click(seed=36):
    r = np.random.default_rng(seed); n = int(.1 * SR)
    return click(n, .003, 1500, 7000, r) * .6 + ping(n, 1800, .012) * .35

def footstep(seed, bright):
    r = np.random.default_rng(seed); n = int(.26 * SR)
    thump = sweep(n, 130 + 15 * r.random(), 70, .02) * env(n, .045, .0007) * .9
    body = lp(noise(n, r), 700 + 250 * bright) * env(n, .035, .0005) * .8
    grass = bp(noise(n, r), 1800, 6500, 2) * env(n, .05, .004) * .22 * bright
    return thump + body + grass


# ------------------------------------------------------------------ loop (mulus) : ambience & dengung drone
def spectral_loop(sr, seconds, shape, seed):
    """Noise dengan spektrum bentukan -> otomatis periodik, jadi loop tanpa klik."""
    r = np.random.default_rng(seed); n = int(sr * seconds)
    f = np.fft.rfftfreq(n, 1 / sr); S = shape(f) * np.exp(1j * r.uniform(0, 2 * np.pi, len(f))); S[0] = 0
    return np.fft.irfft(S, n)

def wind():
    sr = 22050; secs = 8
    x = spectral_loop(sr, secs, lambda f: 1.0 / (1 + (f / 220) ** 2) * (f > 40) + 0.25 / (1 + (f / 900) ** 2), 41)
    t = np.arange(len(x)) / sr
    x *= 0.55 + 0.45 * np.sin(2 * np.pi * (1 / 8) * t * 1) * np.sin(2 * np.pi * (3 / 8) * t + 1.0)   # embusan pelan (siklus bulat)
    return x, sr

def drone_hum():
    secs = 2.0; n = int(SR * secs); t = T(n)
    x = sum(np.sin(2 * np.pi * 100 * k * t + k) / k ** .9 for k in range(1, 12)) + .6 * np.sin(2 * np.pi * 103 * t)
    x = x * (0.75 + 0.25 * np.sin(2 * np.pi * 8 * (t / secs) * secs / 2 * 1.0))                    # tremolo 4 Hz (siklus bulat)
    x += spectral_loop(SR, secs, lambda f: (f > 600) * (f < 4000) * 1.0, 42) * .6 * np.abs(np.sin(np.pi * 40 * t / secs * 1))
    return lp(x, 3500, 2)


# ------------------------------------------------------------------ tulis semua
if __name__ == "__main__":
    for i in range(3): finish(f"rifle_shot{i + 1}", rifle_shot(100 + i * 17), .95)
    for i in range(2): finish(f"shotgun_shot{i + 1}", shotgun_shot(200 + i * 13), .97)
    finish("mag_out", mag_out(), .7); finish("mag_in", mag_in(), .8); finish("bolt", bolt(), .8)
    finish("shell_in", shell_in(), .6); finish("pump", pump(), .8)
    finish("dry_click", dry_click(), .55); finish("weapon_switch", weapon_switch(), .55)
    finish("hit_metal", hit_metal(), .75); finish("hit_head", hit_head(), .85)
    finish("drone_die", drone_die(), .9); finish("boss_die", drone_die(7, True), .95)
    finish("player_hurt", player_hurt(), .85); finish("player_death", player_death(), .85)
    finish("heartbeat", heartbeat(), .8)
    finish("pickup_ammo", pickup_ammo(), .7); finish("pickup_health", pickup_health(), .7)
    finish("spawn_alert", spawn_alert(), .7); finish("wave_start", wave_start(), .75)
    finish("game_over", game_over(), .8); finish("ui_click", ui_click(), .5)
    finish("step1", footstep(51, .2), .45); finish("step2", footstep(52, 1.0), .45); finish("step3", footstep(53, .6), .45)
    w, sr = wind(); finish("ambient_wind", w, .35, sr=sr, trim=False)
    finish("drone_hum", drone_hum(), .5, trim=False)
