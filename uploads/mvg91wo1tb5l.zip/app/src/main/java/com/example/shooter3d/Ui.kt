package com.example.shooter3d
import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Latar menu: gradasi gelap + grid halus + reticle besar. */
class BgView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xFF060A12.toInt(), 0xFF111C33.toInt(), 0xFF26143F.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        val cx = w * .24f; val cy = h * .5f; val r = h * .46f
        p.shader = RadialGradient(cx, cy, r * 1.6f, Color.argb(70, 60, 130, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.6f, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.argb(14, 255, 255, 255)
        var x = 0f; while (x < w) { c.drawLine(x, 0f, x, h, p); x += 56f }
        var y = 0f; while (y < h) { c.drawLine(0f, y, w, y, p); y += 56f }
        p.strokeWidth = 3f; p.color = Color.argb(46, 120, 180, 255)
        c.drawCircle(cx, cy, r, p); c.drawCircle(cx, cy, r * .62f, p)
        p.strokeWidth = 2f; p.color = Color.argb(34, 120, 180, 255)
        c.drawLine(cx - r * 1.25f, cy, cx - r * .2f, cy, p); c.drawLine(cx + r * .2f, cy, cx + r * 1.25f, cy, p)
        c.drawLine(cx, cy - r * 1.25f, cx, cy - r * .2f, p); c.drawLine(cx, cy + r * .2f, cx, cy + r * 1.25f, p)
        p.style = Paint.Style.FILL; p.color = Color.argb(90, 255, 70, 70); c.drawCircle(cx, cy, 5f, p)
    }
}

/** Komponen tampilan seragam untuk semua menu. */
object Ui {
    val ACCENT = 0xFF4C8DFF.toInt()
    val GREEN = 0xFF1FA463.toInt()
    val GRAY = 0xFF3B475C.toInt()
    val SUB = 0xFF9FB3C8.toInt()

    fun dp(c: Context, v: Float) = (v * c.resources.displayMetrics.density).toInt()
    fun darken(col: Int) = Color.rgb((Color.red(col) * .72f).toInt(), (Color.green(col) * .72f).toInt(), (Color.blue(col) * .72f).toInt())
    fun rect(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius; if (strokeW > 0) setStroke(strokeW, strokeColor) }
    private fun pressable(normal: Drawable, pressed: Drawable) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), pressed); addState(intArrayOf(), normal)
    }

    fun button(c: Context, text: String, color: Int = ACCENT, onClick: () -> Unit): Button = Button(c).apply {
        this.text = text; setTextColor(Color.WHITE); textSize = 16f; isAllCaps = false; typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null
        val r = dp(c, 14f).toFloat()
        background = pressable(rect(color, r), rect(darken(color), r))
        setPadding(dp(c, 20f), dp(c, 12f), dp(c, 20f), dp(c, 12f))
        setOnClickListener { onClick() }
    }

    /** Kartu pilihan besar: judul + keterangan, dengan garis aksen warna. */
    fun card(c: Context, title: String, sub: String, accent: Int, onClick: () -> Unit): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val r = dp(c, 16f).toFloat(); val sw = dp(c, 1.5f).coerceAtLeast(2)
        background = pressable(rect(0xFF16233A.toInt(), r, accent, sw), rect(0xFF22365A.toInt(), r, accent, sw))
        setPadding(dp(c, 16f), dp(c, 14f), dp(c, 16f), dp(c, 14f)); isClickable = true
        addView(TextView(c).apply { text = title; textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        addView(TextView(c).apply { text = sub; textSize = 12f; setTextColor(SUB); setPadding(0, dp(c, 3f), 0, 0) })
        setOnClickListener { onClick() }
    }

    /** Baris pilihan (chip); hanya satu aktif. */
    fun chips(c: Context, labels: List<String>, sel: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val views = ArrayList<TextView>(); val r = dp(c, 12f).toFloat()
        fun style(cur: Int) { for (i in views.indices) {
            views[i].background = rect(if (i == cur) ACCENT else 0xFF16233A.toInt(), r, if (i == cur) ACCENT else 0xFF2C3E5C.toInt(), dp(c, 1f).coerceAtLeast(1))
            views[i].setTextColor(if (i == cur) Color.WHITE else SUB) } }
        for ((i, l) in labels.withIndex()) {
            val tv = TextView(c).apply { text = l; textSize = 14f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(c, 8f), dp(c, 11f), dp(c, 8f), dp(c, 11f)); isClickable = true
                setOnClickListener { style(i); onSelect(i) } }
            views.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(c, 3f), 0, dp(c, 3f), 0) })
        }
        style(sel); return row
    }

    fun input(c: Context, hint: String, text: String = ""): EditText = EditText(c).apply {
        this.hint = hint; setText(text); setTextColor(Color.WHITE); setHintTextColor(0xFF6B7A90.toInt()); textSize = 16f
        background = rect(0xFF0E1829.toInt(), dp(c, 12f).toFloat(), 0xFF2C3E5C.toInt(), dp(c, 1f).coerceAtLeast(1))
        setPadding(dp(c, 14f), dp(c, 11f), dp(c, 14f), dp(c, 11f)); setSingleLine()
    }

    fun section(c: Context, text: String): TextView = TextView(c).apply {
        this.text = text.uppercase(); textSize = 12f; setTextColor(ACCENT); typeface = Typeface.DEFAULT_BOLD; letterSpacing = .15f
        setPadding(dp(c, 2f), dp(c, 14f), 0, dp(c, 6f))
    }

    fun label(c: Context, text: String, size: Float = 16f, color: Int = Color.WHITE): TextView = TextView(c).apply {
        this.text = text; textSize = size; setTextColor(color); setPadding(0, dp(c, 8f), 0, dp(c, 4f))
    }

    /** Panel gelap membulat tempat isi lobby/pengaturan. */
    fun panel(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = rect(0xDD0C1424.toInt(), dp(c, 20f).toFloat(), 0xFF263754.toInt(), dp(c, 1f).coerceAtLeast(1))
        setPadding(dp(c, 22f), dp(c, 16f), dp(c, 22f), dp(c, 18f))
    }

    fun gap(c: Context, h: Float): View = View(c).apply { layoutParams = LinearLayout.LayoutParams(1, dp(c, h)) }

    /** Layar penuh bergaya: BgView + isi di tengah (maks lebar 560dp) dengan scroll. */
    fun screen(a: android.app.Activity, content: LinearLayout): FrameLayout {
        val c: Context = a
        val frame = FrameLayout(c); frame.addView(BgView(c))
        val wpx = minOf(dp(c, 560f), c.resources.displayMetrics.widthPixels - dp(c, 32f))
        val holder = FrameLayout(c)
        holder.addView(content, FrameLayout.LayoutParams(wpx, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(c, 14f); bottomMargin = dp(c, 14f) })
        frame.addView(ScrollView(c).apply { isFillViewport = true; addView(holder) })
        return frame
    }
}
