package com.example.shooter3d
import java.io.*
import java.net.*
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Protokol LAN sederhana: TCP, tiap pesan = [int panjang][byte tipe][isi]. Host memegang logika game (autoritatif). */
object Proto {
    const val PORT = 7777; const val DISC_PORT = 7778
    // klien -> host
    const val HELLO = 1; const val STATE = 2; const val SHOT = 3; const val HIT = 4
    // host -> klien
    const val PING = 20   // detak jantung dua arah (diabaikan penerima)
    const val WELCOME = 10; const val ROSTER = 11; const val START = 12; const val SNAP = 13; const val EVENT = 14; const val FULL = 15

    fun pack(type: Int, fill: (DataOutputStream) -> Unit): ByteArray {
        val bo = ByteArrayOutputStream(); val d = DataOutputStream(bo)
        d.writeByte(type); fill(d); d.flush(); return bo.toByteArray()
    }

    /** Alamat IPv4 perangkat ini di jaringan lokal (untuk ditampilkan ke teman). */
    fun localIps(): List<String> {
        val out = ArrayList<String>()
        try {
            val en = NetworkInterface.getNetworkInterfaces()
            while (en != null && en.hasMoreElements()) {
                val ni = en.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) if (a is Inet4Address && !a.isLoopbackAddress) out.add(a.hostAddress ?: continue)
            }
        } catch (e: Exception) { }
        return out
    }
}

/**
 * Antrean kirim NON-BLOCKING dengan thread penulis sendiri. Sebelumnya send() menulis langsung ke socket dari thread game;
 * bila satu HP lambat/WiFi tersendat, tulisan macet dan seluruh game (dan UI) ikut membeku sampai Android mematikan app.
 * Sekarang: SNAP/STATE hanya disimpan yang terbaru (yang lama dibuang), pesan lain antre, dan koneksi yang macet > 8 dtk
 * atau antreannya menumpuk diputus sendiri. Bila sepi 2 dtk, otomatis kirim PING supaya timeout baca tidak salah putus.
 */
class Outbox(private val sock: Socket, private val onDead: () -> Unit) {
    private val out = DataOutputStream(BufferedOutputStream(sock.getOutputStream(), 8192))
    private val lock = ReentrantLock()
    private val cond = lock.newCondition()
    private val reliable = java.util.ArrayDeque<ByteArray>()
    private var snap: ByteArray? = null
    private var state: ByteArray? = null
    @Volatile private var alive = true
    @Volatile private var writingSince = 0L

    init { val t = Thread { loop() }; t.isDaemon = true; t.start() }

    fun send(b: ByteArray) {
        if (!alive) return
        val ws = writingSince
        if (ws != 0L && System.currentTimeMillis() - ws > 8000L) { kill(); return }
        var overflow = false
        lock.withLock {
            val t = if (b.isNotEmpty()) b[0].toInt() else -1
            if (t == Proto.SNAP) snap = b
            else if (t == Proto.STATE) state = b
            else if (reliable.size > 3000) overflow = true
            else reliable.add(b)
            cond.signalAll()
            Unit
        }
        if (overflow) kill()
    }

    private fun loop() {
        try {
            while (alive) {
                var msg: ByteArray? = null
                lock.withLock {
                    if (reliable.isEmpty() && snap == null && state == null) cond.await(2, TimeUnit.SECONDS)
                    val r = reliable.poll()
                    if (r != null) msg = r
                    else {
                        val st = state
                        if (st != null) { state = null; msg = st }
                        else { val sn = snap; if (sn != null) { snap = null; msg = sn } }
                    }
                    Unit
                }
                val m = msg ?: Proto.pack(Proto.PING) { }
                writingSince = System.currentTimeMillis()
                out.writeInt(m.size); out.write(m); out.flush()
                writingSince = 0L
            }
        } catch (e: Throwable) { }
        kill()
    }

    fun kill() {
        synchronized(this) { if (!alive) return; alive = false }
        try { sock.close() } catch (e: Throwable) { }
        lock.withLock { cond.signalAll(); Unit }
        try { onDead() } catch (e: Throwable) { }
    }
}

class Conn(val id: Int, val sock: Socket) {
    @Volatile var name = "Pemain"
    @Volatile var open = true
    val inp = DataInputStream(BufferedInputStream(sock.getInputStream()))
    private val box = Outbox(sock) { open = false }
    fun send(b: ByteArray) { box.send(b) }
    fun close() { open = false; box.kill() }
}

interface HostListener {
    fun onJoin(c: Conn)
    fun onLeave(c: Conn)
    fun onMessage(c: Conn, type: Int, d: DataInputStream)
}

class NetHost(var listener: HostListener) {
    val conns = CopyOnWriteArrayList<Conn>()
    private var server: ServerSocket? = null
    @Volatile private var running = false

    fun start(): Boolean {
        return try {
            val s = ServerSocket(); s.reuseAddress = true; s.bind(InetSocketAddress(Proto.PORT))
            server = s; running = true
            val t = Thread { acceptLoop(s) }; t.isDaemon = true; t.start(); true
        } catch (e: Exception) { false }
    }

    private fun acceptLoop(s: ServerSocket) {
        while (running) {
            try {
                val sock = s.accept(); sock.tcpNoDelay = true; sock.keepAlive = true; sock.soTimeout = 12000
                var id = 1
                while (conns.any { it.id == id }) id++
                if (id >= Game.MAX_PLAYERS) {
                    val bo = Proto.pack(Proto.FULL) { }
                    try { val o = DataOutputStream(sock.getOutputStream()); o.writeInt(bo.size); o.write(bo); o.flush() } catch (e: Exception) { }
                    sock.close(); continue
                }
                val c = Conn(id, sock); conns.add(c)
                val t = Thread { readLoop(c) }; t.isDaemon = true; t.start()
            } catch (e: Throwable) { if (!running) return }
        }
    }

    private fun readLoop(c: Conn) {
        try {
            while (running && c.open) {
                val len = c.inp.readInt()
                if (len <= 0 || len > 65536) break
                val buf = ByteArray(len); c.inp.readFully(buf)
                val d = DataInputStream(ByteArrayInputStream(buf)); val t = d.readUnsignedByte()
                if (t == Proto.PING) continue
                // pesan rusak / error di listener tidak boleh memutus koneksi pemain
                try {
                    if (t == Proto.HELLO) { c.name = d.readUTF(); listener.onJoin(c) } else listener.onMessage(c, t, d)
                } catch (e: Exception) { }
            }
        } catch (e: Throwable) { }
        c.close(); conns.remove(c)
        try { listener.onLeave(c) } catch (e: Throwable) { }
    }

    fun broadcast(b: ByteArray) { for (c in conns) c.send(b) }
    fun sendTo(id: Int, b: ByteArray) { for (c in conns) if (c.id == id) c.send(b) }
    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        for (c in conns) c.close()
        conns.clear()
    }
}

interface ClientListener {
    fun onMessage(type: Int, d: DataInputStream)
    fun onClosed()
}

class NetClient(var listener: ClientListener) {
    private var sock: Socket? = null
    private var box: Outbox? = null
    @Volatile var open = false

    fun connect(host: String, name: String, onResult: (Boolean) -> Unit) {
        val t = Thread {
            var ok = false
            try {
                val s = Socket(); s.tcpNoDelay = true; s.keepAlive = true
                s.connect(InetSocketAddress(host, Proto.PORT), 4000); s.soTimeout = 12000
                sock = s
                // bila pengirim macet, cukup tutup socket: readLoop yang akan melapor onClosed()
                box = Outbox(s) { try { s.close() } catch (e: Throwable) { } }
                open = true
                send(Proto.pack(Proto.HELLO) { it.writeUTF(name) })
                ok = true
            } catch (e: Exception) { open = false }
            onResult(ok)
            if (ok) readLoop()
        }
        t.isDaemon = true; t.start()
    }

    private fun readLoop() {
        try {
            val inp = DataInputStream(BufferedInputStream(sock!!.getInputStream()))
            while (open) {
                val len = inp.readInt()
                if (len <= 0 || len > 1_000_000) break
                val buf = ByteArray(len); inp.readFully(buf)
                val d = DataInputStream(ByteArrayInputStream(buf)); val t = d.readUnsignedByte()
                if (t == Proto.PING) continue
                try { listener.onMessage(t, d) } catch (e: Exception) { }
            }
        } catch (e: Throwable) { }
        val was = open
        open = false
        box?.kill()
        if (was) try { listener.onClosed() } catch (e: Throwable) { }
    }

    fun send(b: ByteArray) { box?.send(b) }
    fun close() { open = false; try { sock?.close() } catch (e: Exception) { }; box?.kill() }
}

/** Pemancar "ada room di sini" lewat UDP broadcast supaya teman tidak perlu mengetik IP. */
class Beacon(private val name: String, private val mode: Int) {
    @Volatile private var running = false
    @Volatile var players = 1
    fun start() {
        running = true
        val t = Thread {
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket(); s.broadcast = true
                while (running) {
                    val data = "SH3D|$name|$mode|$players".toByteArray()
                    val targets = ArrayList<InetAddress>()
                    try { targets.add(InetAddress.getByName("255.255.255.255")) } catch (e: Exception) { }
                    try {
                        val en = NetworkInterface.getNetworkInterfaces()
                        while (en != null && en.hasMoreElements()) {
                            val ni = en.nextElement()
                            if (!ni.isUp || ni.isLoopback) continue
                            for (ia in ni.interfaceAddresses) { val b = ia.broadcast; if (b != null) targets.add(b) }
                        }
                    } catch (e: Exception) { }
                    for (a in targets) try { s.send(DatagramPacket(data, data.size, a, Proto.DISC_PORT)) } catch (e: Exception) { }
                    Thread.sleep(1000)
                }
            } catch (e: Exception) { }
            try { s?.close() } catch (e: Exception) { }
        }
        t.isDaemon = true; t.start()
    }
    fun stop() { running = false }
}

/** Pendengar beacon: memanggil onFound(ip, namaHost, modeOrdinal, jumlahPemain). */
class Finder(private val onFound: (String, String, Int, Int) -> Unit) {
    @Volatile private var running = false
    private var sock: DatagramSocket? = null
    fun start() {
        running = true
        val t = Thread {
            try {
                val s = DatagramSocket(null); s.reuseAddress = true; s.bind(InetSocketAddress(Proto.DISC_PORT)); s.soTimeout = 1000; sock = s
                val buf = ByteArray(256)
                while (running) {
                    try {
                        val p = DatagramPacket(buf, buf.size); s.receive(p)
                        val parts = String(p.data, 0, p.length).split("|")
                        if (parts.size >= 4 && parts[0] == "SH3D") onFound(p.address.hostAddress ?: continue, parts[1], parts[2].toIntOrNull() ?: 0, parts[3].toIntOrNull() ?: 1)
                    } catch (e: SocketTimeoutException) { }
                }
            } catch (e: Exception) { }
            try { sock?.close() } catch (e: Exception) { }
        }
        t.isDaemon = true; t.start()
    }
    fun stop() { running = false; try { sock?.close() } catch (e: Exception) { } }
}

/** Sesi mabar yang dibawa dari Lobby ke GameActivity. */
object Session {
    var host: NetHost? = null
    var client: NetClient? = null
    var beacon: Beacon? = null
    var myId = 0
    var mode = Mode.WAVE
    val roster = ArrayList<Pair<Int, String>>()
    @Volatile var inGame = false
    fun clear() {
        beacon?.stop(); beacon = null
        host?.stop(); host = null
        client?.close(); client = null
        roster.clear(); inGame = false; myId = 0
    }
}
