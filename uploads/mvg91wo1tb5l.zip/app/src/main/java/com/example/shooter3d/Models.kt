package com.example.shooter3d
import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/** Kotak berwarna (dipakai untuk lantai, target, peti, item, tangan, pemain lain). */
class Part(val ox: Float, val oy: Float, val oz: Float, val sx: Float, val sy: Float, val sz: Float, val c: FloatArray)
fun col(r: Int, g: Int, b: Int) = floatArrayOf(r / 255f, g / 255f, b / 255f)

/** Mesh dari folder assets/models (berkas .mesh) (hasil tools/glb2mesh.py): per vertex pos(3) normal(3) warna(3). */
class Mesh(val buf: FloatBuffer, val count: Int)
object MeshIO {
    fun load(c: Context, name: String): Mesh {
        val bb = ByteBuffer.wrap(c.assets.open("models/$name.mesh").readBytes()).order(ByteOrder.LITTLE_ENDIAN)
        val n = bb.int
        val fb = ByteBuffer.allocateDirect(n * 36).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (i in 0 until n * 9) fb.put(bb.float)
        fb.position(0); return Mesh(fb, n)
    }
}

object Models {
    /** Target latihan (buatan sendiri dari kotak). */
    val target = listOf(
        Part(0f, .7f, 0f, .1f, 1.4f, .1f, col(90, 90, 90)),
        Part(0f, 1.5f, 0f, 1.4f, 1.4f, .1f, col(240, 240, 240)),
        Part(0f, 1.5f, .06f, 1.0f, 1.0f, .1f, col(220, 30, 30)),
        Part(0f, 1.5f, .12f, .55f, .55f, .1f, col(240, 240, 240)),
        Part(0f, 1.5f, .18f, .2f, .2f, .1f, col(220, 30, 30)))
    /**
     * Penampilan musuh manusia (dibangun dari kotak, dianimasikan di GameRenderer.drawHuman).
     * kind: 0 Prajurit (helm + senapan), 1 Pengintai (topi + bandana + SMG), 2 Berat (zirah + shotgun), 4 Boss (zirah emas + minigun).
     */
    class Look(val kind: Int, val scale: Float, val wid: Float, val skin: FloatArray, val shirt: FloatArray, val pants: FloatArray,
               val boots: FloatArray, val gear: FloatArray, val gun: FloatArray)
    private val soldierLook = Look(0, 1f, 1f, col(222, 180, 140), col(86, 104, 62), col(64, 74, 50), col(40, 36, 32), col(60, 78, 48), col(34, 34, 38))
    val looks = arrayOf(
        soldierLook,
        Look(1, .93f, .88f, col(236, 196, 160), col(52, 64, 98), col(150, 140, 120), col(60, 44, 36), col(214, 52, 44), col(50, 50, 56)),
        Look(2, 1.18f, 1.38f, col(190, 140, 105), col(108, 40, 40), col(70, 70, 76), col(30, 30, 34), col(86, 88, 98), col(46, 40, 36)),
        soldierLook,                                   // 3 = target latihan (tidak dipakai)
        Look(4, 1.65f, 1.45f, col(160, 110, 130), col(70, 30, 90), col(40, 36, 52), col(24, 22, 30), col(226, 178, 52), col(54, 54, 60)))

    /** Pemain lain (mabar): robot/tentara sederhana dari kotak, warna dikalikan tint per pemain. */
    val player = listOf(
        Part(-.16f, .45f, 0f, .2f, .9f, .22f, col(70, 75, 90)),
        Part(.16f, .45f, 0f, .2f, .9f, .22f, col(70, 75, 90)),
        Part(0f, 1.2f, 0f, .56f, .7f, .3f, col(255, 255, 255)),
        Part(-.38f, 1.2f, .05f, .16f, .6f, .18f, col(230, 230, 230)),
        Part(.38f, 1.2f, .12f, .16f, .6f, .18f, col(230, 230, 230)),
        Part(0f, 1.75f, 0f, .34f, .34f, .34f, col(235, 200, 165)),
        Part(0f, 1.8f, .15f, .36f, .12f, .08f, col(30, 30, 40)),
        Part(.33f, 1.15f, .45f, .09f, .12f, .8f, col(40, 40, 45)))
    val playerTint = arrayOf(floatArrayOf(.35f, .6f, 1f), floatArrayOf(.4f, 1f, .45f), floatArrayOf(1f, .65f, .25f), floatArrayOf(.85f, .45f, 1f))

    /** Kotak peluru senapan (kuning-hijau), peluru shotgun (merah), kotak darah (putih + palang merah). */
    val ammoRifle = listOf(
        Part(0f, .2f, 0f, .75f, .4f, .5f, col(76, 98, 56)),
        Part(0f, .41f, 0f, .77f, .04f, .18f, col(240, 200, 30)),
        Part(-.2f, .5f, 0f, .09f, .22f, .09f, col(220, 170, 60)),
        Part(0f, .5f, 0f, .09f, .22f, .09f, col(220, 170, 60)),
        Part(.2f, .5f, 0f, .09f, .22f, .09f, col(220, 170, 60)))
    val ammoShell = listOf(
        Part(0f, .2f, 0f, .75f, .4f, .5f, col(150, 40, 35)),
        Part(0f, .41f, 0f, .77f, .04f, .18f, col(245, 245, 245)),
        Part(-.2f, .52f, 0f, .12f, .25f, .12f, col(210, 50, 40)),
        Part(0f, .52f, 0f, .12f, .25f, .12f, col(210, 50, 40)),
        Part(.2f, .52f, 0f, .12f, .25f, .12f, col(210, 50, 40)),
        Part(-.2f, .67f, 0f, .125f, .06f, .125f, col(220, 190, 80)),
        Part(0f, .67f, 0f, .125f, .06f, .125f, col(220, 190, 80)),
        Part(.2f, .67f, 0f, .125f, .06f, .125f, col(220, 190, 80)))
    val health = listOf(
        Part(0f, .22f, 0f, .7f, .44f, .5f, col(245, 245, 245)),
        Part(0f, .45f, 0f, .42f, .04f, .12f, col(225, 30, 40)),
        Part(0f, .45f, 0f, .12f, .04f, .42f, col(225, 30, 40)),
        Part(0f, .22f, .255f, .42f, .12f, .02f, col(225, 30, 40)),
        Part(0f, .22f, .255f, .12f, .42f, .02f, col(225, 30, 40)))
    val pickupGlow = arrayOf(floatArrayOf(.95f, .85f, .25f), floatArrayOf(1f, .45f, .3f), floatArrayOf(.45f, 1f, .6f))

    /** Tangan (sarung tangan) untuk animasi reload & pegangan senjata. */
    val hand = listOf(
        Part(0f, 0f, 0f, .075f, .075f, .13f, col(55, 60, 55)),
        Part(0f, -.01f, .09f, .06f, .05f, .09f, col(210, 170, 140)))
    /** Magasin / cell energi senapan: dipasang & dilepas pada animasi reload. */
    val mag = listOf(
        Part(0f, 0f, 0f, .085f, .2f, .13f, col(55, 58, 66)),
        Part(0f, -.02f, .066f, .06f, .12f, .01f, col(80, 220, 255)))
    val shellBit = listOf(Part(0f, 0f, 0f, .035f, .035f, .09f, col(220, 60, 50)), Part(0f, 0f, -.05f, .036f, .036f, .03f, col(220, 190, 80)))
    /** Kilatan moncong tampak samping (api memanjang ke depan) untuk karakter teman yang dilihat dari sisi/belakang. */
    val flashSide = listOf(
        Part(0f, 0f, .17f, .09f, .09f, .34f, col(255, 225, 120)),
        Part(0f, 0f, .10f, .20f, .03f, .22f, col(255, 255, 255)),
        Part(0f, 0f, .10f, .03f, .20f, .22f, col(255, 255, 255)))
    val flash = listOf(
        Part(0f, 0f, 0f, .16f, .16f, .04f, col(255, 235, 140)),
        Part(0f, 0f, 0f, .05f, .26f, .04f, col(255, 255, 255)),
        Part(0f, 0f, 0f, .26f, .05f, .04f, col(255, 255, 255)))
}
