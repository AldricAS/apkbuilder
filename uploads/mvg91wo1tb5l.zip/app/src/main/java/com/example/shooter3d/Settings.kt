package com.example.shooter3d
import android.content.Context

/** Pengaturan grafis, suara & kontrol (disimpan di SharedPreferences). */
class Gfx(var quality: Int, var fpsCap: Int, var showFps: Boolean, var sens: Float, var vol: Float = 1f, var name: String = "Pemain", var difficulty: Int = 1) {
    val resScale get() = floatArrayOf(.5f, .75f, 1f)[quality]
    val viewDist get() = floatArrayOf(55f, 85f, 120f)[quality]
    val decor get() = quality > 0
    fun save(c: Context) = c.getSharedPreferences("gfx", 0).edit()
        .putInt("q", quality).putInt("fps", fpsCap).putBoolean("showFps", showFps).putFloat("sens", sens)
        .putFloat("vol", vol).putString("name", name).putInt("diff", difficulty).apply()
    companion object {
        val QUALITY = arrayOf("Rendah", "Sedang", "Tinggi")
        val FPS = intArrayOf(30, 60, 0) // 0 = tanpa batas
        fun load(c: Context): Gfx {
            val p = c.getSharedPreferences("gfx", 0)
            return Gfx(p.getInt("q", 1), p.getInt("fps", 60), p.getBoolean("showFps", false), p.getFloat("sens", .2f),
                p.getFloat("vol", 1f), p.getString("name", "Pemain") ?: "Pemain", p.getInt("diff", 1).coerceIn(0, 2))
        }
    }
}
