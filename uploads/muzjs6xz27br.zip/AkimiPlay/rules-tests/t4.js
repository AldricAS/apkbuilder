const {update,T}=require('./sim.js');
const clone=o=>JSON.parse(JSON.stringify(o));
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};
const DAY=86400000;
const mkU=(uid,id,role,extra={})=>({uid,userId:id,email:uid+'@x',displayName:uid,role,verified:false,level:1,xp:0,totalWatchMinutes:0,createdAt:1,xpAt:1,shard:100,...extra});
const base={users:{
  D:mkU('D',1,'developer'),D2:mkU('D2',2,'developer'),
  U:mkU('U',5,'user'),M:mkU('M',6,'moderator'),
  P:mkU('P',7,'user',{premiumUntil:T+10*DAY}),
  E:mkU('E',8,'user',{premiumUntil:T-DAY}),
  L:mkU('L',11,'premium',{premiumUntil:T+10*DAY}),
  X:mkU('X',9,'user')},
 meta:{userIdCounter:{value:500,lastUid:'X'}},
 userIndex:{1:'D',2:'D2',5:'U',6:'M',7:'P',8:'E',9:'X',11:'L'}};
// ---------- ROLE ----------
t('DEV ubah role user->moderator',update(base,{'users/U/role':'moderator'},'D'),true);
t('DEV ubah role moderator->user',update(base,{'users/M/role':'user'},'D'),true);
t('DEV ubah role ke maou',update(base,{'users/U/role':'maou'},'D'),true);
t('DEV ubah role ke nilai ngawur',update(base,{'users/U/role':'superadmin'},'D'),false);
t('DEV ubah role dirinya sendiri',update(base,{'users/D/role':'user'},'D'),false);
t('DEV ubah role developer lain',update(base,{'users/D2/role':'user'},'D'),true);
t('USER ubah role sendiri jadi developer',update(base,{'users/U/role':'developer'},'U'),false);
t('USER ubah role orang lain',update(base,{'users/X/role':'admin'},'U'),false);
t('MODERATOR ubah role orang',update(base,{'users/U/role':'user'},'M'),false);
t('MODERATOR naikkan role sendiri',update(base,{'users/M/role':'developer'},'M'),false);
// ---------- PREMIUM BUKAN ROLE ----------
t('DEV set role "premium" (bukan role)',update(base,{'users/U/role':'premium'},'D'),false);
t('DEV set role "premium" + premiumUntil',update(base,{'users/U/role':'premium','users/U/premiumUntil':T+30*DAY},'D'),false);
t('USER set role "premium" untuk diri sendiri',update(base,{'users/U/role':'premium'},'U'),false);
t('DEV beri premium: hanya premiumUntil, role tetap user',update(base,{'users/U/premiumUntil':T+30*DAY},'D'),true);
t('DEV rapikan akun lama ber-role "premium" -> user',update(base,{'users/L/role':'user'},'D'),true);
t('DEV beri premium + rapikan role lama sekaligus',update(base,{'users/L/premiumUntil':T+60*DAY,'users/L/role':'user'},'D'),true);
// ---------- PREMIUM UNTIL ----------
t('DEV perpanjang premium',update(base,{'users/P/premiumUntil':T+40*DAY},'D'),true);
t('DEV beri premiumUntil ke staf (role tak berubah)',update(base,{'users/M/premiumUntil':T+30*DAY},'D'),true);
t('DEV premiumUntil > 10 tahun',update(base,{'users/U/premiumUntil':T+4000*DAY},'D'),false);
t('DEV premiumUntil 10 tahun pas',update(base,{'users/U/premiumUntil':T+3650*DAY},'D'),true);
t('DEV cabut premium (hapus premiumUntil)',update(base,{'users/P/premiumUntil':null},'D'),true);
t('DEV premiumUntil untuk dirinya sendiri',update(base,{'users/D/premiumUntil':T+30*DAY},'D'),false);
t('USER beri premium ke dirinya',update(base,{'users/U/premiumUntil':T+30*DAY},'U'),false);
t('USER perpanjang premium sendiri',update(base,{'users/P/premiumUntil':T+999*DAY},'P'),false);
t('USER hapus/ubah premiumUntil sendiri',update(base,{'users/P/premiumUntil':null},'P'),false);
t('USER premiumUntil orang lain',update(base,{'users/X/premiumUntil':T+30*DAY},'U'),false);
t('DEV premiumUntil teks',update(base,{'users/U/premiumUntil':'abc'},'D'),false);
t('DEV premiumUntil nol/negatif',update(base,{'users/U/premiumUntil':0},'D'),false);
// ---------- UBAH ID ----------
const chg=(uid,oldId,newId,extra={})=>({['users/'+uid+'/userId']:newId,['userIndex/'+newId]:uid,['userIndex/'+oldId]:null,...extra});
t('DEV ubah id U #5 -> #10',update(base,chg('U',5,10),'D'),true);
t('DEV ubah id ke yang sudah dipakai (#6)',update(base,chg('U',5,6),'D'),false);
t('DEV ubah id > counter (#9999)',update(base,chg('U',5,9999),'D'),false);
t('DEV ubah id = counter (#500)',update(base,chg('U',5,500),'D'),true);
t('DEV ubah id 0',update(base,chg('U',5,0),'D'),false);
t('DEV ubah id negatif',update(base,chg('U',5,-3),'D'),false);
t('DEV ubah id pecahan',update(base,chg('U',5,10.5),'D'),false);
t('DEV ubah id tanpa pindah userIndex baru',update(base,{'users/U/userId':10,'userIndex/5':null},'D'),false);
t('DEV ubah id tanpa hapus userIndex lama',update(base,{'users/U/userId':10,'userIndex/10':'U'},'D'),false);
t('DEV ubah id, index baru menunjuk uid lain',update(base,{'users/U/userId':10,'userIndex/10':'X','userIndex/5':null},'D'),false);
t('USER biasa ubah id sendiri',update(base,chg('U',5,10),'U'),false);
t('MODERATOR ubah id orang',update(base,chg('U',5,10),'M'),false);
t('DEV hapus userIndex milik id yang masih dipakai',update(base,{'userIndex/5':null},'D'),false);
t('USER hapus userIndex orang',update(base,{'userIndex/5':null},'X'),false);
t('USER tulis userIndex id aktif orang lain',update(clone(base),{'userIndex/77':'X'},'X'),false);
// legacy: user tanpa userIndex
const leg=clone(base);delete leg.userIndex[5];
t('DEV ubah id akun lama tanpa userIndex',update(leg,{'users/U/userId':10,'userIndex/10':'U'},'D'),true);
// regresi: signup user baru membuat profil + index sendiri
const su={users:{},meta:{userIdCounter:{value:501,lastUid:'N'}},userIndex:{}};
t('REGRESI: user baru buat userIndex sendiri',update({...base,users:{...base.users,N:mkU('N',501,'user')},meta:{userIdCounter:{value:501,lastUid:'N'}}},{'userIndex/501':'N'},'N'),true);
t('REGRESI: user ubah displayName sendiri',update(base,{'users/U/displayName':'Baru'},'U'),true);
console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
