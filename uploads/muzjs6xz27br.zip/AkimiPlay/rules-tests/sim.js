// Simulator rules Realtime DB (sederhana): tes logika, bukan pengganti emulator Firebase.
const fs=require('fs');
const T=1_800_000_000_000;
String.prototype.matches=function(re){return re.test(String(this))};
function getAt(db,path){let c=db;for(const k of path){if(c==null||typeof c!=='object')return undefined;c=c[k]}return c}
function setAt(db,path,v){let c=db;for(let i=0;i<path.length-1;i++){const k=path[i];if(c[k]==null||typeof c[k]!=='object')c[k]={};c=c[k]}
 const k=path[path.length-1];if(v===null||v===undefined)delete c[k];else c[k]=v}
function prune(o){if(o&&typeof o==='object'){for(const k of Object.keys(o)){prune(o[k]);if(o[k]&&typeof o[k]==='object'&&!Object.keys(o[k]).length)delete o[k]}}}
class Snap{constructor(db,path){this.db=db;this.path=path}
 raw(){return getAt(this.db,this.path)}
 child(p){if(typeof p!=='string')throw new Error('rules: child() butuh string, dapat '+p);return new Snap(this.db,[...this.path,...p.split('/').filter(x=>x!=='')])}
 parent(){return new Snap(this.db,this.path.slice(0,-1))}
 exists(){const r=this.raw();return r!==undefined&&r!==null}
 val(){const r=this.raw();return r===undefined||(r&&typeof r==='object')?null:r}
 hasChildren(a){const r=this.raw();if(!r||typeof r!=='object')return false;return !a||a.every(k=>k in r)}
 isNumber(){return typeof this.raw()==='number'} isString(){return typeof this.raw()==='string'} isBoolean(){return typeof this.raw()==='boolean'}}
const rules=JSON.parse(fs.readFileSync(process.argv[2]||require('path').join(__dirname,'..','database.rules.json'),'utf8')).rules;
function ev(expr,ctx,vars){
  const names=Object.keys(vars);
  try{return !!new Function('data','newData','root','auth','now',...names,'return ('+expr+')')(ctx.data,ctx.newData,ctx.root,ctx.auth,T,...names.map(n=>vars[n]))}catch(e){if(process.env.RULES_DEBUG)console.log('   [rules error]',e.message);return false}}
function child(node,key){if(node[key]&&typeof node[key]==='object')return[node[key],{}];
 for(const k of Object.keys(node))if(k[0]==='$'&&k!=='$other'){return[node[k],{[k]:key}]}
 if(node.$other)return[node.$other,{}];return[null,{}]}
function validate(node,path,vars,old,nu,auth,why){
  if(!node)return true;const ctx=mk(path,old,nu,auth);
  if(!new Snap(nu,path).exists())return true;
  if(node['.validate']!==undefined){const ok=node['.validate']===false?false:node['.validate']===true?true:ev(node['.validate'],ctx,vars);if(!ok){why.push('validate '+path.join('/'));return false}}
  const r=getAt(nu,path);
  if(r&&typeof r==='object'){for(const k of Object.keys(r)){const[n,v]=child(node,k);if(n===null)continue;if(!validate(n,[...path,k],{...vars,...v},old,nu,auth,why))return false}}
  return true}
function mk(path,old,nu,auth){return{data:new Snap(old,path),newData:new Snap(nu,path),root:new Snap(old,[]),auth}}
// update multi-path; patch: {'a/b':value|null}
function update(db,patch,uid){
  const auth=uid?{uid,token:{email:'x'}}:null;
  const nu=JSON.parse(JSON.stringify(db));
  for(const [p,v] of Object.entries(patch)){const val=(v&&v.__ts)?T:(v&&typeof v==='object'?JSON.parse(JSON.stringify(v),(k,x)=>x&&x.__ts?T:x):v);setAt(nu,p.split('/'),val)}
  prune(nu);
  const why=[];
  for(const p of Object.keys(patch)){
    const path=p.split('/');let node=rules,vars={},allowed=false;
    const chain=[];
    for(let i=0;i<=path.length;i++){
      if(node['.write']!==undefined){const ctx=mk(path.slice(0,i),db,nu,auth);
        const ok=node['.write']===true||(typeof node['.write']==='string'&&ev(node['.write'],ctx,vars));if(ok)allowed=true}
      if(i===path.length)break;
      const[n,v]=child(node,path[i]);if(!n){node=null;break}node=n;vars={...vars,...v}}
    if(!allowed){return{ok:false,why:'write denied @'+p}}
    // validate di lokasi yang ditulis dan turunannya
    if(node&&!validate(node,path,vars,db,nu,auth,why))return{ok:false,why:why.join(',')+' @'+p}
  }
  return{ok:true,db:nu}}
module.exports={update,T};
