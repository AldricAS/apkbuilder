// Tes rules AkimiGame: Dino Run (koleksi, spin, hadiah main, batas harian, jual duplikat). Jalankan: node rules-tests/t11.js
const {update,T}=require('./sim.js');
const ts={__ts:1};
const clone=o=>JSON.parse(JSON.stringify(o));
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};
const DAY=Math.floor((T+25200000)/86400000);
const usr=(shard)=>({uid:'U',userId:7,email:'u@x',displayName:'U',role:'user',verified:false,level:1,xp:0,totalWatchMinutes:0,createdAt:1,xpAt:1,shard});
const dbWith=(shard,dino)=>({users:{U:usr(shard)},...(dino?{dino_game:{U:dino}}:{})});

// ---- rumus undian: HARUS sama dengan rules & dinoService.ts ----
const LENS=[4,4,3,1],BASES=[0,4,8,11];
function outcome(sp,seed=T){
  const roll=(seed+sp.n*7919)%10000, roll2=(seed*7+sp.n*104729+31)%9973;
  let rar= sp.mode===2?0: (sp.pm>=249||roll<20)?3:(sp.pl>=79||roll<250)?2:(sp.pr>=9||roll<2000)?1:0;
  const idx=roll2%LENS[rar];
  return {roll,rar,idx,s:BASES[rar]+idx};
}
const U='dino_game/U/';
const pay=(sp0,mode,shardBefore)=>{const cost=[150,650,50][mode];const sp={seed:ts,pend:mode===1?5:1,mode,n:sp0?sp0.n:0,pr:sp0?sp0.pr:0,pl:sp0?sp0.pl:0,pm:sp0?sp0.pm:0};
  return {[U+'spin']:sp,'users/U/shard':shardBefore-cost}};
const reveal=(sp,own,over={})=>{const o=outcome(sp,sp.seed);const cnt=(own&&own[o.s])||0;
  const ns={seed:sp.seed,pend:sp.pend-1,mode:sp.mode,n:sp.n+1,
    pr:sp.mode===2?sp.pr:(o.rar>=1?0:sp.pr+1),pl:sp.mode===2?sp.pl:(o.rar>=2?0:sp.pl+1),pm:sp.mode===2?sp.pm:(o.rar===3?0:sp.pm+1),...(over.spin||{})};
  return {[U+'spin']:ns,[U+'last']:{s:o.s,rar:o.rar,idx:o.idx,roll:o.roll,ts,n:sp.n,...(over.last||{})},[U+`own/${over.sid!==undefined?over.sid:o.s}`]:cnt+1+(over.extra||0)}};

// ================= UNLOCK PERTAMA (Common, 50 shard) =================
let db=dbWith(100,null);
t('unlock pertama: bayar 50 shard',update(db,pay(null,2,100),'U'),true);
t('unlock pertama: bayar 40 saja (curang)',update(db,{...pay(null,2,100),'users/U/shard':60},'U'),false);
t('unlock pertama: shard tidak berkurang',update(db,{...pay(null,2,100),'users/U/shard':100},'U'),false);
t('spin 150 shard',update(db,pay(null,0,100),'U'),false); // saldo kurang
db=dbWith(400,null);
t('spin 150 shard',update(db,pay(null,0,400),'U'),true);
t('spin 5x 650 shard (saldo kurang)',update(db,pay(null,1,400),'U'),false);
t('spin 150 tapi bayar 100',update(db,{...pay(null,0,400),'users/U/shard':300},'U'),false);
t('spin murah: mode 1 (5x) tapi bayar 150',update(dbWith(900,null),{...pay(null,1,900),'users/U/shard':750},'U'),false);
t('menaikkan shard sendiri',update(db,{'users/U/shard':999999},'U'),false);
t('seed palsu (bukan jam server)',update(db,{...pay(null,0,400),[U+'spin/seed']:5},'U'),false);

// ================= BUKA HASIL =================
const paid=(mode,shard=1000,spExtra={})=>{const sp={seed:T,pend:mode===1?5:1,mode,n:1,pr:0,pl:0,pm:0,...spExtra};return {db:dbWith(shard,{spin:sp}),sp}};
let {db:d1,sp:s1}=paid(0);
t('buka hasil spin (rumus benar)',update(d1,reveal(s1,{}),'U'),true);
const o1=outcome(s1);
t('hasil dipilih sendiri (Akimi Dragon)',update(d1,reveal(s1,{},{last:{s:11,rar:3,idx:0},sid:11}),'U'),false);
t('rarity diubah ke legend',update(d1,reveal(s1,{},{last:{rar:2}}),'U'),false);
t('memberi dino lain dari hasil (sid beda)',update(d1,reveal(s1,{},{sid:(o1.s+1)%12}),'U'),false);
t('dapat 2 dino sekaligus dari 1 spin',update(d1,reveal(s1,{},{extra:1}),'U'),false);
t('tanpa mengurangi pend',update(d1,reveal(s1,{},{spin:{pend:1}}),'U'),false);
t('pity direset palsu',update(paid(0,1000,{pr:5,pl:20,pm:100}).db,reveal(paid(0,1000,{pr:5,pl:20,pm:100}).sp,{},{spin:{pm:0,pl:0,pr:0}}),'U'),o1.rar===3?true:false);
t('buka hasil tanpa bayar (tidak ada pend)',update(dbWith(1000,{spin:{seed:T,pend:0,mode:0,n:3,pr:0,pl:0,pm:0}}),reveal({seed:T,pend:1,mode:0,n:3,pr:0,pl:0,pm:0},{}),'U'),false);
t('menambah dino tanpa spin',update(dbWith(1000,null),{[U+'own/11']:1},'U'),false);
t('menambah dino lagi (duplikat) tanpa spin',update(dbWith(1000,{own:{0:1}}),{[U+'own/0']:5},'U'),false);

t('seed uji: n=1 menghasilkan Common (bukan Mythic kebetulan)',{ok:outcome(s1).rar===0},true);
// ---- pity: hasil dijamin sesuai hitungan ----
{const sp={seed:T,pend:1,mode:0,n:249,pr:3,pl:10,pm:249};const o=outcome(sp);
 t('pity Mythic ke-250 -> Akimi Dragon (rumus)',update(dbWith(1000,{spin:sp}),reveal(sp,{}),'U'),true);
 t('pity Mythic: hasil lain ditolak',update(dbWith(1000,{spin:sp}),reveal(sp,{},{last:{s:0,rar:0,idx:0},sid:0}),'U'),false);
 console.log('      (pity mythic -> rar',o.rar,')');}
{const sp={seed:T,pend:1,mode:0,n:79,pr:4,pl:79,pm:10};const o=outcome(sp);
 t('pity Legend ke-80 menghasilkan rarity >= 2',update(dbWith(1000,{spin:sp}),reveal(sp,{}),'U'),true);
 console.log('      (pity legend -> rar',o.rar,')');if(o.rar<2){fail++;console.log('SALAH: pity legend tidak menjamin legend')}}
{const sp={seed:T,pend:1,mode:0,n:9,pr:9,pl:3,pm:3};const o=outcome(sp);
 t('pity Rare ke-10 menghasilkan rarity >= 1',update(dbWith(1000,{spin:sp}),reveal(sp,{}),'U'),true);if(o.rar<1){fail++;console.log('SALAH: pity rare tidak menjamin rare')}}
{const sp={seed:T,pend:1,mode:2,n:0,pr:0,pl:0,pm:0};const o=outcome(sp);
 t('unlock pertama selalu Common',update(dbWith(50,{spin:sp}),reveal(sp,{}),'U'),true);if(o.rar!==0){fail++;console.log('SALAH: unlock pertama bukan common')}
 t('unlock pertama: coba mengklaim Rare',update(dbWith(50,{spin:sp}),reveal(sp,{},{last:{rar:1,idx:0,s:4},sid:4}),'U'),false);}
// 5x: lima hasil berurutan
{let sp={seed:T,pend:5,mode:1,n:1,pr:0,pl:0,pm:0},own={},ok=true,dbx=dbWith(5,{spin:sp});
 for(let i=0;i<5;i++){const r=update(dbx,reveal(sp,own),'U');if(!r.ok){ok=false;break}dbx=r.db;sp=dbx.dino_game.U.spin;own=dbx.dino_game.U.own||{}}
 t('spin 5x: kelima hasil bisa dibuka berurutan',{ok,why:'gagal di tengah'},true);}

// ================= UNLOCK PERTAMA hanya sekali =================
t('unlock pertama saat sudah punya dino',update(dbWith(500,{own:{0:1},spin:{seed:1,pend:0,mode:0,n:1,pr:1,pl:1,pm:1}}),pay({n:1,pr:1,pl:1,pm:1},2,500),'U'),false);
t('bayar lagi saat hasil belum dibuka',update(dbWith(500,{spin:{seed:T-1000,pend:1,mode:0,n:0,pr:0,pl:0,pm:0}}),pay({n:0,pr:0,pl:0,pm:0},0,500),'U'),false);

// ================= JUAL DUPLIKAT =================
const own2={own:{0:2,4:1,8:2,11:3}};
const sell=(sid,own,shard,price,over={})=>({[U+'sell']:{s:sid,ts},[U+`own/${sid}`]:own[sid]-1,'users/U/shard':shard+price,...over});
t('jual duplikat Common +30',update(dbWith(10,own2),sell(0,own2.own,10,30),'U'),true);
t('jual duplikat Legend +300',update(dbWith(10,own2),sell(8,own2.own,10,300),'U'),true);
t('jual duplikat Mythic +900',update(dbWith(10,own2),sell(11,own2.own,10,900),'U'),true);
t('jual duplikat Common harga 300 (curang)',update(dbWith(10,own2),sell(0,own2.own,10,300),'U'),false);
t('jual dino satu-satunya (tidak boleh)',update(dbWith(10,own2),{[U+'sell']:{s:4,ts},[U+'own/4']:0,'users/U/shard':100},'U'),false);
t('jual tanpa mengurangi jumlah',update(dbWith(10,own2),{[U+'sell']:{s:0,ts},'users/U/shard':40},'U'),false);
t('menambah shard tanpa menjual',update(dbWith(10,own2),{'users/U/shard':5000},'U'),false);
t('menjual 2 sekaligus',update(dbWith(10,own2),{[U+'sell']:{s:11,ts},[U+'own/11']:1,'users/U/shard':10+1800},'U'),false);

// ================= PILIH DINO =================
t('pakai dino yang dimiliki',update(dbWith(10,own2),{[U+'selected']:4},'U'),true);
t('pakai dino yang belum dimiliki',update(dbWith(10,own2),{[U+'selected']:5},'U'),false);
t('kembali ke avatar netral',update(dbWith(10,own2),{[U+'selected']:-1},'U'),true);
t('pakai dino orang lain (uid lain)',update(dbWith(10,own2),{'dino_game/V/selected':4},'V'),false);

// ================= MAIN: batas harian, skor, hadiah =================
const run=(over={})=>({[U+'run']:{t:ts,sel:-1,...(over.run||{})},[U+'daily']:{d:DAY,n:1,t:ts,...(over.daily||{})}});
t('mulai game pertama hari ini',update(dbWith(0,null),run(),'U'),true);
t('mulai game tanpa mencatat batas harian',update(dbWith(0,null),{[U+'run']:{t:ts,sel:-1}},'U'),false);
t('mulai game dengan hitungan tidak naik',update(dbWith(0,{daily:{d:DAY,n:4,t:5}}),run({daily:{n:4}}),'U'),false);
t('mulai game ke-5 (n 4 -> 5)',update(dbWith(0,{daily:{d:DAY,n:4,t:5}}),run({daily:{n:5}}),'U'),true);
t('mulai game ke-10',update(dbWith(0,{daily:{d:DAY,n:9,t:5}}),run({daily:{n:10}}),'U'),true);
t('mulai game ke-11 (melewati 10)',update(dbWith(0,{daily:{d:DAY,n:10,t:5}}),run({daily:{n:11}}),'U'),false);
t('reset hitungan harian sendiri (n=1 padahal sudah 10)',update(dbWith(0,{daily:{d:DAY,n:10,t:5}}),run({daily:{n:1}}),'U'),false);
t('tanggal hari kemarin untuk mereset',update(dbWith(0,{daily:{d:DAY,n:10,t:5}}),run({daily:{d:DAY-1,n:1}}),'U'),false);
t('hari baru: hitungan kembali 1',update(dbWith(0,{daily:{d:DAY-1,n:10,t:5}}),run(),'U'),true);
t('pakai dino yang tidak dimiliki saat mulai',update(dbWith(0,{own:{0:1}}),run({run:{sel:11}}),'U'),false);
t('pakai dino milik saat mulai',update(dbWith(0,{own:{0:1}}),run({run:{sel:0}}),'U'),true);

const started=(sel=-1,tStart=T-60000,extra={})=>dbWith(100,{run:{t:tStart,sel},daily:{d:DAY,n:3,t:tStart},own:{0:1,4:1,8:1,11:1},best:900,total:3000,...extra});
const fin=(sc,e,over={})=>({[U+'run/sc']:sc,[U+'run/e']:e,[U+'best']:over.best===undefined?sc:over.best,[U+'total']:over.total===undefined?3000+sc:over.total,'users/U/shard':100+e,...(over.patch||{})});
t('selesai: skor 1250 = +1250 shard (1:1, di bawah cap)',update(started(-1),fin(1250,1250,{best:1250}),'U'),true);
t('selesai: skor 1250 tapi klaim 1251 shard',update(started(-1),fin(1250,1251),'U'),false);
t('selesai: skor 1250 tapi klaim cuma 12 (tidak sesuai rumus)',update(started(-1),fin(1250,12),'U'),false);
t('selesai: skor 480 (tidak memecahkan best) = +480',update(started(-1),(()=>{const f=fin(480,480,{total:3480});delete f[U+'best'];return f})(),'U'),true);
const long=(sel)=>started(sel,T-400000);  // 400 dtk -> batas skor 10.060
t('selesai: avatar netral skor 2000 -> dipotong cap 1500',update(long(-1),fin(2000,1500,{best:2000,total:5000}),'U'),true);
t('selesai: avatar netral skor 2000 klaim 2000 (di atas cap)',update(long(-1),fin(2000,2000,{best:2000,total:5000}),'U'),false);
t('selesai: Common skor 3000 -> cap 2500',update(long(0),fin(3000,2500,{best:3000,total:6000}),'U'),true);
t('selesai: Rare skor 4000 -> cap 3500',update(long(4),fin(4000,3500,{best:4000,total:7000}),'U'),true);
t('selesai: Legend skor 6000 -> cap 5000',update(long(8),fin(6000,5000,{best:6000,total:9000}),'U'),true);
t('selesai: Mythic skor 9000 -> cap 7500',update(long(11),fin(9000,7500,{best:9000,total:12000}),'U'),true);
t('selesai: Mythic klaim di atas cap (7501)',update(long(11),fin(9000,7501,{best:9000,total:12000}),'U'),false);
t('selesai: Common klaim cap Mythic',update(long(0),fin(9000,7500,{best:9000,total:12000}),'U'),false);
t('skor tidak masuk akal (999999 dalam 60 dtk)',update(started(-1),fin(999999,1500),'U'),false);
t('skor melebihi laju waktu (60 dtk -> maks 1560)',update(started(-1,T-60000),fin(1600,1500,{best:1600,total:4600}),'U'),false);
t('skor wajar untuk 60 dtk (1300) = +1300 shard',update(started(-1,T-60000),fin(1300,1300,{best:1300,total:4300}),'U'),true);
t('best diubah bebas (tanpa skor)',update(started(-1),{[U+'best']:99999},'U'),false);
t('total diubah bebas',update(started(-1),{[U+'total']:99999},'U'),false);
t('hadiah shard tanpa menyelesaikan game',update(started(-1),{'users/U/shard':500},'U'),false);
t('klaim hadiah dua kali (run sudah selesai)',update(started(-1,T-60000,{run:{t:T-60000,sel:-1,sc:1000,e:1000}}),fin(1000,1000,{best:1000,total:4000}),'U'),false);
t('ubah skor yang sudah tersimpan',update(started(-1,T-60000,{run:{t:T-60000,sel:-1,sc:100,e:100}}),{[U+'run/sc']:500},'U'),false);
t('ganti dino di tengah game demi cap lebih besar',update(started(0),{[U+'run/sel']:11},'U'),false);
t('hadiah shard lebih dari e',update(started(-1),fin(1250,1250,{best:1250,patch:{'users/U/shard':999999}}),'U'),false);
t('orang lain menulis data dino kita',update(started(-1),{'dino_game/U/best':5000},'V'),false);

console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
process.exit(fail?1:0);
