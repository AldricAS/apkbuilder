// Tes rules NOBAR (nonton bareng global). Jalankan: node rules-tests/t9.js
const {update,T}=require('./sim.js');
const ts={__ts:1};
const DAY=86400000;
const clone=o=>JSON.parse(JSON.stringify(o));
const u=(uid,userId,extra={})=>({uid,userId,email:uid+'@x',displayName:'Nama'+uid,role:'user',verified:false,level:3,xp:0,totalWatchMinutes:0,createdAt:1,xpAt:1,shard:0,...extra});
const users={
  USER:u('USER',1), PREM:u('PREM',2,{premiumUntil:T+5*DAY}), EXP:u('EXP',3,{premiumUntil:T-DAY}),
  BETA:u('BETA',4,{role:'beta'}), DEV:u('DEV',5,{role:'developer'}), MOD:u('MOD',6,{role:'moderator'}),
  M1:u('M1',11), M2:u('M2',12), M3:u('M3',13), RAC:u('RAC',14),
};
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};

const room=(uid,extra={})=>{const p=users[uid];return {ownerUid:uid,ownerUserId:p.userId,ownerName:p.displayName,ownerRole:p.role,ownerVerified:false,
  ownerPremium:!!(p.premiumUntil&&p.premiumUntil>T),animeId:'a1',animeTitle:'Judul Anime',ep:'e1',epNo:1,playing:false,pos:0,at:ts,createdAt:ts,online:true,...extra}};
const base={users};

// ---------- siapa yang boleh MEMBUAT room ----------
t('user biasa buat room',update(base,{'nobarRooms/USER':room('USER')},'USER'),false);
t('premium kedaluwarsa buat room',update(base,{'nobarRooms/EXP':room('EXP')},'EXP'),false);
t('premium aktif buat room',update(base,{'nobarRooms/PREM':room('PREM')},'PREM'),true);
t('role beta buat room',update(base,{'nobarRooms/BETA':room('BETA')},'BETA'),true);
t('developer buat room',update(base,{'nobarRooms/DEV':room('DEV')},'DEV'),true);
t('user biasa mengaku premium (ownerPremium=true)',update(base,{'nobarRooms/USER':room('USER',{ownerPremium:true})},'USER'),false);
t('user biasa mengaku role developer di room',update(base,{'nobarRooms/USER':room('USER',{ownerRole:'developer'})},'USER'),false);
t('buat room atas nama orang lain',update(base,{'nobarRooms/PREM':room('PREM')},'USER'),false);
t('premium buat room atas nama BETA',update(base,{'nobarRooms/BETA':room('BETA')},'PREM'),false);
t('tanpa login buat room',update(base,{'nobarRooms/PREM':room('PREM')},null),false);
t('room dengan userId palsu',update(base,{'nobarRooms/PREM':room('PREM',{ownerUserId:1})},'PREM'),false);
t('room dengan nama palsu',update(base,{'nobarRooms/PREM':room('PREM',{ownerName:'Admin Resmi'})},'PREM'),false);
t('room dengan field asing',update(base,{'nobarRooms/PREM':room('PREM',{hack:1})},'PREM'),false);
t('room dengan createdAt dimundurkan',update(base,{'nobarRooms/PREM':room('PREM',{createdAt:5})},'PREM'),false);
t('room dengan at palsu',update(base,{'nobarRooms/PREM':room('PREM',{at:5})},'PREM'),false);
t('poster bukan https',update(base,{'nobarRooms/PREM':room('PREM',{poster:'http://x.com/a.jpg'})},'PREM'),false);
t('poster https',update(base,{'nobarRooms/PREM':room('PREM',{poster:'https://x.com/a.jpg'})},'PREM'),true);
t('judul kosong',update(base,{'nobarRooms/PREM':room('PREM',{animeTitle:''})},'PREM'),false);
t('pos negatif',update(base,{'nobarRooms/PREM':room('PREM',{pos:-3})},'PREM'),false);

// ---------- hanya owner yang mengatur ----------
const live=clone(base);live.nobarRooms={PREM:room('PREM',{at:T-10000,createdAt:T-20000})};
t('owner play (pos, playing)',update(live,{'nobarRooms/PREM/playing':true,'nobarRooms/PREM/pos':12.5,'nobarRooms/PREM/at':ts},'PREM'),true);
t('owner ganti episode',update(live,{'nobarRooms/PREM/ep':'e2','nobarRooms/PREM/epNo':2,'nobarRooms/PREM/pos':0,'nobarRooms/PREM/at':ts},'PREM'),true);
t('owner ganti anime',update(live,{'nobarRooms/PREM/animeId':'a2','nobarRooms/PREM/animeTitle':'Baru','nobarRooms/PREM/ep':'z1','nobarRooms/PREM/epNo':1,'nobarRooms/PREM/at':ts},'PREM'),true);
t('member play/pause room orang',update(live,{'nobarRooms/PREM/playing':true,'nobarRooms/PREM/at':ts},'M1'),false);
t('member seek room orang',update(live,{'nobarRooms/PREM/pos':99,'nobarRooms/PREM/at':ts},'M1'),false);
t('member ganti episode',update(live,{'nobarRooms/PREM/ep':'e9','nobarRooms/PREM/at':ts},'M1'),false);
t('member ganti anime',update(live,{'nobarRooms/PREM/animeId':'x','nobarRooms/PREM/at':ts},'M1'),false);
t('member hentikan room orang',update(live,{'nobarRooms/PREM':null},'M1'),false);
t('owner hentikan room sendiri',update(live,{'nobarRooms/PREM':null},'PREM'),true);
t('moderator hentikan room',update(live,{'nobarRooms/PREM':null},'MOD'),true);
t('owner ganti ownerRole di room berjalan',update(live,{'nobarRooms/PREM/ownerRole':'developer','nobarRooms/PREM/at':ts},'PREM'),false);
t('owner ganti ownerUserId di room berjalan',update(live,{'nobarRooms/PREM/ownerUserId':999,'nobarRooms/PREM/at':ts},'PREM'),false);
t('owner ubah createdAt',update(live,{'nobarRooms/PREM/createdAt':ts,'nobarRooms/PREM/at':ts},'PREM'),false);
const fast=clone(base);fast.nobarRooms={PREM:room('PREM',{at:T-100,createdAt:T-20000})};
t('tulis status terlalu rapat (<250 ms)',update(fast,{'nobarRooms/PREM/playing':true,'nobarRooms/PREM/at':ts},'PREM'),false);
t('tulis status dengan at lama (replay)',update(live,{'nobarRooms/PREM/playing':true,'nobarRooms/PREM/at':T-5000},'PREM'),false);
// premium habis di tengah sesi: room berjalan tetap bisa diatur owner, tapi tidak bisa membuat room baru
const lapsed=clone(base);lapsed.users.PREM.premiumUntil=T-1000;lapsed.nobarRooms={PREM:room('PREM',{at:T-10000,createdAt:T-20000})};
t('premium habis: room berjalan masih bisa diatur',update(lapsed,{'nobarRooms/PREM/playing':true,'nobarRooms/PREM/at':ts},'PREM'),true);
const lapsed2=clone(lapsed);delete lapsed2.nobarRooms;
t('premium habis: tidak bisa buat room baru',update(lapsed2,{'nobarRooms/PREM':room('PREM',{ownerPremium:false})},'PREM'),false);

// ---------- room mati (owner terputus > 3 menit) ----------
const dead=clone(base);dead.nobarRooms={PREM:room('PREM',{online:false,at:T-200000,createdAt:T-300000})};
t('siapa pun bersihkan room yang owner-nya putus >3 menit',update(dead,{'nobarRooms/PREM':null},'M1'),true);
const fresh=clone(base);fresh.nobarRooms={PREM:room('PREM',{online:false,at:T-60000,createdAt:T-300000})};
t('room baru putus 1 menit tidak boleh dihapus orang lain',update(fresh,{'nobarRooms/PREM':null},'M1'),false);
const alive=clone(base);alive.nobarRooms={PREM:room('PREM',{online:true,at:T-900000,createdAt:T-999000})};
t('room online tidak boleh dihapus orang lain walau lama',update(alive,{'nobarRooms/PREM':null},'M1'),false);

// ---------- join & batas 20 orang ----------
const m=(uid,slot,extra={})=>({uid,userId:users[uid].userId,name:users[uid].displayName,role:users[uid].role,verified:false,level:3,slot,joinedAt:ts,...extra});
const open=clone(base);open.nobarRooms={PREM:room('PREM',{at:T-10000,createdAt:T-20000})};
const join=(uid,slot,owner='PREM',over={})=>({[`nobarSlots/${owner}/${slot}`]:uid,[`nobarMembers/${owner}/${uid}`]:m(uid,slot,over)});
t('user biasa boleh join (hanya buat yang tidak bisa)',update(open,join('USER',1),'USER'),true);
t('join slot 19',update(open,join('M1',19),'M1'),true);
t('join slot 20 (melebihi batas)',update(open,join('M1',20),'M1'),false);
t('join slot 0',update(open,join('M1',0),'M1'),false);
t('join slot 1.5',update(open,join('M1',1.5),'M1'),false);
t('owner join room sendiri sebagai anggota',update(open,join('PREM',1),'PREM'),false);
t('join tanpa slot (lolos batas)',update(open,{'nobarMembers/PREM/M1':m('M1',1)},'M1'),false);
t('ambil slot tanpa data anggota',update(open,{'nobarSlots/PREM/1':'M1'},'M1'),false);
t('join atas nama orang lain',update(open,join('M2',2),'M1'),false);
t('join dengan userId palsu',update(open,join('M1',2,'PREM',{userId:999}),'M1'),false);
t('join dengan role palsu',update(open,join('M1',2,'PREM',{role:'developer'}),'M1'),false);
t('join dengan nama palsu',update(open,join('M1',2,'PREM',{name:'Owner'}),'M1'),false);
t('join room yang tidak ada',update(open,join('M1',2,'BETA'),'M1'),false);
t('join tanpa login',update(open,join('M1',2),null),false);
const full=clone(open);full.nobarSlots={PREM:{}};for(let i=1;i<=19;i++){const id='X'+i;full.nobarSlots.PREM[i]=id;}
t('slot sudah terisi orang lain (rebutan)',update(full,join('M1',5),'M1'),false);
const withM1=clone(open);Object.assign(withM1,{nobarSlots:{PREM:{3:'M1'}},nobarMembers:{PREM:{M1:m('M1',3)}}});
t('slot lain bebas ambil slot kosong',update(withM1,join('M2',4),'M2'),true);
t('dua slot untuk satu orang (slot 3 sudah dipakai M2?)',update(withM1,join('M2',3),'M2'),false);
t('keluar sendiri (hapus anggota + slot)',update(withM1,{'nobarMembers/PREM/M1':null,'nobarSlots/PREM/3':null},'M1'),true);
t('orang lain hapus anggota',update(withM1,{'nobarMembers/PREM/M1':null,'nobarSlots/PREM/3':null},'M2'),false);
t('orang lain mengosongkan slot orang',update(withM1,{'nobarSlots/PREM/3':null},'M2'),false);

// ---------- kick ----------
const kickPatch=(target,slot)=>({[`nobarKicks/PREM/${target}`]:{ts},[`nobarMembers/PREM/${target}`]:null,[`nobarSlots/PREM/${slot}`]:null});
t('owner kick anggota',update(withM1,kickPatch('M1',3),'PREM'),true);
t('anggota kick anggota lain',update(withM1,kickPatch('M1',3),'M2'),false);
t('anggota kick owner',update(withM1,{'nobarKicks/PREM/PREM':{ts}},'M1'),false);
t('owner kick orang yang bukan anggota (pre-ban)',update(withM1,{'nobarKicks/PREM/M3':{ts}},'PREM'),false);
t('owner kick dirinya sendiri',update(withM1,{'nobarKicks/PREM/PREM':{ts}},'PREM'),false);
t('anggota menghapus kick atas dirinya',update(Object.assign(clone(withM1),{nobarKicks:{PREM:{RAC:{ts:1}}}}),{'nobarKicks/PREM/RAC':null},'RAC'),false);
const kicked=clone(open);kicked.nobarKicks={PREM:{RAC:{ts:1}}};
t('yang di-kick join lagi',update(kicked,join('RAC',2),'RAC'),false);
t('yang di-kick join lagi di slot lain',update(kicked,join('RAC',9),'RAC'),false);
t('yang di-kick tetap bisa join room owner lain',update(Object.assign(clone(kicked),{nobarRooms:{PREM:room('PREM'),BETA:room('BETA')}}),join('RAC',2,'BETA'),'RAC'),true);
t('yang di-kick mengirim chat',update(kicked,{'nobarChat/PREM/c1':{uid:'RAC',userId:14,name:'NamaRAC',role:'user',level:3,text:'halo',ts},'nobarRate/PREM/RAC':ts},'RAC'),false);
t('hapus daftar kick (owner)',update(kicked,{'nobarKicks/PREM/RAC':null},'PREM'),true);

// ---------- komentar ----------
const chat=(uid,over={})=>({uid,userId:users[uid].userId,name:users[uid].displayName,role:users[uid].role,verified:false,level:3,text:'halo',ts,...over});
const withChat=clone(withM1);withChat.nobarChat={PREM:{c1:chat('M1',{ts:T-5000})}};
t('anggota kirim komentar',update(withM1,{'nobarChat/PREM/c1':chat('M1'),'nobarRate/PREM/M1':ts},'M1'),true);
t('owner kirim komentar',update(withM1,{'nobarChat/PREM/c1':chat('PREM'),'nobarRate/PREM/PREM':ts},'PREM'),true);
t('orang luar kirim komentar',update(withM1,{'nobarChat/PREM/c1':chat('M2'),'nobarRate/PREM/M2':ts},'M2'),false);
t('komentar tanpa penanda jeda',update(withM1,{'nobarChat/PREM/c1':chat('M1')},'M1'),false);
t('komentar atas nama orang lain',update(withM1,{'nobarChat/PREM/c1':chat('PREM'),'nobarRate/PREM/M1':ts},'M1'),false);
t('komentar role palsu',update(withM1,{'nobarChat/PREM/c1':chat('M1',{role:'developer'}),'nobarRate/PREM/M1':ts},'M1'),false);
t('komentar 201 huruf',update(withM1,{'nobarChat/PREM/c1':chat('M1',{text:'a'.repeat(201)}),'nobarRate/PREM/M1':ts},'M1'),false);
t('komentar 200 huruf',update(withM1,{'nobarChat/PREM/c1':chat('M1',{text:'a'.repeat(200)}),'nobarRate/PREM/M1':ts},'M1'),true);
t('komentar ts palsu',update(withM1,{'nobarChat/PREM/c1':chat('M1',{ts:5}),'nobarRate/PREM/M1':ts},'M1'),false);
const rapid=clone(withM1);rapid.nobarRate={PREM:{M1:T-500}};
t('spam komentar (<1,2 detik)',update(rapid,{'nobarChat/PREM/c2':chat('M1'),'nobarRate/PREM/M1':ts},'M1'),false);
const slow=clone(withM1);slow.nobarRate={PREM:{M1:T-3000}};
t('komentar setelah jeda cukup',update(slow,{'nobarChat/PREM/c2':chat('M1'),'nobarRate/PREM/M1':ts},'M1'),true);
t('owner hapus komentar rasis',update(withChat,{'nobarChat/PREM/c1':null},'PREM'),true);
t('moderator hapus komentar',update(withChat,{'nobarChat/PREM/c1':null},'MOD'),true);
t('anggota hapus komentar sendiri',update(withChat,{'nobarChat/PREM/c1':null},'M1'),true);
t('anggota hapus komentar orang lain',update(withChat,{'nobarChat/PREM/c1':null},'M2'),false);
t('mengedit komentar orang',update(withChat,{'nobarChat/PREM/c1/text':'diubah'},'M2'),false);

// ---------- pembersihan ----------
const loaded=clone(withChat);loaded.nobarRate={PREM:{M1:T-9000}};
t('owner bersihkan semua data room',update(loaded,{'nobarRooms/PREM':null},'PREM'),true);
const gone=clone(loaded);delete gone.nobarRooms;
t('data yatim: orang lain hapus slot (room sudah tidak ada)',update(gone,{'nobarSlots/PREM':null,'nobarMembers/PREM':null,'nobarChat/PREM':null,'nobarRate/PREM':null},'M2'),true);
t('data room hidup: orang lain tidak bisa hapus slot',update(loaded,{'nobarSlots/PREM':null},'M2'),false);
t('data room hidup: orang lain tidak bisa hapus komentar',update(loaded,{'nobarChat/PREM':null},'M2'),false);
t('owner hapus semua slot sekaligus',update(Object.assign(clone(loaded),{nobarRooms:undefined}),{'nobarSlots/PREM':null},'PREM'),true);

console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
process.exit(fail?1:0);
