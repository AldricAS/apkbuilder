const {update}=require('./sim.js');
const ts={__ts:1};const clone=o=>JSON.parse(JSON.stringify(o));
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};
const users={A:{uid:'A',userId:1,displayName:'Ann',role:'user',level:1,shard:0},B:{uid:'B',userId:2,displayName:'Bob',role:'user',level:2,shard:0},M:{uid:'M',userId:3,displayName:'Mod',role:'moderator',level:1,shard:0}};
// ---------- CHAT ----------
const msg=(u,seq,text='halo')=>({uid:u,userId:users[u].userId,name:users[u].displayName,role:'user',level:users[u].level,text,ts,seq});
const chat=(head,legacyCount=0)=>{const g={};for(let s=Math.max(1,head-39);s<=head;s++)g['m'+s]={...msg('B',s),ts:s};for(let i=0;i<legacyCount;i++){const x=msg('B',1);delete x.seq;x.ts=-100+i;g['old'+i]=x}return {users,globalChat:g,meta:head?{chatHead:{seq:head,key:'m'+head,uid:'B'}}:{}}};
const send=(db,u,key,seq,over={})=>update(db,{['globalChat/'+key]:{...msg(u,seq),...over},'meta/chatHead':{seq,key,uid:u}},u);
let db=chat(40);
t('kirim pesan normal (seq 41)',send(db,'A','n1',41),true);
t('kirim pesan pertama kali (chat kosong, seq 1)',send(chat(0),'A','n1',1),true);
t('seq loncat (45)',send(db,'A','n1',45),false);
t('seq mundur/duplikat (40)',send(db,'A','n1',40),false);
t('pesan tanpa naikkan chatHead',update(db,{'globalChat/n1':msg('A',41)},'A'),false);
t('chatHead naik tanpa pesan (spam untuk hapus orang)',update(db,{'meta/chatHead':{seq:41,key:'x',uid:'A'}},'A'),false);
t('chatHead atas nama orang lain',update(db,{'globalChat/n1':msg('B',41),'meta/chatHead':{seq:41,key:'n1',uid:'B'}},'A'),false);
t('seq di pesan tidak cocok dgn chatHead',update(db,{'globalChat/n1':msg('A',42),'meta/chatHead':{seq:41,key:'n1',uid:'A'}},'A'),false);
t('chatHead menunjuk pesan yang sudah ada (pakai ulang)',update(db,{'meta/chatHead':{seq:41,key:'m40',uid:'A'}},'A'),false);
// hapus
t('hapus pesan ke-31 terbaru (seq 10 saat head 40)',update(db,{'globalChat/m10':null},'A'),true);
t('hapus pesan dalam 30 terbaru (seq 11 saat head 40)',update(db,{'globalChat/m11':null},'A'),false);
t('hapus pesan terbaru',update(db,{'globalChat/m40':null},'A'),false);
t('hapus batch beberapa pesan lama',update(db,{'globalChat/m1':null,'globalChat/m5':null,'globalChat/m10':null},'A'),true);
t('batch campur (satu masih baru)',update(db,{'globalChat/m1':null,'globalChat/m20':null},'A'),false);
t('hapus pesan sendiri yang baru (tetap boleh)',update(db,{'globalChat/m40':null},'B'),true);
t('moderator hapus pesan baru (tetap boleh)',update(db,{'globalChat/m39':null},'M'),true);
const lg=chat(40,3);
t('hapus pesan lama tanpa seq saat head>=30',update(lg,{'globalChat/old0':null},'A'),true);
const lg2=chat(20,3);
t('hapus pesan lama tanpa seq saat head<30',update(lg2,{'globalChat/old0':null},'A'),false);
t('edit isi pesan',update(db,{'globalChat/m40/text':'ganti'},'B'),false);
// ---------- TIER ----------
const mkClan=(over={})=>({users:{L:{uid:'L',role:'user',shard:0},M:{uid:'M',role:'user',shard:0},D:{uid:'D',role:'developer',shard:0}},
 clans:{c1:{name:'Akimi',nameLower:'akimi',tag:'AKM',color:0,emblem:0,leaderUid:'L',xp:5000,xpBalance:9000,slots:30,members:1,createdAt:1,tier:1,...over}},
 clanMembers:{c1:{L:{role:'leader',joinedAt:1,donated:0}}},userClan:{L:'c1'},clanTags:{AKM:'c1'}});
const up=(db,tier,bal,u='L',extra={})=>update(db,{'clans/c1/tier':tier,'clans/c1/xpBalance':bal,...extra},u);
let c=mkClan();
t('tier 1->2 bayar 3000',up(c,2,6000),true);
t('tier 1->3 langsung (loncat)',up(c,3,1000),false);
t('tier 1->2 bayar 1000 (curang)',up(c,2,8000),false);
t('tier 1->2 bayar 4000 (kelebihan)',up(c,2,5000),false);
t('tier 1->2 oleh member biasa',up(c,2,6000,'M'),false);
t('tier 1->2 oleh developer (bukan leader)',up(c,2,6000,'D'),false);
t('tier naik tanpa potong XP',update(c,{'clans/c1/tier':2},'L'),false);
t('potong XP 3000 tanpa naik tier',update(c,{'clans/c1/xpBalance':6000},'L'),false);
t('tier 1->2 sambil menambah xp',up(c,2,6000,'L',{'clans/c1/xp':99999}),false);
t('tier 1->2 sambil tambah slot',up(c,2,6000,'L',{'clans/c1/slots':35}),false);
t('tier turun 1->0',up(c,0,9000),false);
const c2=mkClan({tier:2});
t('tier 2->3 bayar 8000',up(c2,3,1000),true);
t('tier 2->3 bayar 3000',up(c2,3,6000),false);
t('tier 2->1 (turun)',up(c2,1,9000),false);
t('tier 2->2 bayar saja (tanpa naik)',update(c2,{'clans/c1/xpBalance':1000},'L'),false);
const c3=mkClan({tier:3});
t('tier 3->4',up(c3,4,1000),false);
t('tier 3 ->3 bayar 8000',update(c3,{'clans/c1/xpBalance':1000},'L'),false);
const legacy=mkClan();delete legacy.clans.c1.tier;
t('clan lama tanpa field tier -> tier 2 (3000)',up(legacy,2,6000),true);
t('clan lama tanpa field tier -> tier 3 (loncat)',up(legacy,3,1000),false);
// regresi: beli slot & donasi tetap jalan
t('beli slot (+5, -1000 XP)',update(c,{'clans/c1/slots':35,'clans/c1/xpBalance':8000},'L'),true);
t('slot -1000 sambil naik tier diam-diam',update(c,{'clans/c1/slots':35,'clans/c1/xpBalance':8000,'clans/c1/tier':2},'L'),false);
// buat clan: tier harus 1
const nb={users:{N:{uid:'N',role:'user',shard:9999}},clans:{},clanTags:{}};
const nc=(tier)=>({'clans/c9':{name:'Baru',nameLower:'baru',tag:'NEW',color:0,tier,emblem:2,leaderUid:'N',xp:0,xpBalance:0,slots:30,members:1,createdAt:ts},'clanMembers/c9/N':{role:'leader',joinedAt:ts,donated:0},'userClan/N':'c9','clanTags/NEW':'c9','users/N/shard':9999-3500});
t('buat clan tier 1',update(nb,nc(1),'N'),true);
t('buat clan langsung tier 3',update(nb,nc(3),'N'),false);
console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
