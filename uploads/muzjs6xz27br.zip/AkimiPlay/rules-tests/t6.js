// Tes rules app_config (force update). Jalankan: node t6.js
const {update}=require('./sim.js');
const clone=o=>JSON.parse(JSON.stringify(o));
const base={users:{U:{uid:'U',role:'user'},A:{uid:'A',role:'admin'},M:{uid:'M',role:'moderator'},D:{uid:'D',role:'developer'}}};
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};
const cfg={latestVersion:'1.0.1',minimumVersion:'1.0.1',updateUrl:'https://contoh.com/AkimiPlay-1.0.1.apk',updateMessage:'Versi terbaru AkimiPlay diperlukan.',enabled:true};
// ----- user biasa tidak boleh menulis apa pun di app_config (login saja TIDAK cukup) -----
t('user buat app_config',update(base,{'app_config':cfg},'U'),false);
t('user ubah minimumVersion',update(base,{'app_config/minimumVersion':'9.9.9'},'U'),false);
t('user ubah latestVersion',update(base,{'app_config/latestVersion':'9.9.9'},'U'),false);
t('user ubah updateUrl',update(base,{'app_config/updateUrl':'https://evil.com/a.apk'},'U'),false);
t('user ubah updateMessage',update(base,{'app_config/updateMessage':'x'},'U'),false);
t('user ubah enabled',update(base,{'app_config/enabled':false},'U'),false);
t('moderator ubah app_config',update(base,{'app_config':cfg},'M'),false);
t('admin ubah app_config',update(base,{'app_config':cfg},'A'),false);
t('tanpa login ubah app_config',update(base,{'app_config':cfg},null),false);
t('user hapus app_config',update(Object.assign(clone(base),{app_config:cfg}),{'app_config':null},'U'),false);
t('user angkat diri jadi developer lalu tulis',update(base,{'users/U/role':'developer','app_config':cfg},'U'),false);
// ----- developer -----
t('developer tulis config valid',update(base,{'app_config':cfg},'D'),true);
t('developer min 1.0.10',update(base,{'app_config':{...cfg,minimumVersion:'1.0.10'}},'D'),true);
t('developer updateUrl kosong',update(base,{'app_config':{...cfg,updateUrl:''}},'D'),true);
t('developer tanpa updateMessage',update(base,{'app_config':{latestVersion:'1.0.1',minimumVersion:'1.0.1',updateUrl:'https://a.com/x.apk',enabled:false}},'D'),true);
// ----- validasi format -----
t('versi "abc"',update(base,{'app_config':{...cfg,minimumVersion:'abc'}},'D'),false);
t('versi "1.0.x"',update(base,{'app_config':{...cfg,latestVersion:'1.0.x'}},'D'),false);
t('versi "1..0"',update(base,{'app_config':{...cfg,latestVersion:'1..0'}},'D'),false);
t('versi angka (bukan string)',update(base,{'app_config':{...cfg,minimumVersion:101}},'D'),false);
t('updateUrl http (bukan https)',update(base,{'app_config':{...cfg,updateUrl:'http://a.com/x.apk'}},'D'),false);
t('updateUrl javascript:',update(base,{'app_config':{...cfg,updateUrl:'javascript:alert(1)'}},'D'),false);
t('updateUrl > 500 karakter',update(base,{'app_config':{...cfg,updateUrl:'https://a.com/'+'a'.repeat(500)}},'D'),false);
t('enabled bukan boolean',update(base,{'app_config':{...cfg,enabled:'true'}},'D'),false);
t('updateMessage > 200',update(base,{'app_config':{...cfg,updateMessage:'x'.repeat(201)}},'D'),false);
t('field asing',update(base,{'app_config':{...cfg,extra:1}},'D'),false);
t('field wajib hilang (enabled)',update(base,{'app_config':{latestVersion:'1.0.1',minimumVersion:'1.0.1',updateUrl:'https://a.com/x.apk'}},'D'),false);
process.exit(fail?1:0);
