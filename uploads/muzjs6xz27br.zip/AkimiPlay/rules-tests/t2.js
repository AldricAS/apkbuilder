const {update}=require('./sim.js');
const ts={__ts:1};
const clone=o=>JSON.parse(JSON.stringify(o));
const base={
 users:{L:{uid:'L',role:'user',shard:10000,clanTag:'AKM'},M:{uid:'M',role:'user',shard:50,clanTag:'AKM'},X:{uid:'X',role:'user',shard:9000},D:{uid:'D',role:'developer',shard:0},N:{uid:'N',role:'user',shard:9999}},
 clans:{c1:{name:'Akimi',nameLower:'akimi',tag:'AKM',color:0,emblem:0,leaderUid:'L',xp:0,xpBalance:0,slots:30,members:2,createdAt:1},
        c2:{name:'Lain',nameLower:'lain',tag:'LAI',color:0,emblem:1,leaderUid:'X',xp:0,xpBalance:0,slots:30,members:1,createdAt:1}},
 clanMembers:{c1:{L:{role:'leader',joinedAt:1,donated:0},M:{role:'member',joinedAt:2,donated:0}},c2:{X:{role:'leader',joinedAt:1,donated:0}}},
 userClan:{L:'c1',M:'c1',X:'c2'},userClanReq:{N:'c1',Q:'c2'},clanRequests:{c1:{N:1},c2:{Q:1}},
 clanTags:{AKM:'c1',LAI:'c2'},clanColors:{c1:{14:true,5:true,13:true}},clanColorOp:{c1:{n:1,ts:1}}};
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};
// ----- warna -----
t('equip Legend (14) oleh leader',update(base,{'clans/c1/color':14},'L'),true);
t('equip Gold (13)',update(base,{'clans/c1/color':13},'L'),true);
t('equip warna belum dimiliki (3)',update(base,{'clans/c1/color':3},'L'),false);
t('equip 15 (di luar daftar)',update(base,{'clans/c1/color':15},'L'),false);
t('equip oleh member biasa',update(base,{'clans/c1/color':14},'M'),false);
t('equip warna clan LAIN',update(base,{'clans/c2/color':0},'L'),false);
t('equip Legend oleh developer (bukan leader)',update(base,{'clans/c1/color':14},'D'),false);
// ----- buat clan -----
const nb=clone(base);delete nb.userClan.N;delete nb.userClanReq.N;
const newClan={name:'Baru',nameLower:'baru',tag:'NEW',color:0,tier:1,emblem:2,leaderUid:'N',xp:0,xpBalance:0,slots:30,members:1,createdAt:ts};
const mk=(shard,over={})=>({'clans/c3':{...newClan,...over},'clanMembers/c3/N':{role:'leader',joinedAt:ts,donated:0},'userClan/N':'c3','clanTags/NEW':'c3','users/N/shard':shard});
t('buat clan bayar 3500',update(nb,mk(9999-3500),'N'),true);
t('buat clan bayar 1000 (curang)',update(nb,mk(9999-1000),'N'),false);
t('buat clan gratis',update(nb,mk(9999),'N'),false);
t('buat clan dengan warna Legend',update(nb,mk(9999-3500,{color:14}),'N'),false);
// ----- spin (dibayar XP clan / xpBalance, bukan shard) -----
const rich=clone(base);rich.clans.c1.xp=5000;rich.clans.c1.xpBalance=5000;
const sp=(bal,n,extra={})=>({'clans/c1/xpBalance':bal,'clanColorOp/c1':{n,ts},'clanColors/c1/9':true,...extra});
t('spin 1x 250 XP clan',update(rich,sp(4750,1),'L'),true);
t('spin 5x 1125 XP clan',update(rich,sp(3875,5,{'clanColors/c1/14':true}),'L'),true);
t('spin 5x bayar 1250 (lebih)',update(rich,sp(3750,5),'L'),false);
t('spin 5x bayar 1000 (kurang)',update(rich,sp(4000,5),'L'),false);
t('tulis warna + clanColorOp tanpa bayar XP',update(rich,{'clanColorOp/c1':{n:1,ts},'clanColors/c1/9':true},'L'),false);
t('spin 5x tapi bayar harga 1x (250)',update(rich,sp(4750,5),'L'),false);
t('spin oleh member biasa',update(rich,sp(4750,1),'M'),false);
t('spin oleh developer (bukan leader)',update(rich,sp(4750,1),'D'),false);
t('spin sambil mengubah XP total',update(rich,sp(4750,1,{'clans/c1/xp':4750}),'L'),false);
t('spin sambil menambah slot',update(rich,sp(4750,1,{'clans/c1/slots':35}),'L'),false);
t('spin sambil naik tier',update(rich,sp(4750,1,{'clans/c1/tier':2}),'L'),false);
t('spin tanpa clanColorOp',update(rich,{'clans/c1/xpBalance':4750,'clanColors/c1/9':true},'L'),false);
t('spin lama pakai shard (sudah tidak boleh)',update(rich,{'users/L/shard':9750,'clanColorOp/c1':{n:1,ts},'clanColors/c1/9':true},'L'),false);
t('spin XP clan LAIN (c2) oleh leader c1',update(rich,{'clans/c2/xpBalance':-250,'clanColorOp/c1':{n:1,ts}},'L'),false);
t('tambah warna tanpa bayar',update(rich,{'clanColors/c1/14':true},'L'),false);
// ----- developer hapus clan -----
const del=(cid,tag,members,reqUsers,tags)=>{const p={['clans/'+cid]:null,['clanMembers/'+cid]:null,['clanRequests/'+cid]:null,['clanColors/'+cid]:null,['clanColorOp/'+cid]:null,['clanTags/'+tag]:null};
 members.forEach(u=>{p['userClan/'+u]=null;p['users/'+u+'/clanTag']=null});reqUsers.forEach(u=>p['userClanReq/'+u]=null);return p};
const full=del('c1','AKM',['L','M'],['N']);
t('DEV hapus clan c1 lengkap',update(base,full,'D'),true);
t('DEV hapus clan c2 (ada permintaan masuk)',update(base,del('c2','LAI',['X'],['Q']),'D'),true);
t('USER biasa hapus clan orang lain',update(base,full,'X'),false);
t('LEADER lain hapus lewat jalur dev',update(base,full,'L'),false);
t('MEMBER hapus clan',update(base,full,'M'),false);
const only=(k)=>{const p=clone(full);delete p[k];return p};
t('DEV: tanpa hapus clanTags (tag yatim)',update(base,only('clanTags/AKM'),'D'),false);
t('DEV: tanpa hapus clanMembers',update(base,only('clanMembers/c1'),'D'),false);
t('DEV: tanpa hapus clanColors',update(base,only('clanColors/c1'),'D'),false);
t('DEV: hanya hapus node clan saja',update(base,{'clans/c1':null},'D'),false);
t('DEV: nol-kan userClan tanpa hapus clan',update(base,{'userClan/M':null},'D'),false);
t('DEV: hapus tag user yg masih punya clan',update(base,{'users/M/clanTag':null},'D'),false);
t('USER: hapus userClan orang lain',update(base,{'userClan/M':null},'X'),false);
t('USER: hapus clanTags clan orang',update(base,{'clanTags/AKM':null},'X'),false);
t('USER: hapus clanColors clan orang',update(base,{'clanColors/c1':null},'X'),false);
t('USER: hapus clanMembers clan orang',update(base,{'clanMembers/c1':null},'X'),false);
t('DEV: ubah role user lain (sekarang boleh, fitur Role)',update(base,{'users/M/role':'admin'},'D'),true);
t('USER biasa: ubah role user lain',update(base,{'users/M/role':'admin'},'X'),false);
// regresi: bubarkan sendiri oleh leader saat sendirian
const solo={...clone(base)};
t('LEADER bubarkan clan c2 sendiri (members=1)',update(solo,{'clans/c2':null,'clanMembers/c2':null,'userClan/X':null,'clanTags/LAI':null,'clanRequests/c2':null,'clanColors/c2':null,'clanColorOp/c2':null,'users/X/clanTag':null},'X'),true);
console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
