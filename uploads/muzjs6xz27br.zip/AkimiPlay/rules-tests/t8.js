// Tes rules GIVEAWAY PREMIUM (chat global). Jalankan: node rules-tests/t8.js
const {update,T}=require('./sim.js');
const ts={__ts:1};
const DAY=86400000;
const clone=o=>JSON.parse(JSON.stringify(o));
const cum=L=>(L-1)*1000+350*(L-1)*(L-2);
const levelFromXp=x=>{let L=1;while(cum(L+1)<=x)L++;return L};
const u=(uid,extra={})=>({uid,userId:100,email:uid+'@x',displayName:'Nama'+uid,role:'user',verified:false,level:1,xp:0,totalWatchMinutes:0,createdAt:1,xpAt:1,shard:0,...extra});
const base={
 users:{C:u('C',{shard:20000}),P:u('P'),Q:u('Q',{premiumUntil:T+5*DAY}),D:u('D',{role:'developer'}),R:u('R',{premiumUntil:T-DAY})},
 meta:{chatHead:{seq:5,key:'old',uid:'P'}},
 giveaways:{g7:{uid:'C',name:'NamaC',text:'hadiah',days:7,slots:10,claimed:3,ts:1},
            g1:{uid:'C',name:'NamaC',text:'sehari',days:1,slots:5,claimed:0,ts:1},
            full:{uid:'C',name:'NamaC',text:'habis',days:7,slots:2,claimed:2,ts:1},
            other:{uid:'Z',name:'Z',text:'punya orang',days:7,slots:10,claimed:0,ts:1}},
 giveawayClaims:{g7:{Z1:1,Z2:1,Z3:1},full:{Z1:1,Z2:1},g1:{}}};
base.giveawayClaims.g7.Q2=1; // Q2 sudah klaim g7 (claimed=3 dihitung: Z1..Z3)
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};

// ---------- membuat giveaway (dibayar dengan hari Premium sendiri, tanpa AkimiShard) ----------
const bonus=(d,s)=>d*s*900, cost=(d,s)=>d*s*DAY;
const CP=T+400*DAY; // premium C: sisa 400 hari
const mk=(d=7,s=10,over={},opts={})=>{
  const nx=bonus(d,s), c=cost(d,s);
  const p={
   'users/C/premiumUntil':CP-c,
   'users/C/xp':nx,'users/C/level':levelFromXp(nx),
   'giveawayOp/C':{gid:'gn',ts},
   'giveaways/gn':{uid:'C',name:'NamaC',text:'Halo semua',days:d,slots:s,claimed:0,ts,...over},
   'globalChat/m1':{uid:'C',userId:100,name:'NamaC',role:'user',level:1,text:'Halo semua',ts,seq:6,gid:'gn'},
   'meta/chatHead':{seq:6,key:'m1',uid:'C'}};
  return {...p,...opts};
};
base.users.C.premiumUntil=CP;
t('buat 7 hari x 10 orang (70 hari Premium, +63.000 XP)',update(base,mk(),'C'),true);
t('contoh layar: 1 hari x 5 orang = 5 hari Premium, +4.500 XP',bonus(1,5)===4500&&cost(1,5)===5*DAY?{ok:true}:{ok:false,why:'angka salah'},true);
t('buat 1 hari x 5 orang',update(base,mk(1,5),'C'),true);
t('buat 1 hari x 1 orang',update(base,mk(1,1),'C'),true);
t('30 hari x 50 orang (1.500 hari) -> premium kurang',update(base,mk(30,50),'C'),false);
const rich=clone(base);rich.users.C.premiumUntil=T+2000*DAY;
t('30 hari x 50 orang saat premium cukup',update(rich,mk(30,50,{},{'users/C/premiumUntil':T+2000*DAY-cost(30,50)}),'C'),true);
t('potong kurang (60 hari bukan 70)',update(base,mk(7,10,{},{'users/C/premiumUntil':CP-60*DAY}),'C'),false);
t('potong lebih (80 hari)',update(base,mk(7,10,{},{'users/C/premiumUntil':CP-80*DAY}),'C'),false);
t('tidak dipotong sama sekali',update(base,mk(7,10,{},{'users/C/premiumUntil':CP}),'C'),false);
t('premium malah ditambah',update(base,mk(7,10,{},{'users/C/premiumUntil':CP+DAY}),'C'),false);
const exact=clone(base);exact.users.C.premiumUntil=T+5*DAY;
t('premium persis 5 hari, buat 1x5 -> boleh (sisa 0)',update(exact,mk(1,5,{},{'users/C/premiumUntil':T}),'C'),true);
const short=clone(base);short.users.C.premiumUntil=T+4*DAY;
t('premium cuma 4 hari, buat 1x5 -> ditolak',update(short,mk(1,5,{},{'users/C/premiumUntil':T-DAY}),'C'),false);
const none=clone(base);delete none.users.C.premiumUntil;
t('tanpa Premium sama sekali',update(none,mk(1,5,{},{'users/C/premiumUntil':T-5*DAY}),'C'),false);
t('shard dipakai untuk bayar (cara lama) ditolak',update(base,mk(7,10,{},{'users/C/premiumUntil':CP,'users/C/shard':20000-14000}),'C'),false);
t('bonus XP kelebihan',update(base,mk(7,10,{},{'users/C/xp':bonus(7,10)+1000,'users/C/level':levelFromXp(bonus(7,10)+1000)}),'C'),false);
t('bonus XP cara lama (1.100/hari) ditolak',update(base,mk(7,10,{},{'users/C/xp':77000,'users/C/level':levelFromXp(77000)}),'C'),false);
t('bonus XP harus persis jatah',update(base,mk(7,10,{},{'users/C/xp':1000,'users/C/level':levelFromXp(1000)}),'C'),false);
t('level tidak cocok dengan XP',update(base,mk(7,10,{},{'users/C/level':3}),'C'),false);
t('bonus XP tanpa giveaway',update(base,{'users/C/xp':bonus(7,10),'users/C/level':levelFromXp(bonus(7,10))},'C'),false);
t('bonus XP + giveaway tapi premium tidak berkurang',update(base,mk(7,10,{},{'users/C/premiumUntil':CP}),'C'),false);
t('bonus XP memakai giveaway orang lain (other)',update(base,{'users/C/xp':bonus(7,10),'users/C/level':levelFromXp(bonus(7,10)),'giveawayOp/C':{gid:'other',ts}},'C'),false);
t('bonus XP memakai giveaway lama milik sendiri (g7)',update(base,{'users/C/xp':bonus(7,10),'users/C/level':levelFromXp(bonus(7,10)),'giveawayOp/C':{gid:'g7',ts}},'C'),false);
t('potong premium memakai giveaway lama (g7)',update(base,{'users/C/premiumUntil':CP-cost(7,10),'giveawayOp/C':{gid:'g7',ts}},'C'),false);
t('potong premium tanpa giveaway baru',update(base,{'users/C/premiumUntil':CP-DAY},'C'),false);
t('durasi 5 hari (tidak ada di daftar)',update(base,mk(5,10,{days:5},{'users/C/premiumUntil':CP-cost(5,10),'users/C/xp':bonus(5,10),'users/C/level':levelFromXp(bonus(5,10))}),'C'),false);
t('hadiah 51',update(base,mk(7,10,{slots:51}),'C'),false);
t('hadiah 0',update(base,mk(7,10,{slots:0}),'C'),false);
t('hadiah pecahan 2.5',update(base,mk(7,10,{slots:2.5}),'C'),false);
t('pesan kosong',update(base,mk(7,10,{text:''}),'C'),false);
t('pesan 121 karakter',update(base,mk(7,10,{text:'x'.repeat(121)}),'C'),false);
t('nama dipalsukan',update(base,mk(7,10,{name:'Admin Resmi'}),'C'),false);
t('uid giveaway = orang lain',update(base,mk(7,10,{uid:'P'}),'C'),false);
t('claimed awal 5 (curang)',update(base,mk(7,10,{claimed:5}),'C'),false);
t('ts giveaway bukan waktu server',update(base,mk(7,10,{ts:123}),'C'),false);
t('field asing di giveaway',update(base,mk(7,10,{bonus:1}),'C'),false);
t('tanpa giveawayOp',update(base,(()=>{const p=mk();delete p['giveawayOp/C'];return p})(),'C'),false);
t('giveawayOp menunjuk gid lain',update(base,mk(7,10,{},{'giveawayOp/C':{gid:'zzz',ts}}),'C'),false);
t('tanpa pesan pengumuman di chat (boleh)',update(base,(()=>{const p=mk();delete p['globalChat/m1'];delete p['meta/chatHead'];return p})(),'C'),true);
t('chat gid menunjuk giveaway lama (g7)',update(base,{'globalChat/m1':{uid:'C',userId:100,name:'NamaC',role:'user',level:1,text:'iklan',ts,seq:6,gid:'g7'},'meta/chatHead':{seq:6,key:'m1',uid:'C'}},'C'),false);
t('chat gid menunjuk giveaway orang lain',update(base,{'globalChat/m1':{uid:'C',userId:100,name:'NamaC',role:'user',level:1,text:'iklan',ts,seq:6,gid:'other'},'meta/chatHead':{seq:6,key:'m1',uid:'C'}},'C'),false);
t('chat biasa tanpa gid tetap jalan',update(base,{'globalChat/m1':{uid:'C',userId:100,name:'NamaC',role:'user',level:1,text:'halo',ts,seq:6},'meta/chatHead':{seq:6,key:'m1',uid:'C'}},'C'),true);
t('orang lain membuat giveaway atas nama C',update(base,mk(),'P'),false);

// ---------- klaim ----------
const claim=(uid,gid,cur,days,over={})=>{
  const g=base.giveaways[gid];
  const until=Math.max(cur||0,T)+days*DAY;
  return {[`giveaways/${gid}/claimed`]:g.claimed+1,[`giveawayClaims/${gid}/${uid}`]:ts,[`giveawayLastClaim/${uid}`]:{gid,ts},[`users/${uid}/premiumUntil`]:until,...over};
};
t('P klaim g7 (belum premium) -> +7 hari',update(base,claim('P','g7',0,7),'P'),true);
t('P klaim g1 -> +1 hari',update(base,claim('P','g1',0,1),'P'),true);
t('Q (premium aktif 5 hari) klaim g7 -> ditambah di belakang',update(base,claim('Q','g7',T+5*DAY,7),'Q'),true);
t('R (premium sudah habis) klaim g7 -> mulai dari sekarang',update(base,claim('R','g7',T-DAY,7),'R'),true);
t('toleransi jam +4 menit',update(base,claim('P','g7',0,7,{'users/P/premiumUntil':T+7*DAY+4*60000}),'P'),true);
t('terlalu banyak (+10 menit)',update(base,claim('P','g7',0,7,{'users/P/premiumUntil':T+7*DAY+10*60000}),'P'),false);
t('terlalu sedikit (-10 menit, tetap ditolak agar angka konsisten)',update(base,claim('P','g7',0,7,{'users/P/premiumUntil':T+7*DAY-10*60000}),'P'),false);
t('curang: klaim g7 tapi minta 30 hari',update(base,claim('P','g7',0,7,{'users/P/premiumUntil':T+30*DAY}),'P'),false);
t('curang: klaim g1 tapi minta 7 hari',update(base,claim('P','g1',0,1,{'users/P/premiumUntil':T+7*DAY}),'P'),false);
t('Q klaim tapi premium lama dihapus (mulai dari sekarang)',update(base,claim('Q','g7',T+5*DAY,7,{'users/Q/premiumUntil':T+7*DAY}),'Q'),false);
t('pembuat klaim giveaway sendiri',update(base,claim('C','g7',0,7),'C'),false);
t('klaim dua kali (Z1 sudah klaim)',update({...base,users:{...base.users,Z1:u('Z1')}},claim('Z1','g7',0,7),'Z1'),false);
t('klaim giveaway yang sudah habis',update(base,claim('P','full',0,7),'P'),false);
t('claimed naik 2 sekaligus',update(base,claim('P','g7',0,7,{'giveaways/g7/claimed':5}),'P'),false);
t('claimed turun (curang)',update(base,claim('P','g7',0,7,{'giveaways/g7/claimed':2}),'P'),false);
t('klaim tanpa menaikkan claimed',update(base,(()=>{const p=claim('P','g7',0,7);delete p['giveaways/g7/claimed'];return p})(),'P'),false);
t('klaim tanpa catatan giveawayClaims',update(base,(()=>{const p=claim('P','g7',0,7);delete p['giveawayClaims/g7/P'];return p})(),'P'),false);
t('klaim atas nama orang lain (catatan milik P ditulis Q)',update(base,claim('P','g7',0,7),'Q'),false);
t('klaim tanpa premium (rugi sendiri, hanya memakai slot)',update(base,(()=>{const p=claim('P','g7',0,7);delete p['users/P/premiumUntil'];return p})(),'P'),true);
t('giveawayLastClaim menunjuk giveaway yang tidak diklaim',update(base,claim('P','g7',0,7,{'giveawayLastClaim/P':{gid:'g1',ts}}),'P'),false);
t('tulis premiumUntil sendiri tanpa klaim',update(base,{'users/P/premiumUntil':T+30*DAY},'P'),false);
const stale=clone(base);stale.giveawayLastClaim={P:{gid:'g7',ts:5}};stale.giveawayClaims.g7.P=5;
t('tulis premiumUntil memakai klaim lama (ts basi)',update(stale,{'users/P/premiumUntil':T+7*DAY},'P'),false);
t('tulis premiumUntil orang lain memakai klaim sendiri',update(base,claim('P','g7',0,7,{'users/Q/premiumUntil':T+99*DAY}),'P'),false);
t('premium lebih dari 10 tahun (bertumpuk)',update(base,claim('Q','g7',T+3649*DAY,7,{'users/Q/premiumUntil':T+3656*DAY}),'Q'),false);

// ---------- skenario Zaal & Zuul: klaim terkunci per giveaway, giveaway baru membuka klaim baru ----------
const zz=clone(base);
zz.users.Zuul=u('Zuul',{premiumUntil:T+1*DAY});            // Zuul sudah klaim giveaway pertama (gA, 1 hari)
zz.giveaways.gA={uid:'C',name:'NamaC',text:'pertama',days:1,slots:5,claimed:1,ts:1};
zz.giveawayClaims.gA={Zuul:1};
zz.giveawayLastClaim={Zuul:{gid:'gA',ts:5}};
zz.giveaways.gB={uid:'C',name:'NamaC',text:'kedua',days:1,slots:5,claimed:0,ts:2}; // Zaal (C) gift lagi
zz.giveawayClaims.gB={};
t('Zuul klaim gA lagi -> terkunci',update(zz,{'giveaways/gA/claimed':2,'giveawayClaims/gA/Zuul':ts,'giveawayLastClaim/Zuul':{gid:'gA',ts},'users/Zuul/premiumUntil':T+2*DAY},'Zuul'),false);
t('Zaal gift lagi (gB) -> Zuul klaim gB 1x lagi, premium ditambah di belakang',update(zz,{'giveaways/gB/claimed':1,'giveawayClaims/gB/Zuul':ts,'giveawayLastClaim/Zuul':{gid:'gB',ts},'users/Zuul/premiumUntil':T+2*DAY},'Zuul'),true);

// ---------- developer tetap bisa mengelola premium ----------
t('developer memberi premium ke P',update(base,{'users/P/premiumUntil':T+30*DAY},'D'),true);
t('developer mencabut premium Q',update(base,{'users/Q/premiumUntil':null},'D'),true);
t('developer memberi premium ke diri sendiri (tetap dilarang)',update(base,{'users/D/premiumUntil':T+30*DAY},'D'),false);
t('user biasa memberi premium ke orang lain',update(base,{'users/Q/premiumUntil':T+30*DAY},'P'),false);

// ---------- giveaway tidak bisa diubah ----------
t('pembuat mengubah teks giveaway',update(base,{'giveaways/g7/text':'baru'},'C'),false);
t('pembuat menaikkan slots',update(base,{'giveaways/g7/slots':50},'C'),false);
t('pembuat menaikkan days',update(base,{'giveaways/g7/days':30},'C'),false);
t('pembuat menghapus giveaway untuk refund premium',update(base,{'giveaways/g7':null,'users/C/premiumUntil':CP+70*DAY},'C'),false);
t('pembuat menaikkan shard sendiri (refund palsu)',update(base,{'users/C/shard':99999},'C'),false);
t('pembuat menambah premium sendiri (refund palsu)',update(base,{'users/C/premiumUntil':CP+70*DAY},'C'),false);
t('orang lain menghapus giveaway',update(base,{'giveaways/g7':null},'P'),false);

console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
process.exit(fail?1:0);
