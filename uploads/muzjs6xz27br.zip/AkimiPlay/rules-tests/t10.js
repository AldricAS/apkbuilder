// Tes rules: XP/level biasa (tanpa riwayat giveaway), klaim Premium pertama, dan badge clan saat ACC.
// Jalankan: node rules-tests/t10.js   (simulator ketat: child(null) dianggap error seperti di Firebase)
const {update,T}=require('./sim.js');
const ts={__ts:1};
const clone=o=>JSON.parse(JSON.stringify(o));
const cum=L=>(L-1)*1000+350*(L-1)*(L-2);
const lvl=x=>{let L=1;while(cum(L+1)<=x)L++;return L};
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};
const u=(uid,xp,xpAt,extra={})=>({uid,userId:5,email:uid+'@x',displayName:'N'+uid,role:'user',verified:false,level:lvl(xp),xp,totalWatchMinutes:10,createdAt:1,xpAt,shard:0,...extra});

// ---------- XP menonton: user yang TIDAK pernah membuat/mengklaim giveaway ----------
const xpDb={users:{U:u('U',5000,T-30000)}};
const flush=(xp,secs,over={})=>({'users/U/xp':xp,'users/U/level':lvl(xp),'users/U/totalWatchMinutes':10+secs/60,'users/U/xpAt':ts,'users/U/updatedAt':ts,'watch/U/ep1':'0-100',...over});
t('XP menonton 30 dtk (tanpa riwayat giveaway)',update(xpDb,flush(5120,30),'U'),true);
t('XP menonton yang melewati batas level',update({users:{U:u('U',1990,T-30000)}},flush(2110,30),'U'),true);
t('XP terlalu besar (cheat)',update(xpDb,flush(9000,30),'U'),false);
t('XP diturunkan',update(xpDb,flush(4000,30),'U'),false);
t('level tidak cocok dengan XP',update(xpDb,flush(5120,30,{'users/U/level':9}),'U'),false);
t('XP orang lain',update({users:{U:u('U',5000,T-30000),V:u('V',100,T-30000)}},{'users/V/xp':220,'users/V/level':1,'users/V/xpAt':ts},'U'),false);

// ---------- klaim Premium pertama kali (belum ada giveawayLastClaim) ----------
const DAY=86400000;
const cDb={users:{C:u('C',0,1,{premiumUntil:T+10*DAY}),P:u('P',0,1)},giveaways:{g1:{uid:'C',name:'C',text:'x',days:3,slots:5,claimed:0,ts:1}},giveawayClaims:{g1:{}}};
const claim=(uid,until,gid='g1')=>({'giveaways/g1/claimed':1,[`giveawayClaims/${gid}/${uid}`]:ts,[`giveawayLastClaim/${uid}`]:{gid,ts},[`users/${uid}/premiumUntil`]:until});
t('klaim pertama oleh user tanpa Premium',update(cDb,claim('P',T+3*DAY),'P'),true);
t('klaim memberi lebih dari hak',update(cDb,claim('P',T+30*DAY),'P'),false);
t('menulis premiumUntil tanpa klaim',update(cDb,{'users/P/premiumUntil':T+30*DAY},'P'),false);

// ---------- badge clan saat ACC ----------
const base={users:{L:u('L',0,1,{clanTag:'AKM'}),M:u('M',0,1,{clanTag:'AKM'}),N:u('N',0,1),X:u('X',0,1),V:u('V',0,1,{clanTag:'AKM'}),Z:u('Z',0,1)},
 clans:{c1:{name:'Akimi',nameLower:'akimi',tag:'AKM',color:0,emblem:0,leaderUid:'L',xp:0,xpBalance:0,slots:30,members:3,createdAt:1}},
 clanMembers:{c1:{L:{role:'leader',joinedAt:1,donated:0},M:{role:'member',joinedAt:2,donated:0},V:{role:'vice',joinedAt:3,donated:0}}},
 userClan:{L:'c1',M:'c1',V:'c1'},userClanReq:{N:'c1',Z:'c1'},clanRequests:{c1:{N:1,Z:1}},clanTags:{AKM:'c1'}};
const acc=(uid,extra={})=>({[`clanMembers/c1/${uid}`]:{role:'member',joinedAt:ts,donated:0},[`clanRequests/c1/${uid}`]:null,[`userClanReq/${uid}`]:null,[`userClan/${uid}`]:'c1','clans/c1/members':4,'clans/c1/inOp':{uid,ts},...extra});
t('leader ACC + pasang badge clan',update(base,acc('N',{'users/N/clanTag':'AKM'}),'L'),true);
t('vice-leader ACC + pasang badge clan',update(base,acc('N',{'users/N/clanTag':'AKM'}),'V'),true);
t('leader ACC tanpa badge (seperti sebelumnya)',update(base,acc('N'),'L'),true);
t('member biasa memasang badge ke orang lain',update(base,acc('N',{'users/N/clanTag':'AKM'}),'M'),false);
t('orang luar clan memasang badge ke orang lain',update(base,acc('N',{'users/N/clanTag':'AKM'}),'X'),false);
t('leader memasang tag clan yang salah',update(base,acc('N',{'users/N/clanTag':'LAI'}),'L'),false);
t('leader memasang badge tanpa ACC (userClan tidak dibuat)',update(base,{'users/N/clanTag':'AKM'},'L'),false);
t('leader memasang badge ke orang yang sudah di clan',update(base,{'users/Z/clanTag':'AKM'},'L'),false);
t('user memasang tag clan sendiri (sinkronisasi lama)',update(Object.assign(clone(base),{userClan:{L:'c1',M:'c1',V:'c1',N:'c1'}}),{'users/N/clanTag':'AKM'},'N'),true);

console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
process.exit(fail?1:0);
