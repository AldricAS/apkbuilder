// Tes rules banner pengumuman developer (tombol + link) dan banner profil (URL panjang). Jalankan: node rules-tests/t12.js
const {update,T}=require('./sim.js');
const ts={__ts:1};
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};
const usr=(uid,role,extra={})=>({uid,userId:uid==='DEV'?1:2,email:uid+'@x',displayName:uid,role,verified:false,level:1,xp:0,totalWatchMinutes:0,createdAt:1,xpAt:1,shard:0,...extra});
const db={users:{DEV:usr('DEV','developer'),USR:usr('USR','user'),PRM:usr('PRM','user',{premiumUntil:T+86400000})}};
const b=(o={})=>({title:'Update',text:'Versi baru',byId:1,ts,...o});
t('banner tanpa tombol (OFF)',update(db,{banner:b()},'DEV'),true);
t('banner dengan tombol + link',update(db,{banner:b({btn:'Update sekarang',link:'https://akimiplay.app/update'})},'DEV'),true);
t('tombol tanpa link',update(db,{banner:b({btn:'Klik'})},'DEV'),false);
t('link tanpa tombol',update(db,{banner:b({link:'https://x.com'})},'DEV'),false);
t('link bukan https',update(db,{banner:b({btn:'Klik',link:'http://x.com'})},'DEV'),false);
t('link javascript:',update(db,{banner:b({btn:'Klik',link:'javascript:alert(1)'})},'DEV'),false);
t('teks tombol 31 huruf',update(db,{banner:b({btn:'a'.repeat(31),link:'https://x.com'})},'DEV'),false);
t('link 501 huruf',update(db,{banner:b({btn:'Klik',link:'https://x.com/'+'a'.repeat(490)})},'DEV'),false);
t('user biasa membuat banner',update(db,{banner:b({btn:'Klik',link:'https://x.com'})},'USR'),false);
t('field asing di banner',update(db,{banner:b({hack:1})},'DEV'),false);
// banner profil: URL sampai 1000 huruf
const url=(n)=>'https://cdn.example.com/'+'a'.repeat(n-24-4)+'.gif';
t('banner profil premium URL 800 huruf',update(db,{'users/PRM/bannerURL':url(800)},'PRM'),true);
t('banner profil premium URL 1001 huruf',update(db,{'users/PRM/bannerURL':url(1001)},'PRM'),false);
t('banner profil user biasa',update(db,{'users/USR/bannerURL':url(100)},'USR'),false);
t('banner profil http',update(db,{'users/PRM/bannerURL':'http://x.com/a.gif'},'PRM'),false);
console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
process.exit(fail?1:0);
