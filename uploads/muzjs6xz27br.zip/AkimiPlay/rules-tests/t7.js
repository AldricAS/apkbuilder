// Tes rules ROLE clan: leader > vice > admiral > officer > member. Jalankan: node rules-tests/t7.js
const {update}=require('./sim.js');
const ts={__ts:1};
const clone=o=>JSON.parse(JSON.stringify(o));
const mem=(role,j)=>({role,joinedAt:j,donated:0});
const base={
 users:{L:{uid:'L',role:'user',shard:1000},V:{uid:'V',role:'user',shard:1000},V2:{uid:'V2',role:'user',shard:1000},A:{uid:'A',role:'user',shard:1000},A2:{uid:'A2',role:'user',shard:1000},
        O:{uid:'O',role:'user',shard:1000},M:{uid:'M',role:'user',shard:1000},M2:{uid:'M2',role:'user',shard:1000},N:{uid:'N',role:'user',shard:1000},X:{uid:'X',role:'user',shard:1000}},
 clans:{c1:{name:'Akimi',nameLower:'akimi',tag:'AKM',color:0,emblem:0,tier:1,leaderUid:'L',xp:9000,xpBalance:5000,slots:30,members:8,createdAt:1}},
 clanMembers:{c1:{L:mem('leader',1),V:mem('vice',2),V2:mem('vice',3),A:mem('admiral',4),A2:mem('admiral',5),O:mem('officer',6),M:mem('member',7),M2:mem('member',8)}},
 userClan:{L:'c1',V:'c1',V2:'c1',A:'c1',A2:'c1',O:'c1',M:'c1',M2:'c1'},
 userClanReq:{N:'c1'},clanRequests:{c1:{N:1}},clanTags:{AKM:'c1'},clanColors:{c1:{14:true,5:true,13:true}}};
let fail=0;
const t=(n,r,want)=>{const ok=r.ok===want;if(!ok)fail++;console.log((ok?'OK   ':'SALAH')+'  '+(r.ok?'ALLOW':'DENY ')+' '+n+(r.ok?'':'  <- '+r.why))};
const accept=()=>({'clanMembers/c1/N':{role:'member',joinedAt:ts,donated:0},'clanRequests/c1/N':null,'userClanReq/N':null,'userClan/N':'c1','clans/c1/members':9,'clans/c1/inOp':{uid:'N',ts}});
const reject=()=>({'clanRequests/c1/N':null,'userClanReq/N':null});
const kick=(u)=>({['clanMembers/c1/'+u]:null,['userClan/'+u]:null,'clans/c1/members':7,'clans/c1/outOp':{uid:u,ts}});
const role=(u,r)=>({['clanMembers/c1/'+u+'/role']:r});

console.log('--- terima permintaan ---');
t('leader terima',update(base,accept(),'L'),true);
t('vice terima',update(base,accept(),'V'),true);
t('admiral terima',update(base,accept(),'A'),true);
t('officer terima',update(base,accept(),'O'),false);
t('member terima',update(base,accept(),'M'),false);
t('orang luar terima',update(base,accept(),'X'),false);
t('pemohon menerima dirinya sendiri',update(base,accept(),'N'),false);
console.log('--- tolak permintaan ---');
t('leader tolak',update(base,reject(),'L'),true);
t('vice tolak',update(base,reject(),'V'),true);
t('admiral tolak',update(base,reject(),'A'),true);
t('officer tolak',update(base,reject(),'O'),false);
t('member tolak',update(base,reject(),'M'),false);
t('pemohon batalkan sendiri',update(base,reject(),'N'),true);

console.log('--- kick ---');
for(const u of ['V','V2','A','O','M']) t('leader kick '+u,update(base,kick(u),'L'),true);
for(const u of ['A','A2','O','M']) t('vice kick '+u,update(base,kick(u),'V'),true);
t('vice kick vice lain (V2)',update(base,kick('V2'),'V'),false);
t('vice kick leader',update(base,kick('L'),'V'),false);
t('admiral kick member',update(base,kick('M'),'A'),false);
t('admiral kick officer',update(base,kick('O'),'A'),false);
t('officer kick member',update(base,kick('M'),'O'),false);
t('member kick officer',update(base,kick('O'),'M'),false);
t('member kick member',update(base,kick('M2'),'M'),false);
t('leader kick dirinya sendiri',update(base,kick('L'),'L'),false);
t('admiral kick leader',update(base,kick('L'),'A'),false);
t('kick tanpa outOp',update(base,{'clanMembers/c1/M':null,'userClan/M':null,'clans/c1/members':7},'L'),false);
t('kick tapi members dikurangi 2',update(base,{...kick('M'),'clans/c1/members':6},'L'),false);
t('kick tapi userClan dibiarkan',update(base,{'clanMembers/c1/M':null,'clans/c1/members':7,'clans/c1/outOp':{uid:'M',ts}},'L'),false);
t('orang luar kick member',update(base,kick('M'),'X'),false);

console.log('--- keluar sendiri ---');
for(const u of ['V','A','O','M']) t(u+' keluar sendiri',update(base,kick(u),u),true);
t('leader keluar (harus ditolak)',update(base,kick('L'),'L'),false);
t('member keluarkan orang lain dgn dalih keluar',update(base,kick('M2'),'M'),false);

console.log('--- ubah role ---');
t('leader: member -> vice',update(base,role('M','vice'),'L'),true);
t('leader: member -> admiral',update(base,role('M','admiral'),'L'),true);
t('leader: admiral -> officer',update(base,role('A','officer'),'L'),true);
t('leader: vice -> member',update(base,role('V','member'),'L'),true);
t('leader ubah role sendiri',update(base,role('L','member'),'L'),false);
t('leader menjadikan member leader lewat role saja',update(base,role('M','leader'),'L'),false);
t('role ngawur (boss)',update(base,role('M','boss'),'L'),false);
t('vice: member -> admiral',update(base,role('M','admiral'),'V'),true);
t('vice: member -> officer',update(base,role('M','officer'),'V'),true);
t('vice: officer -> admiral',update(base,role('O','admiral'),'V'),true);
t('vice: admiral -> officer',update(base,role('A','officer'),'V'),true);
t('vice: admiral -> member',update(base,role('A','member'),'V'),true);
t('vice: member -> vice',update(base,role('M','vice'),'V'),false);
t('vice: vice lain -> member',update(base,role('V2','member'),'V'),false);
t('vice: leader -> member',update(base,role('L','member'),'V'),false);
t('vice naikkan diri sendiri ke admiral/leader',update(base,role('V','leader'),'V'),false);
t('vice turunkan diri sendiri',update(base,role('V','member'),'V'),false);
t('admiral: member -> officer',update(base,role('M','officer'),'A'),true);
t('admiral: officer -> member',update(base,role('O','member'),'A'),true);
t('admiral: member -> admiral',update(base,role('M','admiral'),'A'),false);
t('admiral: officer -> vice',update(base,role('O','vice'),'A'),false);
t('admiral: admiral lain -> officer',update(base,role('A2','officer'),'A'),false);
t('admiral: vice -> officer',update(base,role('V','officer'),'A'),false);
t('admiral: leader -> member',update(base,role('L','member'),'A'),false);
t('admiral naikkan diri sendiri',update(base,role('A','vice'),'A'),false);
t('officer ubah role member',update(base,role('M','officer'),'O'),false);
t('member ubah role member lain',update(base,role('M2','officer'),'M'),false);
t('member naikkan diri sendiri',update(base,role('M','vice'),'M'),false);
t('orang luar ubah role',update(base,role('M','officer'),'X'),false);
t('developer (bukan leader) ubah role',update({...base,users:{...base.users,D:{uid:'D',role:'developer',shard:0}}},role('M','officer'),'D'),false);

console.log('--- transfer leader ---');
const xfer=(to,from='L')=>({'clans/c1/leaderUid':to,['clanMembers/c1/'+to+'/role']:'leader',['clanMembers/c1/'+from+'/role']:'vice'});
t('leader -> member biasa (M)',update(base,xfer('M'),'L'),true);
t('leader -> vice (V)',update(base,xfer('V'),'L'),true);
t('leader -> officer (O)',update(base,xfer('O'),'L'),true);
t('vice merebut jabatan leader',update(base,xfer('V','L'),'V'),false);
t('member merebut jabatan leader',update(base,xfer('M','L'),'M'),false);
t('hanya leaderUid diganti',update(base,{'clans/c1/leaderUid':'M'},'L'),false);
t('leaderUid + calon leader, tanpa menurunkan leader lama',update(base,{'clans/c1/leaderUid':'M','clanMembers/c1/M/role':'leader'},'L'),false);
t('role calon leader saja (tanpa leaderUid)',update(base,{'clanMembers/c1/M/role':'leader'},'L'),false);
t('leader menurunkan diri tanpa transfer',update(base,{'clanMembers/c1/L/role':'vice'},'L'),false);
t('dua leader sekaligus',update(base,{'clans/c1/leaderUid':'M','clanMembers/c1/M/role':'leader'},'L'),false);
t('transfer ke orang luar (X)',update(base,{'clans/c1/leaderUid':'X','clanMembers/c1/X':mem('leader',ts),'clanMembers/c1/L/role':'vice'},'L'),false);
t('transfer ke diri sendiri',update(base,{'clans/c1/leaderUid':'L'},'L'),false);
t('leader lama jadi member (bukan vice) saat transfer',update(base,{'clans/c1/leaderUid':'M','clanMembers/c1/M/role':'leader','clanMembers/c1/L/role':'member'},'L'),false);
const after=update(base,xfer('M'),'L').db;
t('[setelah transfer] leader baru (M) kick vice (V)',update(after,kick('V'),'M'),true);
t('[setelah transfer] leader baru (M) beli slot',update(after,{'clans/c1/slots':35,'clans/c1/xpBalance':4000},'M'),true);
t('[setelah transfer] leader lama (L, kini vice) beli slot',update(after,{'clans/c1/slots':35,'clans/c1/xpBalance':4000},'L'),false);
t('[setelah transfer] leader lama (kini vice) kick leader baru',update(after,kick('M'),'L'),false);
t('[setelah transfer] leader lama (kini vice) kick admiral',update(after,kick('A'),'L'),true);
t('[setelah transfer] leader lama keluar sebagai vice',update(after,kick('L'),'L'),true);
t('[setelah transfer] leader lama merebut kembali tanpa izin',update(after,xfer('L','M'),'L'),false);

console.log('--- tier / spin / warna / slot ---');
const tier=(bal=2000)=>({'clans/c1/tier':2,'clans/c1/xpBalance':bal});
t('leader upgrade tier',update(base,tier(),'L'),true);
t('vice upgrade tier',update(base,tier(),'V'),true);
t('admiral upgrade tier',update(base,tier(),'A'),false);
t('officer upgrade tier',update(base,tier(),'O'),false);
t('member upgrade tier',update(base,tier(),'M'),false);
const sp=(bal,n)=>({'clans/c1/xpBalance':bal,'clanColorOp/c1':{n,ts},'clanColors/c1/9':true});
t('leader spin 1x',update(base,sp(4750,1),'L'),true);
t('vice spin 1x',update(base,sp(4750,1),'V'),true);
t('vice spin 5x',update(base,sp(3875,5),'V'),true);
t('admiral spin',update(base,sp(4750,1),'A'),false);
t('officer spin',update(base,sp(4750,1),'O'),false);
t('member spin',update(base,sp(4750,1),'M'),false);
t('leader pakai warna',update(base,{'clans/c1/color':14},'L'),true);
t('vice pakai warna',update(base,{'clans/c1/color':14},'V'),true);
t('admiral pakai warna',update(base,{'clans/c1/color':14},'A'),false);
t('member pakai warna',update(base,{'clans/c1/color':14},'M'),false);
t('vice pakai warna yang belum dimiliki',update(base,{'clans/c1/color':3},'V'),false);
const slot={'clans/c1/slots':35,'clans/c1/xpBalance':4000};
t('leader beli slot',update(base,slot,'L'),true);
t('vice beli slot (hanya leader)',update(base,slot,'V'),false);
t('admiral beli slot',update(base,slot,'A'),false);
console.log(fail?`\n${fail} tes TIDAK sesuai harapan`:'\nSemua tes sesuai harapan');
process.exit(fail?1:0);
