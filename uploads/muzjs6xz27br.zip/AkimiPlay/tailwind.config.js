/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#08080B',
        panel: '#101016',
        raise: '#181821',
        line: 'rgba(255,255,255,0.08)',
        muted: '#8C8C9B',
        accent: '#FF7AA2',
      },
      fontFamily: {
        sans: ['Roboto', '"Noto Sans"', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        // badge Developer: kapsul merah tumbuh dari kiri, lalu menyusut ke kanan (siklus 4,6 dtk: 48% tumbuh, 48% menyusut, 4% jeda)
        devSweep: {
          '0%': { left: '0%', width: '0%' },
          '47.8%': { left: '0%', width: '100%' },
          '95.7%': { left: '100%', width: '0%' },
          '100%': { left: '100%', width: '0%' },
        },
        // badge Premium: kilau putih menyapu dari kiri ke kanan, lalu jeda
        premiumShine: {
          '0%': { left: '-50%' },
          '55%': { left: '115%' },
          '100%': { left: '115%' },
        },
        sheetUp: { from: { transform: 'translateY(100%)' }, to: { transform: 'translateY(0)' } },
        fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } },
        lift: {
          '0%': { transform: 'translateY(0) scale(1)' },
          '50%': { transform: 'translateY(-5px) scale(1.18)' },
          '100%': { transform: 'translateY(-2px) scale(1.08)' },
        },
        flash: {
          '0%': { opacity: '0', transform: 'scale(.8)' },
          '30%': { opacity: '1', transform: 'scale(1)' },
          '100%': { opacity: '0', transform: 'scale(1.05)' },
        },
        floaty: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-10px)' } },
        glow: { '0%,100%': { opacity: '.55', transform: 'scale(1)' }, '50%': { opacity: '.95', transform: 'scale(1.12)' } },
        // AkimiGames / Nobar: partikel latar
        twinkle: { '0%,100%': { opacity: '.15', transform: 'scale(.7)' }, '50%': { opacity: '1', transform: 'scale(1.15)' } },
        petal: {
          '0%': { transform: 'translate3d(0,-12vh,0) rotate(0deg)', opacity: '0' },
          '10%': { opacity: '.75' },
          '90%': { opacity: '.55' },
          '100%': { transform: 'translate3d(var(--sway,40px),112vh,0) rotate(540deg)', opacity: '0' },
        },
        orbit: { to: { transform: 'rotate(360deg)' } },
        dash: { to: { strokeDashoffset: '-24' } },
        shoot: {
          '0%': { transform: 'translate3d(0,0,0) rotate(35deg)', opacity: '0' },
          '3%': { opacity: '1' },
          '13%': { transform: 'translate3d(-260px,182px,0) rotate(35deg)', opacity: '0' },
          '100%': { transform: 'translate3d(-260px,182px,0) rotate(35deg)', opacity: '0' },
        },
      },
      animation: {
        devSweep: 'devSweep 4.6s linear infinite',
        premiumShine: 'premiumShine 3.6s ease-in-out infinite',
        sheetUp: 'sheetUp .28s cubic-bezier(.2,.8,.2,1)',
        fadeIn: 'fadeIn .2s ease-out',
        lift: 'lift .32s ease-out forwards',
        flash: 'flash .7s ease-out forwards',
        floaty: 'floaty 5s ease-in-out infinite',
        glow: 'glow 4s ease-in-out infinite',
        twinkle: 'twinkle 4s ease-in-out infinite',
        petal: 'petal 12s linear infinite',
        orbit: 'orbit 26s linear infinite',
        dash: 'dash 2.4s linear infinite',
        shoot: 'shoot 9s ease-out infinite',
      },
    },
  },
  plugins: [],
}
