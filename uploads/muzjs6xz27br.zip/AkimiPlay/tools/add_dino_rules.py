#!/usr/bin/env python3
"""Menambahkan rules AkimiGame: Dino Run ke database.rules.json (idempotent) dan membuka jalur AkimiShard untuk
belanja spin, hadiah main, dan jual duplikat. Angka HARUS sama dengan src/services/dinoService.ts."""
import json, os
path = os.path.join(os.path.dirname(__file__), '..', 'database.rules.json')
d = json.load(open(path, encoding='utf8')); r = d['rules']

DAY = "((now + 25200000 - (now + 25200000) % 86400000) / 86400000)"      # tanggal WIB (UTC+7) dari jam SERVER
OLD = "root.child('dino_game').child($uid)"
SP = OLD + ".child('spin')"
# ---- undian: seluruh hasil dihitung dari data server (seed = jam server saat bayar, n = hitungan undian) ----
ROLL = f"({SP}.child('seed').val() + {SP}.child('n').val() * 7919) % 10000"
ROLL2 = f"({SP}.child('seed').val() * 7 + {SP}.child('n').val() * 104729 + 31) % 9973"
pm, pl, pr, mode = (f"{SP}.child('{k}').val()" for k in ('pm', 'pl', 'pr', 'mode'))
RL = "newData.parent().child('roll').val()"
RAR = f"({mode} === 2 ? 0 : ({pm} >= 249 || {RL} < 20) ? 3 : ({pl} >= 79 || {RL} < 250) ? 2 : ({pr} >= 9 || {RL} < 2000) ? 1 : 0)"
def LEN(x): return f"({x} === 3 ? 1 : {x} === 2 ? 3 : 4)"
def BASE(x): return f"({x} === 3 ? 11 : {x} === 2 ? 8 : {x} === 1 ? 4 : 0)"
CAP = lambda sel: f"({sel} < 0 ? 1500 : {sel} < 4 ? 2500 : {sel} < 8 ? 3500 : {sel} < 11 ? 5000 : 7500)"
PRICE = lambda sid: f"({sid} < 4 ? 30 : {sid} < 8 ? 90 : {sid} < 11 ? 300 : 900)"
SHARD_OLD = "root.child('users').child($uid).child('shard').val()"
SHARD_NEW = "newData.parent().parent().parent().child('users').child($uid).child('shard').val()"
INT = lambda v: f"{v} % 1 === 0"

spin_validate = (
 "newData.hasChildren(['seed', 'pend', 'mode', 'n', 'pr', 'pl', 'pm']) && newData.child('seed').isNumber() && newData.child('pend').isNumber() && "
 "newData.child('mode').isNumber() && newData.child('n').isNumber() && newData.child('pr').isNumber() && newData.child('pl').isNumber() && newData.child('pm').isNumber() && "
 "(("                                                    # --- BAYAR ---
 f"(!data.exists() || data.child('pend').val() === 0) && newData.child('seed').val() === now && "
 f"newData.child('n').val() === (data.exists() ? data.child('n').val() : 0) && newData.child('pr').val() === (data.exists() ? data.child('pr').val() : 0) && "
 f"newData.child('pl').val() === (data.exists() ? data.child('pl').val() : 0) && newData.child('pm').val() === (data.exists() ? data.child('pm').val() : 0) && ("
 f"(newData.child('mode').val() === 0 && newData.child('pend').val() === 1 && {SHARD_OLD} - {SHARD_NEW} === 150) || "
 f"(newData.child('mode').val() === 1 && newData.child('pend').val() === 5 && {SHARD_OLD} - {SHARD_NEW} === 650) || "
 f"(newData.child('mode').val() === 2 && newData.child('pend').val() === 1 && {SHARD_OLD} - {SHARD_NEW} === 50 && !data.parent().child('own').exists())"
 ")) || ("                                              # --- BUKA HASIL (satu per satu) ---
 "data.exists() && data.child('pend').val() >= 1 && newData.child('pend').val() === data.child('pend').val() - 1 && "
 "newData.child('seed').val() === data.child('seed').val() && newData.child('mode').val() === data.child('mode').val() && "
 "newData.child('n').val() === data.child('n').val() + 1 && "
 "newData.parent().child('last').child('ts').val() === now && "
 "(data.child('mode').val() === 2 ? (newData.child('pr').val() === data.child('pr').val() && newData.child('pl').val() === data.child('pl').val() && newData.child('pm').val() === data.child('pm').val()) : "
 "(newData.child('pm').val() === (newData.parent().child('last').child('rar').val() === 3 ? 0 : data.child('pm').val() + 1) && "
 "newData.child('pl').val() === (newData.parent().child('last').child('rar').val() >= 2 ? 0 : data.child('pl').val() + 1) && "
 "newData.child('pr').val() === (newData.parent().child('last').child('rar').val() >= 1 ? 0 : data.child('pr').val() + 1))"
 ")))")

last_validate = (
 f"newData.hasChildren(['s', 'rar', 'idx', 'roll', 'ts', 'n']) && newData.child('ts').val() === now && {SP}.exists() && {SP}.child('pend').val() >= 1 && "
 f"newData.child('n').val() === {SP}.child('n').val() && newData.parent().child('spin').child('n').val() === {SP}.child('n').val() + 1"
)
RARN = "newData.parent().child('rar').val()"
IDXN = "newData.parent().child('idx').val()"
last_children = {
 'roll': {'.validate': f"newData.isNumber() && newData.val() % 1 === 0 && newData.val() === {ROLL}"},
 'rar': {'.validate': f"newData.isNumber() && newData.val() === {RAR}"},
 'idx': {'.validate': f"newData.isNumber() && newData.val() % 1 === 0 && newData.val() === ({ROLL2}) % {LEN(RARN)}"},
 's': {'.validate': f"newData.isNumber() && newData.val() === {BASE(RARN)} + {IDXN}"},
 'ts': {'.validate': 'newData.isNumber()'}, 'n': {'.validate': 'newData.isNumber()'},
}

own_validate = (
 "newData.isNumber() && newData.val() >= 1 && newData.val() <= 99 && newData.val() % 1 === 0 && ("
 "(newData.val() === (data.exists() ? data.val() : 0) + 1 && newData.parent().parent().child('last').child('ts').val() === now && newData.parent().parent().child('last').child('s').val() + '' === $sid) || "
 "(data.exists() && data.val() >= 2 && newData.val() === data.val() - 1 && newData.parent().parent().child('sell').child('ts').val() === now && newData.parent().parent().child('sell').child('s').val() + '' === $sid))"
)

SC = "newData.parent().child('sc').val()"
SEL = "newData.parent().child('sel').val()"
FL = f"({SC})"
dino = {
 '$uid': {
  '.read': "auth != null && auth.uid === $uid",
  'daily': {
   '.write': "auth != null && auth.uid === $uid && newData.exists()",
   '.validate': f"newData.hasChildren(['d', 'n', 't']) && newData.child('t').val() === now && newData.child('d').val() === {DAY} && newData.child('n').isNumber() && newData.child('n').val() >= 1 && newData.child('n').val() <= 10 && "
                f"newData.child('n').val() === (data.exists() && data.child('d').val() === {DAY} ? data.child('n').val() + 1 : 1) && newData.parent().child('run').child('t').val() === now",
   'd': {'.validate': 'newData.isNumber()'}, 'n': {'.validate': 'newData.isNumber()'}, 't': {'.validate': 'newData.isNumber()'},
   '$other': {'.validate': False}},
  'run': {
   '.write': "auth != null && auth.uid === $uid && newData.exists()",
   '.validate': "newData.hasChildren(['t', 'sel']) && newData.child('t').isNumber() && ((newData.child('t').val() === now && newData.parent().child('daily').child('t').val() === now && !newData.child('sc').exists() && !newData.child('e').exists()) || "
                "(data.exists() && newData.child('t').val() === data.child('t').val() && newData.child('sel').val() === data.child('sel').val()))",
   't': {'.validate': 'newData.isNumber() && (newData.val() === now || (data.exists() && newData.val() === data.val()))'},
   'sel': {'.validate': "newData.isNumber() && newData.val() % 1 === 0 && newData.val() >= -1 && newData.val() <= 11 && (newData.val() === -1 || newData.parent().parent().child('own').child(newData.val() + '').exists()) && (newData.parent().child('t').val() === now || (data.exists() && newData.val() === data.val()))"},
   'sc': {'.validate': f"!data.exists() && newData.isNumber() && newData.val() % 1 === 0 && newData.val() >= 0 && newData.val() <= 999999 && newData.parent().child('t').exists() && newData.val() <= (now - newData.parent().child('t').val()) / 1000 * 25 + 60"},
   'e': {'.validate': f"!data.exists() && newData.isNumber() && newData.parent().child('sc').exists() && newData.val() === ({FL} < {CAP(SEL)} ? {FL} : {CAP(SEL)})"},
   '$other': {'.validate': False}},
  'best': {'.write': "auth != null && auth.uid === $uid && newData.exists()",
           '.validate': "newData.isNumber() && newData.val() % 1 === 0 && newData.val() >= 0 && newData.parent().child('run').child('sc').val() === newData.val() && newData.val() > (data.exists() ? data.val() : -1) && !data.parent().child('run').child('sc').exists()"},
  'total': {'.write': "auth != null && auth.uid === $uid && newData.exists()",
            '.validate': "newData.isNumber() && newData.val() === (data.exists() ? data.val() : 0) + newData.parent().child('run').child('sc').val() && !data.parent().child('run').child('sc').exists()"},
  'selected': {'.write': "auth != null && auth.uid === $uid && newData.exists()",
               '.validate': "newData.isNumber() && newData.val() % 1 === 0 && newData.val() >= -1 && newData.val() <= 11 && (newData.val() === -1 || newData.parent().child('own').child(newData.val() + '').exists())"},
  'own': {'$sid': {'.write': "auth != null && auth.uid === $uid && newData.exists() && $sid.matches(/^([0-9]|1[01])$/)", '.validate': own_validate}},
  'spin': {'.write': "auth != null && auth.uid === $uid && newData.exists()", '.validate': spin_validate,
           **{k: {'.validate': 'newData.isNumber() && newData.val() >= 0 && newData.val() % 1 === 0'} for k in ('seed', 'pend', 'mode', 'n', 'pr', 'pl', 'pm')}, '$other': {'.validate': False}},
  'last': {'.write': "auth != null && auth.uid === $uid && newData.exists()", '.validate': last_validate,
           **last_children, '$other': {'.validate': False}},
  'sell': {'.write': "auth != null && auth.uid === $uid && newData.exists()",
           '.validate': "newData.hasChildren(['s', 'ts']) && newData.child('ts').val() === now && newData.child('s').isNumber() && newData.child('s').val() % 1 === 0 && newData.child('s').val() >= 0 && newData.child('s').val() <= 11",
           's': {'.validate': 'newData.isNumber()'}, 'ts': {'.validate': 'newData.isNumber()'}, '$other': {'.validate': False}},
  '$other': {'.validate': False},
 }
}
r['dino_game'] = dino

# ---- AkimiShard: tambahkan jalur Dino (belanja undian, hadiah main, jual duplikat) ----
sh = r['users']['$uid']['shard']
if 'dino_game' not in sh['.write']:
    RN = "newData.parent().parent().parent()"
    D_NEW = f"{RN}.child('dino_game').child($uid)"
    EARN = f"newData.val() > data.val() && {D_NEW}.child('run').child('sc').exists() && !{OLD}.child('run').child('sc').exists() && newData.val() === data.val() + {D_NEW}.child('run').child('e').val()"
    sid = f"{D_NEW}.child('sell').child('s').val()"
    SELL = (f"newData.val() > data.val() && {D_NEW}.child('sell').child('ts').val() === now && "
            f"{D_NEW}.child('own').child({sid} + '').val() === {OLD}.child('own').child({sid} + '').val() - 1 && newData.val() === data.val() + {PRICE(sid)}")
    SPEND = f"newData.val() < data.val() && {D_NEW}.child('spin').child('seed').val() === now"
    DINO_W = f"auth.uid === $uid && data.exists() && (({SPEND}) || ({EARN}) || ({SELL}))"
    head = "auth != null && newData.exists() && "
    inner = sh['.write'][len(head):]
    sh['.write'] = head + "(" + inner + " || (" + DINO_W + "))"
    old_v = "(newData.val() === data.val() || (auth.uid === $uid && newData.val() < data.val()))"
    assert old_v in sh['.validate']
    sh['.validate'] = sh['.validate'].replace(old_v, "(newData.val() === data.val() || (auth.uid === $uid && newData.val() < data.val()) || (auth.uid === $uid && newData.val() > data.val()))")

lines = [json.dumps(k) + ':' + json.dumps(v, separators=(',', ':'), ensure_ascii=False) for k, v in r.items()]
open(path, 'w', encoding='utf8').write('{"rules":{\n' + ',\n'.join(lines) + '\n}}\n')
print('rules ok', os.path.getsize(path))
