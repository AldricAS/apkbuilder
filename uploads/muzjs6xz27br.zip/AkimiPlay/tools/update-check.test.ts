// Tes logika force update. Jalankan: npx tsx tools/update-check.test.ts
import { compareVersions, decideUpdate, parseAppConfig, parseInstalledVersion, parseVersion, safeUpdateUrl } from '../src/lib/version'

let fail = 0
const eq = (name: string, got: unknown, want: unknown) => {
  const ok = JSON.stringify(got) === JSON.stringify(want)
  if (!ok) fail++
  console.log(`${ok ? 'OK   ' : 'SALAH'} ${name}  -> ${JSON.stringify(got)}${ok ? '' : `  (seharusnya ${JSON.stringify(want)})`}`)
}
const URL_OK = 'https://contoh.com/AkimiPlay-1.0.1.apk'
const cfg = (minimum: string, latest: string, extra: Record<string, unknown> = {}) =>
  parseAppConfig({ latestVersion: latest, minimumVersion: minimum, updateUrl: URL_OK, updateMessage: 'x', enabled: true, ...extra })
const run = (installed: string, minimum: string, latest: string) => decideUpdate(parseInstalledVersion(installed), cfg(minimum, latest))

console.log('--- pembanding versi')
eq('1.0.9 < 1.0.10', compareVersions(parseVersion('1.0.9')!, parseVersion('1.0.10')!), -1)
eq('1.0.10 > 1.0.9', compareVersions(parseVersion('1.0.10')!, parseVersion('1.0.9')!), 1)
eq('1.0.1 == 1.0.1', compareVersions(parseVersion('1.0.1')!, parseVersion('1.0.1')!), 0)
eq('1.1.0 > 1.0.10', compareVersions(parseVersion('1.1.0')!, parseVersion('1.0.10')!), 1)
eq('2.0.0 > 1.99.99', compareVersions(parseVersion('2.0.0')!, parseVersion('1.99.99')!), 1)
eq('1.0 == 1.0.0', compareVersions(parseVersion('1.0')!, parseVersion('1.0.0')!), 0)
eq('v1.0.1 == 1.0.1', compareVersions(parseVersion('v1.0.1')!, parseVersion('1.0.1')!), 0)

console.log('--- skenario wajib (min 1.0.1 / latest 1.0.1)')
eq('1.0.0', run('1.0.0', '1.0.1', '1.0.1'), 'force')
eq('1.0.1', run('1.0.1', '1.0.1', '1.0.1'), 'normal')
eq('1.0.2', run('1.0.2', '1.0.1', '1.0.1'), 'normal')
console.log('--- skenario wajib (min 1.0.1 / latest 1.0.2)')
eq('1.0.0', run('1.0.0', '1.0.1', '1.0.2'), 'force')
eq('1.0.1', run('1.0.1', '1.0.1', '1.0.2'), 'optional')
eq('1.0.2', run('1.0.2', '1.0.1', '1.0.2'), 'normal')
eq('1.0.3', run('1.0.3', '1.0.1', '1.0.2'), 'normal')
console.log('--- skenario wajib (min 1.0.10)')
eq('TEST 4: 1.0.9', run('1.0.9', '1.0.10', '1.0.10'), 'force')
eq('TEST 5: 1.0.10', run('1.0.10', '1.0.10', '1.0.10'), 'normal')
eq('TEST 6: 1.1.0', run('1.1.0', '1.0.10', '1.0.10'), 'normal')
eq('1.0.11', run('1.0.11', '1.0.10', '1.0.10'), 'normal')

console.log('--- TEST 1/2/3/10 (urutan install)')
eq('TEST 1: 1.0.0 vs min 1.0.1', run('1.0.0', '1.0.1', '1.0.1'), 'force')
eq('TEST 2/10: sesudah update 1.0.1 vs min 1.0.1', run('1.0.1', '1.0.1', '1.0.1'), 'normal')
eq('TEST 3: 1.0.2 vs min 1.0.1', run('1.0.2', '1.0.1', '1.0.1'), 'normal')
eq('versionName berakhiran sufiks "1.0.1-debug"', run('1.0.1-debug', '1.0.1', '1.0.1'), 'normal')

console.log('--- TEST 7/8: data rusak / tidak ada -> tidak memblokir, tidak loop')
eq('TEST 7: config tidak ada (null)', decideUpdate(parseInstalledVersion('1.0.0'), null), 'normal')
eq('versi terpasang tidak terbaca', decideUpdate(null, cfg('1.0.1', '1.0.1')), 'normal')
eq('enabled=false', decideUpdate(parseInstalledVersion('1.0.0'), cfg('1.0.1', '1.0.1', { enabled: false })), 'normal')
eq('enabled tidak ada', decideUpdate(parseInstalledVersion('1.0.0'), parseAppConfig({ minimumVersion: '1.0.1', latestVersion: '1.0.1', updateUrl: URL_OK })), 'normal')
eq('TEST 8: minimumVersion rusak ("abc")', run('1.0.0', 'abc', '1.0.0'), 'normal')
eq('minimumVersion bukan string', decideUpdate(parseInstalledVersion('1.0.0'), parseAppConfig({ minimumVersion: 101, latestVersion: '1.0.0', enabled: true })), 'normal')
eq('latestVersion rusak, minimum valid & terpenuhi', run('1.0.1', '1.0.1', 'xx'), 'normal')
eq('minimum rusak tapi latest lebih baru -> optional', run('1.0.0', 'abc', '1.0.1'), 'optional')
eq('config string / array / angka', [parseAppConfig('x'), parseAppConfig(5), parseAppConfig(undefined)], [null, null, null])
eq('"1.0.1" tidak dianggap < "1.0.1"', run('1.0.1', '1.0.1', '1.0.1') === 'force', false)
eq('"1.0.10" tidak dianggap < "1.0.9"', run('1.0.10', '1.0.9', '1.0.9') === 'force', false)

console.log('--- updateUrl')
eq('https valid', safeUpdateUrl(URL_OK), URL_OK)
eq('kosong', safeUpdateUrl(''), null)
eq('http', safeUpdateUrl('http://contoh.com/a.apk'), null)
eq('javascript:', safeUpdateUrl('javascript:alert(1)'), null)
eq('intent://', safeUpdateUrl('intent://x#Intent;end'), null)
eq('tanpa skema', safeUpdateUrl('contoh.com/a.apk'), null)
eq('berspasi', safeUpdateUrl('https://contoh.com/a b.apk'), null)
eq('bukan string', safeUpdateUrl(123), null)
eq('config dgn url rusak -> updateUrl null', cfg('1.0.1', '1.0.1', { updateUrl: 'ftp://x' })?.updateUrl, null)
eq('url rusak tetap force (halaman memblokir)', decideUpdate(parseInstalledVersion('1.0.0'), cfg('1.0.1', '1.0.1', { updateUrl: '' })), 'force')

process.exit(fail ? 1 : 0)
