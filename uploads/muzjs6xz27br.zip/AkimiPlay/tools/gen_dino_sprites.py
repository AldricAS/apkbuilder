#!/usr/bin/env python3
"""Generator sprite sheet pixel art AkimiGame: Dino Run.
Jalankan: python3 tools/gen_dino_sprites.py   -> public/dino/*.png

Setiap skin = 1 sprite sheet 128x128 (4 kolom x 4 baris, frame 32x32):
  baris 0: idle0, idle1, idle-kedip, hit
  baris 1: run0..run3
  baris 2: jump-antisipasi, jump-launch, jump-udara, landing(squash)
  baris 3: crouch0, crouch1, jatuh(turun), cadangan
Badan dirakit dari bagian-bagian (kepala, torso, ekor, kaki) per pose, lalu diberi shading piksel otomatis,
pola khas skin, aksesori, dan outline. Tidak ada satu gambar statis yang digeser/di-scale.
"""
import os, math, random
from PIL import Image

W = H = 32
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'dino')
os.makedirs(OUT, exist_ok=True)

def hexrgb(h):
    h = h.lstrip('#'); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4)) + (255,)

# ------------------------------------------------------------------ palet
# kunci: L/B/D badan terang/dasar/gelap, W/V perut terang/gelap, S/T jambul dasar/terang, E mata putih, P pupil,
# C cakar, M mulut, X/Y pola 1/2, G aksen bercahaya, R/Q jubah/aksesori 2, O outline
SKINS = {
 'classic':    dict(L='#b4b4be',B='#8e8e99',D='#62626f',W='#e6e1d3',V='#bdb8a8',S='#6d6d7a',T='#9a9aa6',E='#ffffff',P='#15151c',C='#f3efe2',M='#3d3d48',X='#6e6e7b',Y='#a6a6b1',G='#ffffff',R='#8e8e99',Q='#62626f',O='#0e0e13'),
 'leafy':      dict(L='#7fd35a',B='#4aa83a',D='#2b7a2e',W='#efe6bd',V='#c9bd8a',S='#3f9a34',T='#8fe36a',E='#ffffff',P='#12200f',C='#fff6d6',M='#1f5a22',X='#2f8a2d',Y='#9be874',G='#c9ff9a',R='#4aa83a',Q='#2b7a2e',O='#0b1409'),
 'sand':       dict(L='#e3b985',B='#c9955a',D='#9a6a3a',W='#f1dfbd',V='#d2bb92',S='#a8743f',T='#d9a468',E='#ffffff',P='#201208',C='#fff1d6',M='#6b4524',X='#8a5a30',Y='#e8c79a',G='#fff0c8',R='#c9955a',Q='#9a6a3a',O='#150d06'),
 'aqua':       dict(L='#7fd0ff',B='#2f8cf0',D='#1b57c2',W='#bfe9ff',V='#8cc4ee',S='#5cc8ff',T='#d3f3ff',E='#ffffff',P='#081a3a',C='#e6f8ff',M='#12408f',X='#7cc4ff',Y='#d3f3ff',G='#ffffff',R='#2f8cf0',Q='#1b57c2',O='#06142e'),
 'cyber':      dict(L='#3a4a63',B='#1c2638',D='#0e1522',W='#6a7b92',V='#3c4a60',S='#18d2ff',T='#9cf2ff',E='#baf6ff',P='#00b4ff',C='#8fe9ff',M='#00a3d6',X='#12c7ff',Y='#0a86b8',G='#6ff0ff',R='#18d2ff',Q='#0a86b8',O='#04070d'),
 'frost':      dict(L='#ffffff',B='#d6efff',D='#8dc3ee',W='#ffffff',V='#c5e6fb',S='#a6dcff',T='#ffffff',E='#ffffff',P='#1e5fb0',C='#ffffff',M='#5f9fd6',X='#9fd2f7',Y='#ffffff',G='#e8fbff',R='#d6efff',Q='#8dc3ee',O='#173a6a'),
 'flame':      dict(L='#ff7a45',B='#e0362a',D='#a11d1f',W='#ffd187',V='#f0a45a',S='#ff9a2e',T='#ffe45e',E='#fff6d0',P='#6a1000',C='#fff0c0',M='#5a0e0e',X='#ff8a3a',Y='#ffd04a',G='#ffe45e',R='#ff9a2e',Q='#e0362a',O='#240808'),
 'shadow':     dict(L='#6a4aa8',B='#3b2870',D='#221544',W='#7a5ec0',V='#46317f',S='#8a5cf0',T='#c9a6ff',E='#e8d8ff',P='#b46bff',C='#d9bfff',M='#150b2e',X='#5a3ca0',Y='#9b72ff',G='#c58bff',R='#3b2870',Q='#221544',O='#08040f'),
 'galaxy':     dict(L='#4a4ad8',B='#26257f',D='#13124a',W='#6f6ae6',V='#3b3aa8',S='#8a5cf0',T='#e2b6ff',E='#c9f3ff',P='#37c6ff',C='#d6eaff',M='#0c0b34',X='#ff9be8',Y='#7fe0ff',G='#ffffff',R='#26257f',Q='#13124a',O='#05041a'),
 'royal':      dict(L='#fff6e4',B='#f1e2c6',D='#c9b08a',W='#ffffff',V='#e6d6b8',S='#f2c23a',T='#fff0a0',E='#fff7d6',P='#8a5a00',C='#fff6d6',M='#8a6a3a',X='#e0c9a0',Y='#fff6e4',G='#4aa8ff',R='#d02a3a',Q='#8a1424',O='#2a1a08'),
 'mecha':      dict(L='#ffffff',B='#d7e2ee',D='#8fa3b8',W='#a9bccf',V='#6f849a',S='#2fc8ff',T='#b6f1ff',E='#bff6ff',P='#00c2ff',C='#9ff0ff',M='#2a3a4c',X='#5f748a',Y='#2fc8ff',G='#6ff0ff',R='#2fc8ff',Q='#7c90a6',O='#0a1018'),
 'akimidragon':dict(L='#7a4a9a',B='#3a1d52',D='#1d0c2c',W='#ffe9ff',V='#e6b6ff',S='#ff3df0',T='#ffb6ff',E='#ffe0ff',P='#ff3df0',C='#ffe9ff',M='#2a0b3a',X='#8a2fb8',Y='#ff7af5',G='#ffd0ff',R='#c81fd0',Q='#7a1590',O='#0c0414'),
}
# aksen warna cahaya per skin untuk efek di game (juga dipakai UI)
for k,v in SKINS.items(): SKINS[k] = {a: hexrgb(b) for a, b in v.items()}

# ------------------------------------------------------------------ kanvas piksel
class G:
    def __init__(s): s.g = {}
    def set(s, x, y, c, over=True):
        x, y = int(x), int(y)
        if 0 <= x < W and 0 <= y < H and (over or (x, y) not in s.g): s.g[(x, y)] = c
    def get(s, x, y): return s.g.get((x, y))
    def ell(s, cx, cy, rx, ry, c, over=True):
        for y in range(int(cy - ry - 1), int(cy + ry + 2)):
            for x in range(int(cx - rx - 1), int(cx + rx + 2)):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0: s.set(x, y, c, over)
    def rect(s, x, y, w, h, c, over=True):
        for j in range(h):
            for i in range(w): s.set(x + i, y + j, c, over)
    def line(s, x0, y0, x1, y1, c, th=1):
        n = int(max(abs(x1 - x0), abs(y1 - y0))) * 2 + 1
        for i in range(n + 1):
            t = i / n; x = x0 + (x1 - x0) * t; y = y0 + (y1 - y0) * t
            if th <= 1: s.set(round(x), round(y), c)
            else: s.rect(round(x - th / 2 + .5), round(y - th / 2 + .5), th, th, c)
    def stamp(s, ox, oy, rows, mapping=None, over=True):
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch != '.': s.set(ox + i, oy + j, (mapping or {}).get(ch, ch), over)

HEAD = [
 "....bbbbb......",
 "..bbbbbbbbb....",
 ".bbbbbbbbbbbb..",
 ".bbbbbbeeebbbb.",
 "bbbbbbbepebbbbb",
 "bbbbbbbepebbbbb",
 "bbbbbbbbbbbbbbn",
 ".bbbbbbbbbbbbb.",
 "..wwwwwwwwwmm..",
 "...wwwwwwww....",
 "....wwwww......",
]
HEAD_BLINK = [r.replace('eee','bbb').replace('epe','bbb') for r in HEAD]
HEAD_BLINK[4] = "bbbbbbbmmmbbbbb"
HEAD_HIT = [r for r in HEAD]
HEAD_HIT[3] = ".bbbbbbxbxbbbb."; HEAD_HIT[4] = "bbbbbbbbxbbbbbb"; HEAD_HIT[5] = "bbbbbbbxbxbbbbb"

# ------------------------------------------------------------------ pose
class Pose:
    def __init__(s, **k):
        d = dict(dy=0, hx=15, hy=4, tail=0, legs=((0, 0), (0, 0)), tcx=15, tcy=18, trx=7.5, try_=5.5, squash=0, stretch=0,
                 eye='open', arm=(21, 18), tailup=0, lean=0, crouch=False, wing=0, cape=0)
        d.update(k); s.__dict__.update(d)

def run_legs(f):  # (x offset, lift) kaki belakang, kaki depan
    return [((-2, 0), (3, 2)), ((0, 0), (1, 1)), ((3, 2), (-2, 0)), ((1, 1), (0, 0))][f]

def body(skin, p, head_rows=HEAD):
    g = G(); dy = p.dy
    # ekor
    tw = p.tail
    pts = [(9, 18 + dy, 3.6), (6, 19 + dy + tw * .5, 3.2), (3.5, 21 + dy + tw - p.tailup, 2.5), (1.2, 23 + dy + tw - p.tailup * 1.6, 1.5)]
    if p.crouch: pts = [(9, 24 + dy, 3.0), (6, 25 + dy, 2.5), (3.5, 26 + dy + tw * .3, 2.0), (1.0, 27 + dy + tw * .3, 1.2)]
    for x, y, r in pts: g.ell(x, y, r, r, 'b')
    tail_tip = (pts[-1][0], pts[-1][1])
    for t in range(len(pts) - 1):  # perut ekor
        pass
    # kaki jauh (belakang) lalu torso lalu kaki dekat
    def leg(hipx, hipy, ox, lift, code, crouch=False):
        fx = hipx + ox; fy = 30 - lift
        if p.crouch:
            g.ell(hipx, hipy, 3.0, 2.4, code); g.rect(int(fx) - 1, 27, 6, 3, code); g.rect(int(fx) + 3, 29, 3, 1, 'c'); return
        g.ell(hipx, hipy, 3.0, 3.0, code)
        g.line(hipx, hipy + 1, fx + 1, fy - 2, code, th=3)      # paha-betis tebal
        g.rect(int(fx) - 1, int(fy) - 2, 6, 3, code)             # telapak
        g.set(int(fx) + 4, int(fy), 'c'); g.set(int(fx) + 5, int(fy) - 1, 'c'); g.set(int(fx) + 3, int(fy), 'c')
    (b_ox, b_l), (f_ox, f_l) = p.legs
    hipy = 23 + dy + (2 if p.squash else 0)
    leg(13, hipy, b_ox, b_l, 'f'); 
    cy = p.tcy + dy; ry = p.try_ - p.squash * 1.0 + p.stretch * .8
    g.ell(p.tcx, cy, p.trx + p.squash * .8 - p.stretch * .5, ry, 'b')
    # perut
    for y in range(int(cy), int(cy + ry + 1)):
        for x in range(int(p.tcx), int(p.tcx + p.trx + 1)):
            if g.get(x, y) == 'b' and ((x - p.tcx - 1.5) / (p.trx * .75)) ** 2 + ((y - cy - ry * .55) / (ry * .7)) ** 2 <= 1.0: g.set(x, y, 'w')
    leg(19, hipy, f_ox, f_l, 'b')
    # leher + kepala
    hx, hy = p.hx + p.lean, p.hy + dy
    g.rect(hx + 1, hy + 8, 6, 8 - (0 if not p.crouch else 0), 'b', over=False)
    g.stamp(hx, hy, head_rows)
    # lengan
    ax, ay = p.arm[0] + p.lean, p.arm[1] + dy
    g.rect(ax, ay, 2, 2, 'b'); g.set(ax + 2, ay + 2, 'c'); g.set(ax + 1, ay + 2, 'c')
    return g, dict(hx=hx, hy=hy, tail=tail_tip, back=(11, p.tcy + dy - 4), cy=cy)

POSES = {
 'idle0': Pose(legs=((0, 0), (0, 0))),
 'idle1': Pose(dy=1, hy=4, tail=1, legs=((0, 0), (0, 0)), arm=(21, 19)),
 'idleb': Pose(legs=((0, 0), (0, 0)), eye='blink'),
 'hit':   Pose(dy=1, hx=14, tail=-1, tailup=2, lean=-1, legs=((-2, 0), (3, 0)), eye='hit', arm=(20, 18)),
 'run0':  Pose(dy=0, tail=0, legs=run_legs(0), lean=0),
 'run1':  Pose(dy=1, tail=1, legs=run_legs(1), lean=0),
 'run2':  Pose(dy=0, tail=0, legs=run_legs(2), lean=0),
 'run3':  Pose(dy=1, tail=-1, legs=run_legs(3), lean=0),
 'prep':  Pose(dy=4, hx=15, hy=6, squash=1.6, legs=((-1, 0), (1, 0)), tail=-1, arm=(21, 21)),
 'launch':Pose(dy=-1, stretch=1, tail=-1, tailup=2, legs=((-3, 0), (4, 0)), hx=16, lean=1, arm=(22, 18)),
 'air':   Pose(dy=-2, tail=-2, tailup=3, legs=((-3, 3), (4, 4)), lean=1, arm=(22, 18)),
 'land':  Pose(dy=4, squash=2.2, hx=14, legs=((-3, 0), (2, 0)), tail=1, arm=(20, 22)),
 'crouch0': Pose(dy=7, hx=15, hy=8, tcx=14, tcy=19, trx=8, try_=4.0, tcy_=0, crouch=True, legs=((-3, 0), (4, 0)), arm=(22, 22), lean=1, tail=0),
 'crouch1': Pose(dy=7, hx=15, hy=8, tcx=14, tcy=19, trx=8, try_=4.0, crouch=True, legs=((-2, 0), (5, 0)), arm=(22, 22), lean=1, tail=1),
 'fall':  Pose(dy=-1, tail=-1, tailup=1, legs=((-1, 1), (2, 1)), lean=1, arm=(22, 19)),
 'spare': Pose(),
}
ORDER = ['idle0','idle1','idleb','hit','run0','run1','run2','run3','prep','launch','air','land','crouch0','crouch1','fall','spare']

# ------------------------------------------------------------------ crest/aksesori/pola
def crest_pixels(name, a, p):
    hx, hy = a['hx'], a['hy']; out = []
    def add(rows, ox, oy, m=None): 
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch != '.': out.append((hx + ox + i, hy + oy + j, (m or {}).get(ch, ch)))
    if name == 'classic':
        add(["...s...", "..sss..", ".sssss.", "sssssss"], 2, -3)
    elif name == 'leafy':
        add(["..ss...", ".ssst..", "sssts..", ".ssss.."], 1, -4); add(["s.", "ss"], -1, 0)
    elif name == 'sand':
        add([".ss.", ".sst", "ssss"], 2, -3); add(["ss", "st"], 6, -1)
    elif name == 'aqua':
        add([".t.t..", ".sts..", "stsst.", "sssss."], 1, -4); add(["t", "s"], 8, -2)
    elif name == 'cyber':
        add(["....sss.....", "..sstts.....", ".sssttss....", "sssssssss..."], -2, -3)
    elif name == 'frost':
        add([".t..t.t..", ".st.sts.s", "ssstsssst", "sssssssss"], 0, -4)
    elif name == 'flame':
        add(["..t...t...", ".tst.tst..", ".sss.sss.s", "ssssssssss"], 0, -4)
    elif name == 'shadow':
        add(["s....s", "ss..ss", "sssss.", ".ssss."], 2, -3)
    elif name == 'galaxy':
        add(["..s.s..", ".sstss.", "ssssss."], 2, -3)
    elif name == 'royal':
        add(["s.s.s.s", "ststsss".ljust(8,'s'), "sttsttts", "ssssssss"], 3, -4, {'t': 'T'})
        out.append((hx + 6, hy - 1, 'G'))
    elif name == 'mecha':
        add(["...s...", "..sts..", ".sssss."], 2, -3); add(["..xx", ".xxx"], 0, 0)
    elif name == 'akimidragon':
        # tanduk panjang menyapu ke belakang + jambul api
        add(["......ss", ".....sts", "....ssss", "...sss..", "..ssts..", ".sss....", "ss......"], -1, -7)
        add(["...tt", "..sst", ".ssss"], 7, -3)
    return out

BACK = G()
def accessories(name, g, a, p, f):
    hx, hy = a['hx'], a['hy']
    gf = g; g = BACK if name in ('royal', 'akimidragon') else gf
    for (x, y, c) in crest_pixels(name, a, p): gf.set(x, y, c)
    tx, ty = a['tail']
    if name == 'leafy':
        gf.stamp(int(tx) - 2, int(ty) - 3, ["..s", ".st", "sst", ".ss"], None)
    if name == 'flame':
        gf.stamp(int(tx) - 3, int(ty) - 4 - (f % 2), ["..t", ".ts", "tss", ".st"], None)
    if name == 'aqua':
        gf.stamp(int(tx) - 2, int(ty) - 3, ["t.s", "sts", ".ss"], None)
    if name == 'frost':
        gf.stamp(int(tx) - 2, int(ty) - 3, ["..t", ".ts", "sss"], None)
    if name == 'cyber':
        gf.stamp(int(tx) - 2, int(ty) - 2, ["s..", "tss", "s.s"], None)
    if name == 'shadow':
        gf.stamp(int(tx) - 2, int(ty) - 3, ["s.s", ".s.", "ss."], None)
    if name == 'mecha':
        gf.stamp(int(tx) - 3, int(ty) - 2, ["sts.", "tssg", "sts."], {'g': 'G'})
    if name == 'akimidragon':
        gf.stamp(int(tx) - 3, int(ty) - 5 - (f % 2), ["..t", ".ts", "tss", "sst", ".ss"], None)
    if name == 'royal':
        # jubah merah berkibar: segitiga terisi di belakang punggung, ujungnya bergerak per frame
        bx, by = a['back']; fl = (f % 2) + p.cape
        for k in range(13):
            x = bx + 6 - k
            th = max(1, 5 - k // 3)
            wob = int(round(math.sin((k + fl * 2) * 0.9) * 1.2))
            top = by - 1 + k // 3 + wob
            for t in range(th):
                g.set(x, top + t, 'Q' if t == th - 1 else 'R')
        g.set(bx + 5, by - 1, 'T'); g.set(bx + 6, by, 'T')
    if name == 'akimidragon':
        # sayap membran terisi + tulang sayap, mengepak per frame
        bx, by = a['back']; fl = f % 2 if p.wing == 0 else p.wing
        lift = 3 if fl else 0
        tips = [(bx - 4, by - 8 + lift), (bx + 1, by - 10 + lift), (bx + 5, by - 7 + lift)]
        for yy in range(by - 10 + lift, by + 3):
            for xx in range(bx - 6, bx + 8):
                # titik dalam segitiga (bahu, ujung kiri, ujung kanan)
                def sgn(a1, b1, c1): return (a1[0] - c1[0]) * (b1[1] - c1[1]) - (b1[0] - c1[0]) * (a1[1] - c1[1])
                P = (xx, yy); A = (bx + 3, by + 3); B = tips[0]; C = tips[2]
                d1, d2, d3 = sgn(P, A, B), sgn(P, B, C), sgn(P, C, A)
                neg = d1 < 0 or d2 < 0 or d3 < 0; pos = d1 > 0 or d2 > 0 or d3 > 0
                if not (neg and pos): g.set(xx, yy, 'S', over=False)
        for (tx2, ty2) in tips: g.line(bx + 3, by + 3, tx2, ty2, 'D')
        for (tx2, ty2) in tips: g.set(tx2, ty2, 'T')

def patterns(name, g, f):
    rnd = random.Random(hash(name) & 0xffff)
    for (x, y), c in list(g.g.items()):
        if c not in ('B', 'D', 'L'): continue
        h = (x * 7 + y * 13 + x * y) % 11
        if name == 'classic' and h in (0, 5): g.g[(x, y)] = 'X' if c != 'L' else 'Y'
        elif name == 'leafy' and (x + y // 2) % 5 == 0 and y > 14 and 7 < x < 24: g.g[(x, y)] = 'X'
        elif name == 'sand' and h in (1, 7) and c != 'L': g.g[(x, y)] = 'X'
        elif name == 'aqua' and h == 3: g.g[(x, y)] = 'Y'
        elif name == 'cyber' and ((x % 4 == 0 and 7 < x < 25) and 15 < y < 26): g.g[(x, y)] = 'X'
        elif name == 'cyber' and y == 21 and 9 < x < 20: g.g[(x, y)] = 'Y'
        elif name == 'frost' and h in (2, 8): g.g[(x, y)] = 'Y'
        elif name == 'flame' and h in (0, 6) and c != 'L': g.g[(x, y)] = 'X'
        elif name == 'shadow' and h in (4, 9): g.g[(x, y)] = 'X'
        elif name == 'galaxy' and h in (0, 6): g.g[(x, y)] = 'X' if (x + y) % 3 else 'Y'
        elif name == 'mecha' and ((x + 2) % 5 == 0 or (y % 6 == 0 and 13 < y < 27)) and 7 < x < 24: g.g[(x, y)] = 'X'
        elif name == 'akimidragon' and h == 3 and c == 'D': g.g[(x, y)] = 'X'
    if name == 'cyber':  # lingkaran inti di paha
        for (dx, dy2) in [(0, 0), (1, 0), (0, 1), (1, 1)]: g.set(11 + dx, 22 + dy2, 'G') if g.get(11 + dx, 22 + dy2) in ('B', 'D', 'X', 'L') else None
    if name == 'mecha':
        for (dx, dy2) in [(0, 0), (1, 0)]: g.set(13 + dx, 20 + dy2, 'G') if g.get(13 + dx, 20 + dy2) else None

# ------------------------------------------------------------------ shading + render
def shade(g):
    out = {}
    for (x, y), c in g.g.items():
        if c in ('b', 'f'):
            up = (x, y - 1) in g.g; dn = (x, y + 1) in g.g; lf = (x - 1, y) in g.g
            up2 = (x, y - 2) in g.g; dn2 = (x, y + 2) in g.g
            if c == 'f': out[(x, y)] = 'D' if (x + y) % 3 else 'B'
            elif not up or (not up2 and (x + y) % 2 == 0 and not lf): out[(x, y)] = 'L'
            elif not dn or (not dn2 and (x + y) % 2 == 0): out[(x, y)] = 'D'
            else: out[(x, y)] = 'B'
        elif c == 'w':
            dn = (x, y + 1) in g.g
            out[(x, y)] = 'V' if (not dn or (x + y) % 5 == 0) else 'W'
        else: out[(x, y)] = c
    g.g = out

KEYMAP = {'e': 'E', 'p': 'P', 'c': 'C', 'm': 'M', 'n': 'M', 'x': 'M', 's': 'S', 't': 'T'}
def render(name, pal, key, outline=True):
    p = POSES[key]; f = int(key[-1]) if key[-1].isdigit() else 0
    rows = HEAD_BLINK if p.eye == 'blink' else HEAD_HIT if p.eye == 'hit' else HEAD
    if name == 'cyber' or name == 'mecha' or name == 'galaxy' or name == 'akimidragon' or name == 'shadow':
        rows = [r.replace('e', 'e') for r in rows]
    BACK.g = {}
    g, a = body(name, p, rows)
    patterns_pre = None
    # jubah/sayap digambar di belakang badan untuk royal & akimidragon (lapis bawah)
    shade(g)
    # jambul & aksesori setelah shading agar warnanya murni
    g2 = G(); accessories(name, g2, a, p, f)
    for k, v in g2.g.items():
        g.g[k] = KEYMAP.get(v, v) if v in KEYMAP else v
    patterns(name, g, f)
    for k2, v2 in BACK.g.items():
        if k2 not in g.g: g.g[k2] = v2
    # mata bercahaya
    if name in ('cyber', 'mecha', 'galaxy', 'akimidragon', 'shadow', 'frost', 'flame'):
        for k, v in list(g.g.items()):
            if v == 'P': g.g[k] = 'P'
    # mapping kunci hurup -> palet
    for k, v in list(g.g.items()): g.g[k] = KEYMAP.get(v, v)
    img = Image.new('RGBA', (W, H), (0, 0, 0, 0)); px = img.load()
    pset = set(g.g.keys())
    if outline:
        oc = pal['O']
        for (x, y) in pset:
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    q = (x + dx, y + dy)
                    if q not in pset and 0 <= q[0] < W and 0 <= q[1] < H: px[q] = oc
    for (x, y), c in g.g.items():
        if c in pal: px[x, y] = pal[c]
    return img

def sheet(name):
    pal = SKINS[name]; sh = Image.new('RGBA', (128, 128), (0, 0, 0, 0))
    for i, key in enumerate(ORDER): sh.paste(render(name, pal, key), ((i % 4) * 32, (i // 4) * 32))
    return sh

if __name__ == '__main__':
    for n in SKINS: sheet(n).save(os.path.join(OUT, f'{n}.png'))
    print('ok', len(SKINS))

# ------------------------------------------------------------------ rintangan + avatar netral
def px_img(w, h, rows, pal):
    im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); p = im.load()
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch in pal: p[x, y] = hexrgb(pal[ch])
    return im

def outline_img(im, col='#0b0a14'):
    w, h = im.size; o = Image.new('RGBA', (w + 2, h + 2), (0, 0, 0, 0)); o.alpha_composite(im, (1, 1))
    src = o.copy(); sp = src.load(); op = o.load(); c = hexrgb(col)
    for y in range(o.size[1]):
        for x in range(o.size[0]):
            if sp[x, y][3] == 0:
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        xx, yy = x + dx, y + dy
                        if 0 <= xx < o.size[0] and 0 <= yy < o.size[1] and sp[xx, yy][3] > 0: op[x, y] = c
    return o

def make_obstacles():
    """Rintangan digambar langsung pada skala piksel yang sama dengan Dino (tidak di-scale saat game)."""
    cp = {'l': '#9be874', 'g': '#4aa83a', 'd': '#2b7a2e', 'y': '#fff6d6'}
    def cactus(w, h, arms):
        g = [['.'] * w for _ in range(h)]
        tw = 4; x0 = (w - tw) // 2
        for y in range(h):
            for x in range(tw):
                if y == 0 and x in (0, tw - 1): continue
                g[y][x0 + x] = 'l' if x == 0 else ('d' if x == tw - 1 else 'g')
        for side, ay, al in arms:                      # (sisi, tinggi dari bawah, panjang vertikal)
            yy = h - ay
            xs = range(0, x0) if side < 0 else range(x0 + tw, w)
            for x in xs:
                for t in range(3):
                    if 0 <= yy + t < h: g[yy + t][x] = 'g' if t == 1 else ('l' if t == 0 else 'd')
            ax = 0 if side < 0 else w - 3
            for y in range(max(0, yy - al), yy + 3):
                for x in range(ax, ax + 3): g[y][x] = 'l' if x == ax else ('d' if x == ax + 2 else 'g')
        for y in range(2, h - 1, 4): g[y][x0 + 2 - (y // 4) % 2] = 'y' if g[y][x0 + 2 - (y // 4) % 2] != '.' else '.'
        return [''.join(r) for r in g]
    cactus_s = cactus(12, 18, [(-1, 9, 5)])
    cactus_m = cactus(16, 28, [(-1, 14, 8), (1, 18, 7)])
    one = cactus(10, 16, [(1, 8, 4)])
    # kelompok 3 kaktus kecil
    grp = ['.' * 34 for _ in range(18)]
    def blit(dst, src, ox, oy):
        for y, r in enumerate(src):
            for x, ch in enumerate(r):
                if ch != '.':
                    row = list(dst[oy + y]); row[ox + x] = ch; dst[oy + y] = ''.join(row)
    blit(grp, one, 0, 2); blit(grp, cactus(12, 18, [(-1, 9, 5)]), 10, 0); blit(grp, one, 23, 2)
    rp = {'a': '#8e8e99', 'b': '#62626f', 'c': '#c3c3cd', 'd': '#3d3d48'}
    rock = ["......ccccc.......", "....ccccccaaa.....", "...cccccaaaaaab...", "..ccccaaaaaaabbb..", ".cccaaaaaaaabbbbb.", "ccaaaaaaabbbbbbbbd", "caaaaabbbbbbbbbddd", "aabbbbbbbbbbddddd."]
    bp = {'m': '#ff3df0', 'n': '#8a1fa8', 'w': '#ffe0ff', 'e': '#ffd84a', 'k': '#2a0b3a', 'p': '#ff9af5'}
    bird0 = ["...........pp...........", "..........ppmm..........", ".........ppmmn..........", "........ppmmmn..........", "...m...ppmmmmn..........", "...mm.ppmmwmmmnkkee.....", "....mmppmmmmmmnnnee.....", ".....mmmmmmmmmn.........", "......nmmmmmnn..........", ".......nnnnn............", "........n.n.............", "........................"]
    bird1 = ["........................", "........................", "........................", "...m....................", "...mm...........kk......", "....mm.mmmmmmmmnkkee....", ".....mmmmmwmmmmnnnee....", "......pmmmmmmmmn........", ".......ppmmmmmnn........", "........ppmmmnn.........", ".........ppmnn..........", "..........pn............"]
    items = [outline_img(px_img(12, 18, cactus_s, cp)), outline_img(px_img(16, 28, cactus_m, cp)), outline_img(px_img(34, 18, grp, cp)),
             outline_img(px_img(18, 8, rock, rp)), outline_img(px_img(24, 12, bird0, bp)), outline_img(px_img(24, 12, bird1, bp))]
    names = ['cactusS', 'cactusM', 'cactusG', 'rock', 'bird0', 'bird1']
    sheet_ = Image.new('RGBA', (160, 32), (0, 0, 0, 0)); meta = {}; x = 0
    for n, im in zip(names, items):
        sheet_.alpha_composite(im, (x, 0)); meta[n] = (x, 0, im.size[0], im.size[1]); x += im.size[0] + 1
    sheet_.save(os.path.join(OUT, 'obstacles.png'))
    import json
    json.dump(meta, open(os.path.join(OUT, 'obstacles.json'), 'w'))
    print('obstacles', meta)

def make_neutral():
    # avatar netral BUKAN dino: "Akimi Orb" bulat dengan dua kaki mungil
    pal = {'a': '#ffd3e3', 'b': '#ff8fb3', 'c': '#c0489f', 'e': '#ffffff', 'p': '#2a0b3a', 'f': '#8b1f6b', 'h': '#fff0f6'}
    base = ["....bbbbbb....", "..bbhhhhbbbb..", ".bbhhaaabbbbb.", ".bhaaaaabbbbb.", "baaaaeeaabbbbb", "baaaaepaabbbcb", "baaaaepaabbcc.", "baaaaaaaabbcc.", ".bbaaaaabbccc.", ".bbbbbbbbccc..", "..bbbbbbcccc..", "...ccccccc...."]
    sq = ["..............", "....bbbbbb....", "..bbhhhhbbbb..", ".bhhaaabbbbbb.", "baaaaeeaabbbbb", "baaaaepaabbbcb", "baaaaaaaabbccb", ".bbaaaaabbcccb", "..bbbbbbbcccc.", "...cccccccc..."]
    st = ["....bbbb....", "...bhhabb...", "..bhaaabbb..", "..baeeabbb..", "..baepabbb..", "..baaaabcb..", "..baaaabcb..", "..bbaabbcb..", "..bbbbbccb..", "...bbbbccb..", "...bbbcccb..", "....cccccc.."]
    def feet(ph): return {0: [(3, 0), (9, -1)], 1: [(4, 0), (8, 0)], 2: [(3, -1), (9, 0)], 3: [(4, 0), (8, 0)]}[ph]
    sh = Image.new('RGBA', (128, 128), (0, 0, 0, 0))
    def put(idx, rows, dy=0, ph=None):
        im = px_img(14, len(rows), rows, pal); im = outline_img(im)
        fr = Image.new('RGBA', (32, 32), (0, 0, 0, 0)); h = im.size[1]
        fr.alpha_composite(im, (9, 30 - h - 1 + dy + (0 if ph is None else 0)))
        if ph is not None:
            fp = Image.new('RGBA', (32, 32), (0, 0, 0, 0)); f = fr.load()
            for fx, fy in feet(ph):
                for t in range(3): f[10 + fx + t, 29 + fy] = hexrgb('#8b1f6b'); f[10 + fx + t, 28 + fy] = hexrgb('#0b0a14')
        sh.paste(fr, ((idx % 4) * 32, (idx // 4) * 32))
    for i in (0, 1, 2, 3): put(i, base, dy=0 if i != 1 else 1)
    for i in (4, 5, 6, 7): put(i, base, dy=-(i % 2), ph=i - 4)
    put(8, sq, dy=0); put(9, st, dy=-2); put(10, base, dy=-3); put(11, sq, dy=0)
    put(12, sq, dy=0); put(13, sq, dy=0); put(14, base, dy=-1); put(15, base)
    sh.save(os.path.join(OUT, 'neutral.png'))

if __name__ == '__main__':
    make_obstacles(); make_neutral()
