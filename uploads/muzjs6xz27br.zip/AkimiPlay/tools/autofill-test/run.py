import http.server,threading,socketserver,os,json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',8795),Q)
threading.Thread(target=srv.serve_forever,daemon=True).start()
from playwright.sync_api import sync_playwright
FILL={'amount':5000,'message':'uidABC123xyz','name':'Akimi Sama','email':'akimi@example.com'}
script=open('../../android/app/src/main/assets/sociabuzz_autofill.js').read()
def run(v,pre=None,expect=None,delay=1500,host_ok=True):
    with sync_playwright() as p:
        b=p.chromium.launch();pg=b.new_page(viewport={'width':390,'height':800})
        pg.on('pageerror',lambda e:print('  pageerror',e))
        # hostname harus sociabuzz.com: pakai route agar bisa memuat mock dari host palsu
        host='sociabuzz.com' if host_ok else 'evil.example'
        pg.route(f'http://{host}/**',lambda r:r.fulfill(body=open('mock.html').read(),content_type='text/html'))
        pg.goto(f'http://{host}/m?v={v}&d={delay}')
        pg.evaluate("f=>{window.__AKIMI_FILL=f}",FILL)
        pg.evaluate(script)   # seperti evaluateJavascript pada onPageFinished
        if pre: pg.wait_for_timeout(delay+200); pre(pg)
        pg.wait_for_timeout(delay+(7000 if v=='nolabel' else 2500))
        st=pg.evaluate("window.__state")
        dom={k:pg.evaluate(f"document.getElementById('{i}')&&document.getElementById('{i}').value") for k,i in [('amount','amt'),('message','msg'),('name','nm'),('email','em')]}
        checks=pg.evaluate("['anon','hide','decl','age'].map(i=>document.getElementById(i)&&document.getElementById(i).checked)")
        b.close()
    return st,dom,checks
def show(n,r):
    st,dom,ck=r;print(n);print('  state(React)=',{k:st[k] for k in ['amount','message','name','email']});print('  dom         =',dom);print('  checkbox    =',ck)
show('1) EN, input ala React, render tertunda 1.5s',run('en'))
show('2) ID (label Indonesia)',run('id'))
show('3) tanpa label (fallback urutan), render 1s',run('nolabel',delay=1000))
def typed(pg):
    pg.fill('#nm','Nama Ketik Sendiri')
show('4) pengguna sudah mengetik nama sendiri -> tidak boleh ditimpa',run('en',pre=typed))
show('5) host BUKAN sociabuzz -> tidak boleh mengisi apa pun',run('en',host_ok=False))
srv.shutdown()
