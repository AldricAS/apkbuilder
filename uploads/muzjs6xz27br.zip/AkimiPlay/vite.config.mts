import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { readFileSync } from 'node:fs'

const app = JSON.parse(readFileSync('app.config.json', 'utf-8'))

export default defineConfig({
  plugins: [
    react(),
    {
      name: 'akimi-html-vars',
      transformIndexHtml: (html) => html.replaceAll('%APP_NAME%', app.appName),
    },
  ],
  define: {
    __APP_NAME__: JSON.stringify(app.appName),
    __APP_VERSION__: JSON.stringify(app.version),
  },
  build: {
    target: 'es2020',
    outDir: 'dist',
    sourcemap: false,
    chunkSizeWarningLimit: 900,
  },
  server: { host: true, port: 5173 },
})
