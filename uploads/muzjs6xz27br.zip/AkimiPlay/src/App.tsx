import { useEffect, useRef, useState } from 'react'
import { NavProvider, useNav, type Tab } from './nav/router'
import { exitApp, useBackHandler } from './native/native'
import { BottomNav } from './components/BottomNav'
import { ErrorBoundary } from './components/ErrorBoundary'
import { OfflineBanner, ToastHost, toast } from './components/Feedback'
import { HomePage } from './pages/HomePage'
import { OngoingPage } from './pages/OngoingPage'
import { FavoritesPage } from './pages/FavoritesPage'
import { HistoryPage } from './pages/HistoryPage'
import { AccountPage } from './pages/AccountPage'
import { DetailPage } from './pages/DetailPage'
import { PlayerPage } from './pages/PlayerPage'
import { SearchPage } from './pages/SearchPage'
import { GenrePage } from './pages/GenrePage'
import { ChatPage } from './pages/ChatPage'
import { DmPage } from './pages/DmPage'
import { ClansPage } from './pages/ClansPage'
import { ClanPage } from './pages/ClanPage'
import { ClanColorPage } from './pages/ClanColorPage'
import { PremiumPage } from './pages/PremiumPage'
import { ClanTagSync } from './components/ClanTagSync'
import { ProfilePage } from './pages/ProfilePage'
import { LeaderboardPage } from './pages/LeaderboardPage'
import { AkimiGamesPage } from './pages/AkimiGamesPage'
import { NobarPage } from './pages/NobarPage'
import { DinoPage } from './pages/DinoPage'
import { DownloadsHome } from './pages/DownloadsPage'
import { SettingsPage } from './pages/SettingsPage'
import { ConnectionsPage } from './pages/ConnectionsPage'
import { FindFriendPage } from './pages/FindFriendPage'
import { AuthGate } from './auth/AuthGate'
import { AuthProvider, useProfile } from './auth/AuthProvider'
import { ensureUserIndex } from './services/friendService'
import { BannerHost } from './components/BannerHost'
import { UpdateGate } from './components/UpdateGate'

const TAB_PAGES: Record<Tab, () => JSX.Element> = {
  home: HomePage,
  ongoing: OngoingPage,
  favorites: FavoritesPage,
  history: HistoryPage,
  account: AccountPage,
}
const TABS = Object.keys(TAB_PAGES) as Tab[]

/** Memastikan akun ini bisa dicari lewat User ID (membuat peta ID -> UID sekali saja; tidak mengubah User ID). */
function FriendIndexBoot() {
  const me = useProfile()
  useEffect(() => {
    void ensureUserIndex(me)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [me.uid, me.userId])
  return null
}

function Shell() {
  const nav = useNav()
  const [visited, setVisited] = useState<Set<Tab>>(new Set(['home']))
  const lastBack = useRef(0)

  useEffect(() => {
    setVisited((v) => (v.has(nav.tab) ? v : new Set(v).add(nav.tab)))
  }, [nav.tab])

  // Back dasar: tutup halaman -> kembali ke Home -> tekan dua kali untuk keluar
  useBackHandler(() => {
    if (nav.stack.length) {
      nav.pop()
      return true
    }
    if (nav.tab !== 'home') {
      nav.setTab('home')
      return true
    }
    const now = Date.now()
    if (now - lastBack.current < 2000) {
      exitApp()
    } else {
      lastBack.current = now
      toast('Tekan sekali lagi untuk keluar')
    }
    return true
  }, 0)

  const top = nav.stack.length - 1

  return (
    <div className="relative h-full w-full overflow-hidden bg-ink">
      {/* tab utama: dimuat saat pertama dibuka, lalu disembunyikan agar posisi scroll tetap */}
      {TABS.map((t) => {
        if (!visited.has(t)) return null
        const Page = TAB_PAGES[t]
        return (
          <div key={t} className={nav.tab === t ? 'absolute inset-0' : 'hidden'}>
            <Page />
          </div>
        )
      })}

      <FriendIndexBoot />
      <BannerHost />
      <ClanTagSync />
      <BottomNav tab={nav.tab} onChange={nav.setTab} />

      {/* halaman bertumpuk: detail, player, pencarian, genre.
          Sengaja TANPA animasi fade-in: fade mulai dari opacity 0 membuat halaman di bawahnya (Home) terlihat
          menembus selama animasi, apalagi saat halaman baru berat dirender. Sekarang langsung solid. */}
      {nav.stack.map((r, i) => (
        <div key={r.key} className={`fixed inset-0 z-40 bg-ink ${i === top ? '' : 'hidden'}`}>
          {r.name === 'detail' ? <DetailPage id={r.id} hint={r.hint} /> : null}
          {r.name === 'search' ? <SearchPage /> : null}
          {r.name === 'chat' ? <ChatPage /> : null}
          {r.name === 'dm' ? <DmPage uid={r.uid} /> : null}
          {r.name === 'profile' ? <ProfilePage uid={r.uid} /> : null}
          {r.name === 'leaderboard' ? <LeaderboardPage /> : null}
          {r.name === 'settings' ? <SettingsPage /> : null}
          {r.name === 'connections' ? <ConnectionsPage /> : null}
          {r.name === 'findfriend' ? <FindFriendPage /> : null}
          {r.name === 'akimigames' ? <AkimiGamesPage /> : null}
          {r.name === 'nobar' ? <NobarPage /> : null}
          {r.name === 'dino' ? <DinoPage /> : null}
          {r.name === 'clans' ? <ClansPage /> : null}
          {r.name === 'clan' ? <ClanPage id={r.id} /> : null}
          {r.name === 'clanColors' ? <ClanColorPage id={r.id} /> : null}
          {r.name === 'premium' ? <PremiumPage /> : null}
          {r.name === 'downloads' ? <DownloadsHome onBack={nav.pop} initialAnimeId={r.animeId} /> : null}
          {r.name === 'genre' ? <GenrePage id={r.id} title={r.title} /> : null}
        </div>
      ))}

      {/* player global: tetap hidup saat diperkecil menjadi mini player */}
      {nav.player ? (
        <PlayerPage
          key={nav.player.key}
          anime={nav.player.anime}
          episodeId={nav.player.episodeId}
          minimized={nav.player.minimized}
          nobarOwner={nav.player.nobar}
        />
      ) : null}

      <OfflineBanner />
      <ToastHost />
    </div>
  )
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <AuthGate>
          <UpdateGate>
            <NavProvider>
              <Shell />
            </NavProvider>
          </UpdateGate>
        </AuthGate>
      </AuthProvider>
    </ErrorBoundary>
  )
}
