// Rentang detik yang sudah ditonton (untuk anti-abuse XP: detik yang sama tidak dihitung dua kali).
export type Range = [number, number]

const total = (rs: Range[]) => rs.reduce((n, [a, b]) => n + (b - a), 0)

export function mergeRanges(rs: Range[]): Range[] {
  const sorted = [...rs].sort((p, q) => p[0] - q[0])
  const out: Range[] = []
  for (const r of sorted) {
    const last = out[out.length - 1]
    if (last && r[0] <= last[1] + 1e-4) last[1] = Math.max(last[1], r[1])
    else out.push([r[0], r[1]])
  }
  return out
}

export function addRange(ranges: Range[], a: number, b: number): { ranges: Range[]; added: number } {
  if (!(b > a)) return { ranges, added: 0 }
  const before = total(ranges)
  const merged = mergeRanges([...ranges, [a, b]])
  return { ranges: merged, added: Math.max(0, total(merged) - before) }
}

export function serializeRanges(rs: Range[]): string {
  let list = mergeRanges(rs.map(([a, b]) => [Math.floor(a * 10) / 10, Math.ceil(b * 10) / 10] as Range))
  let gap = 1
  const fmt = (l: Range[]) => l.map(([a, b]) => `${a.toFixed(1)}-${b.toFixed(1)}`).join(',')
  while (fmt(list).length > 2800 && gap < 600) {
    // terlalu panjang: gabungkan rentang yang berdekatan
    const out: Range[] = []
    for (const r of list) {
      const last = out[out.length - 1]
      if (last && r[0] - last[1] <= gap) last[1] = r[1]
      else out.push([r[0], r[1]])
    }
    list = out
    gap *= 2
  }
  return fmt(list)
}

export function parseRanges(s?: string | null): Range[] {
  if (!s || typeof s !== 'string') return []
  const out: Range[] = []
  for (const part of s.split(',')) {
    const [a, b] = part.split('-').map(Number)
    if (Number.isFinite(a) && Number.isFinite(b) && b > a) out.push([a, b])
  }
  return mergeRanges(out)
}
