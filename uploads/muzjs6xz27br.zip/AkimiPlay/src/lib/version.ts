// Perbandingan versi + keputusan update. Murni (tanpa Firebase/Android) supaya mudah dites.
// Versi dibandingkan ANGKA PER ANGKA (1.0.10 > 1.0.9), bukan sebagai string.

export type Version = number[]
export type UpdateDecision = 'normal' | 'optional' | 'force'

/** "1.0.10" / "v1.0.10" -> [1,0,10]. Format tidak valid -> null (jangan pernah menebak versi). */
export function parseVersion(raw: unknown): Version | null {
  if (typeof raw !== 'string') return null
  const s = raw.trim().replace(/^v/i, '')
  if (!/^\d{1,6}(\.\d{1,6}){0,3}$/.test(s)) return null
  return s.split('.').map(Number)
}

/** versionName Android kadang berakhiran sufiks (mis. "1.0.1-debug"); ambil bagian angkanya saja. */
export function parseInstalledVersion(raw: unknown): Version | null {
  if (typeof raw !== 'string') return null
  return parseVersion(raw.trim().split(/[-+\s]/)[0])
}

/** -1 jika a < b, 0 jika sama, 1 jika a > b. Panjang berbeda dianggap diisi 0 (1.0 == 1.0.0). */
export function compareVersions(a: Version, b: Version): -1 | 0 | 1 {
  const n = Math.max(a.length, b.length)
  for (let i = 0; i < n; i++) {
    const x = a[i] ?? 0
    const y = b[i] ?? 0
    if (x !== y) return x < y ? -1 : 1
  }
  return 0
}

export type AppConfig = {
  enabled: boolean
  latest: Version | null
  latestRaw: string
  minimum: Version | null
  minimumRaw: string
  /** hanya URL https yang valid; selain itu null */
  updateUrl: string | null
  message: string
}

/** Hanya URL HTTPS yang valid. Kosong / http / format rusak -> null. */
export function safeUpdateUrl(raw: unknown): string | null {
  if (typeof raw !== 'string') return null
  const s = raw.trim()
  if (!s || s.length > 500 || /\s/.test(s)) return null
  try {
    const u = new URL(s)
    return u.protocol === 'https:' && u.hostname ? u.toString() : null
  } catch {
    return null
  }
}

/** Data mentah dari app_config -> AppConfig aman. Bukan objek -> null. Nilai rusak diabaikan, bukan ditebak. */
export function parseAppConfig(raw: unknown): AppConfig | null {
  if (!raw || typeof raw !== 'object') return null
  const r = raw as Record<string, unknown>
  const str = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '')
  return {
    enabled: r.enabled === true,
    latest: parseVersion(r.latestVersion),
    latestRaw: str(r.latestVersion, 20),
    minimum: parseVersion(r.minimumVersion),
    minimumRaw: str(r.minimumVersion, 20),
    updateUrl: safeUpdateUrl(r.updateUrl),
    message: str(r.updateMessage, 200),
  }
}

/**
 * installed < minimum                      -> force
 * minimum <= installed < latest            -> optional
 * installed >= latest (atau tidak ada data) -> normal
 * Versi terpasang tidak diketahui, config kosong / enabled bukan true / versinya rusak -> normal (tidak memblokir).
 */
export function decideUpdate(installed: Version | null, cfg: AppConfig | null): UpdateDecision {
  if (!installed || !cfg || !cfg.enabled) return 'normal'
  if (cfg.minimum && compareVersions(installed, cfg.minimum) < 0) return 'force'
  if (cfg.latest && compareVersions(installed, cfg.latest) < 0) return 'optional'
  return 'normal'
}
