import type { AnimeStatus } from '../types'

export function fmtTime(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) sec = 0
  const s = Math.floor(sec % 60)
  const m = Math.floor((sec / 60) % 60)
  const h = Math.floor(sec / 3600)
  const mm = h > 0 ? String(m).padStart(2, '0') : String(m)
  return `${h > 0 ? h + ':' : ''}${mm}:${String(s).padStart(2, '0')}`
}

export function timeAgo(ts: number): string {
  const diff = Math.max(0, Date.now() - ts) / 1000
  if (diff < 60) return 'Baru saja'
  if (diff < 3600) return `${Math.floor(diff / 60)} menit lalu`
  if (diff < 86400) return `${Math.floor(diff / 3600)} jam lalu`
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)} hari lalu`
  return new Date(ts).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })
}

export function statusLabel(s?: AnimeStatus): string | undefined {
  if (s === 'ONGOING') return 'Tayang'
  if (s === 'FINISHED') return 'Tamat'
  if (s === 'WAITING') return 'Segera'
  return undefined
}

export function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n))
}

export function errMsg(e: unknown): string {
  if (e instanceof Error && e.message) return e.message
  return 'Terjadi kesalahan tak terduga'
}

export function episodeLabel(v?: string): string | undefined {
  if (!v) return undefined
  return /^\d+(\.\d+)?$/.test(v) ? `Ep ${v}` : v
}

export function fmtCount(n?: number): string | undefined {
  if (n === undefined || !Number.isFinite(n)) return undefined
  if (n >= 1e6) return `${(n / 1e6).toFixed(1).replace(/\.0$/, '')}M`
  if (n >= 1e3) return `${(n / 1e3).toFixed(1).replace(/\.0$/, '')}K`
  return String(Math.round(n))
}

/** Jam tayang -> "HH:MM" (waktu lokal). Kembali "--:--" jika tidak diketahui. */
export function fmtAirTime(raw?: string): string {
  if (!raw) return '--:--'
  const pad = (n: number) => String(n).padStart(2, '0')
  const local = (d: Date) => `${pad(d.getHours())}:${pad(d.getMinutes())}`
  if (/^\d{10,13}$/.test(raw)) return local(new Date(raw.length === 10 ? +raw * 1000 : +raw))
  if (/^\d{4}-\d{2}-\d{2}T/.test(raw)) {
    const t = Date.parse(raw)
    if (!Number.isNaN(t)) return local(new Date(t))
  }
  const m = raw.match(/(\d{1,2})[:.](\d{2})/)
  return m ? `${pad(+m[1])}:${m[2]}` : '--:--'
}

export function episodeFull(v?: string): string | undefined {
  if (!v) return undefined
  return /^\d+(\.\d+)?$/.test(v) ? `Episode ${v}` : v
}

export function fmtBytes(n?: number): string {
  if (!n || !Number.isFinite(n) || n <= 0) return '0 MB'
  if (n >= 1024 ** 3) return `${(n / 1024 ** 3).toFixed(2)} GB`
  if (n >= 1024 ** 2) return `${Math.round(n / 1024 ** 2)} MB`
  return `${Math.max(1, Math.round(n / 1024))} KB`
}

/** Hari -> "2 bulan 5 hari" (1 bulan = 30 hari, sesuai paket Premium). `short` => "2 bln 5 hr". */
export function fmtPremiumSpan(days: number, short = false): string {
  const d = Math.max(0, Math.floor(days))
  const m = Math.floor(d / 30)
  const r = d % 30
  const mo = short ? 'bln' : 'bulan'
  const dy = short ? 'hr' : 'hari'
  if (m === 0) return `${r} ${dy}`
  if (r === 0) return `${m} ${mo}`
  return `${m} ${mo} ${r} ${dy}`
}
