// Periode leaderboard dihitung dengan zona waktu WIB (UTC+7) agar semua user memakai batas hari yang sama.
export type Period = 'daily' | 'weekly' | 'monthly'

export const PERIOD_LABEL: Record<Period, string> = {
  daily: 'Harian',
  weekly: 'Mingguan',
  monthly: 'Bulanan',
}

const WIB = 7 * 3600 * 1000
const DAY = 86400 * 1000
const p2 = (n: number) => String(n).padStart(2, '0')
const ymd = (d: Date) => `${d.getUTCFullYear()}-${p2(d.getUTCMonth() + 1)}-${p2(d.getUTCDate())}`

/** Awal periode (dalam "jam dinding WIB", dibaca lewat getUTC*). */
function startOf(period: Period, ts: number): Date {
  const d = new Date(ts + WIB)
  const day = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())
  if (period === 'daily') return new Date(day)
  if (period === 'weekly') {
    const dow = (d.getUTCDay() + 6) % 7 // Senin = 0
    return new Date(day - dow * DAY)
  }
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1))
}

/** Kunci node database: harian/mingguan = YYYY-MM-DD (mingguan = tanggal Senin), bulanan = YYYY-MM. */
export function periodKey(period: Period, ts = Date.now()): string {
  const s = startOf(period, ts)
  return period === 'monthly' ? `${s.getUTCFullYear()}-${p2(s.getUTCMonth() + 1)}` : ymd(s)
}

/** Teks rentang tanggal, mis. "2026-10-01 - 2026-10-07". */
export function periodRange(period: Period, ts = Date.now()): string {
  const s = startOf(period, ts)
  if (period === 'daily') return ymd(s)
  if (period === 'weekly') return `${ymd(s)} - ${ymd(new Date(s.getTime() + 6 * DAY))}`
  const last = new Date(Date.UTC(s.getUTCFullYear(), s.getUTCMonth() + 1, 0))
  return `${ymd(s)} - ${ymd(last)}`
}

export const PERIODS: Period[] = ['daily', 'weekly', 'monthly']
