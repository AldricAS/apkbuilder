// Link gambar/GIF untuk banner profil: rapikan link yang sering salah (halaman, bukan file langsung) dan tentukan jenis media.
export const MEDIA_URL_MAX = 1000

const PAGE_HOSTS: { re: RegExp; msg: string }[] = [
  { re: /^https:\/\/(www\.)?tenor\.com\/view\//i, msg: 'Link Tenor ini halaman, bukan file. Klik kanan/tahan GIF, pilih "Salin alamat gambar" (media.tenor.com/....gif)' },
  { re: /^https:\/\/(www\.)?imgur\.com\/(a|gallery)\//i, msg: 'Link album Imgur tidak bisa dipakai. Buka gambarnya lalu salin alamat gambar (i.imgur.com/....gif)' },
  { re: /^https:\/\/(www\.)?(pinterest\.[a-z.]+|pin\.it|instagram\.com|facebook\.com|fb\.watch|twitter\.com|x\.com|tiktok\.com|youtube\.com|youtu\.be|drive\.google\.com|photos\.app\.goo\.gl|images\.google\.[a-z.]+)\//i, msg: 'Itu link halaman, bukan file gambar/GIF. Pakai link langsung yang berakhir .gif/.png/.jpg/.webp' },
]

/** Ubah link halaman populer menjadi link file langsung. Link lain dikembalikan apa adanya. */
export function normalizeMediaUrl(raw: string): string {
  let u = raw.trim()
  let m: RegExpMatchArray | null
  // Giphy: halaman / embed -> file GIF
  if ((m = u.match(/^https:\/\/(?:www\.)?giphy\.com\/(?:gifs|stickers|clips)\/(?:[^/?#]*-)?([A-Za-z0-9]{8,})(?:[/?#].*)?$/i))) return `https://media.giphy.com/media/${m[1]}/giphy.gif`
  if ((m = u.match(/^https:\/\/(?:www\.)?giphy\.com\/embed\/([A-Za-z0-9]+)/i))) return `https://media.giphy.com/media/${m[1]}/giphy.gif`
  // Imgur: halaman gambar tunggal / .gifv -> .gif
  if ((m = u.match(/^https:\/\/(?:www\.|m\.)?imgur\.com\/([A-Za-z0-9]{5,8})(?:[?#].*)?$/i))) return `https://i.imgur.com/${m[1]}.gif`
  if ((m = u.match(/^(https:\/\/i\.imgur\.com\/[A-Za-z0-9]+)\.gifv(\?.*)?$/i))) return `${m[1]}.gif`
  // GitHub: blob -> raw
  if ((m = u.match(/^https:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/(.+)$/i))) return `https://raw.githubusercontent.com/${m[1]}/${m[2]}/${m[3].split('?')[0]}`
  // Dropbox: tampilan halaman -> unduhan langsung
  if (/^https:\/\/(www\.)?dropbox\.com\//i.test(u)) u = u.replace(/([?&])dl=0/i, '$1raw=1')
  return u
}

/** Pesan galat bila link jelas bukan file langsung; null bila boleh dicoba. */
export function mediaUrlProblem(u: string): string | null {
  for (const p of PAGE_HOSTS) if (p.re.test(u)) return p.msg
  return null
}

export type MediaKind = 'image' | 'video'
export const mediaKind = (u: string): MediaKind => (/\.(mp4|webm|m4v|mov)(\?|#|$)/i.test(u) ? 'video' : 'image')

/** Cadangan terakhir: proxy gambar publik (mendukung GIF beranimasi) untuk host yang memblokir hotlink dari aplikasi. */
export const proxiedUrl = (u: string): string => `https://wsrv.nl/?url=${encodeURIComponent(u.replace(/^https?:\/\//i, ''))}&n=-1`
