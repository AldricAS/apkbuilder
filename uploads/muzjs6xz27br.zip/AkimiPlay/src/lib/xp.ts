// Sistem XP & level. Rumus HARUS sama dengan validasi di database.rules.json.
export const XP_PER_MINUTE = 240
export const XP_PER_SECOND = XP_PER_MINUTE / 60

/** XP yang dibutuhkan untuk naik dari `level` ke level berikutnya. */
export const requiredXp = (level: number) => 1000 + (level - 1) * 700

/** Total XP kumulatif minimum untuk mencapai `level` (level 1 = 0 XP). */
export const cumulativeXp = (level: number) => (level - 1) * 1000 + 350 * (level - 1) * (level - 2)

export function levelFromXp(xp: number): number {
  const x = Math.max(0, Math.floor(xp))
  let level = Math.max(1, Math.floor((50 + Math.sqrt(2500 + 1400 * (x + 300))) / 700))
  while (cumulativeXp(level + 1) <= x) level++ // menangani lompat beberapa level sekaligus
  while (level > 1 && cumulativeXp(level) > x) level--
  return level
}

export function xpProgress(xp: number) {
  const level = levelFromXp(xp)
  const current = Math.max(0, xp - cumulativeXp(level))
  const required = requiredXp(level)
  return { level, current, required, ratio: Math.min(1, current / required) }
}

export const fmtNum = (n: number) => Math.round(n).toLocaleString('id-ID')
