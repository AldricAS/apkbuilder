import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { useBackHandler, exitApp } from '../native/native'
import { Logo, APP_NAME } from '../components/Logo'
import { Spinner } from '../components/States'
import { Icon } from '../components/Icon'
import { Avatar } from '../components/UserBadges'
import { useAuth } from './AuthProvider'
import { useOnline } from '../hooks/hooks'
import { hasDownloads, useDownloads } from '../services/downloadService'
import { OfflineApp } from '../pages/DownloadsPage'

function GoogleG() {
  return (
    <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z" />
      <path fill="#FBBC05" d="M10.5 28.7a14.5 14.5 0 0 1 0-9.4l-7.9-6.1a24 24 0 0 0 0 21.6l7.9-6.1z" />
      <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.500 42.600 14.600 48 24 48z" />
    </svg>
  )
}

type LastAccount = { name: string; photoURL?: string }
const LAST_KEY = 'akimi:lastAccount'

function saveLastAccount(v: LastAccount) {
  try {
    localStorage.setItem(LAST_KEY, JSON.stringify(v))
  } catch {
    /* penyimpanan tidak tersedia */
  }
}

function readLastAccount(): LastAccount | null {
  try {
    const v = JSON.parse(localStorage.getItem(LAST_KEY) ?? 'null') as LastAccount | null
    return v && typeof v.name === 'string' && v.name ? v : null
  } catch {
    return null
  }
}

const PERKS: { icon: 'play' | 'clock' | 'chat'; title: string; hint: string }[] = [
  { icon: 'play', title: 'Tonton gratis', hint: 'Ribuan episode anime' },
  { icon: 'clock', title: 'Progres tersimpan', hint: 'Lanjut dari menit terakhir' },
  { icon: 'chat', title: 'Komunitas & XP', hint: 'Komentar, level, leaderboard' },
]

function LoginScreen({ signingIn, error, onSignIn }: { signingIn: boolean; error: string | null; onSignIn: () => void }) {
  const last = useMemo(readLastAccount, [])
  return (
    <div className="relative flex h-full flex-col overflow-hidden bg-ink pt-safe">
      {/* latar aurora */}
      <div className="pointer-events-none absolute -top-24 left-1/2 h-[380px] w-[380px] -translate-x-1/2 animate-glow rounded-full bg-accent/25 blur-[90px]" />
      <div className="pointer-events-none absolute -left-24 top-[28%] h-[260px] w-[260px] animate-glow rounded-full bg-[#7a5cff]/25 blur-[90px]" />
      <div className="pointer-events-none absolute -right-24 top-[8%] h-[220px] w-[220px] animate-glow rounded-full bg-[#F4C96B]/15 blur-[80px]" />

      {/* logo */}
      <div className="relative flex flex-1 flex-col items-center justify-center px-8 text-center">
        <div className="animate-floaty rounded-[28px] bg-gradient-to-br from-white/15 to-white/[0.03] p-4 shadow-[0_20px_60px_rgba(255,122,162,0.25)] ring-1 ring-white/15 backdrop-blur-md">
          <Logo size={72} />
        </div>
        <h1 className="mt-6 bg-gradient-to-r from-white via-white to-accent bg-clip-text text-[32px] font-extrabold tracking-tight text-transparent">
          {APP_NAME}
        </h1>
        <p className="mt-2 max-w-[270px] text-[14px] leading-snug text-white/60">Tonton anime, simpan progres, dan ngobrol bareng komunitas.</p>
      </div>

      {/* kartu login (bottom sheet) */}
      <div className="relative animate-sheetUp rounded-t-[32px] border-t border-white/10 bg-gradient-to-b from-[#1a1a24]/95 to-[#101016]/95 px-5 pb-9 pt-3 shadow-[0_-20px_60px_rgba(0,0,0,0.6)] backdrop-blur-xl">
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-white/15" />

        {last ? (
          <div className="mb-4 flex items-center gap-3 rounded-2xl bg-white/[0.05] p-3 ring-1 ring-white/[0.07]">
            <Avatar url={last.photoURL} name={last.name} size={42} />
            <div className="min-w-0 flex-1">
              <p className="text-[11.5px] text-white/50">Selamat datang kembali</p>
              <p className="truncate text-[15px] font-bold text-white">{last.name}</p>
            </div>
          </div>
        ) : (
          <div className="mb-4 grid grid-cols-1 gap-2">
            {PERKS.map((p) => (
              <div key={p.title} className="flex items-center gap-3 rounded-2xl bg-white/[0.04] px-3 py-2.5 ring-1 ring-white/[0.06]">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent/15 text-accent">
                  <Icon name={p.icon} size={17} />
                </span>
                <div className="min-w-0">
                  <p className="text-[13.5px] font-bold text-white">{p.title}</p>
                  <p className="text-[12px] text-white/50">{p.hint}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {error ? <p className="mb-3 rounded-2xl bg-[#2a1720] px-4 py-3 text-center text-[12.5px] leading-snug text-accent">{error}</p> : null}

        <button
          type="button"
          disabled={signingIn}
          onClick={onSignIn}
          className="flex w-full items-center justify-center gap-3 rounded-full bg-white py-3.5 text-[15px] font-semibold text-[#1f1f1f] shadow-[0_8px_28px_rgba(255,255,255,0.12)] transition-transform active:scale-[0.98] disabled:opacity-70"
        >
          {signingIn ? <Spinner size={20} /> : <GoogleG />}
          {signingIn ? 'Membuka Google...' : last ? 'Lanjutkan dengan Google' : 'Login dengan Google'}
        </button>
        <p className="mt-4 text-center text-[11.5px] leading-snug text-white/45">Kami hanya memakai nama, email, dan foto akun Google untuk membuat profil.</p>
      </div>
    </div>
  )
}

function Centered({ children }: { children: ReactNode }) {
  return <div className="flex h-full flex-col items-center justify-center bg-ink px-8 text-center">{children}</div>
}

export function AuthGate({ children }: { children: ReactNode }) {
  const a = useAuth()
  const online = useOnline()
  useDownloads() // render ulang saat daftar unduhan berubah
  const [offlineMode, setOfflineMode] = useState(false)
  // Dibuka tanpa internet: login/profil tidak bisa dimuat, tapi anime yang sudah di-download tetap bisa ditonton.
  // Mode ini "lengket": saat internet kembali, pengguna yang sedang menonton tidak dipaksa pindah layar;
  // ia keluar lewat tombol "Buka AkimiPlay".
  const wantOffline = !online && !a.profile && a.status !== 'loading' && hasDownloads()
  useEffect(() => {
    if (wantOffline) setOfflineMode(true)
  }, [wantOffline])
  const showOffline = offlineMode || wantOffline

  // ingat akun terakhir yang masuk agar layar login bisa menyapa "Selamat datang kembali"
  const p = a.profile
  useEffect(() => {
    if (p) saveLastAccount({ name: p.username?.trim() || p.displayName, photoURL: p.photoURL })
  }, [p])

  // Di layar login, tombol Back menutup aplikasi.
  useBackHandler(() => {
    exitApp()
    return true
  }, 0, a.status !== 'signedIn' || !a.profile)

  if (showOffline) {
    return <OfflineApp online={online} onExit={() => setOfflineMode(false)} />
  }

  if (a.status === 'loading') {
    return (
      <Centered>
        <Logo size={64} />
        <div className="mt-6">
          <Spinner size={26} />
        </div>
      </Centered>
    )
  }

  if (a.status === 'signedOut') {
    return <LoginScreen signingIn={a.signingIn} error={a.loginError} onSignIn={() => void a.signIn()} />
  }

  // sudah login, tunggu profile
  if (!a.profile) {
    return (
      <Centered>
        {a.profileError ? (
          <>
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-raise text-accent">
              <Icon name="offline" size={26} />
            </div>
            <p className="mt-4 text-[16px] font-semibold text-white">Profil belum bisa dimuat</p>
            <p className="mt-1.5 max-w-[300px] text-[13px] leading-snug text-muted">{a.profileError}</p>
            <div className="mt-5 flex gap-2.5">
              <button
                type="button"
                onClick={a.retryProfile}
                className="rounded-full bg-accent px-5 py-2.5 text-[13.5px] font-bold text-ink active:scale-95"
              >
                Coba lagi
              </button>
              <button
                type="button"
                onClick={() => void a.signOut()}
                className="rounded-full bg-raise px-5 py-2.5 text-[13.5px] font-semibold text-white active:scale-95"
              >
                Keluar
              </button>
            </div>
            {hasDownloads() ? (
              <button
                type="button"
                onClick={() => setOfflineMode(true)}
                className="mt-3 flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-[13.5px] font-semibold text-white active:scale-95"
              >
                Tonton anime yang di-download
              </button>
            ) : null}
          </>
        ) : (
          <>
            <Logo size={64} />
            <p className="mt-5 text-[13.5px] text-muted">Menyiapkan profil...</p>
            <div className="mt-3">
              <Spinner size={24} />
            </div>
          </>
        )}
      </Centered>
    )
  }

  return <>{children}</>
}
