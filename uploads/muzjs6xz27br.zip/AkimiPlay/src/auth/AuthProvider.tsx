import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { onAuthStateChanged, type User } from 'firebase/auth'
import { auth } from '../firebase/config'
import { friendlyAuthError, signInWithGoogle, signOutAll } from '../services/authService'
import { ensureProfile, subscribeProfile, type UserProfile } from '../services/userService'
import { startPresence } from '../services/chatService'
import { startCloudSync } from '../services/syncService'
import { startNotifications } from '../services/notifyService'
import { flushAllStores } from '../storage/stores'
import { toast } from '../components/Feedback'
import { useOnline } from '../hooks/hooks'

type Status = 'loading' | 'signedOut' | 'signedIn'

type AuthCtx = {
  status: Status
  user: User | null
  profile: UserProfile | null
  /** Pesan error saat membuat/memuat profile (mis. Security Rules belum dipublikasikan). */
  profileError: string | null
  signingIn: boolean
  loginError: string | null
  signIn: () => Promise<void>
  signOut: () => Promise<void>
  retryProfile: () => void
}

const Ctx = createContext<AuthCtx | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<Status>('loading')
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [profileError, setProfileError] = useState<string | null>(null)
  const [signingIn, setSigningIn] = useState(false)
  const [loginError, setLoginError] = useState<string | null>(null)
  const [retry, setRetry] = useState(0)
  const lastLevel = useRef<number | null>(null)
  const levelTimer = useRef<ReturnType<typeof setTimeout>>()
  const levelNow = useRef(0)
  const levelShown = useRef(0)
  const online = useOnline()

  // sesi Firebase (tersimpan setelah aplikasi ditutup)
  useEffect(() => {
    return onAuthStateChanged(auth, (u) => {
      setUser(u)
      setStatus(u ? 'signedIn' : 'signedOut')
      if (!u) {
        setProfile(null)
        setProfileError(null)
        lastLevel.current = null
        levelNow.current = 0
        levelShown.current = 0
      }
    })
  }, [])

  // buat/sinkronkan profile lalu dengarkan perubahannya secara realtime
  useEffect(() => {
    if (!user) return
    let cancelled = false
    let unsub: (() => void) | undefined
    setProfileError(null)
    ensureProfile(user)
      .then(() => {
        if (cancelled) return
        unsub = subscribeProfile(
          user.uid,
          (p) => {
            if (cancelled) return
            setProfile(p)
            if (p) {
              // Firebase menampilkan nilai sementara sebelum server menjawab. Kalau server menolak, level kembali turun,
              // jadi toast hanya muncul bila level baru bertahan 2,5 detik (tidak lagi spam "Naik level" palsu).
              if (p.level < levelNow.current && levelTimer.current) {
                clearTimeout(levelTimer.current)
                levelTimer.current = undefined
              }
              if (lastLevel.current !== null && p.level > lastLevel.current) {
                const to = p.level
                if (levelTimer.current) clearTimeout(levelTimer.current)
                levelTimer.current = setTimeout(() => {
                  levelTimer.current = undefined
                  if (levelNow.current >= to && levelShown.current < to) {
                    levelShown.current = to
                    toast(`Naik level! Lvl. ${to}`)
                  }
                }, 2500)
              }
              levelNow.current = p.level
              if (levelShown.current === 0) levelShown.current = p.level
              lastLevel.current = p.level
            }
          },
          (e) => !cancelled && setProfileError(e.message),
        )
      })
      .catch((e: unknown) => {
        if (cancelled) return
        const msg = e instanceof Error ? e.message : String(e)
        setProfileError(
          /permission/i.test(msg)
            ? 'Akses database ditolak. Pastikan Security Rules dari database.rules.json sudah dipublikasikan di Firebase Console.'
            : msg,
        )
      })
    return () => {
      cancelled = true
      unsub?.()
    }
  }, [user, retry])

  // dibuka tanpa internet -> profil gagal dimuat; muat ulang otomatis begitu koneksi kembali
  const needsProfile = !!user && !profile
  useEffect(() => {
    if (online && needsProfile) setRetry((n) => n + 1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [online])

  // presence + sinkronisasi favorit/histori saat profile siap
  const uid = profile?.uid
  useEffect(() => {
    if (!uid) return
    const stopPresence = startPresence(uid)
    const stopSync = startCloudSync(uid)
    const stopNotif = startNotifications()
    return () => {
      stopPresence()
      stopSync()
      stopNotif()
    }
  }, [uid])

  const signIn = useCallback(async () => {
    setSigningIn(true)
    setLoginError(null)
    try {
      await signInWithGoogle()
    } catch (e) {
      setLoginError(friendlyAuthError(e))
    } finally {
      setSigningIn(false)
    }
  }, [])

  const signOut = useCallback(async () => {
    await flushAllStores().catch(() => undefined)
    await signOutAll()
  }, [])

  const value = useMemo<AuthCtx>(
    () => ({
      status,
      user,
      profile,
      profileError,
      signingIn,
      loginError,
      signIn,
      signOut,
      retryProfile: () => setRetry((n) => n + 1),
    }),
    [status, user, profile, profileError, signingIn, loginError, signIn, signOut],
  )
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useAuth(): AuthCtx {
  const v = useContext(Ctx)
  if (!v) throw new Error('useAuth harus dipakai di dalam AuthProvider')
  return v
}

/** Profile user yang sedang login. Hanya dipakai di bawah AuthGate (profile pasti ada). */
export function useProfile(): UserProfile {
  const { profile } = useAuth()
  if (!profile) throw new Error('Profile belum siap')
  return profile
}
