import { Component, type ReactNode } from 'react'
import { Logo } from './Logo'

export class ErrorBoundary extends Component<{ children: ReactNode }, { error?: Error }> {
  state: { error?: Error } = {}
  static getDerivedStateFromError(error: Error) {
    return { error }
  }
  render() {
    if (!this.state.error) return this.props.children
    return (
      <div className="flex h-full flex-col items-center justify-center bg-ink px-8 text-center">
        <Logo size={56} />
        <p className="mt-5 text-[17px] font-semibold text-white">Aplikasi mengalami masalah</p>
        <p className="mt-1 text-[13px] text-muted">{this.state.error.message}</p>
        <button
          type="button"
          onClick={() => location.reload()}
          className="mt-6 rounded-full bg-accent px-6 py-2.5 text-[13.5px] font-bold text-ink"
        >
          Muat ulang
        </button>
      </div>
    )
  }
}
