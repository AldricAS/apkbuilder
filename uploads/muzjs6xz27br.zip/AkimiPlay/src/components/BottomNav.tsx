import { Icon, type IconName } from './Icon'
import type { Tab } from '../nav/router'

const ITEMS: { tab: Tab; label: string; icon: IconName }[] = [
  { tab: 'home', label: 'Home', icon: 'home' },
  { tab: 'ongoing', label: 'Ongoing', icon: 'tv' },
  { tab: 'favorites', label: 'Favorit', icon: 'heart' },
  { tab: 'history', label: 'Histori', icon: 'clock' },
  { tab: 'account', label: 'Akun', icon: 'user' },
]

export function BottomNav({ tab, onChange }: { tab: Tab; onChange: (t: Tab) => void }) {
  const index = ITEMS.findIndex((i) => i.tab === tab)
  return (
    <nav
      className="glass fixed left-1/2 z-30 h-[56px] w-[min(90%,390px)] -translate-x-1/2 rounded-[24px] shadow-[0_12px_40px_rgba(0,0,0,0.55)]"
      style={{ bottom: 'calc(env(safe-area-inset-bottom, 0px) + 12px)' }}
      aria-label="Navigasi utama"
    >
      <div className="relative flex h-full items-center p-1.5">
        {/* indikator yang bergeser mengikuti tab aktif */}
        <div
          className="absolute bottom-1 left-1.5 top-1 rounded-[19px] bg-accent/15 transition-transform duration-300 ease-out"
          style={{ width: 'calc((100% - 12px) / 5)', transform: `translateX(${index * 100}%)` }}
        />
        {ITEMS.map((it) => {
          const active = it.tab === tab
          return (
            <button
              key={it.tab}
              type="button"
              onClick={() => onChange(it.tab)}
              aria-current={active ? 'page' : undefined}
              className="relative z-10 flex h-full flex-1 flex-col items-center justify-center gap-px"
            >
              <span
                key={active ? 'on' : 'off'}
                className={`${active ? 'animate-lift text-accent' : 'text-white/55'}`}
              >
                <Icon name={it.icon} size={20} />
              </span>
              <span
                className={`text-[10px] font-medium leading-none transition-colors ${active ? 'text-accent' : 'text-white/45'}`}
              >
                {it.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
