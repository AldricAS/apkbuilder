import { useEffect, useState, type ReactNode } from 'react'
import { useBackHandler } from '../native/native'
import { useOnline } from '../hooks/hooks'
import { Icon } from './Icon'

// ---------- Toast ----------
const toastListeners = new Set<(m: string) => void>()
export function toast(message: string) {
  toastListeners.forEach((l) => l(message))
}

export function ToastHost() {
  const [msg, setMsg] = useState<string | null>(null)
  useEffect(() => {
    let t: ReturnType<typeof setTimeout>
    const l = (m: string) => {
      setMsg(m)
      clearTimeout(t)
      t = setTimeout(() => setMsg(null), 2200)
    }
    toastListeners.add(l)
    return () => {
      toastListeners.delete(l)
      clearTimeout(t)
    }
  }, [])
  if (!msg) return null
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-28 z-[100] flex justify-center px-6">
      <div className="glass animate-fadeIn rounded-full px-4 py-2.5 text-[13px] font-medium text-white shadow-lg">
        {msg}
      </div>
    </div>
  )
}

// ---------- Offline ----------
export function OfflineBanner() {
  const online = useOnline()
  if (online) return null
  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-[90] flex justify-center pt-safe">
      <div className="mt-2 flex items-center gap-2 rounded-full bg-[#2a1720] px-3.5 py-1.5 text-[12px] font-medium text-accent shadow-lg">
        <Icon name="offline" size={14} /> Kamu sedang offline
      </div>
    </div>
  )
}

// ---------- Sheet & Dialog ----------
export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean
  onClose: () => void
  title?: string
  children: ReactNode
}) {
  useBackHandler(
    () => {
      onClose()
      return true
    },
    300,
    open,
  )
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[85] flex items-end">
      <div className="absolute inset-0 animate-fadeIn bg-black/60" onClick={onClose} />
      <div className="relative max-h-[85%] w-full animate-sheetUp overflow-y-auto rounded-t-[28px] border-t border-line bg-panel px-5 pb-8 pt-3">
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-white/15" />
        {title ? <h3 className="mb-3 text-[17px] font-semibold text-white">{title}</h3> : null}
        {children}
      </div>
    </div>
  )
}

export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel,
  onConfirm,
  onCancel,
}: {
  open: boolean
  title: string
  message: string
  confirmLabel: string
  onConfirm: () => void
  onCancel: () => void
}) {
  useBackHandler(
    () => {
      onCancel()
      return true
    },
    400,
    open,
  )
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[95] flex items-center justify-center px-8">
      <div className="absolute inset-0 animate-fadeIn bg-black/70" onClick={onCancel} />
      <div className="relative w-full max-w-sm animate-fadeIn rounded-3xl border border-line bg-panel p-5">
        <h3 className="text-[17px] font-semibold text-white">{title}</h3>
        <p className="mt-1.5 text-[13.5px] leading-snug text-muted">{message}</p>
        <div className="mt-5 flex gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 rounded-full bg-raise py-2.5 text-[13.5px] font-semibold text-white active:scale-95"
          >
            Batal
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="flex-1 rounded-full bg-accent py-2.5 text-[13.5px] font-bold text-ink active:scale-95"
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}

export function Chip({
  active,
  onClick,
  children,
}: {
  active?: boolean
  onClick?: () => void
  children: ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`shrink-0 rounded-full px-3.5 py-1.5 text-[12.5px] font-medium transition-colors active:scale-95 ${
        active ? 'bg-accent text-ink' : 'bg-raise text-white/80'
      }`}
    >
      {children}
    </button>
  )
}

export function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${on ? 'bg-accent' : 'bg-white/15'}`}
    >
      <span
        className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${on ? 'left-6' : 'left-1'}`}
      />
    </button>
  )
}
