import type { ReactNode } from 'react'
import { Icon } from './Icon'

export function PageHeader({
  title,
  onBack,
  right,
}: {
  title: string
  onBack?: () => void
  right?: ReactNode
}) {
  return (
    <header className="pt-safe sticky top-0 z-20 bg-ink/85 backdrop-blur-xl">
      <div className="flex h-14 items-center gap-2 px-4">
        {onBack ? (
          <button
            type="button"
            aria-label="Kembali"
            onClick={onBack}
            className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"
          >
            <Icon name="back" size={24} />
          </button>
        ) : null}
        <h1 className="min-w-0 flex-1 truncate text-[20px] font-bold tracking-tight text-white">{title}</h1>
        {right}
      </div>
    </header>
  )
}
