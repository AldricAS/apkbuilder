import { useNav } from '../nav/router'
import { useBoard } from '../services/leaderboardService'
import { useLiveUsers } from '../services/liveProfiles'
import { fmtCount } from '../lib/format'
import { Icon } from './Icon'
import { Avatar, BoltIcon, CrownIcon, RankDot, displayNameOf } from './LeaderboardUi'

/** Slide "Top Leaderboard" di carousel banner Home. Menekan banner membuka halaman Leaderboard XP. */
export function LeaderboardBanner() {
  const nav = useNav()
  const board = useBoard('daily', 4)
  const rows = board.status === 'ok' ? board.rows.slice(0, 4) : []
  const live = useLiveUsers(rows.map((r) => r.uid))

  return (
    <button
      type="button"
      onClick={() => nav.push({ name: 'leaderboard' })}
      aria-label="Buka Leaderboard XP"
      className="relative block h-[clamp(148px,44vw,184px)] w-full overflow-hidden rounded-2xl bg-gradient-to-b from-[#16264a] to-[#0d1530] px-3.5 py-3 text-left ring-1 ring-white/10 active:opacity-90"
    >
      <div className="flex items-center gap-1.5 text-[#F4C96B]">
        <CrownIcon size={15} />
        <span className="text-[12.5px] font-extrabold tracking-[0.08em]">TOP LEADERBOARD</span>
      </div>
      <div className="mt-2 flex items-center justify-between text-[#6cb4ff]">
        <span className="flex items-center gap-1.5">
          <BoltIcon size={14} />
          <span className="text-[13px] font-extrabold tracking-wide">TOP XP · HARIAN</span>
        </span>
        <Icon name="chevron" size={15} className="text-white/50" />
      </div>

      <div className="mt-1.5 space-y-[3px]">
        {board.status === 'loading' ? (
          Array.from({ length: 4 }).map((_, i) => <div key={i} className="shimmer h-[22px] rounded-md" />)
        ) : board.status === 'error' ? (
          <p className="pt-3 text-[12px] text-white/60">Leaderboard belum bisa dimuat.</p>
        ) : rows.length === 0 ? (
          <p className="pt-3 text-[12px] leading-snug text-white/60">Belum ada XP hari ini. Tonton anime untuk jadi yang pertama!</p>
        ) : (
          rows.map((r, i) => (
            <div key={r.uid} className="flex h-[22px] items-center gap-2">
              <RankDot rank={i + 1} size={18} />
              <Avatar url={live.get(r.uid)?.photoURL} name={displayNameOf(live.get(r.uid))} size={20} />
              <span className="min-w-0 flex-1 truncate text-[12.5px] font-semibold text-white">{displayNameOf(live.get(r.uid))}</span>
              <span className="shrink-0 text-[12px] font-bold text-[#F4C96B]">{fmtCount(r.xp)}</span>
            </div>
          ))
        )}
      </div>
    </button>
  )
}
