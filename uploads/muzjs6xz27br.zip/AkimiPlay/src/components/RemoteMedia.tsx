import { useEffect, useState } from 'react'
import { mediaKind, proxiedUrl } from '../lib/media'

/**
 * Gambar/GIF/video dari link luar yang tahan banting. Urutan percobaan bila gagal muat:
 *   1) langsung tanpa Referer (mengatasi host yang menolak Referer aplikasi)
 *   2) langsung dengan Referer biasa (sebagian host justru menolak permintaan tanpa Referer)
 *   3) lewat proxy gambar (host yang memblokir hotlink / tipe tidak sesuai)
 * Video (.mp4/.webm) diputar otomatis, berulang, tanpa suara. Semua gagal = tidak menampilkan apa-apa.
 */
export function RemoteMedia({ url, className = '' }: { url?: string; className?: string }) {
  const [stage, setStage] = useState(0)
  useEffect(() => setStage(0), [url])
  if (!url || stage > 2) return null
  const src = stage === 2 ? proxiedUrl(url) : url
  const next = () => setStage((s) => s + 1)
  if (mediaKind(url) === 'video' && stage < 2) {
    return <video key={`${url}-${stage}`} src={src} autoPlay loop muted playsInline preload="auto" onError={next} className={className} />
  }
  return (
    <img
      key={`${url}-${stage}`}
      src={src}
      alt=""
      draggable={false}
      decoding="async"
      referrerPolicy={stage === 1 ? 'strict-origin-when-cross-origin' : 'no-referrer'}
      onError={next}
      className={className}
    />
  )
}
