import { useState } from 'react'
import { useProfile } from '../auth/AuthProvider'
import { acceptRequest, cancelRequest, removeFriend, sendRequest, useRelation, type Relation } from '../services/friendService'
import { errMsg } from '../lib/format'
import { ConfirmDialog, toast } from './Feedback'
import { Icon, type IconName } from './Icon'
import { Spinner } from './States'

const LOOK: Record<Relation, { label: string; icon: IconName; cls: string }> = {
  none: { label: 'Add Friend', icon: 'userPlus', cls: 'bg-accent text-ink' },
  pending_sent: { label: 'Pending', icon: 'clock', cls: 'bg-white/12 text-white/85 ring-1 ring-white/15' },
  pending_received: { label: 'Accept', icon: 'check', cls: 'bg-[#2F8BFF] text-white' },
  friends: { label: 'Friends', icon: 'userCheck', cls: 'bg-[#16382a] text-[#6EE7A0] ring-1 ring-[#6EE7A0]/35' },
}

/**
 * Satu tombol yang berubah menurut status hubungan (none / pending_sent / pending_received / friends).
 * circle = tombol bulat dengan keterangan kecil di bawahnya (profile); pill = tombol memanjang (hasil Cari Teman).
 */
export function FriendButton({ uid, variant = 'circle' }: { uid: string; variant?: 'circle' | 'pill' }) {
  const me = useProfile()
  const { rel, error } = useRelation(me.uid, uid)
  const [busy, setBusy] = useState(false)
  const [confirm, setConfirm] = useState<null | 'cancel' | 'remove'>(null)

  if (uid === me.uid) return null

  const look = LOOK[rel ?? 'none']
  const run = async (fn: () => Promise<void>, ok: string) => {
    setBusy(true)
    try {
      await fn()
      toast(ok)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  const press = () => {
    if (busy) return
    if (error) return toast(error)
    if (!rel) return
    if (rel === 'none') void run(() => sendRequest(me.uid, uid), 'Permintaan pertemanan dikirim')
    else if (rel === 'pending_received') void run(() => acceptRequest(me.uid, uid), 'Kalian sekarang berteman')
    else if (rel === 'pending_sent') setConfirm('cancel')
    else setConfirm('remove')
  }

  const inner = busy || (!rel && !error) ? <Spinner size={variant === 'circle' ? 20 : 16} /> : <Icon name={look.icon} size={variant === 'circle' ? 24 : 18} />

  return (
    <>
      {variant === 'circle' ? (
        <div className="flex w-[64px] flex-col items-center">
          <button
            type="button"
            aria-label={look.label}
            onClick={press}
            className={`flex h-[52px] w-[52px] items-center justify-center rounded-full shadow-[0_8px_24px_rgba(0,0,0,0.45)] transition-transform active:scale-90 ${look.cls}`}
          >
            {inner}
          </button>
          <span className="mt-1 text-[10.5px] font-semibold text-white/70">{look.label}</span>
        </div>
      ) : (
        <button
          type="button"
          onClick={press}
          className={`flex w-full items-center justify-center gap-2 rounded-full py-3 text-[14px] font-bold active:scale-[0.98] ${look.cls}`}
        >
          {inner}
          {look.label}
        </button>
      )}

      <ConfirmDialog
        open={confirm === 'cancel'}
        title="Batalkan permintaan?"
        message="Permintaan pertemanan yang sudah kamu kirim akan dibatalkan."
        confirmLabel="Batalkan"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          setConfirm(null)
          void run(() => cancelRequest(me.uid, uid), 'Permintaan dibatalkan')
        }}
      />
      <ConfirmDialog
        open={confirm === 'remove'}
        title="Hapus dari teman?"
        message="Kalian tidak lagi saling berteman dan komentar teman di profil ini tidak bisa dilihat."
        confirmLabel="Hapus"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          setConfirm(null)
          void run(() => removeFriend(me.uid, uid), 'Teman dihapus')
        }}
      />
    </>
  )
}
