import { useEffect, useState } from 'react'
import { ref, remove, set } from 'firebase/database'
import { db } from '../firebase/config'
import { useProfile } from '../auth/AuthProvider'
import { useClan, useMyClanId } from '../services/clanService'

const KEY = 'akimi:clanTagSynced'
const read = () => {
  try {
    return localStorage.getItem(KEY)
  } catch {
    return null
  }
}
const write = (v: string | null) => {
  try {
    if (v) localStorage.setItem(KEY, v)
    else localStorage.removeItem(KEY)
  } catch {
    /* abaikan */
  }
}

/**
 * Menjaga `users/{uid}/clanTag` (lencana clan di chat, komentar, profil) sama dengan tag clan user.
 * Tag yang dipasang developer secara manual tidak disentuh: hanya tag yang dulu dipasang oleh sinkronisasi ini yang dihapus
 * ketika user tidak lagi punya clan (misalnya dikeluarkan leader saat aplikasi tertutup).
 */
export function ClanTagSync() {
  const me = useProfile()
  const clanId = useMyClanId(me.uid)
  const clan = useClan(clanId)
  const [retry, setRetry] = useState(0)

  useEffect(() => {
    if (clanId === undefined) return
    if (clanId) {
      if (!clan) return
      write(clan.tag)
      if (me.clanTag !== clan.tag) {
        // gagal (sinyal putus, dll.): coba lagi beberapa kali supaya badge tidak tertinggal
        set(ref(db, `users/${me.uid}/clanTag`), clan.tag).catch(() => {
          if (retry < 5) setTimeout(() => setRetry((n) => n + 1), 6000)
        })
      }
    } else if (me.clanTag && read() === me.clanTag) {
      write(null)
      remove(ref(db, `users/${me.uid}/clanTag`)).catch(() => undefined)
    }
  }, [clanId, clan, me.uid, me.clanTag, retry])

  return null
}
