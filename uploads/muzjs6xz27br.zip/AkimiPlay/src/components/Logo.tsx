import logoUrl from '../assets/logo.png'

/** Logo AkimiPlay (huruf "A" pink, dari file logo yang diberikan). */
export function Logo({ size = 28 }: { size?: number }) {
  return <img src={logoUrl} width={size} height={size} alt="" aria-hidden="true" draggable={false} style={{ width: size, height: size, objectFit: 'contain' }} />
}

export const APP_NAME: string = typeof __APP_NAME__ === 'string' ? __APP_NAME__ : 'AkimiPlay'
export const APP_VERSION: string = typeof __APP_VERSION__ === 'string' ? __APP_VERSION__ : '1.0.7'
