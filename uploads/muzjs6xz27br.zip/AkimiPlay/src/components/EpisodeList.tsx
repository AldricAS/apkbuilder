import { useEffect, useMemo, useRef, useState } from 'react'
import type { Anime, AnimeLite, Episode } from '../types'
import { isWatched, progressStore, useStore } from '../storage/stores'
import { Icon } from './Icon'
import { EpisodeDownloadButton } from './DownloadUi'

const CHUNK = 50

type Props = {
  episodes: Episode[]
  currentId?: string
  onSelect: (e: Episode) => void
  /** Jika diisi, tiap baris episode mendapat tombol download. */
  anime?: AnimeLite & Partial<Anime>
}

/** Daftar episode per 50 episode (tidak merender ratusan baris sekaligus). */
export function EpisodeList({ episodes, currentId, onSelect, anime }: Props) {
  const progress = useStore(progressStore)
  const [desc, setDesc] = useState(false)
  const [range, setRange] = useState(0)

  const chunks = Math.ceil(episodes.length / CHUNK)
  const currentIdx = useMemo(() => episodes.findIndex((e) => e.id === currentId), [episodes, currentId])

  // arahkan ke rentang yang memuat episode yang sedang diputar
  useEffect(() => {
    if (currentIdx >= 0) setRange(Math.floor(currentIdx / CHUNK))
  }, [currentIdx])

  const safeRange = Math.min(range, Math.max(0, chunks - 1))
  const visible = useMemo(() => {
    const slice = episodes.slice(safeRange * CHUNK, safeRange * CHUNK + CHUNK)
    return desc ? [...slice].reverse() : slice
  }, [episodes, safeRange, desc])

  if (!episodes.length) return null

  return (
    <div>
      <div className="no-scrollbar mb-3 flex items-center gap-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setDesc((d) => !d)}
          className="shrink-0 rounded-full bg-raise px-3 py-1.5 text-[12px] font-medium text-white/80 active:scale-95"
        >
          {desc ? 'Terbaru dulu' : 'Terlama dulu'}
        </button>
        {chunks > 1
          ? Array.from({ length: chunks }).map((_, i) => {
              const a = episodes[i * CHUNK].number
              const b = episodes[Math.min(episodes.length, (i + 1) * CHUNK) - 1].number
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => setRange(i)}
                  className={`shrink-0 rounded-full px-3 py-1.5 text-[12px] font-medium active:scale-95 ${
                    i === safeRange ? 'bg-accent text-ink' : 'bg-raise text-white/70'
                  }`}
                >
                  {a}–{b}
                </button>
              )
            })
          : null}
      </div>

      <p className="mb-2 text-[12px] text-muted">
        Menampilkan {visible.length ? `${safeRange * CHUNK + 1}–${safeRange * CHUNK + visible.length}` : 0} dari {episodes.length} episode
      </p>

      <ul className="space-y-2">
        {visible.map((ep) => {
          const p = progress[ep.id]
          const watched = isWatched(p)
          const active = ep.id === currentId
          const ratio = p && p.d > 0 && !watched ? Math.min(1, p.p / p.d) : 0
          return (
            <li key={ep.id} className="relative">
              <button
                type="button"
                onClick={() => onSelect(ep)}
                className={`relative flex w-full items-center gap-3 overflow-hidden rounded-2xl px-3 py-2.5 text-left active:opacity-80 ${
                  anime ? 'pr-14' : ''
                } ${active ? 'bg-accent/15 ring-1 ring-accent/50' : 'bg-raise/70'}`}
              >
                <span
                  className={`flex h-10 min-w-[2.5rem] items-center justify-center rounded-xl px-1.5 text-[13px] font-bold ${
                    active ? 'bg-accent text-ink' : 'bg-white/[0.07] text-white'
                  }`}
                >
                  {ep.number}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13.5px] font-medium text-white">
                    {ep.title && ep.title !== String(ep.number) ? ep.title : `Episode ${ep.number}`}
                  </span>
                  {ep.date ? <span className="block text-[11.5px] text-muted">{ep.date}</span> : null}
                </span>
                {watched ? (
                  <span className="flex items-center gap-1 text-[11px] font-medium text-accent">
                    <Icon name="check" size={15} /> Ditonton
                  </span>
                ) : null}
                {ratio > 0 ? (
                  <span className="absolute inset-x-0 bottom-0 h-[3px] bg-white/10">
                    <span className="block h-full bg-accent" style={{ width: `${ratio * 100}%` }} />
                  </span>
                ) : null}
              </button>
              {anime ? <EpisodeDownloadButton anime={anime} episode={ep} /> : null}
            </li>
          )
        })}
      </ul>
    </div>
  )
}

/** Tombol episode berbentuk kartu bulat yang bisa digeser ke samping. */
export function EpisodeTiles({ episodes, currentId, onSelect }: Props) {
  const progress = useStore(progressStore)
  const [range, setRange] = useState(0)
  const activeRef = useRef<HTMLButtonElement>(null)
  const chunks = Math.ceil(episodes.length / CHUNK)
  const currentIdx = useMemo(() => episodes.findIndex((e) => e.id === currentId), [episodes, currentId])

  useEffect(() => {
    if (currentIdx >= 0) setRange(Math.floor(currentIdx / CHUNK))
  }, [currentIdx])

  const safe = Math.min(range, Math.max(0, chunks - 1))
  const visible = useMemo(() => episodes.slice(safe * CHUNK, safe * CHUNK + CHUNK), [episodes, safe])

  useEffect(() => {
    activeRef.current?.scrollIntoView({ inline: 'center', block: 'nearest' })
  }, [currentId, safe])

  if (!episodes.length) return null
  return (
    <div>
      {chunks > 1 ? (
        <div className="no-scrollbar mb-2.5 flex gap-2 overflow-x-auto px-4">
          {Array.from({ length: chunks }).map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setRange(i)}
              className={`shrink-0 rounded-full px-3 py-1 text-[11.5px] font-medium active:scale-95 ${
                i === safe ? 'bg-accent text-ink' : 'bg-raise text-white/70'
              }`}
            >
              {episodes[i * CHUNK].number}–{episodes[Math.min(episodes.length, (i + 1) * CHUNK) - 1].number}
            </button>
          ))}
        </div>
      ) : null}
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-1">
        {visible.map((ep) => {
          const active = ep.id === currentId
          const watched = isWatched(progress[ep.id])
          return (
            <button
              key={ep.id}
              ref={active ? activeRef : undefined}
              type="button"
              onClick={() => onSelect(ep)}
              aria-label={`Episode ${ep.number}`}
              className={`flex h-[50px] min-w-[50px] shrink-0 items-center justify-center rounded-xl px-2 text-[16px] font-semibold active:scale-95 ${
                active
                  ? 'bg-white text-ink ring-2 ring-accent'
                  : watched
                    ? 'bg-raise text-white/40 ring-1 ring-line'
                    : 'bg-raise text-white ring-1 ring-line'
              }`}
            >
              {ep.number}
            </button>
          )
        })}
      </div>
    </div>
  )
}
