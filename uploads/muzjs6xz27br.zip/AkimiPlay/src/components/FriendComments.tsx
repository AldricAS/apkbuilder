import { useEffect, useMemo, useState } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import {
  PC_MAX,
  arrange,
  deleteComment,
  deleteReply,
  isLapsed,
  postComment,
  postReply,
  subscribeProfileComments,
  type PComment,
  type PCReply,
} from '../services/profileCommentService'
import { liveOf, useLiveUsers } from '../services/liveProfiles'
import { errMsg, timeAgo } from '../lib/format'
import { Avatar, RoleBadge, RoleCheck, nameColor } from './UserBadges'
import { ConfirmDialog, toast } from './Feedback'
import { EmptyState, ErrorState, Spinner } from './States'
import { Icon } from './Icon'

type Load = { status: 'loading' } | { status: 'ok'; data: PComment[] } | { status: 'error'; message: string }

function Who({ x, onOpen }: { x: PCReply; onOpen: () => void }) {
  return (
    <button type="button" onClick={onOpen} className="flex min-w-0 items-center gap-1.5 text-left active:opacity-70">
      <span className="min-w-0 truncate text-[13.5px] font-bold" style={{ color: nameColor(x.userId, x.role) }}>
        {x.name}
      </span>
      <RoleCheck role={x.role} verified={x.verified} size={14} />
      <RoleBadge role={x.role} />
    </button>
  )
}

export function FriendComments({ targetUid, isOwn, canPost }: { targetUid: string; isOwn: boolean; canPost: boolean }) {
  const me = useProfile()
  const nav = useNav()
  const [state, setState] = useState<Load>({ status: 'loading' })
  const [now, setNow] = useState(() => Date.now())
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [replyFor, setReplyFor] = useState<string | null>(null)
  const [replyText, setReplyText] = useState('')
  const [del, setDel] = useState<null | { cid: string; rid?: string }>(null)
  const [reload, setReload] = useState(0)

  const isStaff = me.role === 'admin' || me.role === 'developer' || me.role === 'moderator'
  const canReply = isOwn || canPost

  useEffect(() => {
    setState({ status: 'loading' })
    return subscribeProfileComments(
      targetUid,
      (data) => {
        setNow(Date.now())
        setState({ status: 'ok', data })
      },
      (e) => setState({ status: 'error', message: /permission/i.test(e.message) ? 'Komentar teman hanya bisa dilihat oleh teman.' : errMsg(e) }),
    )
  }, [targetUid, reload])

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 60_000)
    return () => clearInterval(t)
  }, [])

  // komentar yang sudah lewat masa tayang dibersihkan diam-diam oleh pemilik profil atau penulisnya
  useEffect(() => {
    if (state.status !== 'ok') return
    for (const c of state.data) {
      if (isLapsed(c, now) && (isOwn || c.uid === me.uid)) void deleteComment(targetUid, c.id).catch(() => undefined)
    }
  }, [state, now, isOwn, me.uid, targetUid])

  const list = useMemo(() => (state.status === 'ok' ? arrange(state.data, now) : []), [state, now])
  const uids = useMemo(() => {
    const s = new Set<string>()
    for (const c of list) {
      s.add(c.uid)
      for (const r of c.replies) s.add(r.uid)
    }
    return [...s]
  }, [list])
  const live = useLiveUsers(uids)

  const submit = async () => {
    if (busy || !text.trim()) return
    setBusy(true)
    try {
      await postComment(me, targetUid, text)
      setText('')
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  const submitReply = async (cid: string) => {
    if (busy || !replyText.trim()) return
    setBusy(true)
    try {
      await postReply(me, targetUid, cid, replyText)
      setReplyText('')
      setReplyFor(null)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  const confirmDelete = async () => {
    const d = del
    setDel(null)
    if (!d) return
    try {
      if (d.rid) await deleteReply(targetUid, d.cid, d.rid)
      else await deleteComment(targetUid, d.cid)
    } catch (e) {
      toast(errMsg(e))
    }
  }

  return (
    <div>
      <h2 className="text-[15px] font-bold text-white">
        Komentar Teman
        {state.status === 'ok' && list.length ? <span className="ml-2 text-[12.5px] font-medium text-muted">{list.length}</span> : null}
      </h2>

      {canPost ? (
        <div className="mt-3 flex items-center gap-2">
          <Avatar url={me.photoURL} name={me.username || me.displayName} size={34} />
          <input
            value={text}
            maxLength={PC_MAX}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && void submit()}
            placeholder="Tulis komentar untuk profil ini.."
            enterKeyHint="send"
            className="h-10 min-w-0 flex-1 rounded-full bg-raise px-4 text-[13.5px] text-white placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
          />
          <button
            type="button"
            aria-label="Kirim komentar"
            disabled={!text.trim() || busy}
            onClick={() => void submit()}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent text-ink active:scale-90 disabled:bg-raise disabled:text-white/30"
          >
            {busy ? <Spinner size={16} /> : <Icon name="send" size={17} />}
          </button>
        </div>
      ) : null}

      <div className="mt-4">
        {state.status === 'loading' ? (
          <div className="flex justify-center py-10">
            <Spinner />
          </div>
        ) : state.status === 'error' ? (
          <ErrorState compact message={state.message} onRetry={() => setReload((n) => n + 1)} />
        ) : !list.length ? (
          <EmptyState
            icon="chat"
            title="Belum ada komentar"
            hint={isOwn ? 'Komentar dari teman akan muncul di sini.' : 'Jadilah yang pertama menulis komentar.'}
          />
        ) : (
          <ul className="space-y-3">
            {list.map((c0) => {
              const c = liveOf(c0, live.get(c0.uid))
              const canDelete = c.uid === me.uid || isOwn || isStaff
              return (
                <li key={c.id} className="rounded-2xl border border-white/[0.06] bg-raise/70 p-3.5">
                  <div className="flex items-start gap-2.5">
                    <button type="button" aria-label={`Lihat profil ${c.name}`} onClick={() => nav.openProfile(c.uid)} className="shrink-0 active:scale-95">
                      <Avatar url={c.photoURL} name={c.name} size={36} />
                    </button>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <Who x={c} onOpen={() => nav.openProfile(c.uid)} />
                        <span className="shrink-0 text-[11px] text-muted">{timeAgo(c.ts)}</span>
                      </div>
                      <p className="mt-1 whitespace-pre-wrap break-words text-[14px] leading-snug text-white">{c.text}</p>
                      <div className="mt-2 flex items-center gap-4 text-[12.5px] font-semibold">
                        {canReply ? (
                          <button
                            type="button"
                            onClick={() => {
                              setReplyFor(replyFor === c.id ? null : c.id)
                              setReplyText('')
                            }}
                            className="flex items-center gap-1 text-accent active:opacity-70"
                          >
                            <Icon name="reply" size={14} /> Balas
                          </button>
                        ) : null}
                        {canDelete ? (
                          <button type="button" onClick={() => setDel({ cid: c.id })} className="flex items-center gap-1 text-muted active:opacity-70">
                            <Icon name="trash" size={14} /> Hapus
                          </button>
                        ) : null}
                      </div>
                    </div>
                  </div>

                  {c.replies.length ? (
                    <div className="mt-3 space-y-3 border-l border-line pl-3">
                      {c.replies.map((r0) => {
                        const r = liveOf(r0, live.get(r0.uid))
                        const canDeleteReply = r.uid === me.uid || isOwn || isStaff
                        return (
                          <div key={r.id} className="flex items-start gap-2">
                            <button type="button" aria-label={`Lihat profil ${r.name}`} onClick={() => nav.openProfile(r.uid)} className="shrink-0 active:scale-95">
                              <Avatar url={r.photoURL} name={r.name} size={28} />
                            </button>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center justify-between gap-2">
                                <Who x={r} onOpen={() => nav.openProfile(r.uid)} />
                                <span className="shrink-0 text-[11px] text-muted">{timeAgo(r.ts)}</span>
                              </div>
                              <p className="mt-0.5 whitespace-pre-wrap break-words text-[13.5px] leading-snug text-white">{r.text}</p>
                              {canDeleteReply ? (
                                <button
                                  type="button"
                                  onClick={() => setDel({ cid: c.id, rid: r.id })}
                                  className="mt-1 flex items-center gap-1 text-[12px] font-semibold text-muted active:opacity-70"
                                >
                                  <Icon name="trash" size={13} /> Hapus
                                </button>
                              ) : null}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  ) : null}

                  {replyFor === c.id ? (
                    <div className="mt-3 flex items-center gap-2">
                      <input
                        autoFocus
                        value={replyText}
                        maxLength={PC_MAX}
                        onChange={(e) => setReplyText(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && void submitReply(c.id)}
                        placeholder={`Balas ${c.name}..`}
                        enterKeyHint="send"
                        className="h-9 min-w-0 flex-1 rounded-full bg-ink/60 px-3.5 text-[13px] text-white placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
                      />
                      <button
                        type="button"
                        aria-label="Kirim balasan"
                        disabled={!replyText.trim() || busy}
                        onClick={() => void submitReply(c.id)}
                        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent text-ink active:scale-90 disabled:bg-raise disabled:text-white/30"
                      >
                        {busy ? <Spinner size={14} /> : <Icon name="send" size={15} />}
                      </button>
                    </div>
                  ) : null}
                </li>
              )
            })}
          </ul>
        )}
      </div>

      <ConfirmDialog
        open={!!del}
        title={del?.rid ? 'Hapus balasan?' : 'Hapus komentar?'}
        message={del?.rid ? 'Balasan ini akan dihapus.' : 'Komentar beserta balasannya akan dihapus.'}
        confirmLabel="Hapus"
        onCancel={() => setDel(null)}
        onConfirm={() => void confirmDelete()}
      />
    </div>
  )
}
