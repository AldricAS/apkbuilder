import { useState } from 'react'
import { useProfile } from '../auth/AuthProvider'
import { useBackHandler } from '../native/native'
import {
  GIVEAWAY_DAYS,
  GIVEAWAY_SLOTS_MAX,
  GIVEAWAY_SLOTS_MIN,
  GIVEAWAY_SLOT_PRESETS,
  GIVEAWAY_TEXT_MAX,
  claimGiveaway,
  createGiveaway,
  giveawayBonusXp,
  giveawayCostDays,
  premiumDaysLeft,
  useGiveaway,
  useMyClaim,
} from '../services/giveawayService'
import { errMsg, fmtPremiumSpan } from '../lib/format'
import { fmtNum } from '../lib/xp'
import { toast } from './Feedback'
import { Spinner } from './States'

// Identitas visual "Sebar Premium": TIKET. Pink AkimiPlay (accent) berpadu emas Premium, sudut bertakik seperti tiket bioskop.
const PINK = '#FF7AA2'
const GOLD = '#F4C96B'
const TICKET_GRADIENT = `linear-gradient(135deg, ${PINK}, ${GOLD})`

const DAY_LABEL: Record<number, string> = { 1: 'Sehari', 3: 'Tiga hari', 7: 'Seminggu', 30: 'Sebulan' }

/** Ikon tiket bertakik (dipakai di tombol chat, judul, dan kartu). */
export function TicketIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h15A1.5 1.5 0 0 1 21 6.5V9a2.5 2.5 0 0 0 0 5v3.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5V14a2.5 2.5 0 0 0 0-5z" />
      <path d="M12.2 9.2l.9 1.9 2.1.3-1.5 1.5.4 2.1-1.9-1-1.9 1 .4-2.1-1.5-1.5 2.1-.3z" fill="#2B1B00" />
    </svg>
  )
}

/** Takik setengah lingkaran di tepi kiri/kanan sebuah garis sobek. `bg` = warna latar di belakang kartu. */
function Notches({ bg, top }: { bg: string; top: string }) {
  return (
    <>
      <span className="absolute -left-2 h-4 w-4 rounded-full" style={{ backgroundColor: bg, top }} />
      <span className="absolute -right-2 h-4 w-4 rounded-full" style={{ backgroundColor: bg, top }} />
    </>
  )
}

/** Popup konfirmasi khas "Sebar Premium": menampilkan tiket yang akan keluar. */
function SebarConfirm({
  open,
  tickets,
  days,
  used,
  xp,
  onCancel,
  onConfirm,
}: {
  open: boolean
  tickets: number
  days: number
  used: number
  xp: number
  onCancel: () => void
  onConfirm: () => void
}) {
  useBackHandler(
    () => {
      onCancel()
      return true
    },
    400,
    open,
  )
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[95] flex items-center justify-center px-6">
      <div className="absolute inset-0 animate-fadeIn bg-black/75" onClick={onCancel} />
      <div className="relative w-full max-w-sm animate-fadeIn overflow-hidden rounded-[26px] border border-white/10 bg-panel text-center">
        <div className="px-6 pb-5 pt-7" style={{ background: 'linear-gradient(180deg, rgba(255,122,162,.18), transparent)' }}>
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl text-[#2B1B00]" style={{ background: TICKET_GRADIENT }}>
            <TicketIcon size={30} />
          </span>
          <h3 className="mt-4 text-[20px] font-extrabold text-white">
            Sebar {fmtNum(tickets)} tiket Premium?
          </h3>
          <p className="mt-2 text-[13.5px] leading-snug text-white/65">
            Tiap tiket berisi <b className="text-white">{days} hari</b>. Premium kamu berkurang <b style={{ color: GOLD }}>{fmtNum(used)} hari</b> sekarang juga, dan
            hari dari tiket yang tidak diambil tidak kembali. Kamu dapat <b className="text-[#5BE08A]">+{fmtNum(xp)} XP</b>.
          </p>
        </div>
        <div className="flex gap-2.5 px-5 pb-5">
          <button type="button" onClick={onCancel} className="flex-1 rounded-2xl bg-raise py-3 text-[14px] font-bold text-white active:scale-95">
            Cek lagi
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="flex-[1.4] rounded-2xl py-3 text-[14px] font-extrabold text-[#2B1B00] active:scale-95"
            style={{ background: TICKET_GRADIENT }}
          >
            Ya, sebarkan
          </button>
        </div>
      </div>
    </div>
  )
}

/** Sheet "Sebar Premium": pilih lama tiket, jumlah tiket, pesan, lalu struk ringkasan. Dibayar dengan hari Premium sendiri. */
export function GiveawaySheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const me = useProfile()
  const [days, setDays] = useState<number>(3)
  const [slots, setSlots] = useState<number>(5)
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const [confirm, setConfirm] = useState(false)

  useBackHandler(
    () => {
      onClose()
      return true
    },
    300,
    open,
  )
  if (!open) return null

  const have = premiumDaysLeft(me.premiumUntil)
  const need = giveawayCostDays(days, slots)
  const bonus = giveawayBonusXp(days, slots)
  const enough = have >= need
  const after = Math.max(0, have - need)
  const ready = message.trim().length > 0 && enough && !busy
  const setSlotsSafe = (n: number) => setSlots(Math.min(GIVEAWAY_SLOTS_MAX, Math.max(GIVEAWAY_SLOTS_MIN, Math.round(n) || GIVEAWAY_SLOTS_MIN)))
  const pct = ((slots - GIVEAWAY_SLOTS_MIN) / (GIVEAWAY_SLOTS_MAX - GIVEAWAY_SLOTS_MIN)) * 100

  const submit = async () => {
    setConfirm(false)
    if (!ready) return
    setBusy(true)
    try {
      await createGiveaway(me, { days, slots, message })
      toast('Tiket Premium sudah disebar ke chat')
      setMessage('')
      onClose()
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-[85] flex items-end">
      <div className="absolute inset-0 animate-fadeIn bg-black/65" onClick={onClose} />
      <div className="relative max-h-[92%] w-full animate-sheetUp overflow-y-auto rounded-t-[30px] border-t border-white/10 bg-panel pb-6">
        <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-white/15" />

        {/* kepala */}
        <div className="flex items-center gap-3.5 px-5 pb-1 pt-4">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-[#2B1B00]" style={{ background: TICKET_GRADIENT }}>
            <TicketIcon size={28} />
          </span>
          <div className="min-w-0">
            <h2 className="text-[22px] font-extrabold leading-tight tracking-tight text-white">Sebar Premium</h2>
            <p className="text-[12.5px] leading-snug text-white/55">Bagikan hari Premium-mu jadi tiket untuk penonton chat.</p>
          </div>
        </div>

        <div className="px-5">
          {/* lama tiket */}
          <p className="mt-5 text-[13px] font-extrabold uppercase tracking-[0.14em] text-white/45">1 · Lama tiap tiket</p>
          <div className="mt-2.5 grid grid-cols-4 gap-2">
            {GIVEAWAY_DAYS.map((d) => {
              const on = days === d
              return (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDays(d)}
                  className={`rounded-2xl border px-1 py-3 text-center active:scale-95 ${on ? 'border-transparent text-[#2B1B00]' : 'border-white/10 bg-raise text-white'}`}
                  style={on ? { background: TICKET_GRADIENT } : undefined}
                >
                  <span className="block text-[22px] font-extrabold leading-none">{d}</span>
                  <span className={`mt-1 block text-[10.5px] font-bold uppercase tracking-wide ${on ? 'text-[#2B1B00]/70' : 'text-white/45'}`}>hari</span>
                  <span className={`mt-1 block text-[10.5px] ${on ? 'text-[#2B1B00]/70' : 'text-white/40'}`}>{DAY_LABEL[d]}</span>
                </button>
              )
            })}
          </div>

          {/* jumlah tiket */}
          <div className="mt-6 flex items-end justify-between">
            <p className="text-[13px] font-extrabold uppercase tracking-[0.14em] text-white/45">2 · Jumlah tiket</p>
            <p className="text-[26px] font-extrabold leading-none" style={{ color: GOLD }}>
              {slots}
              <span className="ml-1 text-[13px] font-bold text-white/50">tiket</span>
            </p>
          </div>
          <div className="mt-2 flex items-center gap-2">
            <button type="button" aria-label="Kurangi tiket" onClick={() => setSlotsSafe(slots - 1)} className="h-10 w-10 shrink-0 rounded-xl bg-raise text-[20px] font-bold text-white active:scale-90">
              −
            </button>
            <input
              type="range"
              className="tiket"
              min={GIVEAWAY_SLOTS_MIN}
              max={GIVEAWAY_SLOTS_MAX}
              step={1}
              value={slots}
              aria-label="Jumlah tiket"
              onChange={(e) => setSlotsSafe(Number(e.target.value))}
              style={{ ['--p' as string]: `${pct}%` }}
            />
            <button type="button" aria-label="Tambah tiket" onClick={() => setSlotsSafe(slots + 1)} className="h-10 w-10 shrink-0 rounded-xl bg-raise text-[20px] font-bold text-white active:scale-90">
              +
            </button>
          </div>
          <div className="mt-1.5 flex gap-1.5">
            {GIVEAWAY_SLOT_PRESETS.map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setSlots(n)}
                className={`flex-1 rounded-lg py-1.5 text-[12.5px] font-bold active:scale-95 ${slots === n ? 'bg-accent/20 text-accent ring-1 ring-accent/50' : 'bg-white/[0.05] text-white/55'}`}
              >
                {n}
              </button>
            ))}
          </div>

          {/* pesan */}
          <div className="mt-6 flex items-end justify-between">
            <p className="text-[13px] font-extrabold uppercase tracking-[0.14em] text-white/45">3 · Pesan untuk penonton</p>
            <span className="text-[11.5px] text-white/35">
              {message.length}/{GIVEAWAY_TEXT_MAX}
            </span>
          </div>
          <textarea
            value={message}
            rows={2}
            maxLength={GIVEAWAY_TEXT_MAX}
            onChange={(e) => setMessage(e.target.value.replace(/\n/g, ' '))}
            placeholder="Contoh: Makasih sudah nonton bareng, ambil tiketnya ya!"
            className="mt-2.5 w-full resize-none rounded-2xl border border-white/10 bg-raise px-4 py-3 text-[15px] leading-snug text-white placeholder:text-white/30 focus:border-accent/60 focus:outline-none"
          />

          {/* struk */}
          <div className="relative mt-6 rounded-3xl border border-white/10 bg-raise px-4 pb-4 pt-4">
            <p className="text-[12px] font-extrabold uppercase tracking-[0.18em]" style={{ color: GOLD }}>
              Struk Premium
            </p>
            <div className="mt-3 flex items-center justify-between text-[14.5px]">
              <span className="text-white/55">Tiket disebar</span>
              <span className="font-extrabold text-white">
                {slots} tiket <span className="font-normal text-white/40">×</span> {days} hari
              </span>
            </div>
            <div className="mt-2.5 flex items-center justify-between text-[14.5px]">
              <span className="text-white/55">Premium terpakai</span>
              <span className="font-extrabold" style={{ color: enough ? GOLD : '#FF8A9A' }}>
                {fmtNum(need)} hari
              </span>
            </div>

            <div className="relative my-3.5 border-t-2 border-dashed border-white/15">
              <Notches bg="#101016" top="-9px" />
            </div>

            <div className="flex items-center justify-between text-[14.5px]">
              <span className="text-white/55">Premium kamu</span>
              <span className="font-bold text-white/85">{have > 0 ? fmtPremiumSpan(have) : 'Belum aktif'}</span>
            </div>
            <div className="mt-2.5 flex items-center justify-between text-[14.5px]">
              <span className="text-white/55">Sisa setelah disebar</span>
              <span className={`font-bold ${enough ? 'text-white/85' : 'text-[#FF8A9A]'}`}>{enough ? fmtPremiumSpan(after) : `kurang ${fmtNum(need - have)} hari`}</span>
            </div>
            <div className="mt-2.5 flex items-center justify-between text-[14.5px]">
              <span className="text-white/55">Hadiah XP untukmu</span>
              <span className="text-[16px] font-extrabold text-[#5BE08A]">+{fmtNum(bonus)} XP</span>
            </div>
            <p className="mt-3.5 text-[11.5px] leading-snug text-white/40">
              Tanpa biaya AkimiShard dan tanpa potongan pajak. Yang berkurang hanya hari Premium milikmu, sebanyak tiket yang disebar.
            </p>
          </div>

          {have === 0 ? (
            <p className="mt-3 rounded-2xl bg-[#FF8A9A]/10 px-4 py-3 text-center text-[12.5px] leading-snug text-[#FF8A9A]">Kamu belum punya Premium aktif. Aktifkan Premium dulu, baru bisa dibagikan.</p>
          ) : !enough ? (
            <p className="mt-3 rounded-2xl bg-[#FF8A9A]/10 px-4 py-3 text-center text-[12.5px] leading-snug text-[#FF8A9A]">
              Butuh {fmtNum(need)} hari Premium, kamu baru punya {fmtNum(have)} hari. Kurangi tiket atau lama tiket.
            </p>
          ) : null}

          <button
            type="button"
            disabled={!ready}
            onClick={() => setConfirm(true)}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl py-4 text-[16.5px] font-extrabold active:scale-[0.98] disabled:bg-raise disabled:text-white/30"
            style={ready ? { background: TICKET_GRADIENT, color: '#2B1B00' } : undefined}
          >
            {busy ? <Spinner size={18} /> : <TicketIcon size={20} />} Sebarkan Premium
          </button>
          <button type="button" onClick={onClose} className="mx-auto mt-4 block text-[14.5px] font-bold text-white/55 active:opacity-70">
            Nanti saja
          </button>
        </div>
      </div>
      <SebarConfirm open={confirm} tickets={slots} days={days} used={need} xp={bonus} onCancel={() => setConfirm(false)} onConfirm={() => void submit()} />
    </div>
  )
}

/** Tiket Premium di chat: potongan "hari" di kiri, progres + tombol Ambil di kanan. */
export function GiveawayCard({ gid, compact = false }: { gid: string; compact?: boolean }) {
  const me = useProfile()
  const g = useGiveaway(gid)
  const claimed = useMyClaim(gid, me.uid)
  const [busy, setBusy] = useState(false)

  if (g === undefined) return null
  if (g === null) {
    return compact ? null : <p className="mt-2 rounded-2xl bg-white/[0.04] px-3 py-2 text-[12px] text-muted">Tiket Premium ini sudah tidak tersedia.</p>
  }

  const left = Math.max(0, g.slots - g.claimed)
  const own = g.uid === me.uid
  const full = left === 0
  const state: 'own' | 'claimed' | 'full' | 'open' = own ? 'own' : claimed ? 'claimed' : full ? 'full' : 'open'
  const label = state === 'own' ? 'Tiket buatanmu' : state === 'claimed' ? 'Sudah kamu ambil ✓' : state === 'full' ? 'Tiket habis' : `Ambil ${g.days} hari Premium`

  const claim = async () => {
    if (state !== 'open' || busy || claimed === undefined) return
    setBusy(true)
    try {
      const until = await claimGiveaway(me, g.id)
      toast(`Tiket diambil! Premium aktif sampai ${new Date(until).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}`)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className={`relative flex overflow-hidden rounded-2xl border border-white/10 bg-[#15121a] ${compact ? 'w-[260px] shrink-0' : 'mt-2'}`}>
      {/* potongan kiri: lama tiket */}
      <div className="relative flex w-[74px] shrink-0 flex-col items-center justify-center py-3 text-[#2B1B00]" style={{ background: TICKET_GRADIENT }}>
        <span className="text-[30px] font-extrabold leading-none">{g.days}</span>
        <span className="mt-0.5 text-[10.5px] font-extrabold uppercase tracking-[0.12em]">hari</span>
        <span className="mt-1.5 opacity-70">
          <TicketIcon size={15} />
        </span>
      </div>
      {/* garis sobek */}
      <div className="relative w-0 border-l-2 border-dashed border-white/15">
        <span className="absolute -left-[9px] -top-2 h-4 w-4 rounded-full bg-ink" />
        <span className="absolute -bottom-2 -left-[9px] h-4 w-4 rounded-full bg-ink" />
      </div>
      {/* badan kanan */}
      <div className="min-w-0 flex-1 p-3">
        <p className="truncate text-[13px] font-extrabold" style={{ color: GOLD }}>
          {compact ? `${g.name} bagi-bagi Premium` : 'Tiket Premium'}
        </p>
        {compact && g.text ? <p className="mt-0.5 truncate text-[11.5px] text-white/55">{g.text}</p> : null}
        <div className="mt-2 flex items-center justify-between text-[11.5px] text-white/55">
          <span>{full ? 'Semua tiket sudah diambil' : `Tersisa ${left} dari ${g.slots} tiket`}</span>
          <span className="font-bold text-white/75">
            {g.claimed}/{g.slots}
          </span>
        </div>
        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full" style={{ width: `${Math.min(100, (g.claimed / g.slots) * 100)}%`, background: TICKET_GRADIENT }} />
        </div>
        <button
          type="button"
          disabled={state !== 'open' || busy || claimed === undefined}
          onClick={() => void claim()}
          className="mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-xl py-2 text-[13px] font-extrabold active:scale-[0.98] disabled:bg-white/[0.07] disabled:text-white/40"
          style={state === 'open' ? { background: TICKET_GRADIENT, color: '#2B1B00' } : undefined}
        >
          {busy ? <Spinner size={15} /> : null} {label}
        </button>
      </div>
    </div>
  )
}
