import { useId } from 'react'
import { clampTier, clanColorOf } from '../services/clanService'
import { PixelEmblem } from './PixelEmblem'

const H = 28 // tinggi kanvas internal; ukuran asli diatur lewat prop `height`

/** Perkiraan lebar satu huruf tebal 14px (huruf sempit/lebar dibedakan supaya tag pendek seperti "AKM" tidak rapat). */
const charW = (ch: string) => ('IJ1'.includes(ch) ? 5.6 : 'MW'.includes(ch) ? 12.6 : 'OQDGHNUBCRSKXZAVYT0234567896'.includes(ch) ? 10.4 : 9.4) + 0.5

const f = (n: number) => Math.round(n * 100) / 100

/**
 * Bodi lencana berujung lancip (kiri & kanan). `i` = jarak ke dalam untuk garis bingkai.
 * Tier 3 menambah tiga mahkota runcing di tepi atas.
 */
function bodyPath(w: number, tier: number, i = 0): string {
  const top = tier === 3 ? 6 + i : 1.5 + i
  const bot = 26.5 - i
  const mid = (top + bot) / 2 + (tier === 3 ? 0 : 0)
  const tip = 1.2 + i * 1.7
  const slant = tier === 1 ? 7 : 9.5
  const xl = tip + slant * ((mid - top) / 12.5) + (tier === 1 ? 0 : 0)
  const xr = w - xl
  const cx = w / 2
  const pts: [number, number][] = [[tip, mid], [xl, top]]
  if (tier === 3 && i === 0) {
    // mahkota: tiga puncak (tengah paling tinggi)
    pts.push([cx - 15, top], [cx - 10, 1.4], [cx - 5, top], [cx, 0.4], [cx + 5, top], [cx + 10, 1.4], [cx + 15, top])
  }
  pts.push([xr, top], [w - tip, mid], [xr, bot], [xl, bot])
  return 'M' + pts.map(([x, y]) => `${f(x)} ${f(y)}`).join('L') + 'Z'
}

/**
 * Lencana clan: emblem pixel + tag, berwarna sesuai warna clan, bentuk sesuai tier clan.
 *  Tier 1: ujung lancip. Tier 2: lancip + bingkai dalam + permata di ujung. Tier 3: bingkai emas + mahkota runcing.
 * Rare mendapat cahaya lembut; Legend (Black Shine) berdasar hitam dengan kilau yang bergerak pelan.
 */
export function ClanBadge({ tag, color, emblem, tier = 1, height = 30, noEmblem }: { tag: string; color: number; emblem: number; tier?: number; height?: number; noEmblem?: boolean }) {
  const uid = useId().replace(/:/g, '')
  const c = clanColorOf(color)
  const t = clampTier(tier)
  const tagW = [...tag].reduce((a, ch) => a + charW(ch), 0)
  const left = noEmblem ? 16 : 36
  const w = Math.ceil(left + tagW + 15)
  const light = c.ink !== '#FFFFFF' // lencana terang (White, Yellow, Aqua, Gold)
  const glow = c.rarity === 'legend' ? 'rgba(160,160,190,0.35)' : c.rarity === 'rare' ? `${c.edge}88` : undefined
  const body = bodyPath(w, t)
  const top = t === 3 ? 6 : 1.5
  const midY = (top + 26.5) / 2
  const trim = t === 3 ? '#FFE08A' : '#FFFFFF'
  const emblemCx = 21
  const ringId = `c${uid}`

  return (
    <svg
      width={(w * height) / H}
      height={height}
      viewBox={`0 0 ${w} ${H}`}
      aria-label={`Clan ${tag}, tier ${t}`}
      className="shrink-0"
      style={glow ? { filter: `drop-shadow(0 0 ${Math.max(2, height / 9)}px ${glow})`, overflow: 'visible' } : { overflow: 'visible' }}
    >
      <defs>
        <linearGradient id={`g${uid}`} x1="0" y1="0" x2="0.35" y2="1">
          <stop offset="0" stopColor={c.from} />
          {c.mid ? <stop offset="0.5" stopColor={c.mid} /> : null}
          <stop offset="1" stopColor={c.to} />
        </linearGradient>
        <linearGradient id={`e${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={t === 3 ? '#FFE08A' : c.edge} />
          <stop offset="1" stopColor={t === 3 ? '#C9962B' : c.edge} stopOpacity={t === 3 ? 1 : 0.45} />
        </linearGradient>
        <clipPath id={ringId}>
          <path d={body} />
        </clipPath>
        {c.shine ? (
          <linearGradient id={`s${uid}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#fff" stopOpacity="0" />
            <stop offset="0.5" stopColor="#fff" stopOpacity="0.34" />
            <stop offset="1" stopColor="#fff" stopOpacity="0" />
          </linearGradient>
        ) : null}
      </defs>

      <path d={body} fill={`url(#g${uid})`} stroke={`url(#e${uid})`} strokeWidth={t === 1 ? 1.6 : 1.9} strokeLinejoin="round" />
      {/* kilap tipis di bagian atas */}
      <rect x="0" y={top} width={w} height={(26.5 - top) * 0.42} fill="#fff" opacity={light ? 0.35 : 0.12} clipPath={`url(#${ringId})`} />

      {t >= 2 ? (
        <>
          {/* bingkai dalam */}
          <path d={bodyPath(w, t, 2.6)} fill="none" stroke={trim} strokeOpacity={t === 3 ? 0.9 : 0.5} strokeWidth="0.9" strokeLinejoin="round" />
          {/* permata di kedua ujung */}
          <path d={`M${f(5.4)} ${f(midY - 2.6)}L${f(8)} ${f(midY)}L${f(5.4)} ${f(midY + 2.6)}L${f(2.8)} ${f(midY)}Z`} fill={t === 3 ? '#FFE08A' : '#fff'} opacity="0.95" />
          <path d={`M${f(w - 5.4)} ${f(midY - 2.6)}L${f(w - 2.8)} ${f(midY)}L${f(w - 5.4)} ${f(midY + 2.6)}L${f(w - 8)} ${f(midY)}Z`} fill={t === 3 ? '#FFE08A' : '#fff'} opacity="0.95" />
        </>
      ) : null}

      {c.shine ? (
        <g clipPath={`url(#${ringId})`}>
          {/* pita cahaya miring yang menyapu pelan dari kiri ke kanan (siklus 4,5 dtk dengan jeda) */}
          <g transform="skewX(-22)">
            <rect x={-18} y="-2" width="18" height={H + 4} fill={`url(#s${uid})`}>
              <animate attributeName="x" values={`${-20};${-20};${w + 10}`} keyTimes="0;0.15;1" dur="4.5s" repeatCount="indefinite" calcMode="spline" keySplines="0 0 1 1;0.4 0 0.6 1" />
            </rect>
          </g>
        </g>
      ) : null}

      {noEmblem ? null : (
        <>
          <circle cx={emblemCx} cy={midY} r="10" fill="#000" opacity={light ? 0.14 : 0.3} />
          <PixelEmblem index={emblem} size={16} x={emblemCx - 8} y={midY - 8} />
        </>
      )}
      <text
        x={left}
        y={midY + 5}
        fontSize="14"
        fontWeight="800"
        fill={c.ink}
        textLength={tagW}
        lengthAdjust="spacing"
        style={{ fontFamily: 'Roboto, "Noto Sans", system-ui, sans-serif' }}
      >
        {tag}
      </text>
    </svg>
  )
}
