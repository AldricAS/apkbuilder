import { memo } from 'react'
import type { AnimeLite } from '../types'
import { episodeLabel, fmtCount, statusLabel } from '../lib/format'
import { Icon } from './Icon'
import { Poster } from './Poster'

type Props = {
  anime: AnimeLite
  onOpen: (a: AnimeLite) => void
  /** row = kartu di baris horizontal, grid = mengisi kolom grid */
  variant?: 'row' | 'grid'
  /** 0..1, tampilkan bar progres di bawah poster */
  progress?: number
  /** teks pengganti label episode di kiri bawah poster */
  badge?: string
  /** label sudut kiri atas, mis. "New" atau "Movie" */
  tag?: string
  onRemove?: () => void
}

function AnimeCardBase({ anime, onOpen, variant = 'row', progress, badge, tag, onRemove }: Props) {
  const total = anime.totalEpisodes ? `${anime.totalEpisodes} Eps` : undefined
  const ep = badge ?? total ?? episodeLabel(anime.latestEpisode)
  const views = fmtCount(anime.views)
  const sub = variant === 'grid' && anime.genres?.length && !views ? anime.genres.slice(0, 2).join(', ') : statusLabel(anime.status)

  return (
    <div className={variant === 'row' ? 'w-[clamp(112px,33vw,140px)] shrink-0 snap-start' : 'w-full'}>
      <button type="button" onClick={() => onOpen(anime)} className="block w-full text-left active:opacity-80">
        <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-raise">
          <Poster src={anime.poster} alt={anime.title} className="h-full w-full" />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/90 to-transparent" />
          {tag ? (
            <span className="absolute left-0 top-0 rounded-br-xl bg-accent px-2 py-0.5 text-[10px] font-extrabold text-ink">
              {tag}
            </span>
          ) : null}
          {anime.score ? (
            <span className="absolute right-1.5 top-1.5 flex items-center gap-0.5 rounded-full bg-black/55 px-1.5 py-0.5 text-[10.5px] font-semibold text-white backdrop-blur">
              <Icon name="star" size={10} className="text-accent" />
              {anime.score.toFixed(1)}
            </span>
          ) : null}
          {ep ? (
            <span className="absolute bottom-1.5 left-1.5 text-[11px] font-bold text-white drop-shadow">{ep}</span>
          ) : null}
          {progress !== undefined ? (
            <div className="absolute inset-x-0 bottom-0 h-1 bg-white/20">
              <div className="h-full bg-accent" style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
          ) : null}
        </div>
        <p className="mt-1.5 line-clamp-2 text-[12px] font-semibold leading-tight text-white">{anime.title}</p>
        {views ? (
          <p className="mt-0.5 flex items-center gap-1 text-[10.5px] text-muted">
            <Icon name="eye" size={12} /> {views}
          </p>
        ) : sub ? (
          <p className="mt-0.5 truncate text-[11px] text-muted">{sub}</p>
        ) : null}
      </button>
      {onRemove ? (
        <button
          type="button"
          aria-label="Hapus"
          onClick={onRemove}
          className="mt-1 flex items-center gap-1 text-[11px] text-muted active:text-accent"
        >
          <Icon name="trash" size={12} /> Hapus
        </button>
      ) : null}
    </div>
  )
}

export const AnimeCard = memo(AnimeCardBase)
