import { Avatar } from './UserBadges'
import { useBoard } from '../services/leaderboardService'
import type { UserProfile } from '../services/userService'

export const RANK_COLOR = ['#F4C96B', '#C9D1E0', '#D58B5A'] as const

export function displayNameOf(p: UserProfile | null | undefined): string {
  if (!p) return '…'
  return p.username?.trim() || p.displayName || 'Pengguna'
}

export function RankDot({ rank, size = 20 }: { rank: number; size?: number }) {
  const c = rank <= 3 ? RANK_COLOR[rank - 1] : '#3b4468'
  return (
    <span
      className="flex shrink-0 items-center justify-center rounded-full font-extrabold"
      style={{ width: size, height: size, fontSize: size * 0.55, background: c, color: rank <= 3 ? '#1a1305' : '#cfd6f5' }}
    >
      {rank}
    </span>
  )
}

export function BoltIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M13.5 2L5 13.5h6L10 22l9-12h-6.2z" />
    </svg>
  )
}

export function CrownIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z" />
    </svg>
  )
}

export { Avatar }

/** Badge "Top N LB" tampil untuk user yang masuk peringkat ini (XP bulanan). */
export const TOP_LB_LIMIT = 10

/** Peringkat XP bulanan user (1 = teratas), atau null bila di luar TOP_LB_LIMIT / belum ada XP bulan ini. */
export function useMonthlyRank(uid: string): number | null {
  const board = useBoard('monthly', TOP_LB_LIMIT)
  if (board.status !== 'ok') return null
  const i = board.rows.findIndex((r) => r.uid === uid)
  return i < 0 ? null : i + 1
}

const TOP_LB_STYLE: Record<number, string> = {
  1: 'bg-gradient-to-r from-[#B8860B] via-[#F4C96B] to-[#FFE9A8] text-[#2a1b00] ring-1 ring-[#F4C96B]/60',
  2: 'bg-gradient-to-r from-[#8A93A6] via-[#C9D1E0] to-[#EEF2F8] text-[#1a2030] ring-1 ring-[#C9D1E0]/60',
  3: 'bg-gradient-to-r from-[#8C4F26] via-[#D58B5A] to-[#F0B98F] text-[#2a1305] ring-1 ring-[#D58B5A]/60',
}
const TOP_LB_DEFAULT = 'bg-gradient-to-r from-[#2A1252] to-[#8B3DFF] text-white ring-1 ring-[#8B3DFF]/50'

/** Ukuran & tipografi disamakan dengan pill role (USER/ADMIN/dst). */
export function TopLbBadge({ rank }: { rank: number | null }) {
  if (!rank) return null
  return (
    <span
      title={`Peringkat ${rank} leaderboard XP bulanan`}
      className={`inline-flex items-center gap-1 rounded-md px-2 py-[2px] text-[10.5px] font-extrabold uppercase leading-[14px] tracking-wider ${TOP_LB_STYLE[rank] ?? TOP_LB_DEFAULT}`}
    >
      <CrownIcon size={11} />
      Top {rank} LB
    </span>
  )
}

/** Bintang berkilau 4 sudut (ikon AkimiShard). */
export function SparkIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M12 2l2.2 7.3L22 12l-7.8 2.7L12 22l-2.2-7.3L2 12l7.8-2.7z" />
    </svg>
  )
}

/** Bintang berkilau + percikan kecil (ikon AkimiGames). */
export function SparklesIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M10 5l1.8 5.2L17 12l-5.2 1.8L10 19l-1.8-5.2L3 12l5.2-1.8z" />
      <path d="M18 3l.9 2.1L21 6l-2.1.9L18 9l-.9-2.1L15 6l2.1-.9z" />
      <path d="M18.5 14l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z" />
    </svg>
  )
}
