// Tombol & sheet download episode (satu per satu atau banyak sekaligus).
import { useMemo, useState } from 'react'
import type { Anime, AnimeLite, Episode } from '../types'
import {
  cancelDownload,
  enqueueDownloads,
  retryDownload,
  useDownloadProgress,
  useDownloads,
} from '../services/downloadService'
import { Icon } from './Icon'
import { Sheet, toast } from './Feedback'

type AnimeMeta = AnimeLite & Partial<Anime>

function Ring({ ratio, size = 26 }: { ratio: number; size?: number }) {
  const r = (size - 4) / 2
  const c = 2 * Math.PI * r
  const indeterminate = ratio <= 0
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className={indeterminate ? 'animate-spin' : ''}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth="2.5" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeDasharray={`${indeterminate ? c * 0.25 : c * Math.min(1, ratio)} ${c}`}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
    </svg>
  )
}

/** Tombol download di baris episode: unduh / progres (ketuk = batal) / selesai / ulangi. */
export function EpisodeDownloadButton({ anime, episode }: { anime: AnimeMeta; episode: Episode }) {
  const entries = useDownloads()
  const prog = useDownloadProgress()
  const e = entries[episode.id]
  const p = prog[episode.id]
  const ratio = p && p.total > 0 ? p.received / p.total : 0

  let content = <Icon name="download" size={19} />
  let label = `Download episode ${episode.number}`
  let color = 'text-white/70'
  let onClick: () => void = () => {
    enqueueDownloads(anime, [episode])
  }

  if (e?.status === 'queued') {
    content = <Ring ratio={0} size={24} />
    label = 'Dalam antrean, ketuk untuk membatalkan'
    color = 'text-white/60'
    onClick = () => {
      cancelDownload(e.id)
      toast('Download dibatalkan')
    }
  } else if (e?.status === 'downloading') {
    content = (
      <span className="relative flex items-center justify-center">
        <Ring ratio={ratio} size={28} />
        <span className="absolute text-[8px] font-bold text-white">{ratio > 0 ? Math.round(ratio * 100) : ''}</span>
      </span>
    )
    label = 'Sedang di-download, ketuk untuk membatalkan'
    color = 'text-accent'
    onClick = () => {
      cancelDownload(e.id)
      toast('Download dibatalkan')
    }
  } else if (e?.status === 'done') {
    content = <Icon name="check" size={19} />
    label = 'Sudah di-download'
    color = 'text-accent'
    onClick = () => toast('Sudah di-download. Tonton lewat Home → Anime yang di download')
  } else if (e?.status === 'error') {
    content = <Icon name="refresh" size={19} />
    label = 'Download gagal, ketuk untuk mengulang'
    color = 'text-[#FF6B7A]'
    onClick = () => {
      toast(e.error ?? 'Download gagal')
      retryDownload(e.id)
    }
  }

  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className={`absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full active:bg-white/10 ${color}`}
    >
      {content}
    </button>
  )
}

const CHUNK = 50

/** Pilih banyak episode lalu download sekaligus (atau langsung semua). */
export function DownloadSheet({
  open,
  onClose,
  anime,
  episodes,
}: {
  open: boolean
  onClose: () => void
  anime: AnimeMeta
  episodes: Episode[]
}) {
  const entries = useDownloads()
  const [picked, setPicked] = useState<Set<string>>(new Set())
  const [range, setRange] = useState(0)

  const chunks = Math.ceil(episodes.length / CHUNK)
  const safeRange = Math.min(range, Math.max(0, chunks - 1))
  const visible = useMemo(() => episodes.slice(safeRange * CHUNK, safeRange * CHUNK + CHUNK), [episodes, safeRange])
  const free = useMemo(
    () => episodes.filter((e) => !entries[e.id] || entries[e.id].status === 'error'),
    [episodes, entries],
  )
  const freeIds = useMemo(() => new Set(free.map((e) => e.id)), [free])
  const chosen = episodes.filter((e) => picked.has(e.id) && freeIds.has(e.id))

  const toggle = (id: string) =>
    setPicked((s) => {
      const n = new Set(s)
      if (n.has(id)) n.delete(id)
      else n.add(id)
      return n
    })

  const selectVisible = () =>
    setPicked((s) => {
      const n = new Set(s)
      for (const e of visible) if (freeIds.has(e.id)) n.add(e.id)
      return n
    })

  const start = (list: Episode[]) => {
    if (!list.length) return
    const added = enqueueDownloads(anime, list)
    if (added > 0) {
      setPicked(new Set())
      onClose()
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title="Download episode">
      <p className="-mt-1 mb-3 text-[12px] leading-snug text-muted">
        Video disimpan di dalam aplikasi AkimiPlay (tidak masuk galeri) dan bisa ditonton tanpa internet.
      </p>

      {chunks > 1 ? (
        <div className="no-scrollbar mb-3 flex gap-2 overflow-x-auto">
          {Array.from({ length: chunks }).map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setRange(i)}
              className={`shrink-0 rounded-full px-3 py-1.5 text-[12px] font-medium active:scale-95 ${
                i === safeRange ? 'bg-accent text-ink' : 'bg-raise text-white/70'
              }`}
            >
              {episodes[i * CHUNK].number}–{episodes[Math.min(episodes.length, (i + 1) * CHUNK) - 1].number}
            </button>
          ))}
        </div>
      ) : null}

      <div className="grid grid-cols-5 gap-2">
        {visible.map((ep) => {
          const e = entries[ep.id]
          const locked = !!e && e.status !== 'error'
          const on = picked.has(ep.id) && !locked
          return (
            <button
              key={ep.id}
              type="button"
              disabled={locked}
              onClick={() => toggle(ep.id)}
              aria-label={`Episode ${ep.number}`}
              className={`relative flex h-11 items-center justify-center rounded-xl text-[14px] font-semibold active:scale-95 ${
                on
                  ? 'bg-accent text-ink'
                  : locked
                    ? 'bg-raise/50 text-white/35 ring-1 ring-line'
                    : 'bg-raise text-white ring-1 ring-line'
              }`}
            >
              {ep.number}
              {e?.status === 'done' ? (
                <span className="absolute right-0.5 top-0.5 text-accent">
                  <Icon name="check" size={11} />
                </span>
              ) : null}
            </button>
          )
        })}
      </div>

      <div className="mt-3 flex gap-2">
        <button
          type="button"
          onClick={selectVisible}
          className="flex-1 rounded-full bg-raise py-2.5 text-[12.5px] font-semibold text-white active:scale-95"
        >
          Pilih semua di sini
        </button>
        <button
          type="button"
          onClick={() => setPicked(new Set())}
          className="flex-1 rounded-full bg-raise py-2.5 text-[12.5px] font-semibold text-white/80 active:scale-95"
        >
          Kosongkan
        </button>
      </div>

      <button
        type="button"
        disabled={!chosen.length}
        onClick={() => start(chosen)}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-accent py-3 text-[14px] font-bold text-ink active:scale-[0.98] disabled:opacity-40"
      >
        <Icon name="download" size={18} /> {chosen.length ? `Download ${chosen.length} episode` : 'Pilih episode dulu'}
      </button>
      <button
        type="button"
        disabled={!free.length}
        onClick={() => start(free)}
        className="mt-2 w-full rounded-full bg-raise py-2.5 text-[13px] font-semibold text-white active:scale-[0.98] disabled:opacity-40"
      >
        {free.length ? `Download semua (${free.length} episode)` : 'Semua episode sudah di-download'}
      </button>
    </Sheet>
  )
}
