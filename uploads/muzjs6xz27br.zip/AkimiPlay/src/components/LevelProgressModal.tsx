import { LEVEL_TIERS, levelTier } from './LevelIcon'
import { Icon } from './Icon'
import { useBackHandler } from '../native/native'
import { fmtNum } from '../lib/xp'
import { fmtWatchTime } from '../services/profileService'

const LAST = LEVEL_TIERS[LEVEL_TIERS.length - 1]

function Hourglass({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M6 3h12M6 21h12M7 3c0 5 5 6 5 9s-5 4-5 9M17 3c0 5-5 6-5 9s5 4 5 9" />
    </svg>
  )
}

/** Pop-up "Level Progress": daftar semua ikon level berurutan, tier yang dilewati dicentang, tier sekarang punya progress. */
export function LevelProgressModal({
  open,
  onClose,
  level,
  xp,
  watchMinutes,
}: {
  open: boolean
  onClose: () => void
  level: number
  xp: number
  watchMinutes: number
}) {
  useBackHandler(
    () => {
      onClose()
      return true
    },
    350,
    open,
  )
  if (!open) return null

  const cur = levelTier(level)
  const curIdx = LEVEL_TIERS.indexOf(cur)

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center px-4 py-8">
      <div className="absolute inset-0 animate-fadeIn bg-black/70" onClick={onClose} />
      <div
        role="dialog"
        aria-label="Level Progress"
        className="relative flex max-h-full w-full max-w-[400px] animate-fadeIn flex-col rounded-3xl border border-white/10 bg-[#111522] px-5 pb-4 pt-5"
      >
        <h2 className="text-center text-[22px] font-extrabold text-white">Level Progress</h2>
        <p className="mt-1 text-center text-[14px] text-white/75">
          Level {fmtNum(level)} · {cur.label}
        </p>

        <ul className="mt-4 min-h-0 flex-1 space-y-1 overflow-y-auto">
          {LEVEL_TIERS.map((t, i) => {
            const done = i < curIdx
            const isCur = i === curIdx
            const isLast = t === LAST
            const range = isLast ? `Level ${fmtNum(t.min)}+` : `Level ${fmtNum(t.min)} - ${fmtNum(t.max)}`
            const next = LEVEL_TIERS[i + 1]
            const span = t.max - t.min + 1
            const ratio = isLast ? 1 : Math.min(1, Math.max(0, (level - t.min) / span))
            return (
              <li key={t.label} className="flex items-center gap-3 py-2" style={{ opacity: done || isCur ? 1 : 0.55 }}>
                <img src={t.src} alt="" width={36} height={36} draggable={false} className="h-9 w-9 shrink-0 object-contain" />
                <div className="min-w-0 flex-1">
                  <p className="text-[16px] font-bold leading-tight" style={{ color: t.color }}>
                    {t.label}
                  </p>
                  <p className="text-[13.5px] leading-tight" style={{ color: t.color, opacity: 0.8 }}>
                    {range}
                  </p>
                  {isCur ? (
                    <>
                      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
                        <div className="h-full rounded-full" style={{ width: `${ratio * 100}%`, background: t.color }} />
                      </div>
                      <p className="mt-1 text-[12px] font-semibold text-white/85">
                        {isLast ? 'Tier tertinggi' : `${Math.round(ratio * 100)}% · ${fmtNum(next.min - level)} level ke ${next.label}`}
                      </p>
                    </>
                  ) : null}
                </div>
                <span className="flex w-7 shrink-0 justify-center">
                  {done ? (
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#4ADE80] text-ink">
                      <Icon name="check" size={16} />
                    </span>
                  ) : isCur ? (
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white text-ink">
                      <Icon name="check" size={16} />
                    </span>
                  ) : (
                    <span className="text-white/70">
                      <Hourglass size={22} />
                    </span>
                  )}
                </span>
              </li>
            )
          })}
        </ul>

        <p className="mt-3 flex items-center justify-center gap-3 text-[15px] font-bold text-white">
          <span>EXP: {fmtNum(xp)}</span>
          <span className="h-4 w-px bg-white/25" />
          <span>Waktu: {fmtWatchTime(watchMinutes)}</span>
        </p>
        <button type="button" onClick={onClose} className="mx-auto mt-3 rounded-full bg-white/10 px-6 py-2 text-[13px] font-semibold text-white active:scale-95">
          Tutup
        </button>
      </div>
    </div>
  )
}
