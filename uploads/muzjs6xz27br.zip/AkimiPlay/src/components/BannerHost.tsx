import { useEffect, useRef, useState } from 'react'
import { useBackHandler } from '../native/native'
import { subscribeBanner, type Banner } from '../services/bannerService'
import { Icon } from './Icon'

/** Berapa lama aplikasi harus berada di latar belakang sebelum banner ditampilkan lagi saat dibuka kembali. 0 = setiap kali dibuka kembali. */
export const BANNER_RESHOW_AFTER_MS = 30_000

/** Kartu banner. Dipakai untuk tampilan asli (dengan tombol X) dan pratinjau di Panel Developer (tanpa `onClose`). */
export function BannerCard({ title, text, btn, link, onClose, onLink }: { title: string; text: string; btn?: string; link?: string; onClose?: () => void; onLink?: (url: string) => void }) {
  return (
    <div className="w-full rounded-[26px] border-[1.5px] border-[#D93A52] bg-[#2A2029] p-5 shadow-[0_24px_70px_rgba(0,0,0,0.65)]">
      <div className="flex items-center gap-3">
        <Icon name="bell" size={26} className="shrink-0 text-[#F0455A]" />
        <h2 className="min-w-0 flex-1 break-words text-[21px] font-extrabold leading-tight tracking-tight text-white">{title || '…'}</h2>
        {onClose ? (
          <button
            type="button"
            aria-label="Tutup banner"
            onClick={onClose}
            className="-mr-1.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white active:bg-white/10"
          >
            <Icon name="x" size={26} />
          </button>
        ) : null}
      </div>
      <div className="mt-4 max-h-[52vh] overflow-y-auto">
        <p className="whitespace-pre-wrap break-words text-[16px] leading-[1.6] text-white/90">{text || '…'}</p>
      </div>
      {btn && link ? (
        <button
          type="button"
          onClick={() => onLink?.(link)}
          className="mt-5 flex h-12 w-full items-center justify-center rounded-full bg-[#F0455A] px-5 text-[15px] font-extrabold text-white shadow-[0_6px_20px_rgba(240,69,90,0.4)] active:scale-[0.98]"
        >
          {btn}
        </button>
      ) : null}
    </div>
  )
}

/**
 * Menampilkan banner developer sebagai pop-up setiap aplikasi dibuka.
 * - Ditutup dengan tombol X, tombol Kembali HP, atau mengetuk area gelap.
 * - Status "sudah ditutup" hanya disimpan di memori, jadi muncul lagi saat aplikasi dibuka berikutnya.
 * - Banner yang diganti developer (ts berbeda) muncul lagi walau yang lama sudah ditutup.
 */
export function BannerHost() {
  const [banner, setBanner] = useState<Banner | null>(null)
  const [dismissedTs, setDismissedTs] = useState<number | null>(null)
  const hiddenAt = useRef<number | null>(null)

  useEffect(() => subscribeBanner(setBanner), [])

  // dibuka kembali dari latar belakang (bukan buka baru): tampilkan lagi jika sudah cukup lama ditinggalkan
  useEffect(() => {
    const onVis = () => {
      if (document.hidden) {
        hiddenAt.current = Date.now()
        return
      }
      const away = hiddenAt.current ? Date.now() - hiddenAt.current : 0
      hiddenAt.current = null
      if (away >= BANNER_RESHOW_AFTER_MS) setDismissedTs(null)
    }
    document.addEventListener('visibilitychange', onVis)
    return () => document.removeEventListener('visibilitychange', onVis)
  }, [])

  const open = !!banner && banner.ts !== dismissedTs
  const close = () => banner && setDismissedTs(banner.ts)

  useBackHandler(
    () => {
      close()
      return true
    },
    450,
    open,
  )

  if (!open || !banner) return null
  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center px-5 pt-safe">
      <div className="absolute inset-0 animate-fadeIn bg-black/70" onClick={close} />
      <div className="relative w-full max-w-md animate-fadeIn">
        <BannerCard
          title={banner.title}
          text={banner.text}
          btn={banner.btn}
          link={banner.link}
          onClose={close}
          onLink={(u) => {
            window.open(u, '_blank', 'noopener')
            close()
          }}
        />
      </div>
    </div>
  )
}
