import type { ReactNode } from 'react'
import { AnimeCard } from './AnimeCard'
import type { Anime, AnimeLite } from '../types'

export function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-6">
      <h2 className="px-4 text-[18px] font-semibold tracking-tight text-white">{title}</h2>
      <div className="no-scrollbar mt-2.5 flex snap-x gap-2.5 overflow-x-auto px-4 pb-1">{children}</div>
    </section>
  )
}

export function AnimeRow({
  title,
  items,
  onOpen,
}: {
  title: string
  items: Anime[]
  onOpen: (a: AnimeLite) => void
}) {
  if (!items.length) return null
  return (
    <Section title={title}>
      {items.slice(0, 30).map((a) => (
        <AnimeCard key={a.id} anime={a} onOpen={onOpen} />
      ))}
    </Section>
  )
}

export function RowSkeleton({ title }: { title?: string }) {
  return (
    <section className="mt-6">
      {title ? <h2 className="px-4 text-[18px] font-semibold tracking-tight text-white">{title}</h2> : null}
      <div className="no-scrollbar mt-3 flex gap-3 overflow-hidden px-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="w-[clamp(112px,33vw,140px)] shrink-0">
            <div className="shimmer aspect-[2/3] rounded-xl" />
            <div className="shimmer mt-2 h-3 w-full rounded" />
            <div className="shimmer mt-1.5 h-3 w-2/3 rounded" />
          </div>
        ))}
      </div>
    </section>
  )
}

export function GridSkeleton({ count = 9 }: { count?: number }) {
  return (
    <div className="grid grid-cols-3 gap-2.5 px-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i}>
          <div className="shimmer aspect-[2/3] rounded-2xl" />
          <div className="shimmer mt-2 h-3 w-full rounded" />
          <div className="shimmer mt-1.5 h-3 w-2/3 rounded" />
        </div>
      ))}
    </div>
  )
}
