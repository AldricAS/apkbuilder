import { useEffect, useState } from 'react'
import { Capacitor, CapacitorHttp } from '@capacitor/core'
import { Logo } from './Logo'

// Sebagian server gambar menolak hotlink tanpa Referer. Jika <img> gagal, coba ambil lewat
// HTTP native Android dengan header Referer, lalu tampilkan sebagai data URL.
const memo = new Map<string, string | null>()
let active = 0
const waiters: Array<() => void> = []

async function slot() {
  if (active >= 4) await new Promise<void>((r) => waiters.push(r))
  active++
}
function release() {
  active--
  waiters.shift()?.()
}

async function viaNative(url: string): Promise<string | null> {
  if (memo.has(url)) return memo.get(url) ?? null
  if (!Capacitor.isNativePlatform()) return null
  await slot()
  try {
    const r = await CapacitorHttp.get({
      url,
      responseType: 'blob',
      headers: {
        Referer: 'https://animeinweb.com/',
        Accept: 'image/avif,image/webp,image/*,*/*;q=0.8',
      },
    })
    if (r.status < 400 && typeof r.data === 'string' && r.data.length > 100) {
      const h = (r.headers ?? {}) as Record<string, string>
      const ct = (h['Content-Type'] ?? h['content-type'] ?? 'image/jpeg').split(';')[0]
      const out = `data:${ct};base64,${r.data}`
      if (memo.size > 150) memo.delete(memo.keys().next().value as string)
      memo.set(url, out)
      return out
    }
  } catch {
    /* diabaikan */
  } finally {
    release()
  }
  memo.set(url, null)
  return null
}

export function Poster({ src, alt, className = '' }: { src?: string; alt: string; className?: string }) {
  const [current, setCurrent] = useState(src)
  const [failed, setFailed] = useState(false)
  const [triedNative, setTriedNative] = useState(false)

  useEffect(() => {
    setCurrent(src)
    setFailed(false)
    setTriedNative(false)
  }, [src])

  const onError = () => {
    if (!src || triedNative) {
      setFailed(true)
      return
    }
    setTriedNative(true)
    void viaNative(src).then((data) => (data ? setCurrent(data) : setFailed(true)))
  }

  if (!current || failed) {
    return (
      <div className={`flex items-center justify-center bg-raise ${className}`}>
        <div className="opacity-40">
          <Logo size={36} />
        </div>
      </div>
    )
  }
  return (
    <img
      src={current}
      alt={alt}
      loading="lazy"
      decoding="async"
      draggable={false}
      referrerPolicy="no-referrer"
      onError={onError}
      className={`bg-raise object-cover ${className}`}
    />
  )
}
