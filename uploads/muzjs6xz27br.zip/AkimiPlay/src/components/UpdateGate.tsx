import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import { App } from '@capacitor/app'
import type { PluginListenerHandle } from '@capacitor/core'
import { exitApp, isNative, useBackHandler } from '../native/native'
import { Logo, APP_NAME } from './Logo'
import { Spinner } from './States'
import { compareVersions, decideUpdate, type AppConfig, type UpdateDecision } from '../lib/version'
import { getInstalledVersion, openUpdateUrl, subscribeAppConfig, type ConfigResult, type Installed } from '../services/updateService'

const CHECK_TIMEOUT_MS = 6000

function Backdrop({ children }: { children: ReactNode }) {
  return (
    <div className="pt-safe fixed inset-0 z-[300] flex flex-col overflow-hidden bg-ink">
      <div className="pointer-events-none absolute -top-24 left-1/2 h-[380px] w-[380px] -translate-x-1/2 animate-glow rounded-full bg-accent/25 blur-[90px]" />
      <div className="pointer-events-none absolute -left-24 top-[30%] h-[260px] w-[260px] animate-glow rounded-full bg-[#7a5cff]/20 blur-[90px]" />
      {children}
    </div>
  )
}

/** Tombol pink khas AkimiPlay. */
function UpdateButton({ label, disabled, onClick }: { label: string; disabled?: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className="relative flex h-[52px] w-full items-center justify-center overflow-hidden rounded-full bg-gradient-to-r from-[#FF9DBB] via-accent to-[#FF5C8D] px-4 text-[15px] font-extrabold uppercase tracking-wide text-ink shadow-[0_6px_22px_rgba(255,92,141,0.35)] ring-1 ring-white/20 active:scale-[0.98] disabled:opacity-50"
    >
      {label}
    </button>
  )
}

/** Halaman FORCE UPDATE: tanpa Lewati / Nanti / Tutup. Satu-satunya aksi: UNDUH & UPDATE (atau keluar dari aplikasi lewat Back). */
function ForceUpdateScreen({ installed, cfg, onUpdate }: { installed: string; cfg: AppConfig; onUpdate: () => void }) {
  useBackHandler(() => {
    exitApp()
    return true
  }, 100)
  return (
    <Backdrop>
      <div className="relative flex flex-1 flex-col items-center justify-center px-7 text-center">
        <div className="rounded-[28px] bg-gradient-to-br from-white/15 to-white/[0.03] p-4 shadow-[0_20px_60px_rgba(255,122,162,0.25)] ring-1 ring-white/15">
          <Logo size={64} />
        </div>
        <h1 className="mt-6 text-[26px] font-extrabold tracking-tight text-white">Update Diperlukan</h1>
        <p className="mt-2 max-w-[300px] text-[14px] leading-snug text-white/65">
          {cfg.message || `Kamu harus memperbarui ${APP_NAME} terlebih dahulu.`}
        </p>
        <div className="mt-5 w-full max-w-[320px] divide-y divide-white/[0.07] overflow-hidden rounded-2xl bg-white/[0.05] ring-1 ring-white/[0.08]">
          <div className="flex items-center justify-between px-4 py-3">
            <span className="text-[13px] text-muted">Versi saat ini</span>
            <span className="text-[14px] font-bold text-white">{installed}</span>
          </div>
          <div className="flex items-center justify-between px-4 py-3">
            <span className="text-[13px] text-muted">Versi minimum</span>
            <span className="text-[14px] font-bold text-accent">{cfg.minimumRaw}</span>
          </div>
        </div>
      </div>
      <div className="relative px-6 pb-10">
        {cfg.updateUrl ? (
          <>
            <UpdateButton label="Unduh & Update" onClick={onUpdate} />
            <p className="mt-3 text-center text-[12px] leading-snug text-white/45">
              Setelah APK terpasang, buka kembali {APP_NAME}.
            </p>
          </>
        ) : (
          <>
            <UpdateButton label="Unduh & Update" disabled onClick={() => undefined} />
            <p className="mt-3 text-center text-[13px] font-semibold text-accent">Link update tidak tersedia.</p>
          </>
        )}
      </div>
    </Backdrop>
  )
}

/** Update opsional: boleh ditunda dengan "Nanti". */
function OptionalUpdateDialog({ cfg, onUpdate, onLater }: { cfg: AppConfig; onUpdate: () => void; onLater: () => void }) {
  useBackHandler(() => {
    onLater()
    return true
  }, 100)
  return (
    <div className="fixed inset-0 z-[300] flex items-end bg-black/60 backdrop-blur-sm">
      <div className="w-full animate-sheetUp rounded-t-[28px] border-t border-white/10 bg-gradient-to-b from-[#1a1a24] to-[#101016] px-5 pb-8 pt-3">
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-white/15" />
        <h2 className="text-center text-[20px] font-extrabold text-white">Update Tersedia</h2>
        <p className="mt-2 text-center text-[13.5px] leading-snug text-white/65">
          {cfg.message || `Versi baru ${APP_NAME} sudah tersedia.`}
        </p>
        <p className="mt-3 text-center text-[13px] text-muted">
          Versi terbaru: <span className="font-bold text-accent">{cfg.latestRaw}</span>
        </p>
        <div className="mt-5 space-y-2.5">
          <UpdateButton label="Update" onClick={onUpdate} />
          <button
            type="button"
            onClick={onLater}
            className="flex h-12 w-full items-center justify-center rounded-full bg-white/10 text-[14px] font-semibold text-white active:scale-[0.98]"
          >
            Nanti
          </button>
        </div>
      </div>
    </div>
  )
}

/**
 * Pintu update, dipasang setelah login. Setiap kali dibuka: baca versi APK yang sedang berjalan (tanpa cache) lalu
 * bandingkan dengan app_config di Realtime Database. Force update memblokir seluruh aplikasi (children tidak dirender).
 * Firebase gagal / app_config tidak ada atau rusak / versi tidak terbaca -> aplikasi tetap terbuka (tidak ada loop).
 */
export function UpdateGate({ children }: { children: ReactNode }) {
  const [installed, setInstalled] = useState<Installed | null>(null)
  const [result, setResult] = useState<ConfigResult | null>(null)
  const [timedOut, setTimedOut] = useState(false)
  const [laterFor, setLaterFor] = useState<string | null>(null)

  const readInstalled = useCallback(() => {
    let alive = true
    void getInstalledVersion().then((i) => alive && setInstalled(i))
    return () => {
      alive = false
    }
  }, [])

  // versi terpasang: dibaca ulang setiap gate dibuka dan setiap aplikasi kembali ke depan
  useEffect(() => {
    const stop = readInstalled()
    let handle: PluginListenerHandle | undefined
    let cancelled = false
    if (isNative) {
      App.addListener('appStateChange', ({ isActive }) => {
        if (isActive) readInstalled()
      })
        .then((h) => (cancelled ? h.remove() : (handle = h)))
        .catch(() => undefined)
    }
    return () => {
      stop()
      cancelled = true
      handle?.remove()
    }
  }, [readInstalled])

  // konfigurasi update: langganan live (developer menaikkan minimum -> langsung berlaku)
  useEffect(() => subscribeAppConfig(setResult), [])

  // jangan menahan pengguna selamanya bila server tidak menjawab
  const answered = result !== null
  useEffect(() => {
    if (answered) return
    const t = setTimeout(() => setTimedOut(true), CHECK_TIMEOUT_MS)
    return () => clearTimeout(t)
  }, [answered])

  const cfg = result?.ok ? result.config : null
  const decision: UpdateDecision = installed ? decideUpdate(installed.version, cfg) : 'normal'
  const resolved = installed !== null && (answered || timedOut)

  // gagal membaca config: catat saja (jangan crash, jangan memblokir)
  const warned = useRef(false)
  useEffect(() => {
    if (result && !result.ok && !warned.current) {
      warned.current = true
      console.warn('[update] app_config tidak bisa dibaca:', result.error)
    }
  }, [result])

  const doUpdate = useCallback(() => {
    if (cfg?.updateUrl) void openUpdateUrl(cfg.updateUrl).catch(() => undefined)
  }, [cfg])

  if (!resolved) {
    return (
      <Backdrop>
        <div className="relative flex flex-1 flex-col items-center justify-center px-8 text-center">
          <Logo size={64} />
          <p className="mt-5 text-[13.5px] text-muted">Memeriksa pembaruan...</p>
          <div className="mt-3">
            <Spinner size={24} />
          </div>
        </div>
      </Backdrop>
    )
  }

  if (decision === 'force' && cfg) {
    return <ForceUpdateScreen installed={installed?.raw ?? '-'} cfg={cfg} onUpdate={doUpdate} />
  }

  const showOptional =
    decision === 'optional' && !!cfg?.updateUrl && !!installed?.version && !!cfg.latest && laterFor !== cfg.latestRaw &&
    compareVersions(installed.version, cfg.latest) < 0

  return (
    <>
      {children}
      {showOptional && cfg ? <OptionalUpdateDialog cfg={cfg} onUpdate={doUpdate} onLater={() => setLaterFor(cfg.latestRaw)} /> : null}
    </>
  )
}
