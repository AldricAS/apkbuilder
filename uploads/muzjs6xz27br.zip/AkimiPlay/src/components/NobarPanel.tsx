import { useState, type ReactNode } from 'react'
import { useNav } from '../nav/router'
import { kickMember, NOBAR_MAX, type NobarMember, type NobarRoom } from '../services/nobarService'
import { liveOf, useLiveUsers } from '../services/liveProfiles'
import type { Episode } from '../types'
import { Avatar, RoleCheck, UserLine } from './UserBadges'
import { EpisodeTiles } from './EpisodeList'
import { ConfirmDialog, Sheet, toast } from './Feedback'
import { Icon } from './Icon'
import { NobarChat } from './NobarChat'

function Btn({ onClick, children, tone = 'plain' }: { onClick: () => void; children: ReactNode; tone?: 'plain' | 'accent' | 'danger' }) {
  const cls =
    tone === 'accent'
      ? 'bg-accent text-ink'
      : tone === 'danger'
        ? 'bg-[#301014] text-[#f87171] ring-1 ring-[#6b1f27]'
        : 'bg-raise text-white ring-1 ring-line'
  return (
    <button type="button" onClick={onClick} className={`flex h-9 items-center gap-1.5 rounded-full px-3.5 text-[12.5px] font-bold active:scale-95 ${cls}`}>
      {children}
    </button>
  )
}

/**
 * Bagian bawah player saat nobar: siapa owner-nya, jumlah orang, tombol owner (episode, ganti anime, stop),
 * daftar peserta (owner bisa kick), dan komentar room.
 */
export function NobarPanel({
  room,
  isOwner,
  members,
  episodes,
  epId,
  onPickEpisode,
  onChangeAnime,
  onStop,
  onLeave,
}: {
  room: NobarRoom
  isOwner: boolean
  members: NobarMember[]
  episodes: Episode[]
  epId?: string
  onPickEpisode: (id: string) => void
  onChangeAnime: () => void
  onStop: () => void
  onLeave: () => void
}) {
  const nav = useNav()
  const live = useLiveUsers([room.ownerUid, ...members.map((m) => m.uid)])
  const owner = liveOf(
    { uid: room.ownerUid, name: room.ownerName, photoURL: room.ownerPhoto, role: room.ownerRole, verified: room.ownerVerified, level: 1 },
    live.get(room.ownerUid),
  )
  const [people, setPeople] = useState(false)
  const [eps, setEps] = useState(false)
  const [confirm, setConfirm] = useState<'stop' | 'leave' | null>(null)
  const [kick, setKick] = useState<NobarMember | null>(null)
  const count = 1 + members.length

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="shrink-0 border-b border-line px-4 pb-3 pt-3">
        <div className="flex items-center gap-3">
          <button type="button" aria-label={`Profil ${owner.name}`} onClick={() => nav.openProfile(room.ownerUid)} className="shrink-0 active:scale-95">
            <Avatar url={owner.photoURL} name={owner.name} size={40} />
          </button>
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-accent">
              <span className="relative flex h-2 w-2">
                <span className={`absolute inline-flex h-full w-full rounded-full ${room.online ? 'animate-ping bg-[#4ade80]/70' : ''}`} />
                <span className={`relative inline-flex h-2 w-2 rounded-full ${room.online ? 'bg-[#4ade80]' : 'bg-[#f5b94a]'}`} />
              </span>
              Nobar aktif
            </p>
            <p className="flex min-w-0 items-center gap-1.5 text-[14px] font-extrabold text-white">
              <span className="truncate">Owner {owner.name}</span>
              <RoleCheck role={owner.role} verified={owner.verified} size={15} />
            </p>
          </div>
          <button
            type="button"
            onClick={() => setPeople(true)}
            className="flex shrink-0 items-center gap-1.5 rounded-full bg-raise px-3 py-1.5 text-[12.5px] font-bold text-white ring-1 ring-line active:scale-95"
          >
            <Icon name="users" size={15} /> {count}/{NOBAR_MAX}
          </button>
        </div>

        {!room.online ? (
          <p className="mt-2.5 rounded-xl bg-[#2b2210] px-3 py-2 text-[12px] text-[#f5b94a]">Owner sedang terputus. Menunggu tersambung lagi...</p>
        ) : null}

        <div className="mt-2.5 flex flex-wrap gap-2">
          {isOwner ? (
            <>
              <Btn onClick={() => setEps(true)}>
                <Icon name="list" size={15} /> Episode
              </Btn>
              <Btn onClick={onChangeAnime}>
                <Icon name="refresh" size={15} /> Ganti anime
              </Btn>
              <Btn tone="danger" onClick={() => setConfirm('stop')}>
                <Icon name="x" size={15} /> Stop nobar
              </Btn>
            </>
          ) : (
            <>
              <p className="flex h-9 items-center gap-1.5 rounded-full bg-white/5 px-3 text-[12px] text-white/60">
                <Icon name="eye" size={14} /> Hanya owner yang bisa play, jeda, dan geser
              </p>
              <Btn tone="danger" onClick={() => setConfirm('leave')}>
                <Icon name="logout" size={15} /> Keluar
              </Btn>
            </>
          )}
        </div>
      </div>

      <div className="min-h-0 flex-1">
        <NobarChat owner={room.ownerUid} isOwner={isOwner} members={members} ownerName={owner.name} />
      </div>

      <Sheet open={people} onClose={() => setPeople(false)} title={`Peserta nobar (${count}/${NOBAR_MAX})`}>
        <ul className="space-y-2">
          <li className="flex items-center gap-3 rounded-2xl bg-raise px-3 py-2.5">
            <Avatar url={owner.photoURL} name={owner.name} size={36} />
            <div className="min-w-0 flex-1">
              <UserLine name={owner.name} userId={room.ownerUserId} role={owner.role} verified={owner.verified} level={owner.level} size="sm" onProfile={() => nav.openProfile(room.ownerUid)} />
            </div>
            <span className="shrink-0 rounded-full bg-accent/20 px-2.5 py-1 text-[10.5px] font-extrabold uppercase tracking-wide text-accent">Owner</span>
          </li>
          {members.map((m) => {
            const l = liveOf({ ...m, level: m.level }, live.get(m.uid))
            return (
              <li key={m.uid} className="flex items-center gap-3 rounded-2xl bg-raise px-3 py-2.5">
                <Avatar url={l.photoURL} name={l.name} size={36} />
                <div className="min-w-0 flex-1">
                  <UserLine name={l.name} userId={m.userId} role={l.role} verified={l.verified} level={l.level} clanTag={l.clanTag} size="sm" onProfile={() => nav.openProfile(m.uid)} />
                </div>
                {isOwner ? (
                  <button
                    type="button"
                    aria-label={`Kick ${l.name}`}
                    onClick={() => {
                      setKick(m)
                      setPeople(false)
                    }}
                    className="shrink-0 rounded-full bg-[#301014] px-3 py-1.5 text-[11.5px] font-bold text-[#f87171] active:scale-95"
                  >
                    Kick
                  </button>
                ) : null}
              </li>
            )
          })}
          {members.length === 0 ? <li className="py-3 text-center text-[12.5px] text-muted">Belum ada yang bergabung.</li> : null}
        </ul>
      </Sheet>

      <Sheet open={eps} onClose={() => setEps(false)} title="Pilih episode">
        <p className="mb-3 text-[12.5px] text-muted">Semua peserta ikut pindah ke episode yang kamu pilih.</p>
        <div className="-mx-5">
          <EpisodeTiles
            episodes={episodes}
            currentId={epId}
            onSelect={(e) => {
              setEps(false)
              onPickEpisode(e.id)
            }}
          />
        </div>
      </Sheet>

      <ConfirmDialog
        open={confirm === 'stop'}
        title="Stop nobar?"
        message="Room ditutup untuk semua peserta dan komentar room dihapus."
        confirmLabel="Stop"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          setConfirm(null)
          onStop()
        }}
      />
      <ConfirmDialog
        open={confirm === 'leave'}
        title="Keluar dari nobar?"
        message="Kamu bisa masuk lagi selama room masih aktif."
        confirmLabel="Keluar"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          setConfirm(null)
          onLeave()
        }}
      />
      <ConfirmDialog
        open={!!kick}
        title={`Kick ${kick?.name ?? ''}?`}
        message={`${kick?.name ?? 'Orang ini'} langsung dikeluarkan dan tidak bisa masuk lagi ke room ${owner.name}.`}
        confirmLabel="Kick"
        onCancel={() => setKick(null)}
        onConfirm={() => {
          const k = kick
          setKick(null)
          if (!k) return
          void kickMember(room.ownerUid, k)
            .then(() => toast(`${k.name} di-kick`))
            .catch(() => toast('Gagal kick, coba lagi'))
        }}
      />
    </div>
  )
}
