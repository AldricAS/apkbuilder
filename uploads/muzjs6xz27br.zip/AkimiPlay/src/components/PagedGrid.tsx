import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import type { Anime, AnimeLite, Paged } from '../types'
import { errMsg } from '../lib/format'
import { AnimeCard } from './AnimeCard'
import { GridSkeleton } from './Section'
import { EmptyState, ErrorState, Spinner } from './States'

type Props = {
  /** Ganti nilai ini untuk mengulang dari halaman pertama (mis. saat kata kunci berubah). */
  resetKey: string
  load: (page: number) => Promise<Paged<Anime>>
  onOpen: (a: AnimeLite) => void
  emptyTitle: string
  emptyHint?: string
  emptyAction?: ReactNode
}

/** Grid poster dengan infinite scroll. Berhenti setelah 3 halaman berturut-turut tanpa hasil baru. */
export function PagedGrid({ resetKey, load, onOpen, emptyTitle, emptyHint, emptyAction }: Props) {
  const [items, setItems] = useState<Anime[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [done, setDone] = useState(false)

  const loadRef = useRef(load)
  loadRef.current = load
  const gen = useRef(0)
  const page = useRef(0)
  const busy = useRef(false)
  const doneRef = useRef(false)
  const seen = useRef(new Set<string>())
  const sentinel = useRef<HTMLDivElement>(null)

  const loadMore = useCallback(async () => {
    if (busy.current || doneRef.current) return
    busy.current = true
    const g = gen.current
    setLoading(true)
    setError(null)
    try {
      let empties = 0
      let fresh: Anime[] = []
      for (;;) {
        const r = await loadRef.current(page.current)
        if (g !== gen.current) return
        page.current += 1
        fresh = r.items.filter((a) => !seen.current.has(a.id))
        fresh.forEach((a) => seen.current.add(a.id))
        if (!r.hasMore) {
          doneRef.current = true
          break
        }
        if (fresh.length > 0) break
        empties += 1
        if (empties >= 3) {
          doneRef.current = true
          break
        }
      }
      setDone(doneRef.current)
      if (fresh.length) setItems((p) => [...p, ...fresh])
    } catch (e) {
      if (g === gen.current) setError(errMsg(e))
    } finally {
      if (g === gen.current) {
        busy.current = false
        setLoading(false)
      }
    }
  }, [])

  // reset saat resetKey berubah
  useEffect(() => {
    gen.current += 1
    page.current = 0
    busy.current = false
    doneRef.current = false
    seen.current = new Set()
    setItems([])
    setDone(false)
    setError(null)
    setLoading(true)
    void loadMore()
  }, [resetKey, loadMore])

  // infinite scroll
  useEffect(() => {
    const el = sentinel.current
    if (!el || done || error) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) void loadMore()
      },
      { rootMargin: '700px' },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [items.length, done, error, loadMore])

  if (items.length === 0) {
    if (error) return <ErrorState message={error} onRetry={() => void loadMore()} />
    if (loading) return <GridSkeleton />
    if (done) return <EmptyState title={emptyTitle} hint={emptyHint} action={emptyAction} />
  }

  return (
    <div>
      <div className="grid grid-cols-3 gap-x-2.5 gap-y-4 px-4">
        {items.map((a) => (
          <AnimeCard key={a.id} anime={a} onOpen={onOpen} variant="grid" />
        ))}
      </div>
      <div ref={sentinel} className="flex h-16 items-center justify-center">
        {loading ? <Spinner /> : null}
        {error ? (
          <button type="button" onClick={() => void loadMore()} className="text-[13px] font-semibold text-accent">
            Gagal memuat, ketuk untuk coba lagi
          </button>
        ) : null}
      </div>
    </div>
  )
}
