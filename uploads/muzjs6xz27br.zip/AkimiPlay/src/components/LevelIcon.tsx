import l01 from '../assets/levels/level-01.png'
import l02 from '../assets/levels/level-02.png'
import l03 from '../assets/levels/level-03.png'
import l04 from '../assets/levels/level-04.png'
import l05 from '../assets/levels/level-05.png'
import l06 from '../assets/levels/level-06.png'
import l07 from '../assets/levels/level-07.png'
import l08 from '../assets/levels/level-08.png'
import l09 from '../assets/levels/level-09.png'
import l10 from '../assets/levels/level-10.png'

/**
 * Ikon level per rentang. Gambar berasal dari level.zip (latar sudah dihapus, desain tidak diubah).
 * `max` = level tertinggi di rentang itu; level di atas 6000 tetap memakai ikon terakhir.
 */
export type LevelTier = { min: number; max: number; src: string; name: string; label: string; color: string }

/** Tier ikon level (urut dari terendah). `max` = level tertinggi di tier itu; level di atas tier terakhir tetap memakai ikon terakhir. */
export const LEVEL_TIERS: LevelTier[] = [
  { min: 1, max: 20, src: l01, name: 'Level 1-20', label: 'Coal', color: '#9aa3b5' },
  { min: 21, max: 50, src: l02, name: 'Level 21-50', label: 'Copper', color: '#E39A6B' },
  { min: 51, max: 100, src: l03, name: 'Level 51-100', label: 'Iron', color: '#D5DBE6' },
  { min: 101, max: 200, src: l04, name: 'Level 101-200', label: 'Emerald', color: '#4ADE80' },
  { min: 201, max: 450, src: l05, name: 'Level 201-450', label: 'Diamond', color: '#5EEAD4' },
  { min: 451, max: 890, src: l06, name: 'Level 451-890', label: 'Netherite', color: '#A39BB5' },
  { min: 891, max: 1300, src: l07, name: 'Level 891-1300', label: 'Totem', color: '#F4C96B' },
  { min: 1301, max: 2000, src: l08, name: 'Level 1301-2000', label: 'Nether Star', color: '#B9C4FF' },
  { min: 2001, max: 4000, src: l09, name: 'Level 2001-4000', label: 'Lava', color: '#FF8A3D' },
  { min: 4001, max: 6000, src: l10, name: 'Level 4001-6000', label: 'Bedrock', color: '#8D93A3' },
]
const TIERS = LEVEL_TIERS

export function levelTier(level: number) {
  const lv = Number.isFinite(level) ? Math.max(1, Math.floor(level)) : 1
  return TIERS.find((t) => lv <= t.max) ?? TIERS[TIERS.length - 1]
}

/** Ikon level yang otomatis mengikuti level (persegi, tidak di-stretch, ukuran seragam di seluruh aplikasi). */
export function LevelIcon({ level, size = 16 }: { level: number; size?: number }) {
  const t = levelTier(level)
  return (
    <img
      src={t.src}
      alt={t.name}
      width={size}
      height={size}
      draggable={false}
      className="shrink-0 select-none object-contain"
      style={{ width: size, height: size, minWidth: size }}
    />
  )
}
