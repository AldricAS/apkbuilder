import { useState } from 'react'
import { animeApi } from '../services/animeApi'
import { useAsync, useDebounce } from '../hooks/hooks'
import type { Anime } from '../types'
import { errMsg } from '../lib/format'
import { Poster } from './Poster'
import { Icon } from './Icon'
import { ErrorState, Spinner } from './States'

function Row({ a, onPick }: { a: Anime; onPick: (a: Anime) => void }) {
  const meta = [a.type, a.status === 'ONGOING' ? 'Ongoing' : a.status === 'FINISHED' ? 'Tamat' : undefined, a.latestEpisode ? `Ep ${a.latestEpisode}` : undefined]
    .filter(Boolean)
    .join(' · ')
  return (
    <button
      type="button"
      onClick={() => onPick(a)}
      className="flex w-full items-center gap-3 rounded-2xl bg-raise/70 p-2.5 text-left ring-1 ring-line active:scale-[0.98]"
    >
      <Poster src={a.poster} alt={a.title} className="h-[72px] w-[50px] shrink-0 rounded-lg" />
      <div className="min-w-0 flex-1">
        <p className="line-clamp-2 text-[14px] font-bold leading-tight text-white">{a.title}</p>
        {meta ? <p className="mt-1 truncate text-[12px] text-muted">{meta}</p> : null}
      </div>
      <span className="shrink-0 text-white/40">
        <Icon name="chevron" size={18} />
      </span>
    </button>
  )
}

/** Satu daftar rekomendasi dari beranda API (hot, populer, terbaru), tanpa duplikat. */
async function loadRecommendations(): Promise<Anime[]> {
  const h = await animeApi.home()
  const seen = new Set<string>()
  const out: Anime[] = []
  for (const a of [...h.hot, ...h.popular, ...h.new, ...h.today]) {
    if (seen.has(a.id)) continue
    seen.add(a.id)
    out.push(a)
    if (out.length >= 24) break
  }
  return out
}

/** [Search anime] + "Rekomendasi anime:". Mengetuk satu anime memanggil onPick. */
export function NobarAnimePicker({ onPick }: { onPick: (a: Anime) => void }) {
  const [q, setQ] = useState('')
  const dq = useDebounce(q.trim(), 450)
  const rec = useAsync(() => loadRecommendations(), [])
  const res = useAsync(() => (dq.length >= 2 ? animeApi.search({ q: dq }).then((r) => r.items) : null), [dq])
  const searching = dq.length >= 2

  return (
    <div>
      <div className="flex h-12 items-center gap-2.5 rounded-2xl bg-raise px-4 ring-1 ring-line focus-within:ring-accent">
        <Icon name="search" size={19} className="shrink-0 text-muted" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search anime"
          enterKeyHint="search"
          className="h-full min-w-0 flex-1 bg-transparent text-[15px] text-white placeholder:text-muted focus:outline-none"
        />
        {q ? (
          <button type="button" aria-label="Hapus" onClick={() => setQ('')} className="shrink-0 p-1 text-white/60 active:opacity-70">
            <Icon name="x" size={17} />
          </button>
        ) : null}
      </div>

      <p className="mb-2.5 mt-5 text-[14px] font-extrabold text-white">{searching ? `Hasil untuk "${dq}"` : 'Rekomendasi anime:'}</p>

      {searching ? (
        res.loading ? (
          <div className="flex justify-center py-10">
            <Spinner size={26} />
          </div>
        ) : res.error ? (
          <ErrorState compact message={errMsg(res.error)} onRetry={res.reload} />
        ) : (res.data ?? []).length === 0 ? (
          <p className="py-10 text-center text-[13px] text-muted">Anime tidak ditemukan.</p>
        ) : (
          <div className="space-y-2">{(res.data ?? []).map((a) => <Row key={a.id} a={a} onPick={onPick} />)}</div>
        )
      ) : rec.loading ? (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="shimmer h-[92px] rounded-2xl" />
          ))}
        </div>
      ) : rec.error ? (
        <ErrorState compact message={errMsg(rec.error)} onRetry={rec.reload} />
      ) : (
        <div className="space-y-2">{(rec.data ?? []).map((a) => <Row key={a.id} a={a} onPick={onPick} />)}</div>
      )}
    </div>
  )
}
