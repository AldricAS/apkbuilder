const PATHS = {
  home: 'M3 11l9-8 9 8|M5 10v10h5v-6h4v6h5V10',
  tv: 'M3 8h18v12H3z|M8 3l4 4 4-4',
  heart: 'M12 20s-7-4.5-9-9.2C1.6 7.4 4 4 7.2 4c1.9 0 3.3 1 4.8 2.8C13.5 5 14.9 4 16.8 4 20 4 22.4 7.4 21 10.8 19 15.5 12 20 12 20z',
  clock: 'M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z|M12 7v5l3 2',
  user: 'M12 12a4 4 0 1 0 0-8a4 4 0 0 0 0 8z|M4 21c0-4 3.5-6 8-6s8 2 8 6',
  search: 'M11 4a7 7 0 1 0 0 14a7 7 0 0 0 0-14z|M20 20l-4-4',
  back: 'M15 5l-7 7 7 7',
  chevron: 'M9 5l7 7-7 7',
  fs: 'M4 9V4h5|M20 9V4h-5|M4 15v5h5|M20 15v5h-5',
  exitfs: 'M9 4v5H4|M15 4v5h5|M9 20v-5H4|M15 20v-5h5',
  volume: 'M4 9v6h4l5 4V5L8 9z|M16 9a4 4 0 0 1 0 6|M18.5 6.5a8 8 0 0 1 0 11',
  mute: 'M4 9v6h4l5 4V5L8 9z|M17 9l5 6|M22 9l-5 6',
  gear: 'M12 15a3 3 0 1 0 0-6a3 3 0 0 0 0 6z|M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3 1a7 7 0 0 0-2-1.2L14.3 3h-4.6l-.3 2.7a7 7 0 0 0-2 1.2l-2.3-1-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-1a7 7 0 0 0 2 1.2l.3 2.7h4.6l.3-2.7a7 7 0 0 0 2-1.2l2.3 1 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z',
  list: 'M8 6h13|M8 12h13|M8 18h13|M3 6h.01|M3 12h.01|M3 18h.01',
  pip: 'M3 5h18v14H3z|M12 12h7v5h-7z',
  check: 'M5 12l5 5 9-10',
  x: 'M6 6l12 12|M18 6L6 18',
  trash: 'M4 7h16|M9 7V4h6v3|M6 7l1 13h10l1-13',
  offline: 'M2 8.5a15 15 0 0 1 20 0|M5 12a10 10 0 0 1 14 0|M8.5 15.5a5 5 0 0 1 7 0|M12 19h.01|M3 3l18 18',
  refresh: 'M20 11a8 8 0 1 0-2.3 5.7|M20 4v7h-7',
  shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
  info: 'M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z|M12 11v5|M12 8h.01',
  sliders: 'M4 6h10|M18 6h2|M4 12h4|M12 12h8|M4 18h12|M20 18h0|M14 4v4|M8 10v4|M16 16v4',
  broom: 'M14 4l6 6|M12 6l6 6-7 7H5v-6z',
  bug: 'M9 9h6v8a3 3 0 0 1-6 0z|M9 9a3 3 0 0 1 6 0|M4 13h5|M15 13h5|M5 8l3 2|M19 8l-3 2|M5 19l3-2|M19 19l-3-2',
  send: 'M22 2L11 13|M22 2l-7 20-4-9-9-4z',
  chat: 'M4 5h16v11H9l-5 4z',
  more: 'M12 5h.01|M12 12h.01|M12 19h.01',
  logout: 'M9 4H5v16h4|M16 8l4 4-4 4|M20 12H9',
  reply: 'M9 14L4 9l5-5|M4 9h10a6 6 0 0 1 6 6v3',
  fill: 'M4 6h16v12H4z|M8 10h8v4H8z',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z|M12 9a3 3 0 1 0 0 6a3 3 0 0 0 0-6z',
  edit: 'M4 20h4L19 9l-4-4L4 16z|M13 7l4 4',
  download: 'M12 4v11|M7 11l5 5 5-5|M5 20h14',
  copy: 'M9 9h11v11H9z|M5 15V4h11',
  bell: 'M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z|M10 21h4',
  userPlus: 'M10 12a4 4 0 1 0 0-8a4 4 0 0 0 0 8z|M2 21c0-4 3.5-6 8-6s8 2 8 6|M19 8v6|M16 11h6',
  userCheck: 'M10 12a4 4 0 1 0 0-8a4 4 0 0 0 0 8z|M2 21c0-4 3.5-6 8-6s8 2 8 6|M16 11l2.5 2.5L23 8.5',
  users: 'M9 11a3.5 3.5 0 1 0 0-7a3.5 3.5 0 0 0 0 7z|M2 20c0-3.5 3-5.5 7-5.5s7 2 7 5.5|M16 4.5a3.5 3.5 0 0 1 0 6.5|M18 15c2.5.6 4 2.3 4 5',
} as const

const FILLED = {
  play: 'M7 4.5v15l13-7.5z',
  pause: 'M6 4h4v16H6z|M14 4h4v16h-4z',
  next: 'M5 5l10 7-10 7z|M17 5h2.5v14H17z',
  prev: 'M19 5L9 12l10 7z|M4.5 5H7v14H4.5z',
  star: 'M12 2.8l2.8 5.9 6.4.9-4.7 4.5 1.1 6.4L12 17.4l-5.6 3.1 1.1-6.4L2.8 9.6l6.4-.9z',
  heartFill: 'M12 20s-7-4.5-9-9.2C1.6 7.4 4 4 7.2 4c1.9 0 3.3 1 4.8 2.8C13.5 5 14.9 4 16.8 4 20 4 22.4 7.4 21 10.8 19 15.5 12 20 12 20z',
} as const

export type IconName = keyof typeof PATHS | keyof typeof FILLED

export function Icon({ name, size = 22, className = '' }: { name: IconName; size?: number; className?: string }) {
  const filled = name in FILLED
  const d = (filled ? FILLED[name as keyof typeof FILLED] : PATHS[name as keyof typeof PATHS]).split('|')
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      fill={filled ? 'currentColor' : 'none'}
      stroke={filled ? 'none' : 'currentColor'}
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {d.map((p, i) => (
        <path key={i} d={p} />
      ))}
    </svg>
  )
}
