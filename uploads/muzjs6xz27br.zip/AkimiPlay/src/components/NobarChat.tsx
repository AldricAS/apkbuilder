import { useEffect, useRef, useState } from 'react'
import { useProfile } from '../auth/AuthProvider'
import { useNav } from '../nav/router'
import {
  deleteNobarMsg,
  kickMember,
  NOBAR_CHAT_GAP_MS,
  NOBAR_CHAT_MAX,
  sendNobarMsg,
  subscribeNobarChat,
  type NobarMember,
  type NobarMsg,
} from '../services/nobarService'
import { liveOf, useLiveUsers } from '../services/liveProfiles'
import { Avatar, UserLine } from './UserBadges'
import { Icon } from './Icon'
import { ConfirmDialog, Sheet, toast } from './Feedback'
import { Spinner } from './States'

function Bubble({ m: raw, own, onOpen }: { m: NobarMsg; own: boolean; onOpen: (m: NobarMsg) => void }) {
  const nav = useNav()
  const live = useLiveUsers([raw.uid])
  const m = liveOf(raw, live.get(raw.uid))
  const q = m.replyTo
  return (
    <div id={`nb-${raw.id}`} className={`flex items-end gap-2 rounded-2xl transition-colors duration-500 ${own ? 'flex-row-reverse' : ''}`}>
      <button type="button" aria-label={`Lihat profil ${m.name}`} onClick={() => nav.openProfile(m.uid)} className="shrink-0 self-start active:scale-95">
        <Avatar url={m.photoURL} name={m.name} size={30} />
      </button>
      <button
        type="button"
        onClick={() => onOpen(raw)}
        className={`block min-w-0 max-w-[82%] flex-1 rounded-2xl px-3 py-2 text-left ${own ? 'bg-accent/15 ring-1 ring-accent/30' : 'bg-raise'}`}
      >
        <UserLine name={m.name} userId={m.userId} role={m.role} verified={m.verified} level={m.level} clanTag={m.clanTag} size="sm" onProfile={() => nav.openProfile(m.uid)} />
        {q ? (
          <span className="mt-1.5 block rounded-lg border-l-[3px] border-accent bg-black/25 px-2 py-1">
            <span className="block truncate text-[11px] font-bold text-accent">{q.name}</span>
            <span className="block truncate text-[11.5px] text-white/60">{q.text}</span>
          </span>
        ) : null}
        <span className="mt-1.5 block whitespace-pre-wrap break-words text-[13.5px] leading-snug text-white/90">{m.text}</span>
      </button>
    </div>
  )
}

/**
 * Komentar di dalam room nobar. Owner bisa menghapus komentar siapa pun dan men-KICK anggota (mis. yang rasis):
 * yang di-kick langsung keluar dan tidak bisa masuk lagi ke room milik owner ini.
 */
export function NobarChat({
  owner,
  isOwner,
  members,
  ownerName,
}: {
  owner: string
  isOwner: boolean
  members: NobarMember[]
  ownerName: string
}) {
  const me = useProfile()
  const [messages, setMessages] = useState<NobarMsg[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const [replyTo, setReplyTo] = useState<NobarMsg | null>(null)
  const [selected, setSelected] = useState<NobarMsg | null>(null)
  const [kickTarget, setKickTarget] = useState<NobarMsg | null>(null)
  const scroller = useRef<HTMLDivElement>(null)
  const stick = useRef(true)
  const lastSend = useRef(0)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setMessages([])
    setLoading(true)
    setError(null)
    const off = subscribeNobarChat(
      owner,
      (m) => {
        setLoading(false)
        setMessages((cur) => (cur.some((x) => x.id === m.id) ? cur : [...cur, m].sort((a, b) => (a.ts || 0) - (b.ts || 0))))
      },
      (id) => setMessages((cur) => cur.filter((x) => x.id !== id)),
      () => {
        setLoading(false)
        setError('Komentar belum bisa dimuat')
      },
    )
    // tidak ada pesan sama sekali: child_added tidak pernah terpanggil, jadi matikan spinner sendiri
    const t = setTimeout(() => setLoading(false), 1500)
    return () => {
      off()
      clearTimeout(t)
    }
  }, [owner])

  useEffect(() => {
    const el = scroller.current
    if (el && stick.current) el.scrollTop = el.scrollHeight
  }, [messages])

  const send = async () => {
    const value = text.trim()
    if (!value || sending) return
    if (Date.now() - lastSend.current < NOBAR_CHAT_GAP_MS) {
      toast('Tunggu sebentar sebelum mengirim lagi')
      return
    }
    setSending(true)
    try {
      lastSend.current = Date.now()
      await sendNobarMsg(me, owner, value, replyTo ? { id: replyTo.id, uid: replyTo.uid, name: replyTo.name, text: replyTo.text } : null)
      setReplyTo(null)
      setText('')
      stick.current = true
    } catch {
      toast('Komentar gagal dikirim (kamu mungkin sudah tidak ada di room ini)')
    } finally {
      setSending(false)
    }
  }

  const isStaff = me.role === 'admin' || me.role === 'moderator' || me.role === 'developer'
  const canDelete = !!selected && (selected.uid === me.uid || isOwner || isStaff)
  const target = selected && selected.uid !== me.uid && selected.uid !== owner ? members.find((x) => x.uid === selected.uid) : undefined
  const canKick = isOwner && !!selected && selected.uid !== owner && selected.uid !== me.uid

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div
        ref={scroller}
        onScroll={() => {
          const el = scroller.current
          if (el) stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80
        }}
        className="min-h-0 flex-1 space-y-2.5 overflow-y-auto px-3 py-3"
      >
        {loading ? (
          <div className="flex justify-center py-6">
            <Spinner size={24} />
          </div>
        ) : error ? (
          <p className="py-6 text-center text-[12.5px] text-muted">{error}</p>
        ) : messages.length === 0 ? (
          <p className="py-6 text-center text-[12.5px] text-muted">Belum ada komentar. Sapa teman nobar kamu!</p>
        ) : (
          messages.map((m) => <Bubble key={m.id} m={m} own={m.uid === me.uid} onOpen={setSelected} />)
        )}
      </div>

      <div className="shrink-0 border-t border-line bg-ink px-3 pb-3 pt-2" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 10px)' }}>
        {replyTo ? (
          <div className="mb-2 flex animate-fadeIn items-center gap-2 rounded-xl border-l-[3px] border-accent bg-raise px-3 py-1.5">
            <Icon name="reply" size={15} className="shrink-0 text-accent" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12px] font-bold text-accent">Membalas {replyTo.name}</p>
              <p className="truncate text-[12px] text-white/65">{replyTo.text}</p>
            </div>
            <button type="button" aria-label="Batal membalas" onClick={() => setReplyTo(null)} className="shrink-0 p-1 active:opacity-70">
              <Icon name="x" size={16} />
            </button>
          </div>
        ) : null}
        <div className="flex items-center gap-2">
          <input
            ref={inputRef}
            value={text}
            maxLength={NOBAR_CHAT_MAX}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && void send()}
            placeholder="Komentar nobar..."
            enterKeyHint="send"
            className="h-11 min-w-0 flex-1 rounded-full bg-raise px-4 text-[14.5px] text-white placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
          />
          <button
            type="button"
            aria-label="Kirim"
            disabled={!text.trim() || sending}
            onClick={() => void send()}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-accent text-ink active:scale-90 disabled:bg-raise disabled:text-white/30"
          >
            {sending ? <Spinner size={18} /> : <Icon name="send" size={19} />}
          </button>
        </div>
      </div>

      <Sheet open={!!selected} onClose={() => setSelected(null)} title={selected?.name}>
        <p className="mb-4 whitespace-pre-wrap break-words text-[13.5px] text-white/80">{selected?.text}</p>
        <button
          type="button"
          onClick={() => {
            if (selected) {
              setReplyTo(selected)
              inputRef.current?.focus()
            }
            setSelected(null)
          }}
          className="mb-2 flex w-full items-center justify-center gap-2 rounded-full bg-raise py-3 text-[14px] font-semibold text-white active:scale-[0.98]"
        >
          <Icon name="reply" size={17} /> Balas komentar
        </button>
        {canDelete ? (
          <button
            type="button"
            onClick={() => {
              const id = selected!.id
              setSelected(null)
              void deleteNobarMsg(owner, id).catch(() => toast('Komentar gagal dihapus'))
            }}
            className="mb-2 flex w-full items-center justify-center gap-2 rounded-full bg-[#301014] py-3 text-[14px] font-semibold text-[#f87171] active:scale-[0.98]"
          >
            <Icon name="trash" size={17} /> Hapus komentar
          </button>
        ) : null}
        {canKick ? (
          target ? (
            <button
              type="button"
              onClick={() => {
                setKickTarget(selected)
                setSelected(null)
              }}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-[#301014] py-3 text-[14px] font-bold text-[#f87171] active:scale-[0.98]"
            >
              <Icon name="logout" size={17} /> Kick dari nobar
            </button>
          ) : (
            <p className="rounded-2xl bg-raise px-4 py-3 text-center text-[12.5px] text-muted">{selected?.name} sudah tidak ada di room ini.</p>
          )
        ) : null}
      </Sheet>

      <ConfirmDialog
        open={!!kickTarget}
        title={`Kick ${kickTarget?.name ?? ''}?`}
        message={`${kickTarget?.name ?? 'Orang ini'} langsung dikeluarkan dan tidak bisa masuk lagi ke room ${ownerName}.`}
        confirmLabel="Kick"
        onCancel={() => setKickTarget(null)}
        onConfirm={() => {
          const k = kickTarget
          setKickTarget(null)
          const mem = k ? members.find((x) => x.uid === k.uid) : undefined
          if (!mem) return toast('Orang itu sudah keluar dari room')
          void kickMember(owner, mem)
            .then(() => toast(`${mem.name} di-kick`))
            .catch(() => toast('Gagal kick, coba lagi'))
        }}
      />
    </div>
  )
}
