import { useEffect, useMemo, useState } from 'react'
import { useProfile } from '../auth/AuthProvider'
import { useNav } from '../nav/router'
import {
  addComment,
  addReply,
  COMMENT_MAX,
  deleteComment,
  editComment,
  subscribeComments,
  toggleLike,
  type Comment,
  type Reply,
} from '../services/commentService'
import { timeAgo } from '../lib/format'
import { liveOf, useLiveUsers } from '../services/liveProfiles'
import { Avatar, UserLine } from './UserBadges'
import { Icon } from './Icon'
import { Sheet, Toggle, toast } from './Feedback'
import { Spinner } from './States'

type Sort = 'top' | 'new'
type Target = { kind: 'comment'; c: Comment } | { kind: 'reply'; c: Comment; r: Reply }

export function Comments({ animeId, episodeId }: { animeId: string; episodeId: string }) {
  const me = useProfile()
  const nav = useNav()
  const [list, setList] = useState<Comment[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [sort, setSort] = useState<Sort>('new')
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [replyTo, setReplyTo] = useState<{ c: Comment; name: string } | null>(null)
  const [editing, setEditing] = useState<{ t: Target; text: string } | null>(null)
  const [menu, setMenu] = useState<Target | null>(null)
  const [settings, setSettings] = useState(false)
  const [openReplies, setOpenReplies] = useState<Set<string>>(new Set())
  const [expandAll, setExpandAll] = useState(false)

  // realtime, terikat ke anime + episode ini saja
  useEffect(() => {
    setLoading(true)
    setError(null)
    setList([])
    setReplyTo(null)
    setEditing(null)
    return subscribeComments(
      animeId,
      episodeId,
      (l) => {
        setList(l)
        setLoading(false)
      },
      (e) => {
        setError(e.message)
        setLoading(false)
      },
    )
  }, [animeId, episodeId])

  const sorted = useMemo(() => {
    const score = (c: Comment) => c.likes.length * 2 + c.replies.length
    return [...list].sort((a, b) => (sort === 'top' ? score(b) - score(a) || b.ts - a.ts : b.ts - a.ts))
  }, [list, sort])

  const liveUids = useMemo(() => list.flatMap((c) => [c.uid, ...c.replies.map((r) => r.uid)]), [list])
  const live = useLiveUsers(liveUids)

  const total = list.reduce((n, c) => n + 1 + c.replies.length, 0)
  const isMod = me.role === 'moderator' || me.role === 'admin' || me.role === 'developer'

  const submit = async () => {
    const value = text.trim()
    if (!value || busy) return
    setBusy(true)
    try {
      if (replyTo) {
        await addReply(me, animeId, replyTo.c.id, value, replyTo.name)
        setOpenReplies((s) => new Set(s).add(replyTo.c.id))
        setReplyTo(null)
      } else {
        await addComment(me, animeId, episodeId, value)
      }
      setText('')
    } catch {
      toast('Komentar gagal dikirim')
    } finally {
      setBusy(false)
    }
  }

  const saveEdit = async () => {
    if (!editing) return
    try {
      const { t } = editing
      await editComment(animeId, t.c.id, editing.text, t.kind === 'reply' ? t.r.id : undefined)
      setEditing(null)
    } catch {
      toast('Gagal menyimpan perubahan')
    }
  }

  const remove = async (t: Target) => {
    try {
      await deleteComment(animeId, t.c.id, t.kind === 'reply' ? t.r.id : undefined)
    } catch {
      toast('Tidak bisa menghapus')
    }
  }

  const menuOwner = menu ? (menu.kind === 'comment' ? menu.c.uid : menu.r.uid) === me.uid : false

  return (
    <section className="px-4 pb-16 pt-5">
      <h2 className="text-[20px] font-bold tracking-tight text-white">{total} Comments</h2>

      <div className="mt-3 flex items-center gap-2">
        {(['top', 'new'] as Sort[]).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setSort(s)}
            className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-semibold active:scale-95 ${
              sort === s ? 'bg-white text-ink' : 'bg-raise text-white/80'
            }`}
          >
            {s === 'top' ? 'Top Comment' : 'Terbaru'}
          </button>
        ))}
        <button
          type="button"
          onClick={() => setSettings(true)}
          className="ml-auto flex items-center gap-1.5 text-[12.5px] font-semibold text-white/80 active:opacity-70"
        >
          <Icon name="gear" size={16} /> Atur
        </button>
      </div>

      {/* input */}
      <div className="mt-3.5">
        {replyTo ? (
          <div className="mb-2 flex items-center justify-between rounded-xl bg-raise px-3 py-1.5 text-[12px] text-white/80">
            <span className="truncate">Membalas {replyTo.name}</span>
            <button type="button" aria-label="Batal membalas" onClick={() => setReplyTo(null)}>
              <Icon name="x" size={15} />
            </button>
          </div>
        ) : null}
        <div className="flex items-center gap-2">
          <Avatar url={me.photoURL} name={me.username || me.displayName} size={34} />
          <input
            value={text}
            maxLength={COMMENT_MAX}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && void submit()}
            placeholder={replyTo ? 'Tulis balasan..' : 'Tulis komentar..'}
            enterKeyHint="send"
            className="h-10 min-w-0 flex-1 rounded-full bg-raise px-4 text-[13.5px] text-white placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
          />
          <button
            type="button"
            aria-label="Kirim komentar"
            disabled={!text.trim() || busy}
            onClick={() => void submit()}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent text-ink active:scale-90 disabled:bg-raise disabled:text-white/30"
          >
            {busy ? <Spinner size={16} /> : <Icon name="send" size={17} />}
          </button>
        </div>
      </div>

      {/* daftar */}
      <div className="mt-4 space-y-4">
        {loading ? (
          <div className="flex justify-center py-8">
            <Spinner />
          </div>
        ) : null}
        {error ? <p className="rounded-2xl bg-[#2a1720] px-4 py-3 text-[12.5px] text-accent">Komentar tidak bisa dimuat: {error}</p> : null}
        {!loading && !error && !sorted.length ? (
          <p className="py-8 text-center text-[13px] text-muted">Belum ada komentar. Mulai diskusi di episode ini!</p>
        ) : null}

        {sorted.map((c0) => {
          const c = liveOf(c0, live.get(c0.uid))
          const liked = c.likes.includes(me.uid)
          const showReplies = expandAll || openReplies.has(c.id)
          const isEditing = editing?.t.kind === 'comment' && editing.t.c.id === c.id
          return (
            <article key={c.id} className="flex gap-2.5">
              <button type="button" aria-label={`Lihat profil ${c.name}`} onClick={() => nav.openProfile(c.uid)} className="shrink-0 self-start active:scale-95">
                <Avatar url={c.photoURL} name={c.name} size={34} />
              </button>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <UserLine name={c.name} userId={c.userId} role={c.role} verified={c.verified} level={c.level} clanTag={c.clanTag} size="sm" onProfile={() => nav.openProfile(c.uid)} />
                  <div className="flex shrink-0 items-center gap-1 text-[11px] text-muted">
                    <span>{timeAgo(c.ts)}</span>
                    {c.uid === me.uid || isMod ? (
                      <button type="button" aria-label="Opsi komentar" onClick={() => setMenu({ kind: 'comment', c })} className="p-1">
                        <Icon name="more" size={16} />
                      </button>
                    ) : null}
                  </div>
                </div>

                {isEditing ? (
                  <EditBox value={editing!.text} onChange={(v) => setEditing({ t: editing!.t, text: v })} onSave={() => void saveEdit()} onCancel={() => setEditing(null)} />
                ) : (
                  <p className="mt-1.5 whitespace-pre-wrap break-words text-[14px] leading-snug text-white">
                    {c.text}
                    {c.editedAt ? <span className="ml-1.5 text-[10.5px] text-muted">(diedit)</span> : null}
                  </p>
                )}

                <div className="mt-1.5 flex items-center gap-4 text-[12.5px] font-semibold">
                  <button type="button" onClick={() => setReplyTo({ c, name: c.name })} className="flex items-center gap-1 text-accent active:opacity-70">
                    <Icon name="reply" size={14} /> Reply
                  </button>
                  <button
                    type="button"
                    onClick={() => void toggleLike(animeId, c.id, me.uid, liked).catch(() => toast('Gagal menyukai'))}
                    className={`flex items-center gap-1 active:opacity-70 ${liked ? 'text-accent' : 'text-muted'}`}
                  >
                    <Icon name={liked ? 'heartFill' : 'heart'} size={14} /> {c.likes.length || ''}
                  </button>
                  {c.replies.length && !expandAll ? (
                    <button
                      type="button"
                      onClick={() =>
                        setOpenReplies((s) => {
                          const n = new Set(s)
                          if (n.has(c.id)) n.delete(c.id)
                          else n.add(c.id)
                          return n
                        })
                      }
                      className="text-muted"
                    >
                      {showReplies ? 'Sembunyikan balasan' : `${c.replies.length} balasan`}
                    </button>
                  ) : null}
                </div>

                {showReplies && c.replies.length ? (
                  <div className="mt-3 space-y-3 border-l border-line pl-3">
                    {c.replies.map((r0) => {
                      const r = liveOf(r0, live.get(r0.uid))
                      const editingReply = editing?.t.kind === 'reply' && editing.t.r.id === r.id
                      return (
                        <div key={r.id} className="flex gap-2">
                          <button type="button" aria-label={`Lihat profil ${r.name}`} onClick={() => nav.openProfile(r.uid)} className="shrink-0 self-start active:scale-95">
                            <Avatar url={r.photoURL} name={r.name} size={26} />
                          </button>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <UserLine name={r.name} userId={r.userId} role={r.role} verified={r.verified} level={r.level} clanTag={r.clanTag} size="sm" onProfile={() => nav.openProfile(r.uid)} />
                              <div className="flex shrink-0 items-center gap-1 text-[11px] text-muted">
                                <span>{timeAgo(r.ts)}</span>
                                {r.uid === me.uid || isMod ? (
                                  <button type="button" aria-label="Opsi balasan" onClick={() => setMenu({ kind: 'reply', c, r })} className="p-1">
                                    <Icon name="more" size={15} />
                                  </button>
                                ) : null}
                              </div>
                            </div>
                            {editingReply ? (
                              <EditBox value={editing!.text} onChange={(v) => setEditing({ t: editing!.t, text: v })} onSave={() => void saveEdit()} onCancel={() => setEditing(null)} />
                            ) : (
                              <p className="mt-1 whitespace-pre-wrap break-words text-[13.5px] leading-snug text-white">
                                {r.replyTo ? <span className="mr-1 font-semibold text-accent">@{r.replyTo}</span> : null}
                                {r.text}
                                {r.editedAt ? <span className="ml-1.5 text-[10.5px] text-muted">(diedit)</span> : null}
                              </p>
                            )}
                            <button
                              type="button"
                              onClick={() => setReplyTo({ c, name: r.name })}
                              className="mt-1 flex items-center gap-1 text-[12px] font-semibold text-accent active:opacity-70"
                            >
                              <Icon name="reply" size={13} /> Reply
                            </button>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                ) : null}
              </div>
            </article>
          )
        })}
      </div>

      <Sheet open={!!menu} onClose={() => setMenu(null)} title="Komentar">
        <div className="space-y-2">
          {menuOwner ? (
            <button
              type="button"
              onClick={() => {
                if (menu) setEditing({ t: menu, text: menu.kind === 'comment' ? menu.c.text : menu.r.text })
                setMenu(null)
              }}
              className="flex w-full items-center gap-3 rounded-2xl bg-raise px-4 py-3 text-[14px] font-medium text-white active:opacity-80"
            >
              <Icon name="edit" size={18} /> Edit
            </button>
          ) : null}
          <button
            type="button"
            onClick={() => {
              if (menu) void remove(menu)
              setMenu(null)
            }}
            className="flex w-full items-center gap-3 rounded-2xl bg-raise px-4 py-3 text-[14px] font-medium text-accent active:opacity-80"
          >
            <Icon name="trash" size={18} /> Hapus
          </button>
        </div>
      </Sheet>

      <Sheet open={settings} onClose={() => setSettings(false)} title="Atur komentar">
        <div className="flex items-center justify-between rounded-2xl bg-raise/70 px-4 py-3">
          <div>
            <p className="text-[14px] font-medium text-white">Tampilkan semua balasan</p>
            <p className="mt-0.5 text-[12px] text-muted">Balasan langsung terbuka di bawah komentar.</p>
          </div>
          <Toggle on={expandAll} onChange={setExpandAll} />
        </div>
      </Sheet>
    </section>
  )
}

function EditBox({ value, onChange, onSave, onCancel }: { value: string; onChange: (v: string) => void; onSave: () => void; onCancel: () => void }) {
  return (
    <div className="mt-1.5">
      <input
        value={value}
        maxLength={COMMENT_MAX}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 w-full rounded-xl bg-raise px-3 text-[13.5px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
      />
      <div className="mt-1.5 flex gap-3 text-[12.5px] font-semibold">
        <button type="button" onClick={onSave} className="text-accent">
          Simpan
        </button>
        <button type="button" onClick={onCancel} className="text-muted">
          Batal
        </button>
      </div>
    </div>
  )
}
