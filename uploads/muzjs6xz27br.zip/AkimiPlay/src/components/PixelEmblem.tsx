import { useMemo } from 'react'

/**
 * Emblem clan bergaya pixel-art (seperti ikon item di game blok).
 * Urutan HARUS sama dengan CLAN_EMBLEMS di clanService (indeks 0-15 disimpan di database).
 * '.' = transparan; huruf lain = warna dari palet masing-masing emblem.
 */
type Art = { pal: Record<string, string>; rows: string[] }

const ART: Art[] = [
  // 0 Pedang
  {
    pal: { w: '#E5E7EB', s: '#9CA3AF', g: '#FACC15', b: '#7C4A21', p: '#F59E0B' },
    rows: ['....ws....', '....ws....', '....ws....', '....ws....', '....ws....', '....ws....', '.gggggggg.', '....bb....', '....bb....', '...pppp...'],
  },
  // 1 Perisai
  {
    pal: { l: '#CBD5E1', f: '#4F7CAC', h: '#E2E8F0' },
    rows: ['llllllllll', 'lfffhhfffl', 'lhhhhhhhhl', 'lfffhhfffl', 'lfffhhfffl', '.lffhhffl.', '.lffffffl.', '..lffffl..', '...llll...', '....ll....'],
  },
  // 2 Naga
  {
    pal: { g: '#22C55E', d: '#15803D', y: '#FDE047', r: '#EF4444' },
    rows: ['d........d', 'dd......dd', '.dggggggd.', '.gggggggg.', '.gyyggyyg.', '.gggggggg.', '..gggggg..', '..gddddg..', '..gdrrdg..', '...gggg...'],
  },
  // 3 Api
  {
    pal: { r: '#EF4444', o: '#FB923C', y: '#FACC15' },
    rows: ['....r.....', '....rr....', '...rrr..r.', '..rrorr.rr', '..rooorrr.', '.rrooyoorr', '.rooyyyoor', '.rooyyyoor', '..rooyoor.', '...rrrrr..'],
  },
  // 4 Petir
  {
    pal: { y: '#FACC15', o: '#F59E0B' },
    rows: ['......yyo.', '.....yyo..', '....yyo...', '...yyyyyo.', '...yyyyo..', '.....yyo..', '....yyo...', '...yo.....', '..yo......', '..y.......'],
  },
  // 5 Bulan
  {
    pal: { y: '#FDE68A', w: '#FFFFFF' },
    rows: ['...yyyyy..', '..yyyyy...', '.yyyy.....', '.yyy...w..', '.yyy......', '.yyy......', '.yyyy.....', '..yyyy..y.', '...yyyyyy.', '....yyyy..'],
  },
  // 6 Bintang
  {
    pal: { y: '#FACC15', o: '#F59E0B' },
    rows: ['....yy....', '...yyyy...', '...yyyy...', 'oyyyyyyyyo', '.yyyyyyyy.', '..yyyyyy..', '..oyyyyo..', '.yyy..yyy.', '.yy....yy.', '.y......y.'],
  },
  // 7 Apel
  {
    pal: { r: '#EF4444', d: '#B91C1C', g: '#22C55E', b: '#7C4A21', w: '#FCA5A5' },
    rows: ['.....bgg..', '.....b....', '.rrrrbrrr.', 'rrwwrrrrrr', 'rrwrrrrrrd', 'rrrrrrrrrd', 'rrrrrrrrdd', '.rrrrrrrd.', '..rrrrdd..', '..rr..rr..'],
  },
  // 8 Rubah
  {
    pal: { o: '#F97316', w: '#FFFFFF', k: '#1F2937' },
    rows: ['oo......oo', 'ooo....ooo', 'oooooooooo', 'ookooookoo', 'oooooooooo', 'woooooooow', 'wwooooooww', '.wwwkkwww.', '..wwwwww..', '...wwww...'],
  },
  // 9 Serigala
  {
    pal: { a: '#9CA3AF', d: '#4B5563', w: '#F3F4F6', k: '#111827', y: '#FDE047' },
    rows: ['dd......dd', 'dad....dad', 'daaaaaaaad', 'aayaaaayaa', 'aaaaaaaaaa', '.aaawwaaa.', '.aawwwwaa.', '..awwwwa..', '...wkkw...', '....kk....'],
  },
  // 10 Tengkorak
  {
    pal: { w: '#F3F4F6', k: '#111827' },
    rows: ['..wwwwww..', '.wwwwwwww.', 'wwwwwwwwww', 'wkkkwwkkkw', 'wkkkwwkkkw', 'wwwwkkwwww', '.wwwkkwww.', '..wwwwww..', '..wkwwkw..', '..wwwwww..'],
  },
  // 11 Mahkota
  {
    pal: { y: '#FACC15', o: '#F59E0B', r: '#EF4444', b: '#3B82F6' },
    rows: ['..........', 'y...yy...y', 'yy..yy..yy', 'yyy.yy.yyy', 'yyyyyyyyyy', 'yyrbbbbryy', 'yyyyyyyyyy', 'oooooooooo', '..........', '..........'],
  },
  // 12 Sakura
  {
    pal: { p: '#F9A8D4', d: '#EC4899', y: '#FDE047' },
    rows: ['...pppp...', '.pppppppp.', 'pp.pppp.pp', 'pppddddppp', 'ppdyyyydpp', 'ppdyyyydpp', 'pppddddppp', 'pp.pppp.pp', '.pppppppp.', '...pppp...'],
  },
  // 13 Gamepad
  {
    pal: { g: '#6B7280', w: '#F3F4F6', r: '#EF4444', b: '#3B82F6' },
    rows: ['..........', '..gggggg..', '.gggggggg.', 'gggwgggrgg', 'ggwwwgbgbg', 'gggwgggrgg', 'gggggggggg', '.ggg..ggg.', '.gg....gg.', '..........'],
  },
  // 14 Elang
  {
    pal: { b: '#7C4A21', d: '#4B2E14', y: '#FACC15', w: '#F3F4F6', k: '#111827' },
    rows: ['d........d', 'dd..ww..dd', 'bbdwwwwdbb', 'bbwkwwkwbb', '.bbwyyywb.', '..bbwyybb.', '...bbbb...', '..bbbbbb..', '..y....y..', '..........'],
  },
  // 15 Ombak
  {
    pal: { w: '#F3F4F6', l: '#93C5FD', b: '#3B82F6', d: '#1D4ED8' },
    rows: ['...ww.....', '..wllw.ww.', '.wllllwllw', 'wllbbllbbl', 'lbbbbbbbbb', 'bbbbbbbbbb', 'dbbdbbdbbd', 'dddddddddd'],
  },
]

export const PIXEL_EMBLEM_COUNT = ART.length

/** Satu emblem pixel-art sebagai <svg>. Bisa dipakai bersarang di dalam <svg> lain lewat x/y. */
export function PixelEmblem({ index, size = 40, x, y }: { index: number; size?: number; x?: number; y?: number }) {
  const art = ART[((index % ART.length) + ART.length) % ART.length]
  const paths = useMemo(() => {
    const byColor = new Map<string, string>()
    art.rows.forEach((row, r) => {
      for (let c = 0; c < row.length; c++) {
        const k = row[c]
        const color = art.pal[k]
        if (!color) continue
        byColor.set(color, `${byColor.get(color) ?? ''}M${c} ${r}h1v1h-1z`)
      }
    })
    return [...byColor.entries()]
  }, [art])
  const cols = Math.max(...art.rows.map((r) => r.length))
  return (
    <svg
      x={x}
      y={y}
      width={size}
      height={size}
      viewBox={`0 0 ${cols} ${cols}`}
      shapeRendering="crispEdges"
      aria-hidden
      className="shrink-0"
      // grid yang lebih pendek dari 10 baris ditaruh di tengah vertikal
      preserveAspectRatio="xMidYMid meet"
    >
      <g transform={`translate(0 ${(cols - art.rows.length) / 2})`}>
        {paths.map(([color, d]) => (
          <path key={color} d={d} fill={color} />
        ))}
      </g>
    </svg>
  )
}
