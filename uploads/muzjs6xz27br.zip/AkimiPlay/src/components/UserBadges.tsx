import { useState, type MouseEvent } from 'react'
import type { Role } from '../services/userService'
import { fmtNum } from '../lib/xp'
import { LevelIcon } from './LevelIcon'
import { ClanBadge } from './ClanBadge'
import { useClanByTag } from '../services/clanService'

export function Avatar({ url, name, size = 36 }: { url?: string; name: string; size?: number }) {
  const [failed, setFailed] = useState(false)
  const initial = (name.trim()[0] ?? '?').toUpperCase()
  if (!url || failed) {
    return (
      <div
        className="flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#FFA0BE] to-[#FF5C8D] font-extrabold text-ink"
        style={{ width: size, height: size, fontSize: size * 0.42 }}
      >
        {initial}
      </div>
    )
  }
  return (
    <img
      src={url}
      alt=""
      width={size}
      height={size}
      loading="lazy"
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className="shrink-0 rounded-full bg-raise object-cover"
      style={{ width: size, height: size }}
    />
  )
}

export type CheckKind = 'red' | 'purple' | 'orange' | 'blue' | 'premium' | 'shadow' | 'devred' | 'demon' | 'maou'

/** Warna & label role gradasi hitam ke ungu. Ganti SPECIAL_ROLE_LABEL untuk mengubah teks badge-nya. */
export const SPECIAL_ROLE_LABEL = 'Special'
/** Role "raja_iblis": gradasi hitam ke merah. Ganti label di sini untuk mengubah teks badge-nya. */
export const DEMON_ROLE_LABEL = 'Raja Iblis'
/** Role "maou": gradasi merah ke hitam. Ganti label di sini untuk mengubah teks badge-nya. */
export const MAOU_ROLE_LABEL = 'Maou'
const MAOU_GRAD = 'akimiMaouGrad'
const DEMON_GRAD = 'akimiDemonGrad'
const SHADOW_GRAD = 'akimiShadowGrad'
const DEV_GRAD = 'akimiDevGrad'
const PREMIUM_GRAD = 'akimiPremiumGrad'
/** Warna nama untuk role Premium (biru). */
export const PREMIUM_NAME_COLOR = '#4DA6FF'

const CHECK_COLOR: Record<CheckKind, string> = {
  shadow: `url(#${SHADOW_GRAD})`,
  demon: `url(#${DEMON_GRAD})`,
  maou: `url(#${MAOU_GRAD})`, // merah ke hitam
  devred: `url(#${DEV_GRAD})`, // developer: sama seperti centang special, tetapi merah
  red: '#FF4D5E', // developer & admin
  purple: '#9B7BFF', // moderator
  orange: '#FF8A1F', // beta
  blue: '#3FA2FF', // verified biasa
  premium: `url(#${PREMIUM_GRAD})`, // premium: biru berkilau
}

/** Jenis centang berdasarkan role: developer merah gradasi (seperti special), admin merah polos, moderator ungu, beta oranye, verified biasa biru. */
export function checkKindOf(role?: Role, verified?: boolean): CheckKind | null {
  if (role === 'special') return 'shadow'
  if (role === 'raja_iblis') return 'demon'
  if (role === 'maou') return 'maou'
  if (role === 'developer') return 'devred'
  if (role === 'admin') return 'red'
  if (role === 'moderator') return 'purple'
  if (role === 'beta') return 'orange'
  if (role === 'premium') return 'premium'
  if (verified) return 'blue'
  return null
}

/**
 * Centang bentuk segel (dua persegi membulat yang diputar 45°) pada kanvas persegi 24x24,
 * ukuran dikunci sama lebar & tinggi sehingga tidak pernah gepeng.
 */
export function VerifiedIcon({ kind = 'blue', size = 15 }: { kind?: CheckKind; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      role="img"
      aria-label="Terverifikasi"
      style={{ width: size, height: size, minWidth: size, minHeight: size, display: 'block', flex: 'none' }}
    >
      {kind === 'shadow' ? (
        <defs>
          <linearGradient id={SHADOW_GRAD} x1="3" y1="3" x2="21" y2="21" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#050507" />
            <stop offset="0.45" stopColor="#2A1252" />
            <stop offset="1" stopColor="#8B3DFF" />
          </linearGradient>
        </defs>
      ) : null}
      {kind === 'demon' ? (
        <defs>
          <linearGradient id={DEMON_GRAD} x1="3" y1="3" x2="21" y2="21" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#060102" />
            <stop offset="0.5" stopColor="#5C0614" />
            <stop offset="1" stopColor="#E0142F" />
          </linearGradient>
        </defs>
      ) : null}
      {kind === 'maou' ? (
        <defs>
          <linearGradient id={MAOU_GRAD} x1="3" y1="3" x2="21" y2="21" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#FF1F3D" />
            <stop offset="0.5" stopColor="#7A0A1B" />
            <stop offset="1" stopColor="#050001" />
          </linearGradient>
        </defs>
      ) : null}
      {kind === 'premium' ? (
        <defs>
          <linearGradient id={PREMIUM_GRAD} x1="3" y1="3" x2="21" y2="21" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#9FD6FF" />
            <stop offset="0.45" stopColor="#2E8BFF" />
            <stop offset="1" stopColor="#0A3A9E" />
          </linearGradient>
        </defs>
      ) : null}
      {kind === 'devred' ? (
        <defs>
          <linearGradient id={DEV_GRAD} x1="3" y1="3" x2="21" y2="21" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#050507" />
            <stop offset="0.45" stopColor="#4A0A12" />
            <stop offset="1" stopColor="#FE0F0F" />
          </linearGradient>
        </defs>
      ) : null}
      <g
        fill={CHECK_COLOR[kind]}
        stroke={kind === 'premium' ? '#B9E0FF' : kind === 'shadow' ? '#A66BFF' : kind === 'devred' ? '#FF6B6B' : kind === 'demon' ? '#FF3B57' : kind === 'maou' ? '#FF3B57' : 'none'}
        strokeWidth={kind === 'premium' || kind === 'shadow' || kind === 'devred' || kind === 'demon' || kind === 'maou' ? 0.8 : 0}
      >
        <rect x="3" y="3" width="18" height="18" rx="5" />
        <rect x="3" y="3" width="18" height="18" rx="5" transform="rotate(45 12 12)" />
      </g>
      <path d="M7.9 12.3l2.7 2.7 5.6-5.8" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

/**
 * Badge Developer (mengikuti video referensi): pill biru tua dengan teks putih tebal "Developer";
 * kapsul merah tumbuh dari kiri sampai menutup pill, lalu menyusut ke kanan, berulang tiap 4,6 detik.
 * Semua ukuran memakai em (tinggi 1,72em, padding 0,95em) sehingga proporsinya tetap di ukuran apa pun.
 * Animasi dihentikan bila pengguna memilih "kurangi gerakan".
 */
export function DeveloperBadge({ size = 9.5 }: { size?: number }) {
  return (
    <span
      className="relative inline-block shrink-0 select-none overflow-hidden whitespace-nowrap rounded-full align-middle font-bold text-white"
      style={{ fontSize: size, lineHeight: '1.72em', height: '1.72em', padding: '0 0.95em', background: '#10243b', contain: 'layout paint' }}
    >
      <span
        aria-hidden
        className="absolute inset-y-0 left-0 w-0 animate-devSweep rounded-full motion-reduce:animate-none"
        style={{ background: 'linear-gradient(90deg,#d00000 0,#f80b0b 1em,#fe0f0f 1.3em)' }}
      />
      <span className="relative">Developer</span>
    </span>
  )
}

/**
 * Badge Premium: pill biru berkilau, kedua sisinya menggelap sampai hitam, dengan kilau putih yang menyapu pelan
 * (siklus 3,6 dtk, ada jeda). Ukuran memakai em seperti badge Developer. Animasi berhenti bila pengguna memilih "kurangi gerakan".
 */
export function PremiumBadge({ size = 9.5 }: { size?: number }) {
  return (
    <span
      className="relative inline-block shrink-0 select-none overflow-hidden whitespace-nowrap rounded-full align-middle font-extrabold text-white"
      style={{
        fontSize: size,
        lineHeight: '1.72em',
        height: '1.72em',
        padding: '0 1.15em',
        background: 'linear-gradient(90deg,#000 0,#040A16 14%,#0B3FA8 32%,#2E8BFF 50%,#0B3FA8 68%,#040A16 86%,#000 100%)',
        boxShadow: '0 0 0.9em rgba(46,139,255,0.45), inset 0 0 0 1px rgba(150,205,255,0.4)',
        contain: 'layout paint',
      }}
    >
      <span
        aria-hidden
        className="absolute inset-y-0 w-[42%] animate-premiumShine motion-reduce:animate-none"
        style={{ left: '-50%', background: 'linear-gradient(100deg,transparent 0,rgba(255,255,255,0.6) 50%,transparent 100%)' }}
      />
      <span className="relative tracking-wide" style={{ textShadow: '0 0 0.55em rgba(120,190,255,0.95)' }}>
        Premium
      </span>
    </span>
  )
}

export function RoleBadge({ role }: { role?: Role }) {
  const base = 'rounded-md px-1.5 py-[1px] text-[9.5px] font-extrabold uppercase leading-[14px] tracking-wide'
  if (role === 'special')
    return (
      <span className={`${base} bg-gradient-to-r from-[#050507] via-[#2A1252] to-[#8B3DFF] text-white ring-1 ring-[#8B3DFF]/50`}>
        {SPECIAL_ROLE_LABEL}
      </span>
    )
  if (role === 'raja_iblis')
    return (
      <span className={`${base} bg-gradient-to-r from-[#060102] via-[#5C0614] to-[#E0142F] text-white ring-1 ring-[#E0142F]/55`}>
        {DEMON_ROLE_LABEL}
      </span>
    )
  if (role === 'maou')
    return (
      <span className={`${base} bg-gradient-to-r from-[#FF1F3D] via-[#7A0A1B] to-[#050001] text-white ring-1 ring-[#FF1F3D]/55`}>
        {MAOU_ROLE_LABEL}
      </span>
    )
  if (role === 'developer') return <DeveloperBadge size={9.5} />
  if (role === 'premium') return <PremiumBadge size={9.5} />
  if (role === 'admin') return <span className={`${base} bg-[#FF4D5E] text-white`}>Admin</span>
  if (role === 'moderator') return <span className={`${base} bg-[#9B7BFF] text-white`}>Moderator</span>
  if (role === 'beta') return <span className={`${base} bg-[#FF8A1F] text-white`}>Beta</span>
  return null
}

export function LevelPill({ level }: { level: number }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-[#3a2f14] py-[1px] pl-1 pr-2 text-[10.5px] font-bold leading-[14px] text-[#F4C96B]">
      <LevelIcon level={level} size={16} />
      Lvl. {fmtNum(level)}
    </span>
  )
}

/**
 * Lencana clan di komentar, chat, dan profil: emblem + tag dengan warna clan.
 * Warna & emblem dicari lewat tag (selalu terbaru). Bila `clan` sudah diketahui, pencarian dilewati.
 */
export function ClanPill({ tag, clan, height = 22 }: { tag?: string; clan?: { color: number; emblem: number; tier?: number } | null; height?: number }) {
  const found = useClanByTag(clan ? undefined : tag)
  if (!tag) return null
  const c = clan ?? found
  // sedang memuat: tempat dipesan tapi disembunyikan, supaya warna clan tidak "berkedip putih" dulu
  if (c === undefined) return <span className="inline-flex opacity-0"><ClanBadge tag={tag} color={0} emblem={0} height={height} noEmblem /></span>
  // tag tanpa clan (mis. tag manual dari developer, atau clan sudah dihapus): tampil putih tanpa emblem
  if (c === null) return <ClanBadge tag={tag} color={0} emblem={0} height={height} noEmblem />
  return <ClanBadge tag={tag} color={c.color} emblem={c.emblem} tier={c.tier} height={height} />
}

/** Warna nama yang stabil per user. */
export function nameColor(seed: string | number, role?: Role): string {
  if (role === 'premium') return PREMIUM_NAME_COLOR
  let h = 0
  for (const c of String(seed)) h = (h * 31 + c.charCodeAt(0)) % 360
  return `hsl(${h} 75% 76%)`
}

/**
 * Baris 1: Nama | ✓ | #id
 * Baris 2: Role | Level
 */
export function UserLine({
  name,
  userId,
  role,
  verified,
  level,
  clanTag,
  size = 'md',
  onProfile,
}: {
  name: string
  userId: number
  role?: Role
  verified?: boolean
  level: number
  clanTag?: string
  size?: 'sm' | 'md'
  /** Jika diisi, nama bisa ditekan untuk membuka View Profile. */
  onProfile?: () => void
}) {
  const kind = checkKindOf(role, verified)
  return (
    <div className="min-w-0">
      <div className="flex min-w-0 items-center gap-1.5">
        <span
          {...(onProfile
            ? {
                role: 'button',
                tabIndex: 0,
                onClick: (e: MouseEvent<HTMLElement>) => {
                  e.stopPropagation()
                  onProfile()
                },
              }
            : {})}
          className={`min-w-0 truncate font-bold ${size === 'sm' ? 'text-[13px]' : 'text-[14px]'} ${onProfile ? 'active:opacity-70' : ''}`}
          style={{ color: nameColor(userId, role) }}
        >
          {name}
        </span>
        {kind ? <VerifiedIcon kind={kind} size={size === 'sm' ? 14 : 16} /> : null}
        <span className="shrink-0 text-[11.5px] text-muted">#{userId}</span>
      </div>
      <div className="mt-1 flex flex-wrap items-center gap-1.5">
        <RoleBadge role={role} />
        <ClanPill tag={clanTag} />
        <LevelPill level={level} />
      </div>
    </div>
  )
}

/** Centang sesuai role (kosong jika user biasa tanpa verified). */
export function RoleCheck({ role, verified, size = 15 }: { role?: Role; verified?: boolean; size?: number }) {
  const kind = checkKindOf(role, verified)
  return kind ? <VerifiedIcon kind={kind} size={size} /> : null
}
