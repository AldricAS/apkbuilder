import type { ReactNode } from 'react'
import { Icon, type IconName } from './Icon'

export function ErrorState({
  message,
  onRetry,
  compact = false,
}: {
  message: string
  onRetry?: () => void
  compact?: boolean
}) {
  return (
    <div className={`flex flex-col items-center px-8 text-center ${compact ? 'py-8' : 'py-20'}`}>
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-raise text-accent">
        <Icon name="offline" size={26} />
      </div>
      <p className="mt-4 text-[15px] font-semibold text-white">Data belum bisa dimuat</p>
      <p className="mt-1 text-[13px] leading-snug text-muted">{message}</p>
      {onRetry ? (
        <button
          type="button"
          onClick={onRetry}
          className="mt-5 flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-[13px] font-bold text-ink active:scale-95"
        >
          <Icon name="refresh" size={16} /> Coba lagi
        </button>
      ) : null}
    </div>
  )
}

export function EmptyState({
  icon = 'search',
  title,
  hint,
  action,
}: {
  icon?: IconName
  title: string
  hint?: string
  action?: ReactNode
}) {
  return (
    <div className="flex flex-col items-center px-8 py-20 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-raise text-muted">
        <Icon name={icon} size={26} />
      </div>
      <p className="mt-4 text-[15px] font-semibold text-white">{title}</p>
      {hint ? <p className="mt-1 text-[13px] leading-snug text-muted">{hint}</p> : null}
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  )
}

export function Spinner({ size = 22 }: { size?: number }) {
  return (
    <div
      className="animate-spin rounded-full border-2 border-white/20 border-t-accent"
      style={{ width: size, height: size }}
      role="status"
      aria-label="Memuat"
    />
  )
}
