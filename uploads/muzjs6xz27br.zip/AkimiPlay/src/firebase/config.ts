// Konfigurasi Firebase project "akimiplay-login" (diambil dari android/app/google-services.json).
// Catatan: API key Firebase bukan rahasia; keamanan data dijaga oleh Security Rules (database.rules.json).
import { initializeApp } from 'firebase/app'
import { browserLocalPersistence, indexedDBLocalPersistence, initializeAuth } from 'firebase/auth'
import { getDatabase } from 'firebase/database'

export const firebaseConfig = {
  apiKey: 'AIzaSyAyfkYba4ypklW7_5TLUYUnwsQd-aIpE_s',
  authDomain: 'akimiplay-login.firebaseapp.com',
  databaseURL: 'https://akimiplay-login-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'akimiplay-login',
  storageBucket: 'akimiplay-login.firebasestorage.app',
  messagingSenderId: '520976298442',
  appId: '1:520976298442:android:365a7ef15fb5992e5b1f33',
}

export const app = initializeApp(firebaseConfig)

// initializeAuth (tanpa popup resolver) cocok untuk WebView; sesi disimpan di IndexedDB sehingga
// tetap login setelah aplikasi ditutup.
export const auth = initializeAuth(app, {
  persistence: [indexedDBLocalPersistence, browserLocalPersistence],
})

export const db = getDatabase(app)

/** Key Realtime Database tidak boleh memuat . # $ / [ ] — ID anime/episode di-encode dulu. */
export const encodeKey = (s: string): string =>
  s.replace(/[.#$/\[\]%]/g, (ch) => '%' + ch.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0'))
