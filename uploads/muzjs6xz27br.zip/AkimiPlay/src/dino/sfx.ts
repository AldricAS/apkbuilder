// Efek suara sintetis (WebAudio): tidak ada berkas audio, tidak ada musik otomatis. Dimatikan dengan tombol mute (tersimpan).
// Proyek ini belum punya sistem audio sendiri, jadi modul ini berdiri sendiri dan hanya aktif setelah ada ketukan pengguna.
type Name = 'jump' | 'land' | 'hit' | 'score' | 'tick' | 'unlock' | 'reveal0' | 'reveal1' | 'reveal2' | 'reveal3' | 'click' | 'coin'

const KEY = 'akimi.dino.mute'
let ctx: AudioContext | null = null
let muted = false
try {
  muted = localStorage.getItem(KEY) === '1'
} catch {
  /* abaikan */
}

export const isMuted = (): boolean => muted
export function setMuted(v: boolean): void {
  muted = v
  try {
    localStorage.setItem(KEY, v ? '1' : '0')
  } catch {
    /* abaikan */
  }
}

function ac(): AudioContext | null {
  if (muted) return null
  if (!ctx) {
    const C = (window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext) as typeof AudioContext | undefined
    if (!C) return null
    try {
      ctx = new C()
    } catch {
      return null
    }
  }
  if (ctx.state === 'suspended') void ctx.resume().catch(() => undefined)
  return ctx
}
/** Lepas AudioContext saat halaman game ditutup (hemat baterai / tidak ada pemrosesan yang tertinggal). */
export function closeAudio(): void {
  if (ctx) void ctx.close().catch(() => undefined)
  ctx = null
}

function tone(c: AudioContext, f0: number, f1: number, dur: number, type: OscillatorType, vol: number, delay = 0) {
  const t = c.currentTime + delay
  const o = c.createOscillator()
  const g = c.createGain()
  o.type = type
  o.frequency.setValueAtTime(f0, t)
  o.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur)
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(vol, t + 0.008)
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
  o.connect(g).connect(c.destination)
  o.start(t)
  o.stop(t + dur + 0.02)
}
function noise(c: AudioContext, dur: number, vol: number, delay = 0, hp = 400) {
  const t = c.currentTime + delay
  const n = Math.floor(c.sampleRate * dur)
  const buf = c.createBuffer(1, n, c.sampleRate)
  const d = buf.getChannelData(0)
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n)
  const s = c.createBufferSource()
  s.buffer = buf
  const f = c.createBiquadFilter()
  f.type = 'highpass'
  f.frequency.value = hp
  const g = c.createGain()
  g.gain.value = vol
  s.connect(f).connect(g).connect(c.destination)
  s.start(t)
}

export function sfx(n: Name): void {
  const c = ac()
  if (!c) return
  switch (n) {
    case 'jump': tone(c, 300, 620, 0.13, 'square', 0.07); break
    case 'land': noise(c, 0.07, 0.09, 0, 600); tone(c, 120, 60, 0.08, 'triangle', 0.1); break
    case 'hit': noise(c, 0.3, 0.18, 0, 200); tone(c, 260, 50, 0.35, 'sawtooth', 0.12); break
    case 'score': tone(c, 880, 1320, 0.09, 'square', 0.05); break
    case 'tick': tone(c, 1200 + Math.random() * 300, 900, 0.03, 'square', 0.03); break
    case 'click': tone(c, 700, 500, 0.05, 'square', 0.05); break
    case 'coin': tone(c, 988, 1319, 0.08, 'square', 0.06); tone(c, 1319, 1319, 0.14, 'square', 0.06, 0.07); break
    case 'unlock': [523, 659, 784, 1047].forEach((f, i) => tone(c, f, f, 0.16, 'square', 0.07, i * 0.09)); break
    case 'reveal0': tone(c, 520, 660, 0.18, 'triangle', 0.1); break
    case 'reveal1': [520, 660, 880].forEach((f, i) => tone(c, f, f * 1.01, 0.2, 'triangle', 0.1, i * 0.1)); break
    case 'reveal2': [523, 659, 784, 1047, 1319].forEach((f, i) => tone(c, f, f, 0.22, 'square', 0.07, i * 0.09)); noise(c, 0.25, 0.05, 0.3, 3000); break
    case 'reveal3': [392, 523, 659, 784, 1047, 1319, 1568].forEach((f, i) => { tone(c, f, f, 0.3, 'square', 0.07, i * 0.1); tone(c, f / 2, f / 2, 0.3, 'triangle', 0.08, i * 0.1) }); noise(c, 0.6, 0.08, 0.5, 2500); break
  }
}
