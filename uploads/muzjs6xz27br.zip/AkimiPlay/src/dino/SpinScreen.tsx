import { useEffect, useRef, useState, type MutableRefObject } from 'react'
import { useBackHandler } from '../native/native'
import {
  DINO, DinoError, RARITIES, RAR_KEYS, SKINS, SELL_PRICE, ownedCount, payFirstUnlock, paySpin, revealNext, sellDuplicate,
  type DinoState, type Reveal,
} from '../services/dinoService'
import { sfx } from './sfx'
import { SpriteView } from './SpriteView'
import { Btn } from './ui'
import { Icon } from '../components/Icon'
import { toast } from '../components/Feedback'

const TILE = 92
const VIS = 3
const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms))

/** Burst partikel piksel (satu canvas kecil, berhenti sendiri setelah selesai). */
function useBurst() {
  const ref = useRef<HTMLCanvasElement>(null)
  const parts = useRef<{ x: number; y: number; vx: number; vy: number; l: number; c: string; s: number }[]>([])
  const raf = useRef(0)
  const run = () => {
    const cv = ref.current
    if (!cv || raf.current) return
    const ctx = cv.getContext('2d')!
    let last = performance.now()
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      ctx.clearRect(0, 0, cv.width, cv.height)
      parts.current = parts.current.filter((p) => p.l > 0)
      for (const p of parts.current) {
        p.l -= dt; p.vy += 260 * dt; p.x += p.vx * dt; p.y += p.vy * dt
        ctx.globalAlpha = Math.min(1, p.l * 2)
        ctx.fillStyle = p.c
        ctx.fillRect(Math.round(p.x), Math.round(p.y), p.s, p.s)
      }
      ctx.globalAlpha = 1
      if (parts.current.length) raf.current = requestAnimationFrame(tick)
      else { raf.current = 0; ctx.clearRect(0, 0, cv.width, cv.height) }
    }
    raf.current = requestAnimationFrame(tick)
  }
  useEffect(() => () => cancelAnimationFrame(raf.current), [])
  const burst = (n: number, colors: string[]) => {
    const cv = ref.current
    if (!cv) return
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, v = 40 + Math.random() * 150
      parts.current.push({ x: cv.width / 2, y: cv.height / 2, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 70, l: 0.6 + Math.random() * 0.9, c: colors[i % colors.length], s: Math.random() < 0.5 ? 2 : 3 })
    }
    if (parts.current.length > 160) parts.current.splice(0, parts.current.length - 160)
    run()
  }
  return { ref, burst }
}

function Reel({ handle }: { handle: MutableRefObject<((id: number, ms: number) => Promise<void>) | null> }) {
  const strip = useRef<HTMLDivElement>(null)
  const [tiles, setTiles] = useState<number[]>(() => Array.from({ length: 12 }, (_, i) => i))
  const raf = useRef(0)
  const pos = useRef(0)
  useEffect(() => {
    handle.current = (target, ms) =>
      new Promise<void>((resolve) => {
        const n = 30
        const list = Array.from({ length: n }, () => Math.floor(Math.random() * SKINS.length))
        list[n - 2] = target
        setTiles(list)
        const from = 0
        const to = (n - 2) * TILE - TILE * ((VIS - 1) / 2) // tile target tepat di tengah
        const t0 = performance.now()
        let lastTick = -1
        const step = (now: number) => {
          const k = Math.min(1, (now - t0) / ms)
          const e = 1 - Math.pow(1 - k, 3.2)
          const y = from + (to - from) * e
          pos.current = y
          if (strip.current) strip.current.style.transform = `translateY(${-Math.round(y)}px)`
          const idx = Math.floor((y + TILE / 2) / TILE)
          if (idx !== lastTick) { lastTick = idx; if (k < 0.95) sfx('tick') }
          if (k < 1) raf.current = requestAnimationFrame(step)
          else resolve()
        }
        cancelAnimationFrame(raf.current)
        if (strip.current) strip.current.style.transform = 'translateY(0)'
        raf.current = requestAnimationFrame(step)
      })
    return () => { handle.current = null; cancelAnimationFrame(raf.current) }
  }, [handle])
  return (
    <div className="relative mx-auto overflow-hidden rounded-sm border-[3px] border-[#05040e] bg-[#0b0920]" style={{ width: 150, height: TILE * VIS, boxShadow: 'inset 0 0 0 2px #3b2f7a' }}>
      <div ref={strip} className="will-change-transform">
        {tiles.map((id, i) => {
          const sk = SKINS[id]; const r = RARITIES[sk.rarity]
          return (
            <div key={i} className="flex items-center justify-center" style={{ height: TILE, borderBottom: '2px solid #1a1540', background: `linear-gradient(90deg, transparent, ${r.ring}, transparent)` }}>
              <SpriteView skin={sk.key} still scale={2} />
            </div>
          )
        })}
      </div>
      <div className="pointer-events-none absolute inset-x-0 border-y-[3px] border-[#ffd84a]/80" style={{ top: TILE, height: TILE }} />
      <div className="pointer-events-none absolute inset-0" style={{ background: 'linear-gradient(#0b0920 0%, transparent 28%, transparent 72%, #0b0920 100%)' }} />
    </div>
  )
}

function Meter({ label, val, max, color }: { label: string; val: number; max: number; color: string }) {
  const pct = Math.min(100, Math.round((val / max) * 100))
  return (
    <div>
      <div className="flex justify-between font-mono text-[10.5px] font-bold tracking-wider text-white/70"><span style={{ color }}>{label}</span><span>{val}/{max} · {pct}%</span></div>
      <div className="mt-1 flex h-3 gap-[2px] border-2 border-[#05040e] bg-[#05040e] p-[1px]">
        {Array.from({ length: 20 }).map((_, i) => (<span key={i} className="h-full flex-1" style={{ background: i < Math.round(pct / 5) ? color : '#1d1840' }} />))}
      </div>
    </div>
  )
}

export default function SpinScreen({ uid, state, shard, onBack, onOpen }: { uid: string; state: DinoState; shard: number; onBack: () => void; onOpen: (id: number) => void }) {
  const [busy, setBusy] = useState(false)
  const [results, setResults] = useState<Reveal[] | null>(null)
  const [sold, setSold] = useState<Record<number, boolean>>({})
  const [flash, setFlash] = useState<{ c: string; k: number } | null>(null)
  const [shake, setShake] = useState(0)
  const [five, setFive] = useState(false)
  const handle = useRef<((id: number, ms: number) => Promise<void>) | null>(null)
  const { ref: burstRef, burst } = useBurst()
  const alive = useRef(true)
  useEffect(() => () => { alive.current = false }, [])
  useBackHandler(() => { if (busy) return true; if (results) { setResults(null); return true } onBack(); return true }, 55, true)

  const sp = state.spin
  const pend = sp?.pend ?? 0
  const none = ownedCount(state) === 0
  const pr = sp?.pr ?? 0, pl = sp?.pl ?? 0, pm = sp?.pm ?? 0
  const nexts = [
    { r: 'RARE', left: DINO.PITY_RARE - pr, color: RARITIES.rare.color },
    { r: 'LEGEND', left: DINO.PITY_LEGEND - pl, color: RARITIES.legend.color },
    { r: 'MYTHIC', left: DINO.PITY_MYTHIC - pm, color: RARITIES.mythic.color },
  ].sort((a, b) => a.left - b.left)[0]

  const celebrate = async (r: Reveal, quick: boolean) => {
    const rr = RARITIES[RAR_KEYS[r.rar]]
    sfx(('reveal' + r.rar) as 'reveal0')
    setFlash({ c: rr.color, k: Date.now() })
    if (r.rar >= 1) setShake(Date.now())
    burst([8, 18, 30, 46][r.rar] * (quick ? 0.6 : 1) | 0, [rr.color, '#ffffff', rr.glow])
    await wait(quick ? 450 : 1000 + r.rar * 250)
  }

  const run = async (mode: 'first' | 'one' | 'five' | 'resume') => {
    if (busy) return
    setBusy(true)
    setResults(null)
    setSold({})
    try {
      let count = pend
      if (mode !== 'resume') {
        if (mode === 'first') await payFirstUnlock(uid)
        else await paySpin(uid, mode === 'five')
        sfx('coin')
        count = mode === 'five' ? 5 : 1
      }
      setFive(count > 1)
      const got: Reveal[] = []
      for (let i = 0; i < count; i++) {
        const r = await revealNext(uid)
        got.push(r)
        if (!alive.current) return
        await handle.current?.(r.s, count > 1 ? 1500 : 2900)
        await celebrate(r, count > 1)
      }
      if (alive.current) setResults(got)
    } catch (e) {
      toast(e instanceof DinoError ? e.message : 'Undian gagal, coba lagi')
    } finally {
      if (alive.current) setBusy(false)
    }
  }

  const sell = async (id: number) => {
    try {
      const p = await sellDuplicate(uid, id)
      setSold((s) => ({ ...s, [id]: true }))
      sfx('coin')
      toast(`Terjual +${p} AkimiShard`)
    } catch (e) {
      toast(e instanceof DinoError ? e.message : 'Gagal menjual')
    }
  }

  const canOne = shard >= DINO.SPIN_ONE, canFive = shard >= DINO.SPIN_FIVE, canFirst = shard >= DINO.FIRST_UNLOCK

  return (
    <div className="absolute inset-0 overflow-y-auto overflow-x-hidden bg-[#0a0820] pb-28 text-white [touch-action:pan-y]">
      <header className="pt-safe sticky top-0 z-20 bg-[#0a0820]/95">
        <div className="flex h-14 items-center gap-2 px-3">
          <button type="button" aria-label="Kembali" disabled={busy} onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"><Icon name="back" size={22} /></button>
          <h1 className="flex-1 font-mono text-[17px] font-extrabold tracking-widest">SPIN KOLEKSI</h1>
          <span className="px-panel rounded-sm px-2.5 py-1 font-mono text-[12px] font-extrabold text-[#6cff9a]" style={{ ['--edge' as string]: '#1f6b3a' }}>◆ {shard.toLocaleString('id-ID')}</span>
        </div>
      </header>

      <div className={`relative mx-4 mt-2 ${shake ? 'px-shake' : ''}`} key={shake}>
        <div className="px-panel rounded-sm p-4">
          <Reel handle={handle} />
          <canvas ref={burstRef} width={300} height={220} className="px pointer-events-none absolute left-1/2 top-4 -translate-x-1/2" style={{ width: 300, height: 220 }} />
          {flash ? <div key={flash.k} className="pointer-events-none absolute inset-0" style={{ background: flash.c, animation: 'pxFlash .6s steps(6) forwards', mixBlendMode: 'screen' }} /> : null}
        </div>
      </div>

      {pend > 0 && !busy ? (
        <div className="px-panel mx-4 mt-4 rounded-sm p-3" style={{ ['--edge' as string]: '#c98a00' }}>
          <p className="font-mono text-[12px] font-bold text-[#ffd84a]">Ada {pend} hasil undian yang sudah dibayar menunggu dibuka.</p>
          <div className="mt-2"><Btn tone="gold" onClick={() => void run('resume')}>Buka hasil</Btn></div>
        </div>
      ) : null}

      {results ? (
        <div className="mx-4 mt-4">
          <p className="mb-2 text-center font-mono text-[13px] font-extrabold tracking-widest text-[#ffd84a]">{five ? 'HASIL SPIN 5×' : 'KAMU DAPAT'}</p>
          <div className={`grid gap-2 ${five ? 'grid-cols-3' : 'grid-cols-1'}`}>
            {results.map((r, i) => {
              const sk = SKINS[r.s]; const rr = RARITIES[sk.rarity]
              const dupAny = !r.isNew || results.slice(0, i).some((x) => x.s === r.s)
              return (
                <div key={i} className="px-panel px-pop flex flex-col items-center rounded-sm p-2 text-center" style={{ ['--edge' as string]: rr.color, animationDelay: `${i * 90}ms` }}>
                  <SpriteView skin={sk.key} anim="run" scale={five ? 2 : 4} />
                  <p className="mt-1 font-mono text-[12.5px] font-extrabold" style={{ color: rr.color }}>{sk.name}</p>
                  <p className="font-mono text-[9.5px] font-bold tracking-widest text-white/55">{rr.label}</p>
                  {r.isNew && !dupAny ? <p className="mt-1 font-mono text-[10px] font-extrabold text-[#6cff9a]">BARU!</p> : dupAny ? (
                    <button type="button" disabled={sold[r.s]} onClick={() => void sell(r.s)} className="px-btn mt-1 rounded-sm bg-[#2a2550] px-2 py-1 font-mono text-[10px] text-white">
                      {sold[r.s] ? 'Terjual' : `Duplikat · jual +${SELL_PRICE(r.s)}`}
                    </button>
                  ) : null}
                  {!five ? <button type="button" onClick={() => onOpen(r.s)} className="mt-1 font-mono text-[10.5px] font-bold text-white/55 underline">Lihat detail</button> : null}
                </div>
              )
            })}
          </div>
        </div>
      ) : null}

      <div className="mx-4 mt-5 space-y-2.5">
        {none && pend === 0 ? (
          <>
            <Btn tone="green" disabled={busy || !canFirst} onClick={() => void run('first')}>Unlock pertama (Common) · ◆ {DINO.FIRST_UNLOCK}</Btn>
            <p className="text-center font-mono text-[10.5px] text-white/50">Belum punya Dino. Unlock pertama dijamin Common, harga khusus sekali saja.{!canFirst ? ' Main dulu untuk mengumpulkan AkimiShard.' : ''}</p>
          </>
        ) : null}
        <Btn tone="purple" disabled={busy || !canOne || pend > 0} onClick={() => void run('one')}>Spin dino · ◆ {DINO.SPIN_ONE}</Btn>
        <Btn tone="pink" disabled={busy || !canFive || pend > 0} onClick={() => void run('five')}>Gacha 5× · ◆ {DINO.SPIN_FIVE} <span className="opacity-70">(hemat {DINO.SPIN_ONE * 5 - DINO.SPIN_FIVE})</span></Btn>
        {!canOne && !busy ? <p className="text-center font-mono text-[10.5px] text-white/50">AkimiShard didapat dari top up atau dari bermain Dino Run (1 skor = 1 shard).</p> : null}
      </div>

      <div className="px-panel mx-4 mt-5 rounded-sm p-3.5">
        <p className="font-mono text-[12px] font-extrabold tracking-widest">SPIN PROGRESS</p>
        <div className="mt-3 space-y-3">
          <Meter label="RARE" val={pr} max={DINO.PITY_RARE} color={RARITIES.rare.color} />
          <Meter label="LEGEND" val={pl} max={DINO.PITY_LEGEND} color={RARITIES.legend.color} />
          <Meter label="MYTHIC" val={pm} max={DINO.PITY_MYTHIC} color={RARITIES.mythic.color} />
        </div>
        <p className="mt-3 font-mono text-[11px] text-white/65">Next guaranteed reward: <b style={{ color: nexts.color }}>{nexts.r}</b> dalam {nexts.left} spin lagi.</p>
      </div>

      <div className="px-panel mx-4 mt-4 rounded-sm p-3.5">
        <p className="font-mono text-[12px] font-extrabold tracking-widest">PELUANG (TRANSPARAN)</p>
        <div className="mt-2 space-y-1 font-mono text-[11.5px]">
          <p style={{ color: RARITIES.common.color }}>COMMON · 80%</p>
          <p style={{ color: RARITIES.rare.color }}>RARE · 17,5% (dijamin tiap {DINO.PITY_RARE} spin)</p>
          <p style={{ color: RARITIES.legend.color }}>LEGEND · 2,3% (dijamin tiap {DINO.PITY_LEGEND} spin)</p>
          <p style={{ color: RARITIES.mythic.color }}>MYTHIC · 0,2% (dijamin tiap {DINO.PITY_MYTHIC} spin)</p>
        </div>
        <p className="mt-2.5 font-mono text-[10.5px] leading-relaxed text-white/50">Hasil dihitung server dari waktu bayar, bukan dari aplikasi, jadi tidak bisa diubah. Pembelian memakai AkimiShard, tanpa taruhan uang. Dino ganda bisa dijual: Common +30, Rare +90, Legend +300, Mythic +900.</p>
      </div>
    </div>
  )
}
