import { SKINS } from '../services/dinoService'

const BASE = (import.meta as unknown as { env?: { BASE_URL?: string } }).env?.BASE_URL ?? '/'
export type Anim = 'idle' | 'run' | 'jump' | 'crouch'
const ROW: Record<Anim, number> = { idle: 0, run: 1, jump: 2, crouch: 3 }

/** Sprite beranimasi dari sprite sheet (CSS steps): tanpa canvas, tanpa JS per frame. `locked` = siluet gelap. */
export function SpriteView({ skin, anim = 'idle', scale = 3, locked = false, still = false, className = '' }: { skin: string; anim?: Anim; scale?: number; locked?: boolean; still?: boolean; className?: string }) {
  const sw = 32 * scale
  return (
    <div
      aria-hidden
      className={`spr spr-${anim} ${className}`}
      style={{
        width: sw,
        height: sw,
        ['--sw' as string]: `${sw}px`,
        backgroundImage: `url(${BASE}dino/${skin}.png)`,
        backgroundSize: `${sw * 4}px ${sw * 4}px`,
        backgroundPositionY: `${-ROW[anim] * sw}px`,
        filter: locked ? 'brightness(0) opacity(.78)' : undefined,
        animation: still ? 'none' : undefined,
      }}
    />
  )
}

export const skinKey = (id: number): string => (id >= 0 && SKINS[id] ? SKINS[id].key : 'neutral')
