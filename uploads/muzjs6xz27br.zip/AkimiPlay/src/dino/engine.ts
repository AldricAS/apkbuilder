// Mesin AkimiGame: Dino Run. Canvas 2D beresolusi rendah (lebar logis 176 px) yang diperbesar dengan nearest-neighbor
// (image-rendering: pixelated) supaya pixel art tajam. Semua partikel ada di array tetap (object pooling), tanpa DOM.
import { sfx } from './sfx'

export type FxRarity = 'none' | 'common' | 'rare' | 'legend' | 'mythic'
type Kind = 'none' | 'leaf' | 'sand' | 'drop' | 'spark' | 'snow' | 'ember' | 'wisp' | 'star' | 'gold' | 'jet' | 'dragon'
export type SkinFx = { rarity: FxRarity; c: [string, string, string]; kind: Kind }
export const FX: Record<string, SkinFx> = {
  neutral: { rarity: 'none', c: ['#ffd3e3', '#ff8fb3', '#c0489f'], kind: 'none' },
  classic: { rarity: 'common', c: ['#c9c9d4', '#8e8e99', '#62626f'], kind: 'none' },
  leafy: { rarity: 'common', c: ['#9be874', '#4aa83a', '#2b7a2e'], kind: 'leaf' },
  sand: { rarity: 'common', c: ['#e8c79a', '#c9955a', '#9a6a3a'], kind: 'sand' },
  aqua: { rarity: 'common', c: ['#d3f3ff', '#5cc8ff', '#2f8cf0'], kind: 'drop' },
  cyber: { rarity: 'rare', c: ['#9cf2ff', '#18d2ff', '#0a86b8'], kind: 'spark' },
  frost: { rarity: 'rare', c: ['#ffffff', '#a6dcff', '#5f9fd6'], kind: 'snow' },
  flame: { rarity: 'rare', c: ['#ffe45e', '#ff9a2e', '#e0362a'], kind: 'ember' },
  shadow: { rarity: 'rare', c: ['#c9a6ff', '#8a5cf0', '#3b2870'], kind: 'wisp' },
  galaxy: { rarity: 'legend', c: ['#e2b6ff', '#7fe0ff', '#ff9be8'], kind: 'star' },
  royal: { rarity: 'legend', c: ['#fff0a0', '#f2c23a', '#d02a3a'], kind: 'gold' },
  mecha: { rarity: 'legend', c: ['#b6f1ff', '#2fc8ff', '#7c90a6'], kind: 'jet' },
  akimidragon: { rarity: 'mythic', c: ['#ffd0ff', '#ff3df0', '#8a2fb8'], kind: 'dragon' },
}

// posisi rintangan pada public/dino/obstacles.png (dibuat tools/gen_dino_sprites.py)
const OB: Record<string, [number, number, number, number]> = {
  cactusS: [0, 0, 14, 20],
  cactusM: [15, 0, 18, 30],
  cactusG: [34, 0, 36, 20],
  rock: [71, 0, 20, 10],
  bird0: [92, 0, 26, 14],
  bird1: [119, 0, 26, 14],
}
const F = { idle0: 0, idle1: 1, blink: 2, hit: 3, run: 4, prep: 8, launch: 9, air: 10, land: 11, crouch: 12, fall: 14 }

const BASE = (import.meta as unknown as { env?: { BASE_URL?: string } }).env?.BASE_URL ?? '/'
const cache = new Map<string, Promise<HTMLImageElement>>()
export function loadImage(name: string): Promise<HTMLImageElement> {
  let p = cache.get(name)
  if (!p) {
    p = new Promise((res, rej) => {
      const im = new Image()
      im.onload = () => res(im)
      im.onerror = () => {
        cache.delete(name)
        rej(new Error('sprite ' + name))
      }
      im.src = `${BASE}dino/${name}.png`
    })
    cache.set(name, p)
  }
  return p
}
/** Lepas sprite sheet skin yang tidak dipakai lagi supaya memori kecil (hanya skin aktif + obstacles yang dimuat). */
export const releaseSheets = (keep: string[]) => {
  for (const k of [...cache.keys()]) if (!keep.includes(k)) cache.delete(k)
}

const W = 176
const GRAV = 950
const JUMP_V = -318
const DECIDE_MS = 45
const NP = 220

type Ob = { x: number; y: number; w: number; h: number; spr: string; bird: boolean; hx: number; hy: number; hw: number; hh: number; passed: boolean }

export type EngineOpts = {
  skin: string
  onScore?: (s: number) => void
  onOver?: (score: number) => void
  onState?: (s: 'ready' | 'run' | 'dead') => void
}

export class DinoEngine {
  private ctx: CanvasRenderingContext2D
  private H = 280
  private gy = 196
  private sheet?: HTMLImageElement
  private obs?: HTMLImageElement
  private sky?: HTMLCanvasElement
  private far?: HTMLCanvasElement
  private near?: HTMLCanvasElement
  private ground?: HTMLCanvasElement
  private fx: SkinFx
  private raf = 0
  private last = 0
  private acc = 0
  private running = false
  private destroyed = false
  state: 'ready' | 'run' | 'dead' = 'ready'
  private t = 0 // waktu bermain (detik)
  private clock = 0 // waktu total (animasi)
  private readyT = 0
  private deadT = 0
  private overSent = false
  private speed = 78
  private score = 0
  private scoreSent = 0
  private lastMilestone = 0
  // dino
  private dx = 30
  private dyFeet = 0
  private vy = 0
  private onGround = true
  private landT = 0
  private crouch = false
  private jumpBuf = 0
  private pending: { id: number; y0: number; t0: number; y: number } | null = null
  private runPhase = 0
  private flash = 0
  private shake = 0
  private trailT = 0
  private dustT = 0
  private auraT = 0
  private beam = 0
  private beamX = 0
  // dunia
  private obsList: Ob[] = []
  private since = 0
  private gap = 150
  private lastBird = false
  private bgx = 0
  private stars: { x: number; y: number; p: number }[] = []
  // partikel (pool)
  private pal: string[] = []
  private px = new Float32Array(NP)
  private py = new Float32Array(NP)
  private pvx = new Float32Array(NP)
  private pvy = new Float32Array(NP)
  private pay = new Float32Array(NP)
  private pl = new Float32Array(NP)
  private pm = new Float32Array(NP)
  private ps = new Uint8Array(NP)
  private pc = new Uint8Array(NP)
  private pf = new Uint8Array(NP) // 0 depan biasa, 1 belakang additive, 2 depan additive
  private pn = 0
  private cleanup: Array<() => void> = []

  constructor(
    private canvas: HTMLCanvasElement,
    private o: EngineOpts,
  ) {
    const c = canvas.getContext('2d', { alpha: false })
    if (!c) throw new Error('canvas')
    this.ctx = c
    this.fx = FX[o.skin] ?? FX.neutral
    this.pal = [...this.fx.c, '#ffffff', '#a79fd6', '#6e66a8', '#ffe45e', '#ff3df0', '#000000']
  }

  // ---------- siapkan ----------
  async init(cssW: number, cssH: number): Promise<void> {
    this.H = Math.max(230, Math.min(340, Math.round((W * cssH) / Math.max(1, cssW))))
    this.gy = Math.floor(this.H * 0.7)
    this.dyFeet = this.gy
    this.canvas.width = W
    this.canvas.height = this.H
    const [sheet, obs] = await Promise.all([loadImage(this.o.skin), loadImage('obstacles')])
    if (this.destroyed) return
    this.sheet = sheet
    this.obs = obs
    this.buildBackground()
    for (let i = 0; i < 34; i++) this.stars.push({ x: (i * 53 + 11) % W, y: ((i * 37 + 5) % Math.floor(this.gy * 0.55)) + 4, p: i * 0.7 })
    this.attachInput()
    this.draw()
  }

  private mk(w: number, h: number): HTMLCanvasElement {
    const c = document.createElement('canvas')
    c.width = w
    c.height = h
    return c
  }
  private buildBackground() {
    const H = this.H
    // langit: pita warna bertingkat dengan dither
    const sky = (this.sky = this.mk(W, H))
    const s = sky.getContext('2d')!
    const bands = ['#070a1e', '#0b0e2a', '#10113a', '#18134a', '#221657', '#2e1a62', '#3b2070']
    const bh = Math.ceil(this.gy / bands.length)
    bands.forEach((c, i) => {
      s.fillStyle = c
      s.fillRect(0, i * bh, W, bh + 1)
      if (i < bands.length - 1) {
        s.fillStyle = bands[i + 1]
        for (let x = 0; x < W; x += 2) s.fillRect(x + (x / 2) % 2, (i + 1) * bh - 2, 1, 1)
      }
    })
    s.fillStyle = '#14102e'
    s.fillRect(0, this.gy, W, H - this.gy)
    // bulan pixel
    const mx = Math.floor(W * 0.74), my = Math.floor(H * 0.12)
    for (let y = -11; y <= 11; y++) for (let x = -11; x <= 11; x++) if (x * x + y * y <= 121) { s.fillStyle = x * x + y * y > 100 ? '#ffd6ec' : '#fff1f7'; s.fillRect(mx + x, my + y, 1, 1) }
    s.fillStyle = '#f2c4de'
    for (const [cx, cy] of [[-3, -2], [3, 3], [-5, 4], [4, -5]]) s.fillRect(mx + cx, my + cy, 2, 2)
    // gunung jauh & dekat (ubin 256 px yang digulir)
    const ridge = (h: number, seed: number, col: string, col2: string) => {
      const cv = this.mk(256, h)
      const c = cv.getContext('2d')!
      let v = seed
      const hs: number[] = []
      for (let x = 0; x < 256; x++) {
        v = (v * 1103515245 + 12345) & 0x7fffffff
        hs.push(0)
      }
      for (let x = 0; x < 256; x++) hs[x] = h * 0.45 + Math.sin(x / 256 * Math.PI * 6 + seed) * h * 0.22 + Math.sin(x / 256 * Math.PI * 14 + seed * 2) * h * 0.1
      for (let x = 0; x < 256; x++) {
        const top = Math.floor(h - hs[x])
        c.fillStyle = col
        c.fillRect(x, top, 1, h - top)
        c.fillStyle = col2
        c.fillRect(x, top, 1, 1)
      }
      return cv
    }
    this.far = ridge(46, 3, '#1b1646', '#2c2468')
    this.near = ridge(30, 7, '#241a5a', '#3a2b86')
    // tanah: ubin 64 px berisi kerikil & garis tanah
    const g = (this.ground = this.mk(64, H - this.gy))
    const c = g.getContext('2d')!
    c.fillStyle = '#1b1540'
    c.fillRect(0, 0, 64, g.height)
    c.fillStyle = '#4b3a9a'
    c.fillRect(0, 0, 64, 1)
    c.fillStyle = '#2d2270'
    c.fillRect(0, 1, 64, 2)
    c.fillStyle = '#2a2062'
    const dots = [[5, 8, 3, 1], [22, 14, 2, 1], [40, 7, 4, 1], [55, 18, 2, 1], [12, 24, 3, 1], [33, 28, 2, 1], [48, 34, 3, 1], [60, 30, 2, 1], [8, 40, 2, 1], [28, 44, 4, 1]]
    for (const [x, y, w, h] of dots) if (y < g.height) c.fillRect(x, y, w, h)
    c.fillStyle = '#5a49b8'
    for (const [x, y] of [[14, 6], [46, 12], [30, 20]]) c.fillRect(x, y, 1, 1)
  }

  // ---------- input ----------
  private attachInput() {
    const cv = this.canvas
    const down = (e: PointerEvent) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return
      e.preventDefault()
      try {
        cv.setPointerCapture(e.pointerId)
      } catch {
        /* abaikan */
      }
      if (this.state === 'dead') return
      this.pending = { id: e.pointerId, y0: e.clientY, t0: performance.now(), y: e.clientY }
    }
    const move = (e: PointerEvent) => {
      const p = this.pending
      if (p && p.id === e.pointerId) {
        p.y = e.clientY
        this.decide()
      } else if (this.crouch === false && this.heldId === e.pointerId && e.clientY - this.heldY0 > 14) {
        this.crouch = true // swipe bawah setelah lompat: jatuh cepat / jongkok saat mendarat
      }
    }
    const up = (e: PointerEvent) => {
      const p = this.pending
      if (p && p.id === e.pointerId) this.decide(true)
      if (this.heldId === e.pointerId) {
        this.crouch = false
        this.heldId = -1
      }
    }
    cv.addEventListener('pointerdown', down)
    cv.addEventListener('pointermove', move)
    cv.addEventListener('pointerup', up)
    cv.addEventListener('pointercancel', up)
    const key = (e: KeyboardEvent, d: boolean) => {
      if (e.code === 'ArrowUp' || e.code === 'Space' || e.code === 'KeyW') {
        if (d && !e.repeat) this.jump()
        e.preventDefault()
      } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        this.crouch = d
        e.preventDefault()
      }
    }
    const kd = (e: KeyboardEvent) => key(e, true)
    const ku = (e: KeyboardEvent) => key(e, false)
    window.addEventListener('keydown', kd)
    window.addEventListener('keyup', ku)
    const vis = () => {
      if (document.hidden) this.pause()
    }
    document.addEventListener('visibilitychange', vis)
    this.cleanup.push(() => {
      cv.removeEventListener('pointerdown', down)
      cv.removeEventListener('pointermove', move)
      cv.removeEventListener('pointerup', up)
      cv.removeEventListener('pointercancel', up)
      window.removeEventListener('keydown', kd)
      window.removeEventListener('keyup', ku)
      document.removeEventListener('visibilitychange', vis)
    })
  }
  private heldId = -1
  private heldY0 = 0
  /** Menentukan ketukan/swipe naik = lompat, swipe turun = jongkok. Jendela keputusan 45 ms (pose antisipasi). */
  private decide(release = false) {
    const p = this.pending
    if (!p) return
    const dy = p.y - p.y0
    if (dy > 12) {
      this.crouch = true
      this.heldId = p.id
      this.heldY0 = p.y0
      this.pending = null
      return
    }
    if (release || dy < -10 || performance.now() - p.t0 >= DECIDE_MS) {
      this.heldId = p.id
      this.heldY0 = p.y0
      this.pending = null
      this.jump()
    }
  }
  jump() {
    if (this.state !== 'run' && this.state !== 'ready') return
    if (this.state === 'ready') return
    if (this.onGround && this.landT < 0.05) {
      this.vy = JUMP_V
      this.onGround = false
      sfx('jump')
      this.fxJump()
    } else {
      this.jumpBuf = 0.12
    }
  }

  // ---------- kontrol ----------
  start() {
    this.state = 'ready'
    this.readyT = 0
    this.t = 0
    this.score = 0
    this.scoreSent = -1
    this.speed = 78
    this.obsList = []
    this.since = 0
    this.gap = 170
    this.lastBird = false
    this.deadT = 0
    this.overSent = false
    this.vy = 0
    this.dyFeet = this.gy
    this.onGround = true
    this.crouch = false
    this.pending = null
    this.pn = 0
    this.lastMilestone = 0
    this.o.onState?.('ready')
    this.fxSpawn()
    this.resume()
  }
  pause() {
    this.running = false
    if (this.raf) cancelAnimationFrame(this.raf)
    this.raf = 0
  }
  resume() {
    if (this.running || this.destroyed) return
    this.running = true
    this.last = performance.now()
    this.raf = requestAnimationFrame(this.loop)
  }
  get isRunning() {
    return this.running
  }
  destroy() {
    this.destroyed = true
    this.pause()
    this.cleanup.forEach((f) => f())
    this.cleanup = []
    this.sheet = this.obs = this.sky = this.far = this.near = this.ground = undefined
  }

  private loop = (now: number) => {
    if (!this.running) return
    let dt = (now - this.last) / 1000
    this.last = now
    if (dt > 0.1) dt = 0.1
    this.acc += dt
    const step = 1 / 60
    let n = 0
    while (this.acc >= step && n++ < 4) {
      this.update(step)
      this.acc -= step
    }
    if (n >= 4) this.acc = 0
    this.draw()
    this.raf = requestAnimationFrame(this.loop)
  }

  // ---------- partikel ----------
  private emit(x: number, y: number, vx: number, vy: number, life: number, size: number, col: number, flag = 0, ay = 0) {
    if (this.pn >= NP) return
    const i = this.pn++
    this.px[i] = x
    this.py[i] = y
    this.pvx[i] = vx
    this.pvy[i] = vy
    this.pay[i] = ay
    this.pl[i] = life
    this.pm[i] = life
    this.ps[i] = size
    this.pc[i] = col
    this.pf[i] = flag
  }
  private rnd = (a: number, b: number) => a + Math.random() * (b - a)
  private tier(): number {
    return { none: 0, common: 1, rare: 2, legend: 3, mythic: 4 }[this.fx.rarity]
  }
  private cx() { return this.dx + 16 }
  private cy() { return this.dyFeet - 14 }

  private fxDust(n: number, spread = 1) {
    for (let i = 0; i < n; i++) this.emit(this.dx + this.rnd(2, 12), this.dyFeet - 1, this.rnd(-70, -10) * spread, this.rnd(-45, -8), this.rnd(0.25, 0.5), Math.random() < 0.4 ? 2 : 1, Math.random() < 0.5 ? 4 : 5)
  }
  private fxJump() {
    const t = this.tier()
    this.fxDust(4)
    const [c0, c1] = [0, 1]
    if (t >= 2) for (let i = 0; i < (t === 2 ? 8 : t === 3 ? 16 : 26); i++) { const a = (i / 12) * Math.PI * 2; this.emit(this.cx() + Math.cos(a) * 4, this.dyFeet - 2, Math.cos(a) * this.rnd(30, 70), -Math.abs(Math.sin(a)) * this.rnd(40, 110), this.rnd(0.3, 0.6), 2, i % 3 === 0 ? c0 : c1, 2) }
    if (t >= 3) { this.beam = t === 4 ? 0.32 : 0.2; this.beamX = this.cx() }
    if (t === 4) for (let i = 0; i < 8; i++) this.emit(this.cx() + this.rnd(-8, 8), this.dyFeet - this.rnd(0, 28), this.rnd(-20, 20), this.rnd(-90, -30), this.rnd(0.4, 0.8), 3, 3, 2)
  }
  private fxLand() {
    const t = this.tier()
    this.fxDust(8, 1.5)
    if (t >= 2) for (let i = 0; i < (t === 2 ? 8 : t === 3 ? 16 : 28); i++) { const s = i % 2 ? 1 : -1; this.emit(this.cx() + s * 4, this.dyFeet - 1, s * this.rnd(40, 140), this.rnd(-26, -4), this.rnd(0.25, 0.55), t >= 3 ? 2 : 1, i % 3, 2) }
    if (t === 4) for (let i = 0; i < 10; i++) this.emit(this.cx() + this.rnd(-20, 20), this.dyFeet - 2, this.rnd(-12, 12), this.rnd(-110, -40), this.rnd(0.35, 0.7), 2, 3, 2)
  }
  private fxSpawn() {
    const t = this.tier(), x = this.cx(), y = this.dyFeet
    this.fxDust(6)
    if (t >= 2) for (let i = 0; i < (t === 2 ? 14 : t === 3 ? 28 : 44); i++) { const a = Math.random() * Math.PI * 2, r = this.rnd(16, 34); this.emit(x + Math.cos(a) * r, y - 14 + Math.sin(a) * r * 0.8, -Math.cos(a) * r * 2.2, -Math.sin(a) * r * 1.8, 0.45, 2, i % 3, 2) }
    if (t >= 3) { this.beam = t === 4 ? 0.9 : 0.55; this.beamX = x }
  }
  private fxDeath() {
    const x = this.cx(), y = this.cy()
    for (let i = 0; i < 18 + this.tier() * 6; i++) { const a = Math.random() * Math.PI * 2, v = this.rnd(40, 150); this.emit(x, y, Math.cos(a) * v, Math.sin(a) * v - 30, this.rnd(0.4, 0.9), Math.random() < 0.5 ? 2 : 3, i % 5 === 4 ? 3 : i % 3, 2, 260) }
  }
  /** Efek terus-menerus: debu lari, aura per rarity, jejak (trail). */
  private fxContinuous(dt: number, running: boolean) {
    const t = this.tier(), k = this.fx.kind, cx = this.cx(), fy = this.dyFeet
    if (running && this.onGround) {
      this.dustT += dt
      if (this.dustT > 0.085) { this.dustT = 0; this.emit(this.dx + this.rnd(2, 10), fy - 1, -this.speed * this.rnd(0.35, 0.7), this.rnd(-34, -8), this.rnd(0.25, 0.45), Math.random() < 0.35 ? 2 : 1, Math.random() < 0.5 ? 4 : 5) }
    }
    if (t === 0) return
    // aura / motes: kecil di common, makin rapat tiap rarity
    const rate = [0, 4, 15, 26, 34][t]
    this.auraT += dt * rate
    while (this.auraT >= 1) {
      this.auraT -= 1
      const x = this.dx + this.rnd(4, 26), y = fy - this.rnd(4, 26)
      switch (k) {
        case 'leaf': this.emit(x, y, this.rnd(-30, -8), this.rnd(-14, 10), 0.6, 2, 1); break
        case 'sand': this.emit(x, y + 8, this.rnd(-40, -10), this.rnd(-14, -2), 0.5, 1, 0); break
        case 'drop': this.emit(x, y, this.rnd(-12, 8), this.rnd(-40, -10), 0.5, 1, 0); break
        case 'spark': this.emit(x + this.rnd(-3, 3), y, this.rnd(-60, 20), this.rnd(-40, 40), 0.18, 1, Math.random() < 0.5 ? 0 : 3, 2); break
        case 'snow': this.emit(x, y - 6, this.rnd(-20, 5), this.rnd(10, 36), 0.7, Math.random() < 0.4 ? 2 : 1, Math.random() < 0.5 ? 3 : 0, 1); break
        case 'ember': this.emit(x, y + 4, this.rnd(-26, -4), this.rnd(-70, -28), 0.55, Math.random() < 0.4 ? 2 : 1, Math.random() < 0.4 ? 0 : 1, 2); break
        case 'wisp': this.emit(x, y + 4, this.rnd(-22, -4), this.rnd(-44, -12), 0.8, Math.random() < 0.3 ? 3 : 2, Math.random() < 0.5 ? 1 : 0, 1); break
        case 'star': this.emit(x, y, this.rnd(-30, -6), this.rnd(-30, 16), 0.7, 1, i3(Math.random()), 2); break
        case 'gold': this.emit(x, y, this.rnd(-34, -6), this.rnd(-48, -6), 0.6, Math.random() < 0.5 ? 2 : 1, Math.random() < 0.6 ? 1 : 0, 2); break
        case 'jet': this.emit(this.dx + 4, fy - 12 + this.rnd(-4, 4), -this.speed * 0.6 + this.rnd(-30, 0), this.rnd(-10, 10), 0.28, 2, Math.random() < 0.5 ? 0 : 1, 2); break
        case 'dragon': this.emit(x, y + 2, this.rnd(-40, -8), this.rnd(-60, -16), 0.9, Math.random() < 0.5 ? 3 : 2, Math.random() < 0.5 ? 1 : 0, 2); break
        default: this.emit(x, y, this.rnd(-20, -4), this.rnd(-20, 0), 0.5, 1, 0)
      }
    }
    // jejak energi di belakang (legend & mythic)
    if (t >= 3 && running) {
      this.trailT += dt * (t === 4 ? 70 : 42)
      while (this.trailT >= 1) {
        this.trailT -= 1
        this.emit(this.dx + this.rnd(0, 8), fy - this.rnd(6, 22), -this.speed * this.rnd(0.7, 1.1), this.rnd(-12, 12), t === 4 ? 0.55 : 0.4, t === 4 ? 3 : 2, Math.floor(this.rnd(0, 3)), 1)
      }
    }
    // idle mythic: percikan lembut saat menunggu
    if (t === 4 && !running && Math.random() < dt * 14) this.emit(cx + this.rnd(-18, 18), fy - this.rnd(0, 34), this.rnd(-6, 6), this.rnd(-34, -10), 0.9, 2, Math.floor(this.rnd(0, 4)), 2)
  }

  // ---------- rintangan ----------
  private spawn() {
    const t = this.t
    const pool: string[] = ['cactusS', 'cactusS', 'rock', 'rock']
    if (t > 6) pool.push('cactusM', 'cactusM')
    if (t > 12) pool.push('cactusG', 'cactusG')
    if (t > 20 && !this.lastBird) pool.push('bird', 'bird')
    const pick = pool[Math.floor(Math.random() * pool.length)]
    let spr = pick
    let y = 0
    let bird = false
    if (pick === 'bird') {
      bird = true
      spr = 'bird0'
      const high = t > 35 && Math.random() < 0.3
      const [, , , bh] = OB.bird0
      y = this.gy - (high ? 36 : 17) - bh
    }
    const [sx, sy, w, h] = OB[spr]
    void sx; void sy
    if (!bird) y = this.gy - h
    const hit = bird ? { hx: 4, hy: 3, hw: w - 8, hh: h - 6 } : { hx: 2, hy: 2, hw: w - 4, hh: h - 2 }
    this.obsList.push({ x: W + 16, y, w, h, spr, bird, ...hit, passed: false })
    this.lastBird = bird
    // jarak ke rintangan berikutnya: waktu napas cukup untuk lompat + mendarat, makin pendek pelan-pelan
    const lead = 0.84 + Math.random() * 0.62 - Math.min(0.2, t / 400)
    this.gap = this.speed * lead + w + 24 + (bird ? this.speed * 0.3 : 0)
    this.since = 0
  }

  private hitboxes(): Array<[number, number, number, number]> {
    const x = this.dx, f = this.dyFeet
    if (this.crouch && this.onGround) return [[x + 6, f - 13, 22, 12]]
    return [[x + 9, f - 24, 15, 22], [x + 17, f - 26, 11, 12]]
  }

  // ---------- update ----------
  private update(dt: number) {
    this.clock += dt
    if (this.pending) this.decide()
    if (this.state === 'ready') {
      this.readyT += dt
      this.fxContinuous(dt, false)
      this.updateParticles(dt)
      if (this.readyT >= 1.15) {
        this.state = 'run'
        this.o.onState?.('run')
      }
      this.bgx += 8 * dt
      return
    }
    if (this.state === 'dead') {
      this.deadT += dt
      this.vy += GRAV * dt
      this.dyFeet = Math.min(this.gy, this.dyFeet + this.vy * dt)
      this.flash = Math.max(0, this.flash - dt * 3)
      this.shake = Math.max(0, this.shake - dt)
      this.updateParticles(dt)
      if (this.deadT > 0.85 && !this.overSent) {
        this.overSent = true
        this.o.onOver?.(Math.floor(this.score))
      }
      return
    }
    // --- jalan ---
    this.t += dt
    this.speed = Math.min(200, 78 + this.t * 1.55)
    this.score += this.speed * dt * 0.11
    const sc = Math.floor(this.score)
    if (sc !== this.scoreSent && (sc - this.scoreSent >= 3 || sc < 5)) {
      this.scoreSent = sc
      this.o.onScore?.(sc)
    }
    if (sc - this.lastMilestone >= 100) {
      this.lastMilestone = sc - (sc % 100)
      sfx('score')
    }
    this.bgx += this.speed * dt
    this.runPhase += dt * (8 + this.speed * 0.045)
    // fisika dino
    if (!this.onGround) {
      const g = GRAV * (this.crouch ? 2.3 : 1)
      this.vy += g * dt
      this.dyFeet += this.vy * dt
      if (this.dyFeet >= this.gy) {
        this.dyFeet = this.gy
        this.vy = 0
        this.onGround = true
        this.landT = 0.1
        sfx('land')
        this.fxLand()
        this.shake = Math.max(this.shake, this.tier() >= 3 ? 0.12 : 0)
        if (this.jumpBuf > 0) {
          this.jumpBuf = 0
          this.vy = JUMP_V
          this.onGround = false
          this.landT = 0
          sfx('jump')
          this.fxJump()
        }
      }
    }
    if (this.landT > 0) this.landT -= dt
    if (this.jumpBuf > 0) this.jumpBuf -= dt
    // rintangan
    for (const o of this.obsList) o.x -= (this.speed + (o.bird ? 26 : 0)) * dt
    this.obsList = this.obsList.filter((o) => o.x > -50)
    this.since += this.speed * dt
    if (this.since >= this.gap) this.spawn()
    // tabrakan
    const hb = this.hitboxes()
    for (const o of this.obsList) {
      const ox = o.x + o.hx, oy = o.y + o.hy
      for (const [bx, by, bw, bh] of hb) {
        if (bx < ox + o.hw && bx + bw > ox && by < oy + o.hh && by + bh > oy) return this.die()
      }
    }
    this.fxContinuous(dt, true)
    this.updateParticles(dt)
    if (this.beam > 0) this.beam -= dt
  }

  private die() {
    this.state = 'dead'
    this.deadT = 0
    this.vy = -170
    this.onGround = false
    this.flash = 1
    this.shake = 0.35
    sfx('hit')
    this.fxDeath()
    this.o.onState?.('dead')
    this.o.onScore?.(Math.floor(this.score))
  }

  private updateParticles(dt: number) {
    let i = 0
    while (i < this.pn) {
      this.pl[i] -= dt
      if (this.pl[i] <= 0) {
        const j = --this.pn
        this.px[i] = this.px[j]; this.py[i] = this.py[j]; this.pvx[i] = this.pvx[j]; this.pvy[i] = this.pvy[j]; this.pay[i] = this.pay[j]
        this.pl[i] = this.pl[j]; this.pm[i] = this.pm[j]; this.ps[i] = this.ps[j]; this.pc[i] = this.pc[j]; this.pf[i] = this.pf[j]
        continue
      }
      this.pvy[i] += this.pay[i] * dt
      this.px[i] += this.pvx[i] * dt
      this.py[i] += this.pvy[i] * dt
      i++
    }
  }

  // ---------- gambar ----------
  private frameIndex(): number {
    if (this.state === 'dead') return F.hit
    if (this.pending && this.onGround) return F.prep
    if (this.state === 'ready') return this.clock % 3.2 > 3.05 ? F.blink : Math.floor(this.clock * 2.6) % 2 ? F.idle1 : F.idle0
    if (!this.onGround) return this.crouch ? F.fall : this.vy < -170 ? F.launch : this.vy > 130 ? F.fall : F.air
    if (this.landT > 0.02) return F.land
    if (this.crouch) return F.crouch + (Math.floor(this.runPhase) % 2)
    return F.run + (Math.floor(this.runPhase) % 4)
  }
  private drawDino(ctx: CanvasRenderingContext2D, ox = 0, alpha = 1) {
    if (!this.sheet) return
    const fi = this.frameIndex()
    ctx.globalAlpha = alpha
    ctx.drawImage(this.sheet, (fi % 4) * 32, Math.floor(fi / 4) * 32, 32, 32, Math.round(this.dx + ox), Math.round(this.dyFeet) - 31, 32, 32)
    ctx.globalAlpha = 1
  }

  private draw() {
    const ctx = this.ctx
    if (!this.sky || !this.sheet || !this.obs) return
    const H = this.H
    ctx.imageSmoothingEnabled = false
    ctx.save()
    if (this.shake > 0) ctx.translate(Math.round((Math.random() - 0.5) * 6 * Math.min(1, this.shake * 3)), Math.round((Math.random() - 0.5) * 4 * Math.min(1, this.shake * 3)))
    ctx.drawImage(this.sky, 0, 0)
    // bintang
    for (const s of this.stars) {
      const a = 0.35 + 0.65 * Math.abs(Math.sin(this.clock * 1.4 + s.p))
      ctx.globalAlpha = a
      ctx.fillStyle = '#fff'
      ctx.fillRect(s.x, s.y, s.p % 3 < 1 ? 2 : 1, s.p % 3 < 1 ? 2 : 1)
    }
    ctx.globalAlpha = 1
    // gunung
    const farOff = -Math.floor(this.bgx * 0.12) % 256, nearOff = -Math.floor(this.bgx * 0.3) % 256
    for (let x = farOff - 256; x < W; x += 256) ctx.drawImage(this.far!, x, this.gy - 46)
    for (let x = nearOff - 256; x < W; x += 256) ctx.drawImage(this.near!, x, this.gy - 28)
    // tanah
    const gOff = -Math.floor(this.bgx) % 64
    for (let x = gOff - 64; x < W; x += 64) ctx.drawImage(this.ground!, x, this.gy)
    // kelopak sakura ambient (murah: dihitung dari waktu)
    ctx.fillStyle = '#ff9fc0'
    for (let i = 0; i < 6; i++) {
      const px = (W - ((this.clock * (14 + i * 3) + i * 47) % (W + 20))) | 0
      const py = ((this.clock * (10 + i * 2) + i * 61) % (this.gy - 10)) | 0
      ctx.fillRect(px, py, 2, 1)
      ctx.fillRect(px + 1, py + 1, 1, 1)
    }
    // rintangan
    for (const o of this.obsList) {
      const spr = o.bird ? (Math.floor(this.clock * 8) % 2 ? 'bird1' : 'bird0') : o.spr
      const [sx, sy, w, h] = OB[spr]
      ctx.drawImage(this.obs, sx, sy, w, h, Math.round(o.x), Math.round(o.y), w, h)
    }
    // partikel belakang (additive)
    this.drawParticles(ctx, 1)
    // pilar/ kolom cahaya
    if (this.beam > 0) {
      const a = Math.min(1, this.beam * 3)
      const bw = this.tier() === 4 ? 14 : 10
      ctx.globalCompositeOperation = 'lighter'
      ctx.globalAlpha = a * 0.45
      ctx.fillStyle = this.pal[1]
      ctx.fillRect(Math.round(this.beamX - bw / 2), 0, bw, this.gy)
      ctx.globalAlpha = a * 0.7
      ctx.fillStyle = this.pal[0]
      ctx.fillRect(Math.round(this.beamX - 2), 0, 4, this.gy)
      ctx.globalAlpha = 1
      ctx.globalCompositeOperation = 'source-over'
    }
    // bayangan
    ctx.globalAlpha = 0.35
    ctx.fillStyle = '#000'
    ctx.fillRect(Math.round(this.dx + 6), this.gy, 20, 1)
    ctx.globalAlpha = 1
    // bayangan gerak (legend / mythic)
    const t = this.tier()
    if (t >= 3 && this.state === 'run') {
      const n = t === 4 ? 3 : 2
      for (let i = n; i >= 1; i--) {
        this.drawDino(ctx, -i * 7, (t === 4 ? 0.3 : 0.2) / i)
      }
      ctx.globalAlpha = 1
    }
    // dino (muncul bertahap saat spawn)
    const spawnA = this.state === 'ready' ? Math.min(1, this.readyT / 0.4) : 1
    this.drawDino(ctx, 0, spawnA)
    // bintang mengorbit (mythic)
    if (t === 4 && this.state !== 'dead') {
      ctx.globalCompositeOperation = 'lighter'
      for (let i = 0; i < 3; i++) {
        const a = this.clock * 2.2 + (i * Math.PI * 2) / 3
        const sx = Math.round(this.cx() + Math.cos(a) * 21), sy = Math.round(this.dyFeet - 14 + Math.sin(a) * 15)
        ctx.fillStyle = this.pal[i === 0 ? 3 : 1]
        ctx.fillRect(sx - 1, sy, 3, 1)
        ctx.fillRect(sx, sy - 1, 1, 3)
      }
      ctx.globalCompositeOperation = 'source-over'
    }
    // partikel depan
    this.drawParticles(ctx, 0)
    this.drawParticles(ctx, 2)
    ctx.restore()
    if (this.flash > 0) {
      ctx.globalAlpha = Math.min(1, this.flash) * 0.7
      ctx.fillStyle = '#fff'
      ctx.fillRect(0, 0, W, H)
      ctx.globalAlpha = 1
    }
  }

  private drawParticles(ctx: CanvasRenderingContext2D, flag: 0 | 1 | 2) {
    const add = flag !== 0
    if (add) ctx.globalCompositeOperation = 'lighter'
    for (let i = 0; i < this.pn; i++) {
      if (this.pf[i] !== flag) continue
      const a = Math.min(1, (this.pl[i] / this.pm[i]) * 1.6)
      ctx.globalAlpha = add ? a * 0.9 : a
      ctx.fillStyle = this.pal[this.pc[i]]
      ctx.fillRect(Math.round(this.px[i]), Math.round(this.py[i]), this.ps[i], this.ps[i])
    }
    ctx.globalAlpha = 1
    if (add) ctx.globalCompositeOperation = 'source-over'
  }
}

const i3 = (r: number) => (r < 0.34 ? 0 : r < 0.67 ? 1 : 2)
