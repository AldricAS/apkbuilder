import type { ReactNode } from 'react'

export function Btn({ children, onClick, tone = 'purple', disabled = false, small = false }: { children: ReactNode; onClick: () => void; tone?: 'green' | 'purple' | 'dark' | 'gold' | 'pink'; disabled?: boolean; small?: boolean }) {
  const c = { green: 'bg-[#2fbf5d] text-[#06280f]', purple: 'bg-[#7C3AED] text-white', dark: 'bg-[#2a2550] text-white', gold: 'bg-[#f2c23a] text-[#3a2600]', pink: 'bg-[#ff6fae] text-[#3a0a22]' }[tone]
  return (
    <button type="button" disabled={disabled} onClick={onClick} className={`px-btn w-full rounded-md font-mono ${small ? 'h-10 text-[12px]' : 'h-12 text-[13.5px]'} ${c}`}>
      {children}
    </button>
  )
}
