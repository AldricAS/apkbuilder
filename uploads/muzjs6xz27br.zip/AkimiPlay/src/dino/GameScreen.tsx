import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import { Btn } from './ui'
import { useBackHandler } from '../native/native'
import { DINO, finishRun, startRun, DinoError, type DinoState, type RunResult } from '../services/dinoService'
import { DinoEngine } from './engine'
import { isMuted, setMuted, sfx } from './sfx'
import { Icon } from '../components/Icon'
import { skinKey } from './SpriteView'

const fmt = (n: number) => n.toLocaleString('id-ID')

/** Layar bermain. Engine dibuat sekali per permainan, loop dihentikan saat pause / tab disembunyikan / layar ditutup. */
export default function GameScreen({
  uid,
  state,
  gamesUsed,
  onExit,
  onCollection,
}: {
  uid: string
  state: DinoState
  gamesUsed: number
  onExit: () => void
  onCollection: () => void
}) {
  const wrap = useRef<HTMLDivElement>(null)
  const cv = useRef<HTMLCanvasElement>(null)
  const scoreEl = useRef<HTMLSpanElement>(null)
  const engine = useRef<DinoEngine | null>(null)
  const [phase, setPhase] = useState<'loading' | 'play' | 'over' | 'exhausted' | 'error'>('loading')
  const [paused, setPaused] = useState(false)
  const [result, setResult] = useState<RunResult | null>(null)
  const [saving, setSaving] = useState(false)
  const [round, setRound] = useState(0)
  const [used, setUsed] = useState(gamesUsed)
  const [muted, setMute] = useState(isMuted())
  const [err, setErr] = useState('')
  const best = useRef(state.best)
  const sel = state.selected
  const skin = skinKey(sel)
  const phaseRef = useRef(phase)
  phaseRef.current = phase

  const boot = useCallback(async () => {
    setPhase('loading')
    setPaused(false)
    setResult(null)
    setErr('')
    engine.current?.destroy()
    engine.current = null
    try {
      const ok = await startRun(uid, sel)
      if (!ok) return setPhase('exhausted')
      setUsed((u) => Math.min(DINO.DAILY_MAX, u + 1))
      const el = cv.current
      const box = wrap.current
      if (!el || !box) return
      const eng = new DinoEngine(el, {
        skin,
        onScore: (s) => {
          if (scoreEl.current) scoreEl.current.textContent = fmt(s)
        },
        onOver: (score) => {
          setSaving(true)
          setPhase('over')
          void finishRun(uid, score)
            .then((r) => {
              if (r.best > best.current) best.current = r.best
              setResult(r)
            })
            .catch(() => setResult({ score, best: best.current, reward: 0, newBest: false }))
            .finally(() => setSaving(false))
        },
      })
      engine.current = eng
      const r = box.getBoundingClientRect()
      await eng.init(r.width, r.height)
      if (engine.current !== eng) return eng.destroy()
      if (scoreEl.current) scoreEl.current.textContent = '0'
      setPhase('play')
      eng.start()
    } catch (e) {
      setErr(e instanceof DinoError ? e.message : 'Game gagal dimuat. Cek sinyal lalu coba lagi')
      setPhase('error')
    }
  }, [uid, sel, skin])

  useEffect(() => {
    void boot()
    return () => {
      engine.current?.destroy()
      engine.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round])

  // aplikasi masuk background / layar mati: pause otomatis
  useEffect(() => {
    const hide = () => {
      if (document.hidden && phaseRef.current === 'play') {
        engine.current?.pause()
        setPaused(true)
      }
    }
    document.addEventListener('visibilitychange', hide)
    return () => document.removeEventListener('visibilitychange', hide)
  }, [])

  const pause = () => {
    if (phase !== 'play' || paused) return
    engine.current?.pause()
    setPaused(true)
    sfx('click')
  }
  const resume = () => {
    setPaused(false)
    engine.current?.resume()
  }
  useBackHandler(
    () => {
      if (phase === 'play' && !paused) pause()
      else onExit()
      return true
    },
    60,
    true,
  )

  const again = () => {
    sfx('click')
    setRound((r) => r + 1)
  }

  return (
    <div className="absolute inset-0 flex flex-col bg-[#070a1e]">
      <div ref={wrap} className="relative min-h-0 flex-1 overflow-hidden">
        <canvas ref={cv} className="px absolute inset-0 h-full w-full touch-none select-none" style={{ touchAction: 'none' }} />

        {/* HUD minimal */}
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between px-3 pt-safe">
          <div className="mt-3 rounded-md bg-black/45 px-2.5 py-1.5 font-mono text-white">
            <p className="text-[9px] font-bold tracking-[.18em] text-white/55">SCORE</p>
            <span ref={scoreEl} className="text-[22px] font-extrabold leading-none tabular-nums">0</span>
          </div>
          <div className="mt-3 flex flex-col items-end gap-1 rounded-md bg-black/45 px-2.5 py-1.5 font-mono text-[10px] font-bold tracking-wider text-white/80">
            <span>BEST {fmt(Math.max(best.current, result?.best ?? 0))}</span>
            <span className="text-[#ffd84a]">GAME {Math.min(used, DINO.DAILY_MAX)}/{DINO.DAILY_MAX}</span>
          </div>
        </div>
        <div className="absolute left-3 top-[calc(env(safe-area-inset-top,0px)+76px)] flex gap-2">
          <button type="button" aria-label="Jeda" onClick={pause} className="px-btn flex h-10 w-10 items-center justify-center rounded-md bg-[#3a2b86] text-white">
            <Icon name="pause" size={18} />
          </button>
          <button
            type="button"
            aria-label={muted ? 'Nyalakan suara' : 'Matikan suara'}
            onClick={() => {
              setMuted(!muted)
              setMute(!muted)
            }}
            className="px-btn flex h-10 w-10 items-center justify-center rounded-md bg-[#3a2b86] text-white"
          >
            <Icon name={muted ? 'mute' : 'volume'} size={18} />
          </button>
        </div>

        {phase === 'play' && !paused ? (
          <p className="pointer-events-none absolute inset-x-0 bottom-5 text-center font-mono text-[10.5px] font-bold tracking-wider text-white/35">KETUK / GESER ATAS = LOMPAT · GESER BAWAH = JONGKOK</p>
        ) : null}

        {phase === 'loading' ? (
          <div className="absolute inset-0 flex items-center justify-center bg-[#070a1e] font-mono text-[13px] font-bold tracking-widest text-white/70">MEMUAT…</div>
        ) : null}

        {paused ? (
          <Overlay>
            <h2 className="font-mono text-[26px] font-extrabold tracking-widest text-white">PAUSE</h2>
            <Btn tone="green" onClick={resume}>Lanjut</Btn>
            <Btn tone="purple" onClick={again}>Ulang (game baru)</Btn>
            <Btn tone="dark" onClick={onExit}>Kembali ke menu</Btn>
            <p className="font-mono text-[10px] text-white/40">Ulang memakai 1 jatah game hari ini</p>
          </Overlay>
        ) : null}

        {phase === 'over' ? (
          <Overlay shake>
            <h2 className="font-mono text-[30px] font-extrabold tracking-widest text-[#ff5a7a]">GAME OVER</h2>
            <div className="grid w-full grid-cols-2 gap-3 text-center font-mono">
              <div className="px-panel rounded-sm p-3"><p className="text-[10px] font-bold tracking-widest text-white/55">SCORE</p><p className="text-[24px] font-extrabold text-white tabular-nums">{fmt(result?.score ?? 0)}</p></div>
              <div className="px-panel rounded-sm p-3"><p className="text-[10px] font-bold tracking-widest text-white/55">BEST</p><p className="text-[24px] font-extrabold text-[#ffd84a] tabular-nums">{fmt(Math.max(result?.best ?? 0, best.current))}</p></div>
            </div>
            {saving ? <p className="font-mono text-[11px] text-white/50">Menyimpan…</p> : null}
            {result?.newBest ? <p className="px-pop font-mono text-[13px] font-extrabold tracking-widest text-[#ffd84a]">★ REKOR BARU ★</p> : null}
            {result && result.reward > 0 ? (
              <p className="px-pop rounded-sm bg-[#1a4d2a] px-3 py-1.5 font-mono text-[13px] font-extrabold text-[#6cff9a]">+{result.reward} AKIMISHARD</p>
            ) : !saving && result ? (
              <p className="font-mono text-[11px] text-white/45">1 skor = 1 AkimiShard</p>
            ) : null}
            {used >= DINO.DAILY_MAX ? (
              <p className="rounded-sm bg-black/40 px-3 py-2 text-center font-mono text-[11.5px] text-[#ffb36b]">Kesempatan bermain hari ini sudah habis.</p>
            ) : (
              <Btn tone="green" disabled={saving} onClick={again}>Main lagi</Btn>
            )}
            <Btn tone="purple" onClick={onCollection}>Dino Collection</Btn>
            <Btn tone="dark" onClick={onExit}>Kembali</Btn>
          </Overlay>
        ) : null}

        {phase === 'exhausted' ? (
          <Overlay>
            <h2 className="font-mono text-[22px] font-extrabold tracking-widest text-[#ffb36b]">GAME HARI INI 10/10</h2>
            <p className="text-center font-mono text-[12.5px] text-white/75">Kesempatan bermain hari ini sudah habis.<br />Reset otomatis besok (WIB).</p>
            <Btn tone="purple" onClick={onCollection}>Dino Collection</Btn>
            <Btn tone="dark" onClick={onExit}>Kembali</Btn>
          </Overlay>
        ) : null}

        {phase === 'error' ? (
          <Overlay>
            <h2 className="font-mono text-[20px] font-extrabold tracking-widest text-[#ff5a7a]">OOPS</h2>
            <p className="text-center font-mono text-[12px] text-white/75">{err}</p>
            <Btn tone="green" onClick={again}>Coba lagi</Btn>
            <Btn tone="dark" onClick={onExit}>Kembali</Btn>
          </Overlay>
        ) : null}
      </div>
    </div>
  )
}

function Overlay({ children, shake = false }: { children: ReactNode; shake?: boolean }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/65 px-6">
      <div className={`flex w-full max-w-[300px] flex-col items-center gap-3 ${shake ? 'px-shake' : ''}`}>{children}</div>
    </div>
  )
}
