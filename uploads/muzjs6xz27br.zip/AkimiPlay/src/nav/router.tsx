import { createContext, useCallback, useContext, useMemo, useReducer, useRef, type ReactNode } from 'react'
import type { AnimeLite } from '../types'
import { toast } from '../components/Feedback'

export type Tab = 'home' | 'ongoing' | 'favorites' | 'history' | 'account'

export type RouteBody =
  | { name: 'detail'; id: string; hint?: AnimeLite }
  | { name: 'search' }
  | { name: 'chat' }
  | { name: 'dm'; uid: string }
  | { name: 'profile'; uid: string }
  | { name: 'leaderboard' }
  | { name: 'settings' }
  | { name: 'connections' }
  | { name: 'findfriend' }
  | { name: 'akimigames' }
  | { name: 'nobar' }
  | { name: 'dino' }
  | { name: 'clans' }
  | { name: 'clan'; id: string }
  | { name: 'clanColors'; id: string }
  | { name: 'premium' }
  | { name: 'downloads'; animeId?: string }
  | { name: 'genre'; id: string; title: string }

export type Route = RouteBody & { key: number }

/** nobar = uid owner room kalau player ini sedang dipakai nonton bareng. */
export type PlayerState = { anime: AnimeLite; episodeId?: string; key: number; minimized: boolean; nobar?: string }

type State = { tab: Tab; stack: Route[]; player: PlayerState | null }
type Action =
  | { type: 'tab'; tab: Tab }
  | { type: 'push'; route: Route }
  | { type: 'pop' }
  | { type: 'play'; player: PlayerState }
  | { type: 'expand' }
  | { type: 'minimize' }
  | { type: 'closePlayer' }
  | { type: 'swapNobar'; anime: AnimeLite; episodeId?: string }

function reducer(s: State, a: Action): State {
  switch (a.type) {
    case 'tab':
      return { ...s, tab: a.tab, stack: [] }
    case 'push':
      return { ...s, stack: [...s.stack, a.route] }
    case 'pop':
      return s.stack.length ? { ...s, stack: s.stack.slice(0, -1) } : s
    case 'play':
      return { ...s, player: a.player }
    case 'expand':
      return s.player ? { ...s, player: { ...s.player, minimized: false } } : s
    case 'minimize':
      return s.player ? { ...s, player: { ...s.player, minimized: true } } : s
    case 'closePlayer':
      return { ...s, player: null }
    case 'swapNobar':
      // ganti anime di dalam nobar TANPA memuat ulang player (key tetap) supaya room tidak ikut tertutup
      return s.player?.nobar ? { ...s, player: { ...s.player, anime: a.anime, episodeId: a.episodeId } } : s
  }
}

type Nav = State & {
  setTab: (t: Tab) => void
  push: (r: RouteBody) => void
  pop: () => void
  openAnime: (a: AnimeLite) => void
  openProfile: (uid: string) => void
  play: (a: AnimeLite, episodeId?: string) => void
  playNobar: (a: AnimeLite, episodeId: string | undefined, ownerUid: string) => void
  swapNobar: (a: AnimeLite, episodeId?: string) => void
  minimizePlayer: () => void
  expandPlayer: () => void
  closePlayer: () => void
}

const Ctx = createContext<Nav | null>(null)

export function NavProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, { tab: 'home', stack: [], player: null })
  const keyRef = useRef(1)

  const setTab = useCallback((tab: Tab) => dispatch({ type: 'tab', tab }), [])
  const push = useCallback((r: RouteBody) => dispatch({ type: 'push', route: { ...r, key: keyRef.current++ } }), [])
  const pop = useCallback(() => dispatch({ type: 'pop' }), [])
  const openAnime = useCallback((a: AnimeLite) => push({ name: 'detail', id: a.id, hint: a }), [push])
  const stateRef = useRef(state)
  stateRef.current = state
  const openProfile = useCallback(
    (uid: string) => {
      const s = stateRef.current
      const top = s.stack[s.stack.length - 1]
      if (top?.name === 'profile' && top.uid === uid) return
      // player layar penuh menutupi halaman lain: perkecil dulu agar profile terlihat
      if (s.player && !s.player.minimized) dispatch({ type: 'minimize' })
      push({ name: 'profile', uid })
    },
    [push],
  )
  const play = useCallback((a: AnimeLite, episodeId?: string) => {
    const cur = stateRef.current.player
    // Sedang di dalam nobar: jangan diam-diam menutup room (untuk owner itu menghentikan nobar semua orang).
    if (cur?.nobar) {
      dispatch({ type: 'expand' })
      toast('Kamu sedang di nobar. Keluar dari nobar dulu untuk menonton anime lain')
      return
    }
    // Anime & episode yang sama sudah diputar (mis. di mini player): cukup buka penuh.
    if (cur && !cur.nobar && cur.anime.id === a.id && (!episodeId || cur.episodeId === episodeId)) {
      dispatch({ type: 'expand' })
      return
    }
    dispatch({ type: 'play', player: { anime: a, episodeId, key: keyRef.current++, minimized: false } })
  }, [])
  const playNobar = useCallback((a: AnimeLite, episodeId: string | undefined, ownerUid: string) => {
    const cur = stateRef.current.player
    // sudah ada di room yang sama: cukup buka penuh
    if (cur?.nobar === ownerUid) {
      dispatch({ type: 'expand' })
      return
    }
    dispatch({ type: 'play', player: { anime: a, episodeId, key: keyRef.current++, minimized: false, nobar: ownerUid } })
  }, [])
  const swapNobar = useCallback((a: AnimeLite, episodeId?: string) => dispatch({ type: 'swapNobar', anime: a, episodeId }), [])
  const minimizePlayer = useCallback(() => dispatch({ type: 'minimize' }), [])
  const expandPlayer = useCallback(() => dispatch({ type: 'expand' }), [])
  const closePlayer = useCallback(() => dispatch({ type: 'closePlayer' }), [])

  const value = useMemo<Nav>(
    () => ({ ...state, setTab, push, pop, openAnime, openProfile, play, playNobar, swapNobar, minimizePlayer, expandPlayer, closePlayer }),
    [state, setTab, push, pop, openAnime, openProfile, play, playNobar, swapNobar, minimizePlayer, expandPlayer, closePlayer],
  )
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useNav(): Nav {
  const v = useContext(Ctx)
  if (!v) throw new Error('useNav harus dipakai di dalam NavProvider')
  return v
}
