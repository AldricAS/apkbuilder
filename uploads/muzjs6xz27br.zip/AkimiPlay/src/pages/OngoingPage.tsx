import { useEffect, useMemo, useRef, useState } from 'react'
import { DAY_LABELS, DAY_LIST, animeApi, todayKey, type Day } from '../services/animeApi'
import { useNav } from '../nav/router'
import type { Anime } from '../types'
import { episodeFull, fmtAirTime, fmtCount, statusLabel } from '../lib/format'
import { ErrorState } from '../components/States'
import { Icon } from '../components/Icon'
import { Poster } from '../components/Poster'

type DayData = Partial<Record<Day, Anime[]>>

function sortByTime(list: Anime[]): Anime[] {
  return [...list].sort((a, b) => fmtAirTime(a.airTime).localeCompare(fmtAirTime(b.airTime)))
}

function DayHeader({ day, count }: { day: Day; count: number }) {
  return (
    <div className="flex items-center justify-between rounded-2xl bg-raise px-4 py-2.5 ring-1 ring-line">
      <span className="text-[17px] font-bold text-white">{DAY_LABELS[day]}</span>
      <span className="rounded-full bg-accent/15 px-3 py-1 text-[12px] font-semibold text-accent">{count} Anime</span>
    </div>
  )
}

function ScheduleItem({ a, last, onOpen }: { a: Anime; last: boolean; onOpen: (a: Anime) => void }) {
  const views = fmtCount(a.views)
  return (
    <li className="flex gap-3">
      <div className="flex w-[50px] shrink-0 flex-col items-center pt-1">
        <span className="text-[13px] font-bold tabular-nums text-accent">{fmtAirTime(a.airTime)}</span>
        <span className="mt-2 h-2.5 w-2.5 rounded-full bg-accent" />
        {!last ? <span className="mt-1.5 w-[3px] flex-1 rounded-full bg-accent/20" /> : null}
      </div>
      <button
        type="button"
        onClick={() => onOpen(a)}
        className="mb-4 flex min-w-0 flex-1 gap-3 rounded-2xl bg-raise/80 p-2.5 text-left ring-1 ring-line active:opacity-80"
      >
        <Poster src={a.poster} alt={a.title} className="h-[104px] w-[74px] shrink-0 rounded-xl" />
        <div className="flex min-w-0 flex-1 flex-col justify-center">
          <p className="line-clamp-2 text-[15px] font-bold leading-tight text-white">{a.title}</p>
          {episodeFull(a.latestEpisode) ? (
            <p className="mt-1 text-[13px] font-medium text-white/80">{episodeFull(a.latestEpisode)}</p>
          ) : null}
          <p className="text-[12px] text-muted">{statusLabel(a.status) ?? 'Menunggu Update'}</p>
          {views || a.score ? (
            <p className="mt-1.5 flex items-center gap-1.5 text-[12.5px] text-white/70">
              {views ? <span>{views} dilihat</span> : null}
              {views && a.score ? <span className="text-white/30">•</span> : null}
              {a.score ? (
                <span className="flex items-center gap-0.5 font-semibold text-white">
                  <Icon name="star" size={12} className="text-accent" />
                  {a.score.toFixed(1)}
                </span>
              ) : null}
            </p>
          ) : null}
        </div>
      </button>
    </li>
  )
}

export function OngoingPage() {
  const nav = useNav()
  const [data, setData] = useState<DayData>({})
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState(0)
  const [tick, setTick] = useState(0)
  const [q, setQ] = useState('')
  const [searching, setSearching] = useState(false)
  const [current, setCurrent] = useState<Day>('SENIN')

  const scroller = useRef<HTMLDivElement>(null)
  const bar = useRef<HTMLDivElement>(null)
  const sections = useRef<Partial<Record<Day, HTMLElement | null>>>({})
  const didInitialScroll = useRef(false)

  useEffect(() => {
    let alive = true
    setLoading(true)
    setFailed(0)
    let pending = DAY_LIST.length
    let bad = 0
    DAY_LIST.forEach((d) => {
      animeApi
        .schedule(d)
        .then((list) => alive && setData((p) => ({ ...p, [d]: sortByTime(list) })))
        .catch(() => {
          bad++
        })
        .finally(() => {
          pending--
          if (alive && pending === 0) {
            setFailed(bad)
            setLoading(false)
          }
        })
    })
    return () => {
      alive = false
    }
  }, [tick])

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase()
    const out: DayData = {}
    for (const d of DAY_LIST) {
      const l = data[d]
      if (!l) continue
      out[d] = needle ? l.filter((a) => a.title.toLowerCase().includes(needle)) : l
    }
    return out
  }, [data, q])

  const barH = () => bar.current?.offsetHeight ?? 56
  const goTo = (d: Day, smooth = true) => {
    const el = sections.current[d]
    if (el && scroller.current) scroller.current.scrollTo({ top: el.offsetTop - barH() - 4, behavior: smooth ? 'smooth' : 'auto' })
  }

  // buka langsung di hari ini setelah data pertama kali selesai dimuat
  useEffect(() => {
    if (loading || didInitialScroll.current) return
    didInitialScroll.current = true
    requestAnimationFrame(() => goTo(todayKey(), false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading])

  const onScroll = () => {
    const sc = scroller.current
    if (!sc) return
    const y = sc.scrollTop + barH() + 12
    let found: Day = DAY_LIST[0]
    for (const d of DAY_LIST) {
      const el = sections.current[d]
      if (el && el.offsetTop <= y) found = d
    }
    if (found !== current) setCurrent(found)
  }

  const nextDay = DAY_LIST[(DAY_LIST.indexOf(current) + 1) % DAY_LIST.length]
  const total = DAY_LIST.reduce((n, d) => n + (data[d]?.length ?? 0), 0)
  const allFailed = !loading && failed === DAY_LIST.length

  return (
    <div className="absolute inset-0 flex flex-col">
      <header className="pt-safe shrink-0 border-b border-line bg-ink">
        <div className="relative flex h-14 items-center justify-center px-4">
          <h1 className="text-[20px] font-bold tracking-tight text-white">Jadwal Tayang</h1>
          <button
            type="button"
            aria-label="Cari di jadwal"
            onClick={() => {
              setSearching((s) => !s)
              if (searching) setQ('')
            }}
            className="absolute right-3 flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"
          >
            <Icon name={searching ? 'x' : 'search'} size={20} />
          </button>
        </div>
        {searching ? (
          <div className="px-4 pb-3">
            <label className="flex h-10 items-center gap-2.5 rounded-2xl bg-raise px-3.5">
              <Icon name="search" size={17} className="text-muted" />
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Cari judul di jadwal"
                className="min-w-0 flex-1 bg-transparent text-[14px] text-white placeholder:text-muted focus:outline-none"
              />
            </label>
          </div>
        ) : null}
      </header>

      <div ref={scroller} onScroll={onScroll} className="relative flex-1 overflow-y-auto pb-40">
        {allFailed ? (
          <ErrorState message="Jadwal belum bisa dimuat. Periksa koneksi internet." onRetry={() => setTick((t) => t + 1)} />
        ) : (
          <>
            <div ref={bar} className="sticky top-0 z-10 bg-ink px-4 pb-2 pt-3">
              <DayHeader day={current} count={filtered[current]?.length ?? 0} />
            </div>

            {loading && total === 0 ? (
              <div className="space-y-4 px-4 pt-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="shimmer h-[126px] rounded-2xl" />
                ))}
              </div>
            ) : null}

            {DAY_LIST.map((d, di) => {
              const list = filtered[d]
              if (!list) return null
              if (q.trim() && list.length === 0) return null
              return (
                <section
                  key={d}
                  ref={(el) => {
                    sections.current[d] = el
                  }}
                  className="px-4"
                >
                  {di > 0 ? (
                    <div className="mb-3 mt-3">
                      <DayHeader day={d} count={list.length} />
                    </div>
                  ) : null}
                  {list.length ? (
                    <ul className="pt-1">
                      {list.map((a, i) => (
                        <ScheduleItem key={a.id} a={a} last={i === list.length - 1} onOpen={nav.openAnime} />
                      ))}
                    </ul>
                  ) : (
                    <p className="py-6 text-center text-[13px] text-muted">Tidak ada jadwal di hari ini.</p>
                  )}
                </section>
              )
            })}

            {!loading && failed > 0 && !allFailed ? (
              <button
                type="button"
                onClick={() => setTick((t) => t + 1)}
                className="mx-auto mt-2 block rounded-full bg-raise px-4 py-2 text-[12.5px] font-semibold text-accent"
              >
                Beberapa hari gagal dimuat. Coba lagi
              </button>
            ) : null}
          </>
        )}
      </div>

      {!allFailed && total > 0 && !q.trim() ? (
        <button
          type="button"
          onClick={() => goTo(nextDay)}
          className={`glass fixed z-20 flex items-center gap-2 rounded-full py-3 pl-5 pr-4 text-[14px] font-bold text-white shadow-lg active:scale-95 ${
            nav.player?.minimized ? 'left-4' : 'right-4'
          }`}
          style={{ bottom: 'calc(env(safe-area-inset-bottom, 0px) + 84px)' }}
        >
          {DAY_LABELS[nextDay]}
          <Icon name="chevron" size={18} />
        </button>
      ) : null}
    </div>
  )
}
