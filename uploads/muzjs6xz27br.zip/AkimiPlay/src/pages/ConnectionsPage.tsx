import { useMemo, useState, type ReactNode } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { acceptRequest, cancelRequest, rejectRequest, useOnlineMap, useUidList } from '../services/friendService'
import { useDmPreview } from '../services/dmService'
import { useLiveUsers } from '../services/liveProfiles'
import type { UserProfile } from '../services/userService'
import { errMsg } from '../lib/format'
import { Avatar, ClanPill, LevelPill, RoleCheck } from '../components/UserBadges'
import { Icon, type IconName } from '../components/Icon'
import { PageHeader } from '../components/PageHeader'
import { Sheet, toast } from '../components/Feedback'
import { EmptyState, ErrorState, Spinner } from '../components/States'

type TabKey = 'friends' | 'requests'

const nameOf = (p: UserProfile) => p.username?.trim() || p.displayName

function HeaderIcon({ icon, label, onClick, active }: { icon: IconName; label: string; onClick: () => void; active?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className={`flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10 ${active ? 'bg-white/10 text-accent' : 'text-white'}`}
    >
      <Icon name={icon} size={22} />
    </button>
  )
}

function CardShell({ children }: { children: ReactNode }) {
  return <li className="rounded-3xl border border-white/[0.07] bg-raise/70 p-3.5">{children}</li>
}

/** Avatar + nama + centang + level + klan + #ID. Ditekan untuk membuka profil. */
function Person({ uid, p, online, note }: { uid: string; p: UserProfile | null | undefined; online?: boolean; note?: string }) {
  const nav = useNav()
  if (p === undefined)
    return (
      <div className="flex items-center gap-3.5">
        <div className="shimmer h-[52px] w-[52px] rounded-full" />
        <div className="flex-1 space-y-2">
          <div className="shimmer h-4 w-1/2 rounded" />
          <div className="shimmer h-3.5 w-3/4 rounded" />
        </div>
      </div>
    )
  if (p === null)
    return (
      <div className="flex items-center gap-3.5">
        <Avatar name="?" size={52} />
        <p className="text-[14px] font-semibold text-muted">Pengguna tidak tersedia</p>
      </div>
    )
  const name = nameOf(p)
  return (
    <button type="button" onClick={() => nav.openProfile(uid)} className="flex w-full items-center gap-3.5 text-left active:opacity-80">
      <span className="relative shrink-0">
        <Avatar url={p.photoURL} name={name} size={52} />
        {online ? (
          <span role="img" aria-label="Online" className="absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full border-2 border-[#181821] bg-[#3DDC84]" />
        ) : null}
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1.5">
          <span className="min-w-0 truncate text-[16px] font-bold text-white">{name}</span>
          <RoleCheck role={p.role} verified={p.verified} size={16} />
        </span>
        <span className="mt-1.5 flex flex-wrap items-center gap-1.5">
          <LevelPill level={p.level} />
          <ClanPill tag={p.clanTag} />
          <span className="text-[12px] font-semibold text-muted">#{p.userId}</span>
        </span>
        {note ? <span className="mt-1.5 block text-[12.5px] text-muted">{note}</span> : null}
      </span>
    </button>
  )
}

/** Tombol chat pribadi + pratinjau pesan terakhir + lencana belum dibaca. */
function ChatRow({ uid }: { uid: string }) {
  const nav = useNav()
  const me = useProfile()
  const pv = useDmPreview(me.uid, uid)
  const last = pv?.last
  const preview = last ? `${last.uid === me.uid ? 'Kamu: ' : ''}${last.text}` : 'Mulai chat pribadi'
  return (
    <button
      type="button"
      onClick={() => nav.push({ name: 'dm', uid })}
      className="mt-3 flex h-11 w-full items-center gap-2.5 rounded-2xl bg-white/[0.07] px-3.5 text-left active:scale-[0.98]"
    >
      <Icon name="chat" size={17} className={pv?.unread ? 'text-accent' : 'text-white/70'} />
      <span className={`min-w-0 flex-1 truncate text-[13.5px] ${pv?.unread ? 'font-bold text-white' : 'text-white/70'}`}>{preview}</span>
      {pv?.unread ? <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-accent" /> : null}
    </button>
  )
}

export function ConnectionsPage() {
  const nav = useNav()
  const me = useProfile()
  const [tab, setTab] = useState<TabKey>('friends')
  const [infoOpen, setInfoOpen] = useState(false)
  const [searching, setSearching] = useState(false)
  const [q, setQ] = useState('')
  const [busy, setBusy] = useState<string | null>(null)

  const friends = useUidList(me.uid, 'friends')
  const incoming = useUidList(me.uid, 'incoming')
  const sent = useUidList(me.uid, 'sent')

  const allUids = useMemo(
    () => [...(friends.list ?? []), ...(incoming.list ?? []), ...(sent.list ?? [])].map((e) => e.uid),
    [friends.list, incoming.list, sent.list],
  )
  const live = useLiveUsers(allUids)
  const friendUids = useMemo(() => (friends.list ?? []).map((e) => e.uid), [friends.list])
  const online = useOnlineMap(friendUids)

  const needle = q.trim().replace(/^#/, '').toLowerCase()
  const matches = (uid: string) => {
    if (!needle) return true
    const p = live.get(uid)
    if (!p) return false
    return nameOf(p).toLowerCase().includes(needle) || p.displayName.toLowerCase().includes(needle) || String(p.userId).includes(needle)
  }

  const friendRows = useMemo(() => {
    const rows = (friends.list ?? []).filter((e) => matches(e.uid))
    // yang online di atas, selebihnya urut nama
    return rows.sort((a, b) => {
      const oa = online.get(a.uid) ? 1 : 0
      const ob = online.get(b.uid) ? 1 : 0
      if (oa !== ob) return ob - oa
      const pa = live.get(a.uid)
      const pb = live.get(b.uid)
      return (pa ? nameOf(pa) : '').localeCompare(pb ? nameOf(pb) : '', 'id', { sensitivity: 'base' })
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [friends.list, online, live, needle])

  const incomingRows = (incoming.list ?? []).filter((e) => matches(e.uid))
  const sentRows = (sent.list ?? []).filter((e) => matches(e.uid))

  const act = async (key: string, fn: () => Promise<void>, ok: string) => {
    if (busy) return
    setBusy(key)
    try {
      await fn()
      toast(ok)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(null)
    }
  }

  const tabs: { key: TabKey; label: string; badge?: number }[] = [
    { key: 'friends', label: 'Teman' },
    { key: 'requests', label: 'Permintaan', badge: incoming.list?.length ?? 0 },
  ]

  const loading = tab === 'friends' ? friends.list === undefined : incoming.list === undefined || sent.list === undefined
  const error = tab === 'friends' ? friends.error : incoming.error ?? sent.error

  return (
    <div className="absolute inset-0 overflow-y-auto pb-16">
      <PageHeader
        title="Connections"
        onBack={nav.pop}
        right={
          <div className="-mr-2 flex items-center">
            <HeaderIcon icon="info" label="Info" onClick={() => setInfoOpen(true)} />
            <HeaderIcon
              icon="search"
              label="Cari di daftar"
              active={searching}
              onClick={() => {
                setSearching((v) => !v)
                setQ('')
              }}
            />
            <HeaderIcon icon="userPlus" label="Tambah teman" onClick={() => nav.push({ name: 'findfriend' })} />
          </div>
        }
      />

      <div className="grid grid-cols-2 border-b border-white/[0.06]">
        {tabs.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={`relative flex items-center justify-center gap-2 py-3.5 text-[15px] font-semibold ${tab === t.key ? 'text-white' : 'text-muted'}`}
          >
            {t.label}
            {t.badge ? (
              <span className="flex h-[19px] min-w-[19px] items-center justify-center rounded-full bg-[#2F8BFF] px-1.5 text-[11px] font-bold text-white">{t.badge}</span>
            ) : null}
            {tab === t.key ? <span className="absolute bottom-0 h-[3px] w-14 rounded-full bg-accent" /> : null}
          </button>
        ))}
      </div>

      {searching ? (
        <div className="px-4 pt-3">
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cari nama atau User ID"
            className="h-11 w-full rounded-full border border-white/10 bg-raise px-4 text-[14px] text-white placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
      ) : null}

      <div className="px-4 pt-4">
        {error ? (
          <ErrorState compact message={error} />
        ) : loading ? (
          <div className="flex justify-center py-16">
            <Spinner size={26} />
          </div>
        ) : tab === 'friends' ? (
          friendRows.length ? (
            <ul className="space-y-3">
              {friendRows.map((e) => (
                <CardShell key={e.uid}>
                  <Person uid={e.uid} p={live.get(e.uid)} online={!!online.get(e.uid)} />
                  <ChatRow uid={e.uid} />
                </CardShell>
              ))}
            </ul>
          ) : (
            <EmptyState
              icon="users"
              title={needle ? 'Teman tidak ditemukan' : 'Belum ada teman'}
              hint={needle ? 'Coba nama atau User ID lain.' : 'Cari teman lewat User ID, lalu kirim permintaan pertemanan.'}
              action={
                needle ? undefined : (
                  <button
                    type="button"
                    onClick={() => nav.push({ name: 'findfriend' })}
                    className="flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-[13px] font-bold text-ink active:scale-95"
                  >
                    <Icon name="userPlus" size={16} /> Cari Teman
                  </button>
                )
              }
            />
          )
        ) : (
          <>
            <h2 className="px-1 text-[14px] font-semibold text-accent">Permintaan Masuk</h2>
            {incomingRows.length ? (
              <ul className="mt-2.5 space-y-3">
                {incomingRows.map((e) => (
                  <CardShell key={e.uid}>
                    <Person uid={e.uid} p={live.get(e.uid)} />
                    <div className="mt-3 flex gap-2.5">
                      <button
                        type="button"
                        disabled={!!busy}
                        onClick={() => void act(`a:${e.uid}`, () => acceptRequest(me.uid, e.uid), 'Kalian sekarang berteman')}
                        className="flex h-11 flex-1 items-center justify-center rounded-2xl bg-[#2F8BFF] text-[14px] font-bold text-white active:scale-[0.98] disabled:opacity-60"
                      >
                        {busy === `a:${e.uid}` ? <Spinner size={16} /> : 'Accept'}
                      </button>
                      <button
                        type="button"
                        disabled={!!busy}
                        onClick={() => void act(`r:${e.uid}`, () => rejectRequest(me.uid, e.uid), 'Permintaan ditolak')}
                        className="flex h-11 flex-1 items-center justify-center rounded-2xl bg-white/10 text-[14px] font-bold text-white active:scale-[0.98] disabled:opacity-60"
                      >
                        {busy === `r:${e.uid}` ? <Spinner size={16} /> : 'Reject'}
                      </button>
                    </div>
                  </CardShell>
                ))}
              </ul>
            ) : (
              <p className="px-1 py-5 text-[13px] text-muted">{needle ? 'Tidak ada yang cocok.' : 'Tidak ada permintaan masuk.'}</p>
            )}

            <h2 className="mt-6 px-1 text-[14px] font-semibold text-accent">Permintaan Terkirim</h2>
            {sentRows.length ? (
              <ul className="mt-2.5 space-y-3">
                {sentRows.map((e) => (
                  <CardShell key={e.uid}>
                    <Person uid={e.uid} p={live.get(e.uid)} note="Menunggu konfirmasi" />
                    <button
                      type="button"
                      disabled={!!busy}
                      onClick={() => void act(`c:${e.uid}`, () => cancelRequest(me.uid, e.uid), 'Permintaan dibatalkan')}
                      className="mt-3 flex h-11 w-full items-center justify-center rounded-2xl bg-white/10 text-[14px] font-bold text-white active:scale-[0.98] disabled:opacity-60"
                    >
                      {busy === `c:${e.uid}` ? <Spinner size={16} /> : 'Batal'}
                    </button>
                  </CardShell>
                ))}
              </ul>
            ) : (
              <p className="px-1 py-5 text-[13px] text-muted">{needle ? 'Tidak ada yang cocok.' : 'Belum ada permintaan yang kamu kirim.'}</p>
            )}
          </>
        )}
      </div>

      <Sheet open={infoOpen} onClose={() => setInfoOpen(false)} title="Tentang Connections">
        <div className="space-y-3 text-[13.5px] leading-relaxed text-white/75">
          <p>Teman: daftar akun yang sudah saling menerima. Titik hijau berarti sedang online.</p>
          <p>Permintaan: terima atau tolak permintaan masuk, dan batalkan permintaan yang kamu kirim.</p>
          <p>Ketuk ikon tambah teman di kanan atas, lalu masukkan User ID, contoh 1470 atau #1470, untuk mencari akun.</p>
        </div>
      </Sheet>
    </div>
  )
}
