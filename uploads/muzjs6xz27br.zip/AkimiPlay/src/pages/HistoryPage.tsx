import { useState } from 'react'
import { useNav } from '../nav/router'
import { clearHistory, historyStore, removeHistory, useStore } from '../storage/stores'
import { timeAgo } from '../lib/format'
import { ConfirmDialog, toast } from '../components/Feedback'
import { EmptyState } from '../components/States'
import { PageHeader } from '../components/PageHeader'
import { Poster } from '../components/Poster'
import { Icon } from '../components/Icon'

export function HistoryPage() {
  const nav = useNav()
  const list = useStore(historyStore)
  const [confirmAll, setConfirmAll] = useState(false)

  return (
    <div className="absolute inset-0 overflow-y-auto pb-36">
      <PageHeader
        title="Histori"
        right={
          list.length ? (
            <button
              type="button"
              onClick={() => setConfirmAll(true)}
              className="rounded-full bg-raise px-3.5 py-1.5 text-[12.5px] font-semibold text-white/85 active:scale-95"
            >
              Hapus Semua
            </button>
          ) : undefined
        }
      />

      {list.length === 0 ? (
        <EmptyState
          icon="clock"
          title="Histori kosong"
          hint="Anime yang kamu tonton akan muncul di sini beserta posisi terakhirnya."
        />
      ) : (
        <ul className="space-y-3 px-4">
          {list.map((h) => {
            const pct = h.duration > 0 ? Math.min(100, Math.round((h.position / h.duration) * 100)) : 0
            return (
              <li key={h.animeId} className="flex gap-3 rounded-2xl bg-raise/70 p-2.5">
                <button
                  type="button"
                  onClick={() => nav.openAnime({ id: h.animeId, title: h.title, poster: h.poster })}
                  className="shrink-0"
                  aria-label={`Detail ${h.title}`}
                >
                  <Poster src={h.poster} alt={h.title} className="h-[96px] w-[64px] rounded-xl" />
                </button>
                <div className="flex min-w-0 flex-1 flex-col">
                  <p className="line-clamp-2 text-[14px] font-semibold leading-tight text-white">{h.title}</p>
                  <p className="mt-0.5 text-[12.5px] text-white/75">Episode {h.episodeNumber}</p>
                  <div className="mt-1.5 flex items-center gap-2">
                    <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/10">
                      <div className="h-full bg-accent" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="text-[11.5px] text-muted">Progress {pct}%</span>
                  </div>
                  <div className="mt-auto flex items-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() =>
                        nav.play({ id: h.animeId, title: h.title, poster: h.poster }, h.episodeId)
                      }
                      className="flex items-center gap-1.5 rounded-full bg-accent px-3.5 py-1.5 text-[12.5px] font-bold text-ink active:scale-95"
                    >
                      <Icon name="play" size={14} /> Lanjutkan
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        removeHistory(h.animeId)
                        toast('Histori dihapus')
                      }}
                      className="rounded-full bg-white/[0.07] px-3.5 py-1.5 text-[12.5px] font-medium text-white/80 active:scale-95"
                    >
                      Hapus
                    </button>
                    <span className="ml-auto text-[11px] text-muted">{timeAgo(h.updatedAt)}</span>
                  </div>
                </div>
              </li>
            )
          })}
        </ul>
      )}

      <ConfirmDialog
        open={confirmAll}
        title="Hapus semua histori?"
        message="Semua riwayat tontonan dan posisi terakhir video akan dihapus. Favorit tidak ikut terhapus."
        confirmLabel="Hapus Semua"
        onCancel={() => setConfirmAll(false)}
        onConfirm={() => {
          clearHistory()
          setConfirmAll(false)
          toast('Semua histori dihapus')
        }}
      />
    </div>
  )
}
