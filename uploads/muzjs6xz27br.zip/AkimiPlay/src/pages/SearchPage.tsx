import { useCallback, useEffect, useRef, useState } from 'react'
import { animeApi } from '../services/animeApi'
import { useAsync, useDebounce } from '../hooks/hooks'
import { useNav } from '../nav/router'
import { PagedGrid } from '../components/PagedGrid'
import { Icon } from '../components/Icon'
import { Chip } from '../components/Feedback'

export function SearchPage() {
  const nav = useNav()
  const [q, setQ] = useState('')
  const dq = useDebounce(q, 450).trim()
  const inputRef = useRef<HTMLInputElement>(null)
  const genres = useAsync(() => animeApi.genres().catch(() => []), [])

  useEffect(() => {
    const t = setTimeout(() => inputRef.current?.focus(), 250)
    return () => clearTimeout(t)
  }, [])

  const load = useCallback((page: number) => animeApi.search({ q: dq, page }), [dq])
  const active = dq.length >= 2

  return (
    <div className="absolute inset-0 flex flex-col bg-ink">
      <div className="pt-safe bg-ink">
        <div className="flex h-14 items-center gap-2 px-3">
          <button
            type="button"
            aria-label="Kembali"
            onClick={nav.pop}
            className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"
          >
            <Icon name="back" size={24} />
          </button>
          <label className="flex h-11 min-w-0 flex-1 items-center gap-2.5 rounded-2xl bg-raise px-3.5">
            <Icon name="search" size={18} className="text-muted" />
            <input
              ref={inputRef}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari judul anime"
              enterKeyHint="search"
              className="min-w-0 flex-1 bg-transparent text-[14.5px] text-white placeholder:text-muted focus:outline-none"
            />
            {q ? (
              <button type="button" aria-label="Hapus teks" onClick={() => setQ('')} className="text-muted">
                <Icon name="x" size={16} />
              </button>
            ) : null}
          </label>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-10 pt-2">
        {active ? (
          <PagedGrid
            resetKey={dq}
            load={load}
            onOpen={nav.openAnime}
            emptyTitle={`Tidak ada hasil untuk "${dq}"`}
            emptyHint="Periksa ejaan atau coba kata kunci yang lebih pendek."
          />
        ) : (
          <div className="px-4 pt-4">
            <p className="text-[13.5px] text-muted">
              {q.trim().length === 1 ? 'Ketik minimal 2 huruf.' : 'Ketik judul anime, atau jelajahi lewat genre.'}
            </p>
            {genres.data?.length ? (
              <div className="mt-4 flex flex-wrap gap-2">
                {genres.data.map((g) => (
                  <Chip key={g.id} onClick={() => nav.push({ name: 'genre', id: g.id, title: g.name })}>
                    {g.name}
                  </Chip>
                ))}
              </div>
            ) : null}
          </div>
        )}
      </div>
    </div>
  )
}
