import { useCallback } from 'react'
import { animeApi } from '../services/animeApi'
import { useNav } from '../nav/router'
import { PagedGrid } from '../components/PagedGrid'
import { PageHeader } from '../components/PageHeader'

export function GenrePage({ id, title }: { id: string; title: string }) {
  const nav = useNav()
  const load = useCallback((page: number) => animeApi.search({ genreIds: [id], page, sort: 'views' }), [id])
  return (
    <div className="absolute inset-0 overflow-y-auto pb-10">
      <PageHeader title={title} onBack={nav.pop} />
      <PagedGrid
        resetKey={id}
        load={load}
        onOpen={nav.openAnime}
        emptyTitle="Belum ada anime di genre ini"
        emptyHint="Coba genre lain."
      />
    </div>
  )
}
