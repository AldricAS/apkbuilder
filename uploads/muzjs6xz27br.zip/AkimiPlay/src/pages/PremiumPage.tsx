import { useState } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { isPremiumActive } from '../services/userService'
import { remainingText } from '../services/adminService'
import {
  PREMIUM_PLANS,
  SOCIABUZZ_URL,
  WA_NUMBER,
  rupiah,
  savingPercent,
  waMessage,
  type PayerInfo,
  type PremiumPlan,
} from '../services/premiumPlans'
import { native } from '../native/native'
import { useBackHandler } from '../native/native'
import { fmtNum } from '../lib/xp'
import { Avatar, PremiumBadge } from '../components/UserBadges'
import { SparkIcon } from '../components/LeaderboardUi'
import { Icon } from '../components/Icon'
import { toast } from '../components/Feedback'

const waLink = (text: string) => `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(text)}`

/**
 * Popup cadangan (dipakai bila popup native tidak tersedia, mis. saat dicoba di browser).
 * Di APK, popup native yang dipakai: form Sociabuzz terisi otomatis. Di browser pengisian otomatis tidak mungkin
 * (halaman lain domain), jadi nilainya ditampilkan dengan tombol salin.
 */
function WebPaymentModal({ plan, payer, onClose }: { plan: PremiumPlan; payer: PayerInfo; onClose: () => void }) {
  useBackHandler(() => {
    onClose()
    return true
  }, 50)
  const rows: { label: string; value: string }[] = [
    { label: 'Jumlah', value: String(plan.price) },
    { label: 'Pesan (UID)', value: payer.uid },
    { label: 'Nama', value: payer.name },
    { label: 'Email', value: payer.email },
  ]
  const copy = async (v: string) => {
    try {
      await navigator.clipboard.writeText(v)
      toast('Disalin')
    } catch {
      toast('Tidak bisa menyalin, salin manual')
    }
  }
  return (
    <div className="fixed inset-0 z-[95] flex flex-col justify-end">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative flex h-[calc(100%-56px)] flex-col overflow-hidden rounded-t-3xl bg-panel">
        <div className="flex h-[52px] shrink-0 items-center">
          <p className="flex-1 truncate pl-[18px] text-[16px] font-bold text-white">Pembayaran Premium · {plan.title}</p>
          <button type="button" aria-label="Tutup" onClick={onClose} className="flex h-[52px] w-[52px] items-center justify-center text-[20px] text-white/70">
            ✕
          </button>
        </div>
        <div className="shrink-0 space-y-1.5 border-b border-line px-4 pb-3">
          <p className="text-[11.5px] text-muted">Isi form di bawah dengan data ini (ketuk untuk menyalin):</p>
          <div className="grid grid-cols-2 gap-1.5">
            {rows.map((r) => (
              <button key={r.label} type="button" onClick={() => void copy(r.value)} className="min-w-0 rounded-xl bg-white/[0.06] px-3 py-2 text-left active:scale-[0.98]">
                <p className="text-[10.5px] text-muted">{r.label}</p>
                <p className="truncate text-[12.5px] font-bold text-white">{r.value}</p>
              </button>
            ))}
          </div>
        </div>
        <iframe title="Sociabuzz AkimiPlay" src={SOCIABUZZ_URL} className="min-h-0 flex-1 bg-white" />
        <div className="shrink-0 bg-[#0B0B10] px-3 pb-3 pt-2">
          <p className="pb-1.5 text-[12px] text-muted">Sudah bayar lewat QRIS / e-wallet? Kirim bukti pembayaran ke WhatsApp admin.</p>
          <a
            href={waLink(waMessage(payer, plan))}
            target="_blank"
            rel="noreferrer"
            className="flex h-12 items-center justify-center rounded-full bg-[#1FA855] text-[15px] font-bold text-white active:scale-[0.98]"
          >
            Kirim Bukti ke WhatsApp
          </a>
        </div>
      </div>
    </div>
  )
}

export function PremiumPage() {
  const nav = useNav()
  const me = useProfile()
  const [busy, setBusy] = useState<string | null>(null)
  const [web, setWeb] = useState<PremiumPlan | null>(null)

  const name = me.username?.trim() || me.displayName
  const payer: PayerInfo = { uid: me.uid, userId: me.userId, name, email: me.email }
  const active = isPremiumActive(me)
  const expired = !active && typeof me.premiumUntil === 'number'
  const until = typeof me.premiumUntil === 'number' ? me.premiumUntil : null

  const choose = async (plan: PremiumPlan) => {
    if (busy) return
    setBusy(plan.id)
    try {
      const ok = await native.openPayment({
        url: SOCIABUZZ_URL,
        title: `Pembayaran Premium · ${plan.title}`,
        amount: plan.price,
        message: me.uid,
        name,
        email: me.email,
        waNumber: WA_NUMBER,
        waText: waMessage(payer, plan),
      })
      if (!ok) setWeb(plan)
    } finally {
      setBusy(null)
    }
  }

  const sendProof = async () => {
    const text = waMessage(payer)
    const ok = await native.openWhatsApp(WA_NUMBER, text)
    if (!ok) window.open(waLink(text), '_blank', 'noopener')
  }

  return (
    <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-[#0F121C] to-ink pb-16">
      <header className="pt-safe sticky top-0 z-10 bg-[#0F121C]/95 backdrop-blur">
        <div className="relative flex h-14 items-center px-3">
          <button type="button" aria-label="Kembali" onClick={nav.pop} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10">
            <Icon name="back" size={26} />
          </button>
          <h1 className="pointer-events-none absolute inset-x-0 text-center text-[22px] font-medium text-white">AkimiPlay Premium</h1>
        </div>
      </header>

      {/* akun */}
      <div className="mx-4 mt-3 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] ring-1 ring-black/20">
        <div className="flex">
          <div className="w-1 shrink-0 bg-accent" />
          <div className="min-w-0 flex-1 p-4">
            <div className="flex gap-3.5">
              <Avatar url={me.photoURL} name={name} size={64} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[19px] font-extrabold text-white">{name}</p>
                <p className="truncate text-[13.5px] text-muted">
                  #{me.userId} · {me.email}
                </p>
                <p className="mt-1 text-[13px] leading-snug text-muted">Masa premium akan diperpanjang ke akun ini setelah pembayaran berhasil.</p>
              </div>
            </div>
            <div className="mt-3.5 flex items-center justify-between border-t border-white/10 pt-3.5">
              <span className="text-[12.5px] font-bold uppercase tracking-[0.14em] text-muted">Status Premium</span>
              {active ? (
                <span className="flex items-center gap-2 rounded-full bg-[#12301f] px-3.5 py-2 text-[13.5px] font-extrabold text-[#5BE08A]">
                  <PremiumBadge size={8.5} />
                  {remainingText(until)}
                </span>
              ) : (
                <span className={`rounded-full px-4 py-2 text-[16px] font-extrabold ${expired ? 'bg-[#22303a] text-[#E7C766]' : 'bg-white/10 text-white/70'}`}>
                  {expired ? 'Expired' : 'Belum Premium'}
                </span>
              )}
            </div>
            {active && me.role !== 'premium' ? (
              <p className="mt-2.5 text-[12px] leading-snug text-muted">
                Kamu ber-role <span className="font-bold text-white/80">{me.role}</span>, jadi badge role itu tetap dipakai. Masa Premium tetap berjalan dan badge Premium tampil bila rolemu kembali user.
              </p>
            ) : null}
          </div>
        </div>
      </div>

      {/* paket */}
      <div className="mt-5 flex items-center gap-2 px-4">
        <span className="h-4 w-1 rounded-full bg-accent" />
        <h2 className="text-[13.5px] font-extrabold uppercase tracking-[0.14em] text-white/70">Pilih durasi premium</h2>
      </div>
      <div className="mt-2.5 space-y-3 px-4">
        {PREMIUM_PLANS.map((p) => {
          const save = savingPercent(p)
          return (
            <div key={p.id} className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-[21px] font-extrabold text-white">{p.title}</p>
                    {save > 0 ? <span className="rounded-full bg-[#16382a] px-2 py-[2px] text-[10.5px] font-extrabold text-[#5BE08A]">HEMAT {save}%</span> : null}
                  </div>
                  <p className="text-[13.5px] text-muted">{p.days} hari premium</p>
                  <p className="mt-1 flex items-center gap-1.5 text-[14px] font-bold text-[#8EE6A6]">
                    <span className="text-[#8EC5FF]">
                      <SparkIcon size={16} />
                    </span>
                    Bonus AkimiShard: {fmtNum(p.bonusShard)}
                  </p>
                </div>
                <p className="shrink-0 pt-0.5 text-[22px] font-extrabold text-accent">{rupiah(p.price)}</p>
              </div>
              <button
                type="button"
                disabled={busy !== null}
                onClick={() => void choose(p)}
                className="mt-3.5 flex h-[52px] w-full items-center justify-center rounded-2xl border-2 border-accent/70 text-[17px] font-extrabold text-accent active:scale-[0.98] active:bg-accent/10 disabled:opacity-50"
              >
                {busy === p.id ? 'Membuka…' : 'Pilih Paket'}
              </button>
            </div>
          )
        })}
      </div>

      {/* cara bayar */}
      <div className="mx-4 mt-5 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
        <p className="text-[15px] font-bold text-white">Cara membayar</p>
        <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-[13px] leading-snug text-white/75">
          <li>Pilih paket. Form Sociabuzz terbuka di aplikasi dengan jumlah, UID, nama, dan email sudah terisi.</li>
          <li>Centang pernyataan di form, tekan Choose payment method, lalu bayar dengan QRIS atau e-wallet.</li>
          <li>Kirim bukti pembayaran ke WhatsApp admin (tombol hijau di popup, atau tombol di bawah ini).</li>
          <li>Admin mengaktifkan Premium dan bonus AkimiShard ke akunmu secara manual setelah bukti dicek.</li>
        </ol>
        <button
          type="button"
          onClick={() => void sendProof()}
          className="mt-3.5 flex h-12 w-full items-center justify-center rounded-full bg-[#1FA855] text-[15px] font-bold text-white active:scale-[0.98]"
        >
          Kirim Bukti ke WhatsApp
        </button>
      </div>

      {web ? <WebPaymentModal plan={web} payer={payer} onClose={() => setWeb(null)} /> : null}
    </div>
  )
}
