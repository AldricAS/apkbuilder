import { useEffect, useRef, useState, type ReactNode } from 'react'
import { useBackHandler } from '../native/native'
import { ConfirmDialog, Sheet, toast } from '../components/Feedback'
import { Icon } from '../components/Icon'
import { useProfile } from '../auth/AuthProvider'
import { useNav } from '../nav/router'
import {
  BROADCAST_COOLDOWN_MS,
  BROADCAST_FROM_MAX,
  BROADCAST_TEXT_MAX,
  deleteBroadcast,
  isDeveloper,
  sendBroadcast,
  subscribeBroadcasts,
  type Broadcast,
} from '../services/broadcastService'
import { errMsg } from '../lib/format'
import { fmtNum } from '../lib/xp'
import { copyText } from '../lib/clipboard'
import { findUserByUserId, type FoundUser } from '../services/userLookupService'
import { notifListenStatus, notifStatus, testNotification } from '../services/notifyService'
import { addShard, setShard } from '../services/shardService'
import {
  ASSIGNABLE_ROLES,
  PREMIUM_UNIT_LABEL,
  addDuration,
  changeRole,
  changeUserId,
  findTarget,
  grantPremium,
  remainingText,
  revokePremium,
  type AdminTarget,
  type PremiumUnit,
} from '../services/adminService'
import { PremiumBadge } from '../components/UserBadges'
import { BANNER_BTN_MAX, BANNER_LINK_MAX, BANNER_TEXT_MAX, BANNER_TITLE_MAX, clearBanner, sendBanner, subscribeBanner, type Banner } from '../services/bannerService'
import { BannerCard } from '../components/BannerHost'
import { ClanBadge } from '../components/ClanBadge'
import { adminDeleteClan, clanColorOf, RARITY_LABEL, useTopClans, type Clan } from '../services/clanService'

type DevTab = 'notif' | 'banner' | 'user' | 'shard' | 'clan' | 'id' | 'role' | 'banned'
const TABS: { key: DevTab; label: string }[] = [
  { key: 'notif', label: 'Notif' },
  { key: 'banner', label: 'Banner' },
  { key: 'user', label: 'User' },
  { key: 'shard', label: 'Shard' },
  { key: 'clan', label: 'Clan' },
  { key: 'id', label: 'Ubah ID' },
  { key: 'role', label: 'Role' },
  { key: 'banned', label: 'Banned' },
]

/** Panel khusus developer. Dibuka dari halaman Akun; dijaga di UI dan di Security Rules (role developer). */
export function DevPanel({ onClose }: { onClose: () => void }) {
  const profile = useProfile()
  const [tab, setTab] = useState<DevTab>('notif')
  useBackHandler(
    () => {
      onClose()
      return true
    },
    300,
  )

  // lapisan pertama: bukan developer -> tidak menampilkan apa pun
  if (!isDeveloper(profile)) return null

  return (
    <div className="fixed inset-0 z-[85] flex flex-col bg-ink animate-fadeIn">
      <header className="pt-safe bg-ink/90 backdrop-blur-xl">
        <div className="flex h-14 items-center gap-2 px-4">
          <button
            type="button"
            aria-label="Tutup"
            onClick={onClose}
            className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"
          >
            <Icon name="back" size={24} />
          </button>
          <h1 className="flex-1 text-[20px] font-bold tracking-tight text-white">Panel Developer</h1>
          <Icon name="shield" size={20} className="text-[#FF4D5E]" />
        </div>
        <nav className="flex gap-1 overflow-x-auto whitespace-nowrap border-b border-line px-4">
          {TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setTab(t.key)}
              className={`relative shrink-0 px-3.5 py-3 text-[14px] font-semibold ${tab === t.key ? 'text-white' : 'text-muted'}`}
            >
              {t.label}
              {tab === t.key ? <span className="absolute inset-x-3 bottom-0 h-[3px] rounded-full bg-accent" /> : null}
            </button>
          ))}
        </nav>
      </header>
      <div className="flex-1 overflow-y-auto px-4 pb-24 pt-4">
        {tab === 'notif' ? <NotifTab /> : tab === 'banner' ? <BannerTab /> : tab === 'user' ? <UserTab onClose={onClose} /> : tab === 'shard' ? <ShardTab /> : tab === 'clan' ? <ClanTab /> : tab === 'id' ? <IdTab /> : tab === 'role' ? <RoleTab /> : <BannedTab />}
      </div>
    </div>
  )
}

function NotifTab() {
  const profile = useProfile()
  const [from, setFrom] = useState(profile.username?.trim() || profile.displayName)
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [confirm, setConfirm] = useState(false)
  const [list, setList] = useState<Broadcast[]>([])
  const [listError, setListError] = useState<string | null>(null)
  const [cooldownUntil, setCooldownUntil] = useState(0)
  const [, tick] = useState(0)
  const [delId, setDelId] = useState<string | null>(null)
  const timer = useRef<ReturnType<typeof setInterval>>()

  useEffect(() => subscribeBroadcasts(setList, (e) => setListError(e.message)), [])

  // hitung mundur batas kirim
  useEffect(() => {
    timer.current = setInterval(() => tick((n) => n + 1), 500)
    return () => clearInterval(timer.current)
  }, [])
  const wait = Math.max(0, Math.ceil((cooldownUntil - Date.now()) / 1000))

  const valid = from.trim().length > 0 && text.trim().length > 0
  const send = async () => {
    setConfirm(false)
    setBusy(true)
    try {
      await sendBroadcast(profile, from, text)
      setText('')
      setCooldownUntil(Date.now() + BROADCAST_COOLDOWN_MS)
      toast('Notifikasi terkirim')
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="mb-1.5 block text-[12.5px] font-semibold text-muted">Pesan dari</label>
        <input
          value={from}
          maxLength={BROADCAST_FROM_MAX}
          onChange={(e) => setFrom(e.target.value)}
          placeholder="Nama pengirim"
          className="w-full rounded-2xl bg-raise px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
        />
      </div>
      <div>
        <label className="mb-1.5 block text-[12.5px] font-semibold text-muted">Teks</label>
        <textarea
          value={text}
          maxLength={BROADCAST_TEXT_MAX}
          rows={4}
          onChange={(e) => setText(e.target.value)}
          placeholder="Isi pesan notifikasi"
          className="w-full resize-none rounded-2xl bg-raise px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
        />
        <p className="mt-1 text-right text-[11.5px] text-muted">
          {text.length}/{BROADCAST_TEXT_MAX}
        </p>
      </div>

      <div className="rounded-2xl bg-raise/70 px-4 py-3">
        <p className="text-[11.5px] text-muted">Pratinjau notifikasi</p>
        <p className="mt-1 text-[13.5px] font-bold text-white">Pesan dari {from.trim() || '…'}</p>
        <p className="mt-0.5 whitespace-pre-wrap break-words text-[13px] text-white/75">{text.trim() || '…'}</p>
      </div>

      <button
        type="button"
        disabled={!valid || busy || wait > 0}
        onClick={() => setConfirm(true)}
        className="flex w-full items-center justify-center gap-2 rounded-full bg-accent py-3 text-[14px] font-bold text-ink active:scale-[0.98] disabled:opacity-40"
      >
        <Icon name="send" size={18} />
        {busy ? 'Mengirim…' : wait > 0 ? `Tunggu ${wait} detik` : 'Kirim'}
      </button>
      <p className="text-center text-[11.5px] leading-snug text-muted">
        Terkirim ke semua pengguna yang notifikasinya aktif. Pesan tidak bisa diedit; yang sudah muncul di HP tidak bisa
        ditarik kembali.
      </p>

      <NotifDiag />

      <div className="pt-2">
        <h3 className="mb-2 text-[14px] font-bold text-white">Riwayat terkirim</h3>
        {listError ? <p className="text-[12.5px] text-[#FF4D5E]">{listError}</p> : null}
        {list.length === 0 && !listError ? <p className="text-[12.5px] text-muted">Belum ada pesan.</p> : null}
        <div className="space-y-2">
          {list.map((b) => (
            <div key={b.id} className="flex items-start gap-3 rounded-2xl bg-raise/70 px-4 py-3">
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-bold text-white">{b.from}</p>
                <p className="mt-0.5 whitespace-pre-wrap break-words text-[12.5px] text-white/75">{b.text}</p>
                <p className="mt-1 text-[11px] text-muted">{new Date(b.ts).toLocaleString('id-ID')}</p>
              </div>
              <button
                type="button"
                aria-label="Hapus"
                onClick={() => setDelId(b.id)}
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full active:bg-white/10"
              >
                <Icon name="trash" size={16} className="text-muted" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <ConfirmDialog
        open={confirm}
        title="Kirim notifikasi?"
        message="Notifikasi akan muncul di HP semua pengguna dan tidak bisa ditarik kembali."
        confirmLabel="Kirim"
        onCancel={() => setConfirm(false)}
        onConfirm={() => void send()}
      />
      <ConfirmDialog
        open={delId !== null}
        title="Hapus dari riwayat?"
        message="Pesan dihapus dari database. Notifikasi yang sudah terlanjur muncul di HP pengguna tidak ikut hilang."
        confirmLabel="Hapus"
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          const id = delId
          setDelId(null)
          if (id) deleteBroadcast(profile, id).catch((e) => toast(errMsg(e)))
        }}
      />
    </div>
  )
}

/** Membuat banner pengumuman yang muncul di semua HP setiap aplikasi dibuka. */
function BannerTab() {
  const profile = useProfile()
  const [title, setTitle] = useState('')
  const [text, setText] = useState('')
  const [btnOn, setBtnOn] = useState(false)
  const [btnText, setBtnText] = useState('')
  const [btnLink, setBtnLink] = useState('')
  const [busy, setBusy] = useState(false)
  const [confirm, setConfirm] = useState(false)
  const [confirmDel, setConfirmDel] = useState(false)
  const [active, setActive] = useState<Banner | null | undefined>(undefined)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => subscribeBanner(setActive, (e) => setError(e.message)), [])

  const valid = title.trim().length > 0 && text.trim().length > 0 && (!btnOn || (btnText.trim().length > 0 && btnLink.trim().length > 0))
  const send = async () => {
    setConfirm(false)
    setBusy(true)
    try {
      await sendBanner(profile, title, text, btnOn ? { text: btnText, link: btnLink } : null)
      setTitle('')
      setText('')
      setBtnText('')
      setBtnLink('')
      setBtnOn(false)
      toast('Banner terkirim')
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="mb-1.5 block text-[12.5px] font-semibold text-muted">Judul</label>
        <input
          value={title}
          maxLength={BANNER_TITLE_MAX}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Judul banner"
          className="w-full rounded-2xl bg-raise px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
        />
      </div>
      <div>
        <label className="mb-1.5 block text-[12.5px] font-semibold text-muted">Teks</label>
        <textarea
          value={text}
          maxLength={BANNER_TEXT_MAX}
          rows={6}
          onChange={(e) => setText(e.target.value)}
          placeholder="Isi banner. Baris baru ikut tampil."
          className="w-full resize-none rounded-2xl bg-raise px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
        />
        <p className="mt-1 text-right text-[11.5px] text-muted">
          {text.length}/{BANNER_TEXT_MAX}
        </p>
      </div>

      <div>
        <label className="mb-1.5 block text-[12.5px] font-semibold text-muted">Teks tombol</label>
        <div className="flex items-center gap-3">
          <input
            value={btnText}
            maxLength={BANNER_BTN_MAX}
            disabled={!btnOn}
            onChange={(e) => setBtnText(e.target.value)}
            placeholder="Contoh: Update sekarang"
            className="min-w-0 flex-1 rounded-2xl bg-raise px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-1 focus:ring-accent disabled:opacity-40"
          />
          <button
            type="button"
            role="switch"
            aria-checked={btnOn}
            aria-label={btnOn ? 'Matikan tombol' : 'Nyalakan tombol'}
            onClick={() => setBtnOn((v) => !v)}
            className={`relative flex h-9 w-[76px] shrink-0 items-center rounded-full px-1 text-[11px] font-extrabold tracking-wide transition-colors ${btnOn ? 'justify-start bg-[#2fbf5d] text-[#06280f]' : 'justify-end bg-raise text-white/60'}`}
          >
            <span className={`absolute top-1 h-7 w-7 rounded-full bg-white shadow transition-all ${btnOn ? 'right-1' : 'left-1'}`} />
            <span className={btnOn ? 'pl-2' : 'pr-2'}>{btnOn ? 'ON' : 'OFF'}</span>
          </button>
        </div>
        {btnOn ? (
          <input
            value={btnLink}
            maxLength={BANNER_LINK_MAX}
            inputMode="url"
            autoCapitalize="none"
            autoCorrect="off"
            onChange={(e) => setBtnLink(e.target.value)}
            placeholder="Link tujuan tombol (https://...)"
            className="mt-2.5 w-full rounded-2xl bg-raise px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
          />
        ) : null}
      </div>

      <div>
        <p className="mb-2 text-[11.5px] text-muted">Pratinjau (seperti yang dilihat pengguna)</p>
        <BannerCard title={title.trim()} text={text.trim()} btn={btnOn ? btnText.trim() : undefined} link={btnOn ? btnLink.trim() || '#' : undefined} />
      </div>

      <button
        type="button"
        disabled={!valid || busy}
        onClick={() => setConfirm(true)}
        className="flex w-full items-center justify-center gap-2 rounded-full bg-accent py-3 text-[14px] font-bold text-ink active:scale-[0.98] disabled:opacity-40"
      >
        <Icon name="send" size={18} />
        {busy ? 'Mengirim…' : active ? 'Kirim & ganti banner aktif' : 'Kirim'}
      </button>
      <p className="text-center text-[11.5px] leading-snug text-muted">
        Banner muncul setiap pengguna membuka aplikasi dan bisa ditutup dengan tombol X. Hanya ada satu banner aktif: mengirim yang
        baru menggantikan yang lama. Banner terus muncul sampai kamu menghapusnya.
      </p>

      <div className="pt-2">
        <h3 className="mb-2 text-[14px] font-bold text-white">Banner aktif</h3>
        {error ? <p className="text-[12.5px] text-[#FF4D5E]">{error}</p> : null}
        {active === undefined && !error ? <p className="text-[12.5px] text-muted">Memuat…</p> : null}
        {active === null ? <p className="text-[12.5px] text-muted">Tidak ada banner aktif.</p> : null}
        {active ? (
          <div className="space-y-2.5">
            <BannerCard title={active.title} text={active.text} btn={active.btn} link={active.link} />
            <p className="text-[11px] text-muted">Dikirim {new Date(active.ts).toLocaleString('id-ID')}</p>
            <button
              type="button"
              onClick={() => setConfirmDel(true)}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-raise py-3 text-[14px] font-semibold text-accent active:scale-[0.98]"
            >
              <Icon name="trash" size={17} /> Hapus banner
            </button>
          </div>
        ) : null}
      </div>

      <ConfirmDialog
        open={confirm}
        title={active ? 'Ganti banner aktif?' : 'Kirim banner?'}
        message="Banner akan muncul di semua pengguna setiap membuka aplikasi sampai kamu menghapusnya."
        confirmLabel="Kirim"
        onCancel={() => setConfirm(false)}
        onConfirm={() => void send()}
      />
      <ConfirmDialog
        open={confirmDel}
        title="Hapus banner?"
        message="Banner tidak akan muncul lagi di pembukaan aplikasi berikutnya."
        confirmLabel="Hapus"
        onCancel={() => setConfirmDel(false)}
        onConfirm={() => {
          setConfirmDel(false)
          clearBanner(profile)
            .then(() => toast('Banner dihapus'))
            .catch((e) => toast(errMsg(e)))
        }}
      />
    </div>
  )
}

/** Cek apakah HP ini siap menerima notifikasi, plus tombol uji. */
function NotifDiag() {
  const [info, setInfo] = useState('')
  const [busy, setBusy] = useState(false)
  const run = async () => {
    setBusy(true)
    try {
      const r = await testNotification()
      const st = await notifStatus()
      const l = notifListenStatus()
      const msg: Record<typeof r, string> = {
        ok: 'Notifikasi uji dikirim. Cek status bar HP.',
        web: 'Hanya berlaku di APK (bukan browser).',
        off: 'Notifikasi dimatikan di Akun → pengaturan notifikasi aplikasi.',
        denied: 'Izin notifikasi ditolak. Aktifkan dari pengaturan HP → Aplikasi → AkimiPlay → Notifikasi.',
        blocked: 'Notifikasi gagal ditampilkan (cek channel/izin di pengaturan HP).',
      }
      setInfo(
        `${msg[r]}\nIzin: ${st.granted ? 'diberikan' : 'BELUM'} · Pendengar pesan: ${l.listening ? 'aktif' : 'TIDAK aktif'}${l.error ? ` (${l.error})` : ''}`,
      )
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className="rounded-2xl bg-raise/70 px-4 py-3.5">
      <div className="flex items-center gap-3">
        <div className="min-w-0 flex-1">
          <p className="text-[13px] font-bold text-white">Tes notifikasi HP ini</p>
          <p className="text-[11.5px] text-muted">Memeriksa izin dan menampilkan satu notifikasi uji.</p>
        </div>
        <button
          type="button"
          disabled={busy}
          onClick={() => void run()}
          className="shrink-0 rounded-full bg-white/10 px-4 py-2 text-[13px] font-bold text-white active:scale-95 disabled:opacity-40"
        >
          {busy ? '…' : 'Tes'}
        </button>
      </div>
      {info ? <p className="mt-2 whitespace-pre-line text-[12px] leading-snug text-white/75">{info}</p> : null}
    </div>
  )
}

function UserTab({ onClose }: { onClose: () => void }) {
  const me = useProfile()
  const { openProfile } = useNav()
  const [q, setQ] = useState('')
  const [busy, setBusy] = useState(false)
  const [found, setFound] = useState<FoundUser | null>(null)
  const [error, setError] = useState('')

  const search = async () => {
    setBusy(true)
    setError('')
    setFound(null)
    try {
      setFound(await findUserByUserId(me, q))
    } catch (e) {
      setError(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  const copy = async (text: string, label: string) => toast((await copyText(text)) ? `${label} disalin` : `Gagal menyalin ${label}`)

  return (
    <div className="space-y-4 px-4 pb-24 pt-5">
      <div>
        <label className="mb-1.5 block text-[13px] font-semibold text-muted">ID user (harus tepat)</label>
        <div className="flex gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && q.trim() && !busy) void search()
            }}
            inputMode="numeric"
            placeholder="contoh: 13"
            className="w-full rounded-2xl bg-raise px-4 py-3.5 text-[15px] text-white outline-none placeholder:text-muted"
          />
          <button
            type="button"
            disabled={busy || !q.trim()}
            onClick={() => void search()}
            className="shrink-0 rounded-2xl bg-accent px-5 text-[14px] font-bold text-ink active:scale-95 disabled:opacity-40"
          >
            {busy ? '…' : 'Cari'}
          </button>
        </div>
        <p className="mt-1.5 text-[11.5px] text-muted">Hanya hasil dengan ID yang sama persis yang ditampilkan; daftar semua user tidak tersedia.</p>
      </div>

      {error ? <p className="text-[13px] text-[#FF4D5E]">{error}</p> : null}

      {found ? (
        <div className="space-y-3 rounded-2xl bg-raise/70 px-4 py-4">
          <div>
            <p className="text-[11.5px] text-muted">Nama</p>
            <p className="text-[16px] font-bold text-white">
              {found.name} <span className="text-[12px] font-semibold text-muted">#{String(found.userId)}</span>
            </p>
          </div>
          <div>
            <p className="text-[11.5px] text-muted">UID</p>
            <button
              type="button"
              onClick={() => void copy(found.uid, 'UID')}
              className="mt-0.5 flex w-full items-center justify-between gap-2 rounded-xl bg-black/30 px-3 py-2.5 text-left active:bg-white/10"
            >
              <span className="min-w-0 break-all font-mono text-[12.5px] text-white">{found.uid}</span>
              <Icon name="copy" size={16} className="shrink-0 text-muted" />
            </button>
          </div>
          <button
            type="button"
            onClick={() => {
              onClose()
              openProfile(found.uid)
            }}
            className="w-full rounded-full bg-white/10 py-2.5 text-[13px] font-bold text-white active:scale-[0.98]"
          >
            Lihat profil
          </button>
        </div>
      ) : null}
    </div>
  )
}

const FIELD = 'w-full rounded-2xl bg-raise px-4 py-3.5 text-[15px] text-white outline-none placeholder:text-muted'

/** Kolom cari UID yang dipakai tab Shard, Ubah ID, dan Role. */
function UidSearch({ onFound }: { onFound: (t: AdminTarget | null) => void }) {
  const me = useProfile()
  const [uid, setUid] = useState('')
  const [busy, setBusy] = useState(false)
  const search = async () => {
    if (busy || !uid.trim()) return
    setBusy(true)
    try {
      onFound(await findTarget(me, uid))
    } catch (e) {
      onFound(null)
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  return (
    <div>
      <label className="mb-1.5 block text-[13px] font-semibold text-muted">UID user</label>
      <div className="flex gap-2">
        <input
          value={uid}
          onChange={(e) => setUid(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && void search()}
          placeholder="Tempel UID dari halaman Akun"
          className={FIELD}
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
        />
        <button
          type="button"
          disabled={busy || !uid.trim()}
          onClick={() => void search()}
          className="shrink-0 rounded-2xl bg-accent px-5 text-[14px] font-bold text-ink active:scale-95 disabled:opacity-40"
        >
          Cari
        </button>
      </div>
      <p className="mt-1.5 text-[11.5px] text-muted">UID bisa disalin dengan mengetuk baris UID di halaman Akun user tersebut.</p>
    </div>
  )
}

const fmtDate = (t: number) => new Date(t).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })

function TargetCard({ t, children }: { t: AdminTarget; children?: ReactNode }) {
  const active = !!t.premiumUntil && t.premiumUntil > Date.now()
  return (
    <div className="rounded-2xl bg-raise/70 px-4 py-3.5">
      <p className="truncate text-[15px] font-bold text-white">{t.name}</p>
      <p className="text-[12px] text-muted">
        #{t.userId ?? '?'} · role: <span className="font-bold text-white/80">{t.role}</span>
      </p>
      <div className="mt-2 flex items-center gap-2 text-[12.5px] text-white/70">
        Premium: {active ? <PremiumBadge size={9} /> : null}
        <span>{active ? `${remainingText(t.premiumUntil)} (sampai ${fmtDate(t.premiumUntil as number)})` : 'tidak aktif'}</span>
      </div>
      {children}
    </div>
  )
}

const PRESETS: { label: string; amount: number; unit: PremiumUnit }[] = [
  { label: '30 hari', amount: 30, unit: 'day' },
  { label: '2 bulan', amount: 2, unit: 'month' },
  { label: '3 bulan', amount: 3, unit: 'month' },
  { label: '6 bulan', amount: 6, unit: 'month' },
  { label: '1 tahun', amount: 1, unit: 'year' },
]

function ShardTab() {
  const me = useProfile()
  const [target, setTarget] = useState<AdminTarget | null>(null)
  const [mode, setMode] = useState<'shard' | 'premium'>('shard')
  const [amount, setAmount] = useState('')
  const [pAmount, setPAmount] = useState('30')
  const [pUnit, setPUnit] = useState<PremiumUnit>('day')
  const [busy, setBusy] = useState(false)
  const [confirmRevoke, setConfirmRevoke] = useState(false)

  const run = async (fn: () => Promise<void>) => {
    setBusy(true)
    try {
      await fn()
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  const reload = async (id: string) => setTarget(await findTarget(me, id))
  const n = Number(amount)
  const okNum = amount.trim() !== '' && Number.isInteger(n)
  const pn = Number(pAmount)
  const okP = pAmount.trim() !== '' && Number.isInteger(pn) && pn >= 1 && pn <= 3650
  const self = target?.uid === me.uid
  const activeUntil = target?.premiumUntil && target.premiumUntil > Date.now() ? target.premiumUntil : null
  const previewUntil = okP ? addDuration(activeUntil ?? Date.now(), pn, pUnit) : null

  const btn = 'flex-1 rounded-full py-3 text-[14px] font-bold active:scale-[0.98] disabled:opacity-40'
  const seg = (on: boolean) => `flex-1 rounded-full py-2.5 text-[14px] font-extrabold ${on ? 'bg-accent text-ink' : 'text-muted'}`

  return (
    <div className="space-y-4 px-4 pb-24 pt-5">
      <UidSearch onFound={setTarget} />

      {target ? (
        <>
          <TargetCard t={target}>
            <p className="mt-2 text-[13px] text-white/70">
              AkimiShard saat ini: <span className="text-[16px] font-extrabold text-[#8EC5FF]">{fmtNum(target.shard)}</span>
            </p>
          </TargetCard>

          <div className="flex rounded-full border border-white/10 bg-white/[0.04] p-1.5">
            <button type="button" className={seg(mode === 'shard')} onClick={() => setMode('shard')}>
              Shard
            </button>
            <button type="button" className={seg(mode === 'premium')} onClick={() => setMode('premium')}>
              Premium
            </button>
          </div>

          {mode === 'shard' ? (
            <>
              <div>
                <label className="mb-1.5 block text-[13px] font-semibold text-muted">Jumlah</label>
                <input value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9-]/g, ''))} inputMode="numeric" placeholder="contoh: 50" className={FIELD} />
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={busy || !okNum || n === 0}
                  className={`${btn} bg-accent text-ink`}
                  onClick={() =>
                    void run(async () => {
                      const v = await addShard(me, target.uid, n)
                      setTarget({ ...target, shard: v })
                      setAmount('')
                      toast(`Shard sekarang ${fmtNum(v)}`)
                    })
                  }
                >
                  {busy ? 'Memproses…' : n < 0 ? 'Kurangi' : 'Tambah'}
                </button>
                <button
                  type="button"
                  disabled={busy || !okNum || n < 0}
                  className={`${btn} bg-white/10 text-white`}
                  onClick={() =>
                    void run(async () => {
                      await setShard(me, target.uid, n)
                      await reload(target.uid)
                      setAmount('')
                      toast('Shard diatur')
                    })
                  }
                >
                  Atur ke angka
                </button>
              </div>
            </>
          ) : (
            <>
              {self ? <p className="rounded-2xl bg-white/[0.06] px-4 py-3 text-[13px] text-[#FF8A9A]">Premium tidak bisa diberikan ke akun sendiri.</p> : null}
              <p className="text-[12px] leading-snug text-muted">
                Premium tidak mengubah role. Badge, centang, dan warna nama Premium hanya tampil bila role orang itu <b>user</b> biasa; role lain tetap dengan tampilannya, masa Premium tetap berjalan.
              </p>
              <div>
                <label className="mb-1.5 block text-[13px] font-semibold text-muted">Pilih cepat</label>
                <div className="flex flex-wrap gap-2">
                  {PRESETS.map((p) => (
                    <button
                      key={p.label}
                      type="button"
                      onClick={() => {
                        setPAmount(String(p.amount))
                        setPUnit(p.unit)
                      }}
                      className={`rounded-full px-4 py-2 text-[13px] font-bold ${pn === p.amount && pUnit === p.unit ? 'bg-[#2E8BFF] text-white' : 'bg-white/10 text-white/80'}`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-[13px] font-semibold text-muted">Atur sendiri</label>
                <div className="flex gap-2">
                  <input value={pAmount} onChange={(e) => setPAmount(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))} inputMode="numeric" placeholder="jumlah" className={`${FIELD} w-28 shrink-0`} />
                  <div className="flex flex-1 rounded-2xl bg-raise p-1">
                    {(Object.keys(PREMIUM_UNIT_LABEL) as PremiumUnit[]).map((u) => (
                      <button key={u} type="button" onClick={() => setPUnit(u)} className={`flex-1 rounded-xl text-[13.5px] font-bold ${pUnit === u ? 'bg-[#2E8BFF] text-white' : 'text-muted'}`}>
                        {PREMIUM_UNIT_LABEL[u]}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="mt-1.5 text-[12px] text-muted">
                  {previewUntil
                    ? `${activeUntil ? 'Ditambahkan di belakang masa aktif. ' : ''}Berlaku sampai ${fmtDate(previewUntil)}.`
                    : 'Isi jumlah 1 sampai 3650. Total maksimal 10 tahun dari sekarang.'}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={busy || !okP || self}
                  className={`${btn} bg-[#2E8BFF] text-white`}
                  onClick={() =>
                    void run(async () => {
                      const t = await grantPremium(me, target.uid, pn, pUnit)
                      setTarget(t)
                      toast(`Premium aktif, sisa ${remainingText(t.premiumUntil)}`)
                    })
                  }
                >
                  {busy ? 'Memproses…' : activeUntil ? 'Perpanjang Premium' : 'Berikan Premium'}
                </button>
                <button
                  type="button"
                  disabled={busy || self || !target.premiumUntil}
                  className={`${btn} bg-[#E5484D]/90 text-white`}
                  onClick={() => setConfirmRevoke(true)}
                >
                  Cabut
                </button>
              </div>
            </>
          )}
          <ConfirmDialog
            open={confirmRevoke}
            title={`Cabut Premium ${target.name}?`}
            message="Premium langsung berakhir dan badge Premium hilang. Masa yang tersisa tidak dikembalikan."
            confirmLabel="Cabut Premium"
            onConfirm={() =>
              void run(async () => {
                setConfirmRevoke(false)
                setTarget(await revokePremium(me, target.uid))
                toast('Premium dicabut')
              })
            }
            onCancel={() => setConfirmRevoke(false)}
          />
        </>
      ) : null}
    </div>
  )
}

/** Ubah User ID publik (#nomor): cari UID, ketik ID baru, tekan Enter. */
function IdTab() {
  const me = useProfile()
  const [target, setTarget] = useState<AdminTarget | null>(null)
  const [raw, setRaw] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async () => {
    if (!target || busy || !raw.trim()) return
    setBusy(true)
    try {
      const before = target.userId
      const t = await changeUserId(me, target.uid, raw)
      setTarget(t)
      setRaw('')
      toast(`ID diubah: #${before ?? '?'} → #${t.userId}`)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className="space-y-4 px-4 pb-24 pt-5">
      <UidSearch onFound={setTarget} />
      {target ? (
        <>
          <TargetCard t={target} />
          <div>
            <label className="mb-1.5 block text-[13px] font-semibold text-muted">ID baru</label>
            <div className="flex gap-2">
              <input
                value={raw}
                onChange={(e) => setRaw(e.target.value.replace(/[^0-9#]/g, '').slice(0, 10))}
                onKeyDown={(e) => e.key === 'Enter' && void submit()}
                inputMode="numeric"
                enterKeyHint="done"
                placeholder="contoh: #10"
                className={FIELD}
              />
              <button type="button" disabled={busy || !raw.trim()} onClick={() => void submit()} className="shrink-0 rounded-2xl bg-accent px-5 text-[14px] font-bold text-ink active:scale-95 disabled:opacity-40">
                {busy ? '…' : 'Ubah'}
              </button>
            </div>
            <p className="mt-1.5 text-[12px] leading-snug text-muted">
              ID harus belum dipakai dan tidak lebih besar dari jumlah ID yang sudah dibagikan saat pendaftaran. Pesan dan komentar lama tetap menampilkan ID lama; yang baru memakai ID baru.
            </p>
          </div>
        </>
      ) : null}
    </div>
  )
}

/** Ganti role: cari UID, ketik teks role, tekan Enter. */
function RoleTab() {
  const me = useProfile()
  const [target, setTarget] = useState<AdminTarget | null>(null)
  const [raw, setRaw] = useState('')
  const [busy, setBusy] = useState(false)
  const self = target?.uid === me.uid
  const submit = async () => {
    if (!target || busy || !raw.trim() || self) return
    setBusy(true)
    try {
      const r = await changeRole(me, target.uid, raw)
      setTarget(r.target)
      setRaw('')
      toast(r.note ?? `Role sekarang ${r.target.role}`)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className="space-y-4 px-4 pb-24 pt-5">
      <UidSearch onFound={setTarget} />
      {target ? (
        <>
          <TargetCard t={target} />
          {self ? <p className="rounded-2xl bg-white/[0.06] px-4 py-3 text-[13px] text-[#FF8A9A]">Role akun sendiri tidak bisa diubah dari sini.</p> : null}
          <div>
            <label className="mb-1.5 block text-[13px] font-semibold text-muted">Teks role</label>
            <div className="flex gap-2">
              <input
                value={raw}
                onChange={(e) => setRaw(e.target.value.slice(0, 20))}
                onKeyDown={(e) => e.key === 'Enter' && void submit()}
                enterKeyHint="done"
                placeholder="contoh: moderator"
                className={FIELD}
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                disabled={self}
              />
              <button type="button" disabled={busy || !raw.trim() || self} onClick={() => void submit()} className="shrink-0 rounded-2xl bg-accent px-5 text-[14px] font-bold text-ink active:scale-95 disabled:opacity-40">
                {busy ? '…' : 'Ubah'}
              </button>
            </div>
            <div className="mt-2.5 flex flex-wrap gap-1.5">
              {ASSIGNABLE_ROLES.map((r) => (
                <button key={r} type="button" disabled={self} onClick={() => setRaw(r)} className="rounded-full bg-white/10 px-3 py-1.5 text-[12.5px] font-bold text-white/80 active:scale-95 disabled:opacity-40">
                  {r}
                </button>
              ))}
            </div>
            <p className="mt-2 text-[12px] leading-snug text-muted">Premium bukan role: berikan lewat tab Shard → Premium. Role orang tidak berubah.</p>
          </div>
        </>
      ) : null}
    </div>
  )
}

/** Semua clan; ketuk satu untuk melihat detail dan menghapusnya. Penghapusan dijaga di UI dan di Security Rules (role developer). */
function ClanTab() {
  const me = useProfile()
  const clans = useTopClans(500)
  const [q, setQ] = useState('')
  const [sel, setSel] = useState<Clan | null>(null)
  const [confirm, setConfirm] = useState(false)
  const [busy, setBusy] = useState(false)

  const needle = q.trim().toLowerCase()
  const list = (clans ?? []).filter((c) => !needle || c.nameLower.includes(needle) || c.tag.toLowerCase().includes(needle))
  const col = sel ? clanColorOf(sel.color) : null

  const del = async () => {
    if (!sel || busy) return
    setBusy(true)
    try {
      await adminDeleteClan(me, sel)
      toast(`Clan ${sel.name} dihapus`)
      setConfirm(false)
      setSel(null)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-3 pb-10">
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Cari nama atau tag clan"
        className="w-full rounded-2xl bg-raise px-4 py-3.5 text-[15px] text-white outline-none placeholder:text-muted"
        autoCapitalize="off"
        autoCorrect="off"
        spellCheck={false}
      />
      <p className="text-[12px] text-muted">{clans === undefined ? 'Memuat…' : `${list.length} clan${needle ? ' cocok' : ''}`}</p>
      {clans !== undefined && list.length === 0 ? <p className="py-10 text-center text-[14px] text-muted">Tidak ada clan.</p> : null}
      <div className="space-y-2">
        {list.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setSel(c)}
            className="flex w-full items-center gap-3 rounded-2xl bg-raise/70 px-3.5 py-3 text-left active:scale-[0.99]"
          >
            <ClanBadge tag={c.tag} color={c.color} emblem={c.emblem} tier={c.tier} height={30} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[15px] font-bold text-white">{c.name}</p>
              <p className="text-[12px] text-muted">
                {c.members} anggota · {fmtNum(c.xp)} XP
              </p>
            </div>
            <Icon name="chevron" size={18} className="shrink-0 text-muted" />
          </button>
        ))}
      </div>

      <Sheet open={!!sel && !confirm} onClose={() => setSel(null)} title="Detail clan">
        {sel && col ? (
          <div className="space-y-4 px-5 pb-6">
            <div className="flex justify-center py-1">
              <ClanBadge tag={sel.tag} color={sel.color} emblem={sel.emblem} tier={sel.tier} height={40} />
            </div>
            <div className="space-y-1.5 rounded-2xl bg-white/[0.05] px-4 py-3 text-[13.5px]">
              <p className="text-[16px] font-extrabold text-white">{sel.name}</p>
              <p className="text-muted">Tag: <span className="font-bold text-white">{sel.tag}</span></p>
              <p className="text-muted">Warna: <span className="font-bold text-white">{col.name} ({RARITY_LABEL[col.rarity]})</span></p>
              <p className="text-muted">Tier: <span className="font-bold text-white">{sel.tier}</span></p>
              <p className="text-muted">Anggota: <span className="font-bold text-white">{sel.members}</span> / {sel.slots} slot</p>
              <p className="text-muted">XP total: <span className="font-bold text-white">{fmtNum(sel.xp)}</span></p>
              <p className="break-all text-[11.5px] text-muted">ID: {sel.id}</p>
              <p className="break-all text-[11.5px] text-muted">Leader UID: {sel.leaderUid}</p>
            </div>
            <button
              type="button"
              onClick={() => setConfirm(true)}
              className="w-full rounded-full bg-[#E5484D] py-3.5 text-[15px] font-extrabold text-white active:scale-[0.98]"
            >
              Hapus clan
            </button>
          </div>
        ) : null}
      </Sheet>

      <ConfirmDialog
        open={confirm && !!sel}
        title={`Hapus clan ${sel?.name ?? ''}?`}
        message={`Clan, ${sel?.members ?? 0} anggota, koleksi warna, dan tag ${sel?.tag ?? ''} akan dihapus permanen. Shard yang sudah dipakai tidak dikembalikan. Tindakan ini tidak bisa dibatalkan.`}
        confirmLabel={busy ? 'Menghapus…' : 'Hapus permanen'}
        onConfirm={() => void del()}
        onCancel={() => setConfirm(false)}
      />
    </div>
  )
}

function BannedTab() {
  return (
    <div className="flex flex-col items-center px-6 pt-16 text-center">
      <Icon name="shield" size={36} className="text-muted" />
      <p className="mt-3 text-[15px] font-semibold text-white">Fitur Banned segera hadir</p>
      <p className="mt-1 text-[12.5px] leading-snug text-muted">Fitur Notif dikerjakan lebih dulu.</p>
    </div>
  )
}
