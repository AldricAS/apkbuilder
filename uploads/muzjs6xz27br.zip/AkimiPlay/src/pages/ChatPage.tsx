import { useEffect, useLayoutEffect, useRef, useState, type PointerEvent as RPointerEvent } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import {
  CHAT_KEEP,
  CHAT_MAX,
  deleteChat,
  sendChat,
  subscribeChat,
  subscribeConnected,
  subscribeOnlineCount,
  type ChatMessage,
} from '../services/chatService'
import { timeAgo } from '../lib/format'
import { liveOf, useLiveUsers } from '../services/liveProfiles'
import { Avatar, UserLine } from '../components/UserBadges'
import { Icon } from '../components/Icon'
import { Spinner } from '../components/States'
import { Sheet, toast } from '../components/Feedback'
import { GiveawayCard, GiveawaySheet, TicketIcon } from '../components/GiveawayUi'


const SWIPE_TRIGGER = 56
const SWIPE_MAX = 84

function Bubble({
  m: raw,
  own,
  onLong,
  onReply,
}: {
  m: ChatMessage
  own: boolean
  onLong: (m: ChatMessage) => void
  onReply: (m: ChatMessage) => void
}) {
  const nav = useNav()
  // identitas selalu terbaru (level, role, nama, foto), walau pesan dikirim saat data masih lama
  const live = useLiveUsers([raw.uid])
  const m = liveOf(raw, live.get(raw.uid))

  // geser ke kanan = balas pesan ini
  const [dx, setDx] = useState(0)
  const [dragging, setDragging] = useState(false)
  const gesture = useRef<{ x: number; y: number; lock: 'h' | 'v' | null; crossed: boolean } | null>(null)
  const suppressClick = useRef(false)

  const onDown = (e: RPointerEvent<HTMLDivElement>) => {
    gesture.current = { x: e.clientX, y: e.clientY, lock: null, crossed: false }
  }
  const onMove = (e: RPointerEvent<HTMLDivElement>) => {
    const g = gesture.current
    if (!g) return
    const mx = e.clientX - g.x
    const my = e.clientY - g.y
    if (!g.lock && (Math.abs(mx) > 8 || Math.abs(my) > 8)) {
      g.lock = mx > 0 && Math.abs(mx) > Math.abs(my) * 1.3 ? 'h' : 'v'
      if (g.lock === 'h') {
        setDragging(true)
        e.currentTarget.setPointerCapture(e.pointerId)
      }
    }
    if (g.lock === 'h') {
      const v = Math.min(Math.max(mx, 0), SWIPE_MAX * 1.6) // sedikit tahanan di ujung
      const shown = v > SWIPE_MAX ? SWIPE_MAX + (v - SWIPE_MAX) * 0.2 : v
      setDx(shown)
      if (!g.crossed && mx >= SWIPE_TRIGGER) {
        g.crossed = true
        navigator.vibrate?.(12)
      } else if (g.crossed && mx < SWIPE_TRIGGER) {
        g.crossed = false
      }
    }
  }
  const onEnd = (e: RPointerEvent<HTMLDivElement>) => {
    const g = gesture.current
    gesture.current = null
    if (g?.lock === 'h') {
      suppressClick.current = true
      setTimeout(() => (suppressClick.current = false), 0)
      if (e.clientX - g.x >= SWIPE_TRIGGER) onReply(m)
    }
    setDragging(false)
    setDx(0)
  }

  const q = m.replyTo
  const progress = Math.min(1, dx / SWIPE_TRIGGER)

  return (
    <div id={`msg-${raw.id}`} className="relative rounded-2xl transition-colors duration-500">
      <span
        className="pointer-events-none absolute left-1 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-accent/20 text-accent"
        style={{ opacity: progress, transform: `translateY(-50%) scale(${0.6 + 0.4 * progress})` }}
      >
        <Icon name="reply" size={17} />
      </span>
      <div
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onEnd}
        onPointerCancel={onEnd}
        style={{ transform: `translateX(${dx}px)`, transition: dragging ? 'none' : 'transform .22s ease-out', touchAction: 'pan-y' }}
        className={`flex items-end gap-2 ${own ? 'flex-row-reverse' : ''}`}
      >
        <button type="button" aria-label={`Lihat profil ${m.name}`} onClick={() => nav.openProfile(m.uid)} className="shrink-0 self-start active:scale-95">
          <Avatar url={m.photoURL} name={m.name} size={34} />
        </button>
        <div className="min-w-0 flex-1">
        <button
          type="button"
          onContextMenu={(e) => {
            e.preventDefault()
            onLong(raw)
          }}
          onClick={() => {
            if (!suppressClick.current) onLong(raw)
          }}
          className={`block w-full min-w-0 rounded-2xl px-3.5 py-2.5 text-left ${own ? 'bg-accent/15 ring-1 ring-accent/30' : 'bg-raise'}`}
        >
          <UserLine name={m.name} userId={m.userId} role={m.role} verified={m.verified} level={m.level} clanTag={m.clanTag} size="sm" onProfile={() => nav.openProfile(m.uid)} />
          {q ? (
            <span
              role="button"
              tabIndex={0}
              onClick={(e) => {
                e.stopPropagation()
                const el = document.getElementById(`msg-${q.id}`)
                if (!el) return toast('Pesan asli sudah tidak ada di daftar')
                el.scrollIntoView({ block: 'center', behavior: 'smooth' })
                el.classList.add('bg-accent/20')
                setTimeout(() => el.classList.remove('bg-accent/20'), 1200)
              }}
              className="mt-2 block rounded-xl border-l-[3px] border-accent bg-black/25 px-2.5 py-1.5"
            >
              <span className="block truncate text-[12px] font-bold text-accent">{q.name}</span>
              <span className="line-clamp-2 break-words text-[12.5px] leading-snug text-white/70">{q.text}</span>
            </span>
          ) : null}
          <p className="mt-2 whitespace-pre-wrap break-words text-[15px] leading-snug text-white">{m.text}</p>
          <p className="mt-1.5 text-[11px] text-muted">{timeAgo(m.ts)}</p>
        </button>
        {m.gid ? <GiveawayCard gid={m.gid} /> : null}
        </div>
      </div>
    </div>
  )
}

export function ChatPage() {
  const nav = useNav()
  const me = useProfile()
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [ready, setReady] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const [connected, setConnected] = useState(true)
  const [online, setOnline] = useState(0)
  const [selected, setSelected] = useState<ChatMessage | null>(null)
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null)
  const [giveaway, setGiveaway] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const [, force] = useState(0)

  const scroller = useRef<HTMLDivElement>(null)
  const stick = useRef(true)
  const lastSend = useRef(0)

  // realtime: pesan baru masuk tanpa refresh
  useEffect(() => {
    const unsub = subscribeChat(
      CHAT_KEEP,
      (m) => {
        setReady(true)
        setMessages((list) => (list.some((x) => x.id === m.id) ? list.map((x) => (x.id === m.id ? m : x)) : [...list, m].sort((a, b) => a.ts - b.ts)))
      },
      (id) => setMessages((list) => list.filter((x) => x.id !== id)),
      (e) => {
        setReady(true)
        setError(e.message)
      },
    )
    const t = setTimeout(() => setReady(true), 2500)
    const offConn = subscribeConnected(setConnected)
    const offCount = subscribeOnlineCount(setOnline)
    const tick = setInterval(() => force((n) => n + 1), 30000) // segarkan "x menit lalu"
    return () => {
      unsub()
      offConn()
      offCount()
      clearTimeout(t)
      clearInterval(tick)
    }
  }, [])

  // scroll: tetap di bawah untuk pesan baru
  useLayoutEffect(() => {
    const el = scroller.current
    if (!el) return
    if (stick.current) {
      el.scrollTop = el.scrollHeight
    }
  }, [messages])

  const onScroll = () => {
    const el = scroller.current
    if (!el) return
    stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80
  }

  const send = async () => {
    const value = text.trim()
    if (!value || sending) return
    if (Date.now() - lastSend.current < 1000) {
      toast('Tunggu sebentar sebelum mengirim lagi')
      return
    }
    setSending(true)
    try {
      lastSend.current = Date.now()
      await sendChat(
        me,
        value,
        replyTo ? { id: replyTo.id, uid: replyTo.uid, name: replyTo.name, text: replyTo.text } : null,
      )
      setReplyTo(null)
      setText('')
      stick.current = true
    } catch {
      toast('Pesan gagal dikirim')
    } finally {
      setSending(false)
    }
  }

  const canDelete = selected && (selected.uid === me.uid || me.role === 'admin' || me.role === 'moderator' || me.role === 'developer')

  return (
    <div className="absolute inset-0 flex flex-col bg-ink">
      <header className="pt-safe shrink-0 bg-ink">
        <div className="flex h-14 items-center gap-2 px-3">
          <button
            type="button"
            aria-label="Kembali"
            onClick={nav.pop}
            className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"
          >
            <Icon name="back" size={24} />
          </button>
          <h1 className="flex-1 text-[19px] font-bold tracking-tight text-white">Public Diskusi</h1>
          <span
            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-semibold ring-1 ${
              connected ? 'bg-[#10301f] text-[#4ade80] ring-[#1f6b41]' : 'bg-[#301014] text-[#f87171] ring-[#6b1f27]'
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${connected ? 'bg-[#4ade80]' : 'bg-[#f87171]'}`} />
            {connected ? `Online${online ? ` · ${online}` : ''}` : 'Offline'}
          </span>
        </div>
        <div className="h-px bg-line" />
      </header>

      <div ref={scroller} onScroll={onScroll} className="flex-1 space-y-3 overflow-y-auto px-3 py-3">
        <p className="pb-1 text-center text-[11.5px] text-muted">Hanya {CHAT_KEEP} pesan terakhir yang disimpan.</p>
        {!ready ? (
          <div className="flex justify-center py-20">
            <Spinner size={28} />
          </div>
        ) : null}
        {error ? (
          <p className="rounded-2xl bg-[#2a1720] px-4 py-3 text-center text-[12.5px] text-accent">
            Chat tidak bisa dimuat: {error}
          </p>
        ) : null}
        {ready && !messages.length && !error ? (
          <p className="py-20 text-center text-[13.5px] text-muted">Belum ada pesan. Jadilah yang pertama menyapa!</p>
        ) : null}
        {messages.map((m) => (
          <Bubble
            key={m.id}
            m={m}
            own={m.uid === me.uid}
            onLong={setSelected}
            onReply={(msg) => {
              setReplyTo(msg)
              inputRef.current?.focus()
            }}
          />
        ))}
      </div>

      <div className="shrink-0 border-t border-line bg-ink px-3 pb-3 pt-2" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 12px)' }}>
        {replyTo ? (
          <div className="mb-2 flex animate-fadeIn items-center gap-2 rounded-xl border-l-[3px] border-accent bg-raise px-3 py-1.5">
            <Icon name="reply" size={15} className="shrink-0 text-accent" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12px] font-bold text-accent">Membalas {replyTo.name}</p>
              <p className="truncate text-[12px] text-white/65">{replyTo.text}</p>
            </div>
            <button type="button" aria-label="Batal membalas" onClick={() => setReplyTo(null)} className="shrink-0 p-1 active:opacity-70">
              <Icon name="x" size={16} />
            </button>
          </div>
        ) : null}
        <div className="flex items-center gap-2">
          <Avatar url={me.photoURL} name={me.username || me.displayName} size={36} />
          <input
            ref={inputRef}
            value={text}
            maxLength={CHAT_MAX}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && void send()}
            placeholder="Ketik pesan..."
            enterKeyHint="send"
            className="h-11 min-w-0 flex-1 rounded-full bg-raise px-4 text-[14.5px] text-white placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
          />
          <button
            type="button"
            aria-label="Sebar Premium"
            onClick={() => setGiveaway(true)}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-[#2B1B00] active:scale-90"
            style={{ background: 'linear-gradient(135deg, #FF7AA2, #F4C96B)' }}
          >
            <TicketIcon size={22} />
          </button>
          <button
            type="button"
            aria-label="Kirim"
            disabled={!text.trim() || sending}
            onClick={() => void send()}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-accent text-ink active:scale-90 disabled:bg-raise disabled:text-white/30"
          >
            {sending ? <Spinner size={18} /> : <Icon name="send" size={19} />}
          </button>
        </div>
      </div>

      <GiveawaySheet open={giveaway} onClose={() => setGiveaway(false)} />
      <Sheet open={!!selected} onClose={() => setSelected(null)} title={selected?.name}>
        <p className="mb-4 whitespace-pre-wrap break-words text-[13.5px] text-white/80">{selected?.text}</p>
        <button
          type="button"
          onClick={() => {
            if (selected) {
              setReplyTo(selected)
              inputRef.current?.focus()
            }
            setSelected(null)
          }}
          className="mb-2 flex w-full items-center justify-center gap-2 rounded-full bg-raise py-3 text-[14px] font-semibold text-white active:scale-[0.98]"
        >
          <Icon name="reply" size={17} /> Balas pesan
        </button>
        {canDelete ? (
          <button
            type="button"
            onClick={() => {
              const id = selected!.id
              setSelected(null)
              deleteChat(id).catch(() => toast('Tidak bisa menghapus pesan'))
            }}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-raise py-3 text-[14px] font-semibold text-accent active:scale-[0.98]"
          >
            <Icon name="trash" size={17} /> Hapus pesan
          </button>
        ) : (
          <p className="text-[12.5px] text-muted">Kamu hanya bisa menghapus pesanmu sendiri.</p>
        )}
      </Sheet>
    </div>
  )
}
