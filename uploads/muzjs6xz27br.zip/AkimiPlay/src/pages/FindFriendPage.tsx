import { useState } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { lookupByUserId } from '../services/friendService'
import type { UserProfile } from '../services/userService'
import { errMsg } from '../lib/format'
import { Avatar, ClanPill, LevelPill, RoleCheck } from '../components/UserBadges'
import { FriendButton } from '../components/FriendButton'
import { PageHeader } from '../components/PageHeader'
import { EmptyState, Spinner } from '../components/States'

type Result =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'found'; user: UserProfile }
  | { status: 'none' }
  | { status: 'error'; message: string }

export function FindFriendPage() {
  const nav = useNav()
  const me = useProfile()
  const [input, setInput] = useState('')
  const [res, setRes] = useState<Result>({ status: 'idle' })

  const search = async () => {
    if (res.status === 'loading' || !input.trim()) return
    setRes({ status: 'loading' })
    try {
      const user = await lookupByUserId(me, input)
      setRes(user ? { status: 'found', user } : { status: 'none' })
    } catch (e) {
      setRes({ status: 'error', message: errMsg(e) })
    }
  }

  return (
    <div className="absolute inset-0 overflow-y-auto bg-[#0E1019] pb-16">
      <PageHeader title="Cari Teman" onBack={nav.pop} />

      <div className="flex items-center gap-2.5 px-4 pt-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && void search()}
          placeholder="User ID"
          enterKeyHint="search"
          autoComplete="off"
          autoCapitalize="off"
          maxLength={17}
          className="h-[54px] min-w-0 flex-1 rounded-full border border-white/10 bg-[#151925] px-5 text-[16px] text-white placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
        />
        <button
          type="button"
          disabled={!input.trim() || res.status === 'loading'}
          onClick={() => void search()}
          className="flex h-[54px] w-[84px] shrink-0 items-center justify-center whitespace-nowrap rounded-full bg-accent text-[15px] font-bold text-ink active:scale-95 disabled:bg-white/10 disabled:text-white/40"
        >
          {res.status === 'loading' ? <Spinner size={18} /> : 'Cari'}
        </button>
      </div>

      <div className="px-4 pt-5">
        {res.status === 'found' ? (
          <FoundCard user={res.user} isMe={res.user.uid === me.uid} />
        ) : res.status === 'none' ? (
          <EmptyState icon="user" title="User tidak ditemukan." hint="Periksa kembali User ID. Jika sudah benar, minta pemilik akun menutup lalu membuka aplikasi sekali (versi terbaru) agar ID-nya bisa dicari." />
        ) : res.status === 'error' ? (
          <p className="rounded-2xl bg-[#2a1720] px-4 py-3 text-[13px] text-accent">{res.message}</p>
        ) : res.status === 'idle' ? (
          <p className="px-1 text-[13px] leading-snug text-muted">Masukkan User ID teman, contoh 1470 atau #1470.</p>
        ) : null}
      </div>
    </div>
  )
}

function FoundCard({ user, isMe }: { user: UserProfile; isMe: boolean }) {
  const nav = useNav()
  return (
    <div className="rounded-3xl border border-white/[0.07] bg-raise/70 p-4">
      <button type="button" onClick={() => nav.openProfile(user.uid)} className="flex w-full items-center gap-3.5 text-left active:opacity-80">
        <Avatar url={user.photoURL} name={user.username?.trim() || user.displayName} size={64} />
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-1.5">
            <span className="min-w-0 truncate text-[17px] font-bold text-white">{user.username?.trim() || user.displayName}</span>
            <RoleCheck role={user.role} verified={user.verified} size={17} />
          </span>
          <span className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <LevelPill level={user.level} />
            <ClanPill tag={user.clanTag} />
            <span className="text-[12.5px] font-semibold text-muted">#{user.userId}</span>
          </span>
        </span>
      </button>
      <div className="mt-4">
        {isMe ? <p className="text-center text-[13px] text-muted">Ini akun kamu.</p> : <FriendButton uid={user.uid} variant="pill" />}
      </div>
    </div>
  )
}
