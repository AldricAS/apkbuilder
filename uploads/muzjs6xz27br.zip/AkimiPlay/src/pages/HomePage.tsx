import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { animeApi } from '../services/animeApi'
import { useAsync, useOnline } from '../hooks/hooks'
import { useNav } from '../nav/router'
import { historyStore, useStore } from '../storage/stores'
import { useAuth } from '../auth/AuthProvider'
import { subscribeLatest, type ChatMessage } from '../services/chatService'
import { fmtNum, xpProgress } from '../lib/xp'
import { Avatar, LevelPill, RoleCheck, nameColor } from '../components/UserBadges'
import type { Anime, AnimeLite } from '../types'
import { errMsg, fmtCount, fmtTime, statusLabel } from '../lib/format'
import { AnimeCard } from '../components/AnimeCard'
import { AnimeRow, GridSkeleton, RowSkeleton } from '../components/Section'
import { PagedGrid } from '../components/PagedGrid'
import { ErrorState } from '../components/States'
import { Icon } from '../components/Icon'
import { Poster } from '../components/Poster'
import { CrownIcon, SparkIcon, SparklesIcon } from '../components/LeaderboardUi'
import { isPremiumActive } from '../services/userService'
import { LeaderboardBanner } from '../components/LeaderboardBanner'
import { DownloadedRow, DownloadsHome } from './DownloadsPage'

function uniq(list: Anime[]): Anime[] {
  const seen = new Set<string>()
  return list.filter((a) => (seen.has(a.id) ? false : (seen.add(a.id), true)))
}

function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="flex items-center justify-between px-4">
      <h2 className="text-[18px] font-bold tracking-tight text-white">{title}</h2>
      {action ? (
        <button type="button" onClick={onAction} className="flex items-center gap-0.5 text-[12px] font-semibold text-accent active:opacity-70">
          {action} <Icon name="chevron" size={14} />
        </button>
      ) : null}
    </div>
  )
}

function GridSection({
  title,
  action,
  onAction,
  items,
  tag,
  limit = 9,
  onOpen,
}: {
  title: string
  action?: string
  onAction?: () => void
  items: Anime[]
  tag?: string | ((a: Anime) => string | undefined)
  limit?: number
  onOpen: (a: AnimeLite) => void
}) {
  if (!items.length) return null
  return (
    <section className="mt-6">
      <SectionHeader title={title} action={action} onAction={onAction} />
      <div className="mt-2.5 grid grid-cols-3 gap-x-2.5 gap-y-4 px-4">
        {items.slice(0, limit).map((a) => (
          <AnimeCard key={a.id} anime={a} variant="grid" tag={typeof tag === 'function' ? tag(a) : tag} onOpen={onOpen} />
        ))}
      </div>
    </section>
  )
}

const NEW_MIN_SCORE = 7
const NEW_SHOW = 20

/**
 * "NEW anime update": anime yang BARU dapat episode (urut dari update terbaru), hanya yang bagus
 * (skor >= 7; kalau API tidak memberi skor sama sekali, pakai yang paling banyak ditonton), dan hanya yang
 * episodenya benar-benar ada. Anime tanpa episode tidak ditampilkan. Label di poster = nomor episode terbaru.
 */
type NewUpdate = { anime: Anime; ep: number }

async function loadNewUpdates(fromHome: Anime[]): Promise<NewUpdate[]> {
  const pages = await Promise.allSettled([0, 1, 2, 3, 4].map((page) => animeApi.search({ status: 'ONGOING', sort: 'latest', page })))
  const fetched = pages.flatMap((r) => (r.status === 'fulfilled' ? r.value.items : []))
  const pool = uniq([...fetched, ...fromHome]).filter((a) => a.poster && a.status !== 'WAITING')

  let good: Anime[]
  if (pool.some((a) => a.score !== undefined)) {
    good = pool.filter((a) => (a.score ?? 0) >= NEW_MIN_SCORE)
  } else {
    const v = pool.map((a) => a.views ?? 0).sort((a, b) => a - b)
    const med = v[Math.floor(v.length / 2)] ?? 0
    good = pool.filter((a) => (a.views ?? 0) > med)
  }

  const out: NewUpdate[] = []
  const cand = good.slice(0, 60)
  for (let i = 0; i < cand.length && out.length < NEW_SHOW; i += 6) {
    const batch = cand.slice(i, i + 6)
    const res = await Promise.allSettled(batch.map((a) => animeApi.episodes(a.id)))
    res.forEach((r, k) => {
      if (r.status !== 'fulfilled' || !r.value.length) return // belum ada episode: jangan tampilkan
      const ep = Math.max(...r.value.map((e) => e.number))
      if (Number.isFinite(ep) && ep > 0) out.push({ anime: batch[k], ep })
    })
  }
  return out.slice(0, NEW_SHOW)
}

function NewUpdateSection({ items, loading, onOpen }: { items: NewUpdate[]; loading: boolean; onOpen: (a: AnimeLite) => void }) {
  if (loading && !items.length) return <RowSkeleton title="" />
  if (!items.length) return null
  return (
    <section className="mt-6">
      <div className="px-4">
        <h2 className="flex items-baseline gap-1.5 leading-none">
          <span className="text-[26px] font-black tracking-tight text-accent">NEW</span>
          <span className="text-[14px] font-bold tracking-tight text-white">anime update</span>
        </h2>
      </div>
      <div className="mt-2.5 grid grid-cols-3 gap-x-2.5 gap-y-4 px-4">
        {items.map(({ anime, ep }) => (
          <AnimeCard key={anime.id} anime={anime} variant="grid" badge={`Ep ${ep}`} onOpen={onOpen} />
        ))}
      </div>
    </section>
  )
}

function ProfileCard() {
  const nav = useNav()
  const { profile } = useAuth()
  if (!profile) return null
  const name = profile.username?.trim() || profile.displayName
  const xp = xpProgress(profile.xp)
  return (
    <div className="mx-4 mt-1 rounded-2xl bg-gradient-to-br from-raise to-panel px-3.5 py-3 ring-1 ring-line">
      <button type="button" onClick={() => nav.setTab('account')} className="flex w-full items-center gap-3 text-left active:opacity-80">
        <Avatar url={profile.photoURL} name={name} size={44} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <p className="truncate text-[15px] font-bold leading-tight text-white">{name}</p>
            <RoleCheck role={profile.role} verified={profile.verified} size={13} />
            <span className="shrink-0 text-[11px] text-muted">#{profile.userId}</span>
          </div>
          <div className="mt-1 flex items-center gap-2">
            <LevelPill level={xp.level} />
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-accent" style={{ width: `${xp.ratio * 100}%` }} />
            </div>
          </div>
        </div>
        <Icon name="chevron" size={16} className="text-muted" />
      </button>
      <div className="mt-2.5 flex items-center justify-between gap-2 border-t border-line pt-2.5">
        <div className="flex min-w-0 items-center gap-2">
          <span className="text-[#8EC5FF]">
            <SparkIcon size={20} />
          </span>
          <span className="text-[16px] font-extrabold leading-none text-white">{fmtNum(Math.max(0, Math.floor(Number(profile.shard) || 0)))}</span>
          <span className="truncate text-[14px] font-bold tracking-wide text-white/75">AkimiShard</span>
        </div>
        <button
          type="button"
          onClick={() => nav.push({ name: 'akimigames' })}
          className="flex shrink-0 items-center gap-1.5 rounded-full bg-[#F4C96B]/15 px-3.5 py-2 text-[#F4C96B] ring-1 ring-[#F4C96B]/25 active:scale-95"
        >
          <SparklesIcon size={16} />
          <span className="text-[14px] font-extrabold tracking-wide">AkimiGames</span>
        </button>
      </div>
    </div>
  )
}

/** Tombol beli Premium: kotak emas berisi mahkota + tombol pil warna khas AkimiPlay (pink), dengan kilau pelan. */
function PremiumCta() {
  const nav = useNav()
  const { profile } = useAuth()
  if (!profile) return null
  const active = isPremiumActive(profile)
  return (
    <div className="mx-4 mt-3 flex items-center gap-3 rounded-2xl bg-gradient-to-br from-raise to-panel p-3 ring-1 ring-line">
      <button
        type="button"
        aria-label="Premium"
        onClick={() => nav.push({ name: 'premium' })}
        className="flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FFE08A] to-[#E9A23B] text-[#2B1B00] shadow-[0_4px_14px_rgba(233,162,59,0.35)] active:scale-95"
      >
        <CrownIcon size={24} />
      </button>
      <button
        type="button"
        onClick={() => nav.push({ name: 'premium' })}
        className="relative flex h-[52px] min-w-0 flex-1 items-center justify-center overflow-hidden rounded-full bg-gradient-to-r from-[#FF9DBB] via-accent to-[#FF5C8D] px-3 text-[15.5px] font-extrabold uppercase tracking-wide text-ink shadow-[0_6px_22px_rgba(255,92,141,0.35)] ring-1 ring-white/20 active:scale-[0.98]"
      >
        <span
          aria-hidden
          className="absolute inset-y-0 w-[36%] animate-premiumShine motion-reduce:animate-none"
          style={{ left: '-50%', background: 'linear-gradient(100deg,transparent 0,rgba(255,255,255,0.45) 50%,transparent 100%)' }}
        />
        <span className="relative truncate">{active ? 'Perpanjang Premium' : 'Premium'}</span>
      </button>
    </div>
  )
}

/** Preview pesan terbaru Public Diskusi (compact). */
function ChatPreview() {
  const nav = useNav()
  const [last, setLast] = useState<ChatMessage | null>(null)
  useEffect(() => subscribeLatest(setLast), [])
  return (
    <button
      type="button"
      onClick={() => nav.push({ name: 'chat' })}
      className="mx-4 mt-3 flex h-11 w-[calc(100%-2rem)] items-center gap-2.5 rounded-xl bg-raise px-3 text-left ring-1 ring-line active:opacity-80"
    >
      <span className="text-accent">
        <Icon name="chat" size={18} />
      </span>
      <span className="shrink-0 text-[13px] font-bold text-white">Public Diskusi</span>
      <span className="h-4 w-px shrink-0 bg-line" />
      <span className="flex min-w-0 flex-1 items-center gap-1.5 text-[12px]">
        {last ? (
          <>
            <Avatar url={last.photoURL} name={last.name} size={20} />
            <span className="max-w-[86px] shrink-0 truncate font-semibold" style={{ color: nameColor(last.userId, last.role) }}>
              {last.name}
            </span>
            <span className="shrink-0 text-muted">:</span>
            <span className="truncate text-white/70">{last.text}</span>
          </>
        ) : (
          <span className="truncate text-muted">Belum ada pesan, mulai obrolan!</span>
        )}
      </span>
      <Icon name="chevron" size={16} className="shrink-0 text-accent" />
    </button>
  )
}

/** Banner 1: Top Anime. Tetap SATU banner; isinya berganti otomatis (tidak bisa digeser per anime). */
function TopAnimeBanner({ items }: { items: Anime[] }) {
  const nav = useNav()
  const [cur, setCur] = useState(0)

  useEffect(() => {
    setCur(0)
    if (items.length < 2) return
    const t = setInterval(() => setCur((n) => (n + 1) % items.length), 5000)
    return () => clearInterval(t)
  }, [items.length])

  return (
    <div className="relative h-[clamp(148px,44vw,184px)] overflow-hidden rounded-2xl bg-raise ring-1 ring-line">
      {items.map((a, i) => {
        const on = i === cur
        return (
          <div
            key={a.id}
            aria-hidden={!on}
            className={`absolute inset-0 transition-opacity duration-700 ${on ? 'opacity-100' : 'pointer-events-none opacity-0'}`}
          >
            <Poster
              src={a.banner ?? a.poster}
              alt=""
              className={`absolute inset-0 h-full w-full ${a.banner ? '' : 'object-[50%_22%]'}`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
            <button type="button" aria-label={`Detail ${a.title}`} tabIndex={on ? 0 : -1} onClick={() => nav.openAnime(a)} className="absolute inset-0" />
            {fmtCount(a.views) ? (
              <span className="pointer-events-none absolute left-2.5 top-2.5 flex items-center gap-1 rounded-full bg-black/55 px-2 py-1 text-[10.5px] font-semibold text-white backdrop-blur">
                <Icon name="eye" size={12} /> {fmtCount(a.views)}
              </span>
            ) : null}
            <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end gap-2 p-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 text-[11px] text-white/70">
                  <span className="font-extrabold text-accent">#{i + 1}</span>
                  {statusLabel(a.status) ? <span>· {statusLabel(a.status)}</span> : null}
                  {a.totalEpisodes ? <span>· {a.totalEpisodes} Eps</span> : null}
                  {a.score ? <span>· ★ {a.score.toFixed(1)}</span> : null}
                </div>
                <h2 className="mt-0.5 line-clamp-1 text-[15px] font-bold leading-tight text-white">{a.title}</h2>
              </div>
              <button
                type="button"
                tabIndex={on ? 0 : -1}
                onClick={() => nav.play(a)}
                className="pointer-events-auto flex shrink-0 items-center gap-1.5 rounded-full bg-accent px-3.5 py-2 text-[12px] font-bold text-ink active:scale-95"
              >
                <Icon name="play" size={13} /> Tonton
              </button>
            </div>
          </div>
        )
      })}
    </div>
  )
}

/** Dua banner dalam carousel: 1) Top Anime (isi berganti otomatis), 2) Top XP. Geser kiri/kanan untuk pindah banner. */
function Hero({ items }: { items: Anime[] }) {
  const [idx, setIdx] = useState(0)
  return (
    <div className="mt-3">
      <div
        className="no-scrollbar flex snap-x snap-mandatory overflow-x-auto"
        onScroll={(e) => setIdx(Math.round(e.currentTarget.scrollLeft / e.currentTarget.clientWidth))}
      >
        <div className="w-full shrink-0 snap-center px-4">
          <TopAnimeBanner items={items} />
        </div>
        <div className="w-full shrink-0 snap-center px-4">
          <LeaderboardBanner />
        </div>
      </div>
      <div className="mt-2 flex justify-center gap-1.5">
        {[0, 1].map((i) => (
          <span key={i} className={`h-1 rounded-full transition-all ${i === idx ? 'w-5 bg-accent' : 'w-1 bg-white/25'}`} />
        ))}
      </div>
    </div>
  )
}

/** Online: Home lengkap. Offline: hanya "Anime yang di download" supaya aplikasi tetap berguna tanpa internet. */
export function HomePage() {
  const online = useOnline()
  return online ? <OnlineHome /> : <DownloadsHome offline />
}

function OnlineHome() {
  const nav = useNav()
  const home = useAsync(() => animeApi.home(), [])
  const genres = useAsync(() => animeApi.genres().catch(() => []), [])
  const ongoingQ = useAsync(() => animeApi.ongoingPreview().catch(() => [] as Anime[]), [])
  const movies = useAsync(() => animeApi.byType('MOVIE', 9).catch(() => [] as Anime[]), [])
  const history = useStore(historyStore)
  const h = home.data
  const newUpd = useAsync(() => (h ? loadNewUpdates(h.new) : null), [h])
  const hero = useMemo(() => {
    if (!h) return []
    return uniq([...h.slider, ...h.hot, ...h.new]).filter((a) => a.banner || a.poster).slice(0, 6)
  }, [h])

  const ongoing = useMemo(() => {
    if (!h) return []
    return uniq([...h.today, ...(ongoingQ.data ?? []), ...h.hot, ...h.new]).filter(
      (a) => a.status === 'ONGOING' || h.today.some((t) => t.id === a.id),
    )
  }, [h, ongoingQ.data])

  const loadCompleted = useCallback((page: number) => animeApi.search({ status: 'FINISHED', sort: 'views', page }), [])
  const open = (a: AnimeLite) => nav.openAnime(a)
  const scroller = useRef<HTMLDivElement>(null)

  return (
    <div ref={scroller} className="absolute inset-0 overflow-y-auto pb-32">
      {/* pencarian menempel di atas */}
      <div className="pt-safe sticky top-0 z-20 bg-ink/85 backdrop-blur-xl">
        <div className="px-4 pb-2 pt-2">
          <button
            type="button"
            onClick={() => nav.push({ name: 'search' })}
            className="flex h-10 w-full items-center gap-2.5 rounded-xl bg-raise px-3.5 text-left ring-1 ring-line active:opacity-80"
          >
            <Icon name="search" size={17} className="text-muted" />
            <span className="text-[13.5px] text-muted">Mencari anime</span>
          </button>
        </div>
      </div>

      <ProfileCard />

      <PremiumCta />

      {home.loading ? (
        <>
          <div className="shimmer mx-4 mt-3 h-[clamp(148px,44vw,184px)] rounded-2xl" />
          <div className="mt-6">
            <GridSkeleton />
          </div>
        </>
      ) : null}

      {hero.length || !home.loading ? <Hero items={hero} /> : null}

      <ChatPreview />

      <DownloadedRow
        onOpen={(animeId) => nav.push({ name: 'downloads', animeId })}
        onManage={() => nav.push({ name: 'downloads' })}
      />

      {history.length ? (
        <section className="mt-5">
          <SectionHeader title="Terakhir Ditonton" action="Selengkapnya" onAction={() => nav.setTab('history')} />
          <div className="no-scrollbar mt-2 flex snap-x gap-2 overflow-x-auto px-4">
            {history.slice(0, 12).map((e) => {
              const pct = e.duration > 0 ? Math.min(1, e.position / e.duration) : 0
              return (
                <button
                  key={e.animeId}
                  type="button"
                  onClick={() => nav.play({ id: e.animeId, title: e.title, poster: e.poster, banner: e.banner }, e.episodeId)}
                  className="w-[clamp(90px,25vw,108px)] shrink-0 snap-start text-left active:opacity-80"
                >
                  <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-raise">
                    <Poster src={e.poster ?? e.banner} alt={e.title} className="h-full w-full" />
                    <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-black/90 to-transparent" />
                    <span className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur">
                      <Icon name="play" size={10} />
                    </span>
                    <div className="absolute inset-x-0 bottom-0 h-[3px] bg-white/20">
                      <div className="h-full bg-accent" style={{ width: `${pct * 100}%` }} />
                    </div>
                  </div>
                  <p className="mt-1 line-clamp-1 text-[11.5px] font-semibold text-white">{e.title}</p>
                  <p className="text-[10px] text-muted">
                    Eps {e.episodeNumber} · {Math.round(pct * 100)}%
                  </p>
                </button>
              )
            })}
          </div>
        </section>
      ) : null}

      {home.error && !h ? <ErrorState message={errMsg(home.error)} onRetry={home.reload} /> : null}

      {h ? (
        <>
          <NewUpdateSection items={newUpd.data ?? []} loading={newUpd.loading} onOpen={open} />

          {ongoingQ.loading && !ongoing.length ? (
            <RowSkeleton title="Ongoing" />
          ) : (
            <GridSection title="Ongoing" action="Lihat Jadwal" onAction={() => nav.setTab('ongoing')} items={ongoing} onOpen={open} />
          )}

          <GridSection title="Populer" items={h.popular.length ? h.popular : h.hot} onOpen={open} limit={6} />

          {movies.loading ? (
            <RowSkeleton title="Movie Update" />
          ) : (
            <GridSection
              title="Movie Update"
              action="Lihat Genres"
              onAction={() => nav.push({ name: 'search' })}
              items={movies.data ?? []}
              tag="Movie"
              onOpen={open}
            />
          )}

          <GridSection title="Sedang Hot" items={h.hot} onOpen={open} limit={6} />
          <GridSection title="Segera Tayang" items={h.waiting} tag="Soon" onOpen={open} limit={6} />
        </>
      ) : null}

      {genres.data?.length ? (
        <section className="mt-6">
          <SectionHeader title="Genre" />
          <div className="mt-2.5 flex flex-wrap gap-2 px-4">
            {genres.data.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => nav.push({ name: 'genre', id: g.id, title: g.name })}
                className="rounded-full bg-raise px-3 py-1.5 text-[12px] font-medium text-white/85 active:scale-95 active:bg-accent active:text-ink"
              >
                {g.name}
              </button>
            ))}
          </div>
        </section>
      ) : null}

      {h ? (
        <section className="mt-6">
          <SectionHeader title="Completed Anime" />
          <div className="mt-2.5">
            <PagedGrid
              resetKey="completed"
              load={loadCompleted}
              onOpen={open}
              emptyTitle="Belum ada anime tamat"
              emptyHint="Coba lagi nanti."
            />
          </div>
        </section>
      ) : null}
    </div>
  )
}
