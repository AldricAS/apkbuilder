import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { DM_MAX, deleteDm, loadOlderDm, markDmRead, sendDm, subscribeDm, type DmMessage } from '../services/dmService'
import { useOnlineMap, useRelation } from '../services/friendService'
import { useLiveUsers } from '../services/liveProfiles'
import { subscribeConnected } from '../services/chatService'
import { timeAgo } from '../lib/format'
import { Avatar, RoleCheck } from '../components/UserBadges'
import { Icon } from '../components/Icon'
import { Spinner } from '../components/States'
import { Sheet, toast } from '../components/Feedback'

const PAGE = 30

/** Chat pribadi dengan satu teman. `uid` = UID teman. */
export function DmPage({ uid: peer }: { uid: string }) {
  const nav = useNav()
  const me = useProfile()
  const live = useLiveUsers([peer])
  const peerProfile = live.get(peer)
  const peerName = peerProfile ? peerProfile.username?.trim() || peerProfile.displayName : '...'
  const online = !!useOnlineMap([peer]).get(peer)
  const { rel } = useRelation(me.uid, peer)
  const isFriend = rel === 'friends'

  const [messages, setMessages] = useState<DmMessage[]>([])
  const [ready, setReady] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(true)
  const [loadingOlder, setLoadingOlder] = useState(false)
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const [connected, setConnected] = useState(true)
  const [selected, setSelected] = useState<DmMessage | null>(null)
  const [, force] = useState(0)

  const scroller = useRef<HTMLDivElement>(null)
  const stick = useRef(true)
  const prevHeight = useRef<number | null>(null)
  const lastSend = useRef(0)

  useEffect(() => {
    setMessages([])
    setReady(false)
    setError(null)
    const unsub = subscribeDm(
      me.uid,
      peer,
      40,
      (m) => {
        setReady(true)
        setMessages((list) => (list.some((x) => x.id === m.id) ? list.map((x) => (x.id === m.id ? m : x)) : [...list, m].sort((a, b) => a.ts - b.ts)))
        void markDmRead(me.uid, peer)
      },
      (id) => setMessages((list) => list.filter((x) => x.id !== id)),
      (e) => {
        setReady(true)
        setError(e.message)
      },
    )
    const t = setTimeout(() => setReady(true), 2500)
    const offConn = subscribeConnected(setConnected)
    const tick = setInterval(() => force((n) => n + 1), 30000)
    void markDmRead(me.uid, peer)
    return () => {
      unsub()
      offConn()
      clearTimeout(t)
      clearInterval(tick)
      void markDmRead(me.uid, peer)
    }
  }, [me.uid, peer])

  useLayoutEffect(() => {
    const el = scroller.current
    if (!el) return
    if (prevHeight.current !== null) {
      el.scrollTop = el.scrollHeight - prevHeight.current
      prevHeight.current = null
    } else if (stick.current) {
      el.scrollTop = el.scrollHeight
    }
  }, [messages])

  const fetchOlder = useCallback(async () => {
    if (loadingOlder || !hasMore || !messages.length) return
    setLoadingOlder(true)
    try {
      const older = await loadOlderDm(me.uid, peer, messages[0].ts, PAGE)
      const ids = new Set(messages.map((m) => m.id))
      const fresh = older.filter((m) => !ids.has(m.id))
      if (fresh.length < PAGE) setHasMore(false)
      if (fresh.length) {
        prevHeight.current = scroller.current?.scrollHeight ?? null
        setMessages((l) => [...fresh, ...l].sort((a, b) => a.ts - b.ts))
      }
    } catch {
      toast('Gagal memuat pesan lama')
    } finally {
      setLoadingOlder(false)
    }
  }, [loadingOlder, hasMore, messages, me.uid, peer])

  const onScroll = () => {
    const el = scroller.current
    if (!el) return
    stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80
    if (el.scrollTop < 60) void fetchOlder()
  }

  const send = async () => {
    const value = text.trim()
    if (!value || sending || !isFriend) return
    if (Date.now() - lastSend.current < 700) {
      toast('Tunggu sebentar sebelum mengirim lagi')
      return
    }
    setSending(true)
    try {
      lastSend.current = Date.now()
      await sendDm(me.uid, peer, value)
      setText('')
      stick.current = true
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Pesan gagal dikirim')
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="absolute inset-0 flex flex-col bg-ink">
      <header className="pt-safe shrink-0 bg-ink">
        <div className="flex h-14 items-center gap-1 px-3">
          <button type="button" aria-label="Kembali" onClick={nav.pop} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10">
            <Icon name="back" size={24} />
          </button>
          <button type="button" onClick={() => nav.openProfile(peer)} className="flex min-w-0 flex-1 items-center gap-2.5 text-left active:opacity-80">
            <span className="relative shrink-0">
              <Avatar url={peerProfile?.photoURL} name={peerName} size={38} />
              {online ? <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-ink bg-[#3DDC84]" /> : null}
            </span>
            <span className="min-w-0">
              <span className="flex items-center gap-1.5">
                <span className="truncate text-[16.5px] font-bold leading-tight text-white">{peerName}</span>
                {peerProfile ? <RoleCheck role={peerProfile.role} verified={peerProfile.verified} size={15} /> : null}
              </span>
              <span className={`block text-[11.5px] leading-tight ${connected ? (online ? 'text-[#4ade80]' : 'text-muted') : 'text-[#f87171]'}`}>
                {connected ? (online ? 'Online' : 'Offline') : 'Tidak ada koneksi'}
              </span>
            </span>
          </button>
        </div>
        <div className="h-px bg-line" />
      </header>

      <div ref={scroller} onScroll={onScroll} className="flex-1 space-y-1.5 overflow-y-auto px-3 py-3">
        {loadingOlder ? (
          <div className="flex justify-center py-1">
            <Spinner size={18} />
          </div>
        ) : null}
        {!ready ? (
          <div className="flex justify-center py-20">
            <Spinner size={28} />
          </div>
        ) : null}
        {error ? <p className="rounded-2xl bg-[#2a1720] px-4 py-3 text-center text-[12.5px] text-accent">Chat tidak bisa dimuat: {error}</p> : null}
        {ready && !messages.length && !error ? <p className="py-20 text-center text-[13.5px] text-muted">Belum ada pesan. Sapa {peerName}!</p> : null}
        {messages.map((m, i) => {
          const own = m.uid === me.uid
          const prev = messages[i - 1]
          const newGroup = !prev || prev.uid !== m.uid || m.ts - prev.ts > 5 * 60_000
          return (
            <div key={m.id} className={`flex ${own ? 'justify-end' : 'justify-start'} ${newGroup ? 'pt-1.5' : ''}`}>
              <button
                type="button"
                onClick={() => setSelected(m)}
                onContextMenu={(e) => {
                  e.preventDefault()
                  setSelected(m)
                }}
                className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-left ${own ? 'rounded-br-md bg-accent/20 ring-1 ring-accent/30' : 'rounded-bl-md bg-raise'}`}
              >
                <p className="whitespace-pre-wrap break-words text-[15px] leading-snug text-white">{m.text}</p>
                <p className="mt-1 text-right text-[10.5px] text-muted">{timeAgo(m.ts)}</p>
              </button>
            </div>
          )
        })}
      </div>

      <div className="shrink-0 border-t border-line bg-ink px-3 pt-2" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 12px)' }}>
        {rel !== undefined && !isFriend ? (
          <p className="py-2 text-center text-[13px] text-muted">Kalian belum berteman, jadi chat pribadi tidak bisa dikirim.</p>
        ) : (
          <div className="flex items-center gap-2">
            <input
              value={text}
              maxLength={DM_MAX}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && void send()}
              placeholder={`Pesan untuk ${peerName}`}
              enterKeyHint="send"
              className="h-11 min-w-0 flex-1 rounded-full bg-raise px-4 text-[14.5px] text-white placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-accent"
            />
            <button
              type="button"
              aria-label="Kirim"
              disabled={!text.trim() || sending || !isFriend}
              onClick={() => void send()}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-accent text-ink active:scale-90 disabled:bg-raise disabled:text-white/30"
            >
              {sending ? <Spinner size={18} /> : <Icon name="send" size={19} />}
            </button>
          </div>
        )}
      </div>

      <Sheet open={!!selected} onClose={() => setSelected(null)} title={selected?.uid === me.uid ? 'Pesanmu' : peerName}>
        <p className="mb-4 whitespace-pre-wrap break-words text-[13.5px] text-white/80">{selected?.text}</p>
        <button
          type="button"
          onClick={() => {
            const m = selected
            setSelected(null)
            if (m) deleteDm(me.uid, peer, m).catch(() => toast('Tidak bisa menghapus pesan'))
          }}
          className="flex w-full items-center justify-center gap-2 rounded-full bg-raise py-3 text-[14px] font-semibold text-accent active:scale-[0.98]"
        >
          <Icon name="trash" size={17} /> {selected?.uid === me.uid ? 'Hapus untuk semua' : 'Hapus dari chatku'}
        </button>
      </Sheet>
    </div>
  )
}
