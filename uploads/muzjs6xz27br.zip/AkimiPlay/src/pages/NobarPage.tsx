import { useEffect, useMemo, useRef, useState } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { useBackHandler } from '../native/native'
import { animeApi } from '../services/animeApi'
import {
  canHostNobar,
  createRoom,
  isRoomStale,
  joinRoom,
  NOBAR_MAX,
  NobarError,
  reapRoom,
  stopRoom,
  subscribeRooms,
  subscribeSlotCounts,
  type NobarRoom,
} from '../services/nobarService'
import { liveOf, useLiveUsers } from '../services/liveProfiles'
import type { Anime } from '../types'
import { Avatar, RoleCheck } from '../components/UserBadges'
import { Poster } from '../components/Poster'
import { Icon } from '../components/Icon'
import { NobarAnimePicker } from '../components/NobarAnimePicker'
import { Sheet, toast } from '../components/Feedback'
import { Spinner } from '../components/States'
import { errMsg } from '../lib/format'

/** Partikel halus di latar (posisi tetap, tidak acak tiap render). */
const DOTS = Array.from({ length: 22 }, (_, i) => ({
  x: (i * 47 + 13) % 100,
  y: (i * 31 + 5) % 100,
  s: 1 + (i % 3),
  d: 4 + (i % 5),
  o: 0.15 + ((i * 13) % 40) / 100,
}))

function Backdrop() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-[#7C3AED]/20 blur-3xl" />
      <div className="absolute -right-24 top-60 h-72 w-72 rounded-full bg-[#FF7AA2]/15 blur-3xl" />
      {DOTS.map((d, i) => (
        <span
          key={i}
          className="absolute animate-twinkle rounded-full bg-white"
          style={{ left: `${d.x}%`, top: `${d.y}%`, width: d.s, height: d.s, opacity: d.o, animationDuration: `${d.d}s`, animationDelay: `${(i % 7) * 0.4}s` }}
        />
      ))}
    </div>
  )
}

function RoomCard({
  room,
  count,
  mine,
  busy,
  onJoin,
  onStop,
}: {
  room: NobarRoom
  count: number
  mine: boolean
  busy: boolean
  onJoin: () => void
  onStop: () => void
}) {
  const live = useLiveUsers([room.ownerUid])
  const o = liveOf({ uid: room.ownerUid, name: room.ownerName, photoURL: room.ownerPhoto, role: room.ownerRole, verified: room.ownerVerified, level: 1 }, live.get(room.ownerUid))
  const total = 1 + count
  const full = total >= NOBAR_MAX
  return (
    <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.05] p-3.5 backdrop-blur-sm">
      <div className="flex gap-3">
        <Poster src={room.poster} alt={room.animeTitle} className="h-[96px] w-[66px] shrink-0 rounded-xl ring-1 ring-white/10" />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Avatar url={o.photoURL} name={o.name} size={24} />
            <p className="flex min-w-0 items-center gap-1.5 text-[14.5px] font-extrabold text-white">
              <span className="truncate">Owner {o.name}</span>
              <RoleCheck role={o.role} verified={o.verified} size={15} />
            </p>
          </div>
          <p className="mt-2 line-clamp-2 text-[13px] leading-snug text-white/80">
            <span className="text-white/50">Judul anime:</span> {room.animeTitle}
          </p>
          <div className="mt-2 flex items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-[11.5px] font-bold text-white/80">
              <Icon name="users" size={13} /> Org {total}/{NOBAR_MAX}
            </span>
            {!room.online ? <span className="rounded-full bg-[#2b2210] px-2 py-1 text-[10.5px] font-bold text-[#f5b94a]">Terputus</span> : null}
          </div>
        </div>
      </div>
      <div className="mt-3 flex gap-2">
        {mine ? (
          <>
            <button type="button" disabled={busy} onClick={onJoin} className="flex h-10 flex-1 items-center justify-center rounded-full bg-accent text-[13.5px] font-extrabold text-ink active:scale-95 disabled:opacity-60">
              {busy ? <Spinner size={18} /> : 'Lanjutkan room kamu'}
            </button>
            <button type="button" disabled={busy} onClick={onStop} className="h-10 rounded-full bg-[#301014] px-4 text-[13px] font-bold text-[#f87171] ring-1 ring-[#6b1f27] active:scale-95 disabled:opacity-60">
              Stop
            </button>
          </>
        ) : (
          <button
            type="button"
            disabled={busy || full}
            onClick={onJoin}
            className="flex h-10 flex-1 items-center justify-center rounded-full bg-accent text-[13.5px] font-extrabold text-ink active:scale-95 disabled:bg-white/10 disabled:text-white/40"
          >
            {busy ? <Spinner size={18} /> : full ? 'Penuh' : 'Join'}
          </button>
        )}
      </div>
    </div>
  )
}

/** Halaman Nobar: Buat global nobar, daftar nobar aktif, dan pemilihan anime. */
export function NobarPage() {
  const nav = useNav()
  const me = useProfile()
  const [view, setView] = useState<'home' | 'create'>('home')
  const [rooms, setRooms] = useState<NobarRoom[] | null>(null)
  const [counts, setCounts] = useState<Record<string, number>>({})
  const [busy, setBusy] = useState<string | null>(null)
  const [lock, setLock] = useState(false)
  const [picked, setPicked] = useState<Anime | null>(null)
  const [creating, setCreating] = useState(false)
  const reaped = useRef(new Set<string>())
  const canHost = canHostNobar(me)

  useEffect(() => subscribeRooms((r) => setRooms(r), () => setRooms([])), [])
  useEffect(() => subscribeSlotCounts(setCounts), [])

  // room yang owner-nya terputus > 3 menit dibersihkan (siapa pun yang melihatnya)
  useEffect(() => {
    for (const r of rooms ?? []) {
      if (isRoomStale(r) && !reaped.current.has(r.ownerUid)) {
        reaped.current.add(r.ownerUid)
        void reapRoom(r.ownerUid)
      }
    }
  }, [rooms])

  useBackHandler(
    () => {
      setView('home')
      return true
    },
    50,
    view === 'create',
  )

  const active = useMemo(() => (rooms ?? []).filter((r) => !isRoomStale(r)), [rooms])

  const join = async (r: NobarRoom) => {
    if (busy) return
    setBusy(r.ownerUid)
    try {
      if (r.ownerUid !== me.uid) await joinRoom(me, r.ownerUid)
      nav.playNobar({ id: r.animeId, title: r.animeTitle, poster: r.poster }, r.ep, r.ownerUid)
    } catch (e) {
      toast(e instanceof NobarError ? e.message : 'Gagal masuk nobar. Coba lagi')
    } finally {
      setBusy(null)
    }
  }

  const create = async () => {
    if (!picked || creating) return
    setCreating(true)
    try {
      const eps = await animeApi.episodes(picked.id)
      if (!eps.length) {
        toast('Anime ini belum punya episode, pilih yang lain')
        return
      }
      const first = eps[0]
      await createRoom(me, { id: picked.id, title: picked.title, poster: picked.poster }, { id: first.id, number: first.number })
      const a = picked
      setPicked(null)
      setView('home')
      nav.playNobar(a, first.id, me.uid)
    } catch (e) {
      const msg = e instanceof Error ? e.message : ''
      toast(msg.toLowerCase().includes('permission') ? 'Membuat nobar hanya untuk Premium atau role khusus' : errMsg(e))
    } finally {
      setCreating(false)
    }
  }

  const header = (title: string, onBack: () => void) => (
    <header className="pt-safe relative">
      <div className="flex h-16 items-center gap-3 px-4">
        <button type="button" aria-label="Kembali" onClick={onBack} className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10">
          <Icon name="back" size={24} />
        </button>
        <h1 className="text-[24px] font-extrabold tracking-tight text-white">{title}</h1>
        <span className="rounded-lg bg-[#2a1f45] px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wide text-[#C4B0FF]">Global</span>
      </div>
    </header>
  )

  return (
    <div className="absolute inset-0 overflow-y-auto overflow-x-hidden overscroll-x-none [touch-action:pan-y] bg-gradient-to-b from-[#0a0f24] to-ink pb-24">
      <Backdrop />

      {view === 'home' ? (
        <>
          {header('Nobar', nav.pop)}
          <div className="relative mx-4 mt-2">
            <button
              type="button"
              onClick={() => (canHost ? setView('create') : setLock(true))}
              className="relative flex h-16 w-full items-center justify-center gap-3 overflow-hidden rounded-3xl text-[17px] font-extrabold text-white shadow-[0_10px_30px_rgba(124,58,237,0.35)] active:scale-[0.98]"
              style={{ background: canHost ? 'linear-gradient(120deg, #7C3AED 0%, #C0489F 55%, #FF7AA2 100%)' : 'linear-gradient(120deg, #2a2a38, #1d1d28)' }}
            >
              <span className="absolute inset-y-0 -left-1/2 w-1/2 animate-premiumShine bg-gradient-to-r from-transparent via-white/25 to-transparent" aria-hidden />
              <Icon name={canHost ? 'tv' : 'shield'} size={22} />
              Buat global nobar
              {!canHost ? <span className="rounded-full bg-white/15 px-2 py-0.5 text-[10.5px] font-extrabold uppercase tracking-wide">Premium</span> : null}
            </button>
            {!canHost ? <p className="mt-2 px-1 text-center text-[12px] text-white/50">Membuat nobar khusus Premium atau role khusus. Join nobar orang lain tetap bebas.</p> : null}
          </div>

          <div className="relative mx-4 mt-6">
            <p className="flex items-center gap-2 text-[15px] font-extrabold text-white">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#4ade80]/70" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[#4ade80]" />
              </span>
              Nobar aktif
              {active.length ? <span className="text-[12.5px] font-semibold text-white/50">({active.length})</span> : null}
            </p>
            <div className="mt-3 space-y-3">
              {rooms === null ? (
                <div className="shimmer h-[150px] rounded-3xl" />
              ) : active.length === 0 ? (
                <div className="rounded-3xl border border-dashed border-white/15 px-6 py-10 text-center">
                  <p className="text-[14px] font-semibold text-white/80">Belum ada nobar aktif</p>
                  <p className="mt-1 text-[12.5px] text-white/50">Jadilah yang pertama membuat nobar global.</p>
                </div>
              ) : (
                active.map((r) => (
                  <RoomCard
                    key={r.ownerUid}
                    room={r}
                    count={counts[r.ownerUid] ?? 0}
                    mine={r.ownerUid === me.uid}
                    busy={busy === r.ownerUid}
                    onJoin={() => void join(r)}
                    onStop={() => void stopRoom(me.uid).then(() => toast('Nobar dihentikan')).catch(() => toast('Gagal menghentikan nobar'))}
                  />
                ))
              )}
            </div>
          </div>
        </>
      ) : (
        <>
          {header('Pilih anime', () => setView('home'))}
          <div className="relative mx-4 mt-2">
            <NobarAnimePicker onPick={setPicked} />
          </div>
        </>
      )}

      <Sheet open={!!picked} onClose={() => (creating ? undefined : setPicked(null))} title="Nobar anime ini?">
        {picked ? (
          <div>
            <div className="flex gap-3">
              <Poster src={picked.poster} alt={picked.title} className="h-[108px] w-[74px] shrink-0 rounded-xl ring-1 ring-line" />
              <div className="min-w-0 flex-1">
                <p className="line-clamp-3 text-[15px] font-bold leading-tight text-white">{picked.title}</p>
                <p className="mt-2 text-[12.5px] leading-snug text-white/60">Kamu jadi owner: hanya kamu yang bisa play, jeda, geser, ganti episode atau anime, dan kick peserta.</p>
              </div>
            </div>
            <button
              type="button"
              disabled={creating}
              onClick={() => void create()}
              className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-full text-[15px] font-extrabold text-white active:scale-[0.98] disabled:opacity-70"
              style={{ background: 'linear-gradient(120deg, #7C3AED, #C0489F 55%, #FF7AA2)' }}
            >
              {creating ? <Spinner size={20} /> : 'Buat global nobar'}
            </button>
          </div>
        ) : null}
      </Sheet>

      <Sheet open={lock} onClose={() => setLock(false)} title="Khusus Premium">
        <p className="text-[13.5px] leading-relaxed text-white/75">
          Membuat room nobar hanya untuk akun Premium atau role khusus (Beta, Moderator, Admin, Developer, Special, dan sejenisnya). Akun biasa tetap bisa join nobar siapa pun.
        </p>
        <button
          type="button"
          onClick={() => {
            setLock(false)
            nav.push({ name: 'premium' })
          }}
          className="mt-5 flex h-12 w-full items-center justify-center rounded-full bg-accent text-[15px] font-extrabold text-ink active:scale-[0.98]"
        >
          Lihat Premium
        </button>
      </Sheet>
    </div>
  )
}
