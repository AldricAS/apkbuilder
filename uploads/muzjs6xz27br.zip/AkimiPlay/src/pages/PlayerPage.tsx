import type { MouseEvent, PointerEvent as RPointerEvent, ReactNode } from 'react'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { animeApi } from '../services/animeApi'
import { useAsync } from '../hooks/hooks'
import { useNav } from '../nav/router'
import { native, useBackHandler } from '../native/native'
import {
  pickResumeEpisode,
  progressStore,
  recordProgress,
  settingsStore,
  toggleFavorite,
  useIsFavorite,
  useStore,
} from '../storage/stores'
import type { AnimeLite, StreamSource } from '../types'
import { clamp, errMsg, fmtCount, fmtTime } from '../lib/format'
import { EpisodeList, EpisodeTiles } from '../components/EpisodeList'
import { Comments } from '../components/Comments'
import { Poster } from '../components/Poster'
import { APP_NAME } from '../components/Logo'
import { useAuth } from '../auth/AuthProvider'
import { WatchXpTracker } from '../services/xpService'
import {
  armMemberCleanup,
  changeRoomAnime,
  createPlaybackWriter,
  expectedPos,
  isKicked,
  leaveRoom,
  NOBAR_DRIFT_PAUSED,
  NOBAR_DRIFT_PLAYING,
  NOBAR_STALE_MS,
  reapRoom,
  serverNow,
  startHostPresence,
  stopRoom,
  subscribeMyMembership,
  useNobarMembers,
  useNobarRoom,
} from '../services/nobarService'
import { NobarPanel } from '../components/NobarPanel'
import { NobarAnimePicker } from '../components/NobarAnimePicker'
import { ErrorState, Spinner } from '../components/States'
import { Icon } from '../components/Icon'
import { Sheet, toast } from '../components/Feedback'

/** Pilih sumber awal: kualitas favorit user, atau (otomatis) yang tertinggi sampai 720p. */
function pickInitial(sources: StreamSource[], pref: number): StreamSource {
  const known = sources.filter((s) => s.height > 0)
  if (!known.length) return sources[0]
  const limit = pref > 0 ? pref : 720
  const fit = known.find((s) => s.height <= limit) // sources sudah urut dari tertinggi
  return fit ?? known[known.length - 1]
}

const SPEEDS = [0.75, 1, 1.25, 1.5, 2]

// Posisi mini player diingat selama aplikasi terbuka (null = posisi default kanan bawah).
let savedMiniPos: { x: number; y: number } | null = null

function PChip({ onClick, children, label }: { onClick: () => void; children: ReactNode; label: string }) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="flex h-9 items-center gap-1.5 rounded-full bg-black/55 px-3 text-[12px] font-bold text-white backdrop-blur active:scale-95"
    >
      {children}
    </button>
  )
}

function SkipIcon({ dir, sec }: { dir: -1 | 1; sec: number }) {
  return (
    <span className="relative flex h-7 w-7 items-center justify-center">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ transform: dir > 0 ? 'scaleX(-1)' : undefined }}>
        <path d="M3 12a9 9 0 1 0 3-6.7" />
        <path d="M3 4v5h5" />
      </svg>
      <span className="absolute pt-0.5 text-[8px] font-extrabold">{sec}</span>
    </span>
  )
}

export function PlayerPage({
  anime,
  episodeId: initialEp,
  minimized,
  nobarOwner,
}: {
  anime: AnimeLite
  episodeId?: string
  minimized: boolean
  /** uid owner room kalau ini nobar (owner sendiri atau anggota). */
  nobarOwner?: string
}) {
  const nav = useNav()
  const settings = useStore(settingsStore)

  // ---- data ----
  const eps = useAsync(() => animeApi.episodes(anime.id), [anime.id])
  const episodes = eps.data ?? []
  const [epId, setEpId] = useState<string | undefined>(initialEp)

  useEffect(() => {
    if (!epId && episodes.length) setEpId(pickResumeEpisode(episodes, anime.id))
  }, [epId, episodes, anime.id])

  const episode = episodes.find((e) => e.id === epId)
  const epIndex = episodes.findIndex((e) => e.id === epId)

  const stream = useAsync(() => (epId ? animeApi.stream(epId) : null), [epId])
  const sources = stream.data?.sources ?? []
  const [srcUrl, setSrcUrl] = useState<string>()
  const prefHeight = useRef(settings.defaultQuality)

  useEffect(() => {
    setSrcUrl(sources.length ? pickInitial(sources, prefHeight.current).url : undefined)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stream.data])
  const currentSource = sources.find((s) => s.url === srcUrl)

  // ---- state player ----
  const videoRef = useRef<HTMLVideoElement>(null)
  const [playing, setPlaying] = useState(false)
  const [buffering, setBuffering] = useState(false)
  const [time, setTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [muted, setMuted] = useState(false)
  const [volume, setVolume] = useState(1)
  const [videoError, setVideoError] = useState<string | null>(null)
  const [showControls, setShowControls] = useState(true)
  const [fs, setFs] = useState(false)
  const [pip, setPip] = useState(false)
  const [pipSupported, setPipSupported] = useState(false)
  const [listOpen, setListOpen] = useState(false)
  const [qualityOpen, setQualityOpen] = useState(false)
  const [flash, setFlash] = useState<{ side: -1 | 1; k: number } | null>(null)

  const [miniPos, setMiniPos] = useState<{ x: number; y: number } | null>(savedMiniPos)
  const [snapping, setSnapping] = useState(false)
  const miniRef = useRef<HTMLDivElement>(null)
  const drag = useRef<{ sx: number; sy: number; ox: number; oy: number; moved: boolean } | null>(null)
  const [fill, setFill] = useState(false)
  const [speed, setSpeed] = useState(1)
  const [epCollapsed, setEpCollapsed] = useState(false)
  const [synMore, setSynMore] = useState(false)
  const [rulesOpen, setRulesOpen] = useState(false)

  // detail anime (sinopsis, views) untuk bagian info
  const detail = useAsync(() => animeApi.detail(anime.id), [anime.id])
  const fav = useIsFavorite(anime.id)

  // XP dari waktu menonton yang benar-benar berjalan
  const { profile } = useAuth()
  const profileRef = useRef(profile)
  profileRef.current = profile
  const tracker = useMemo(
    () => (profile ? new WatchXpTracker(profile.uid, () => profileRef.current) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [profile?.uid],
  )
  const trackerRef = useRef(tracker)
  trackerRef.current = tracker
  useEffect(() => {
    if (tracker && epId) void tracker.start(epId)
  }, [tracker, epId])
  useEffect(() => {
    const t = setInterval(() => void trackerRef.current?.flush(), 30000)
    return () => clearInterval(t)
  }, [])

  const resumeAt = useRef(0)
  const wasPlaying = useRef(true)
  const dragging = useRef(false)
  const hideTimer = useRef<ReturnType<typeof setTimeout>>()
  const tapTimer = useRef<ReturnType<typeof setTimeout>>()
  const lastTap = useRef(0)
  const fsRef = useRef(false)
  const pipRef = useRef(false)
  fsRef.current = fs
  pipRef.current = pip

  // ---- nobar ----
  // Owner mengatur semuanya (play, jeda, geser, episode, anime) dan menulis status ke room; anggota HANYA mengikuti.
  const nobarId = nobarOwner
  const isOwner = !!nobarId && nobarId === profile?.uid
  const locked = !!nobarId && !isOwner
  const room = useNobarRoom(nobarId)
  const members = useNobarMembers(nobarId)
  const roomRef = useRef(room)
  roomRef.current = room
  const lockedRef = useRef(locked)
  lockedRef.current = locked
  const epIdRef = useRef(epId)
  epIdRef.current = epId
  const episodesRef = useRef(episodes)
  episodesRef.current = episodes
  const writer = useMemo(() => (isOwner && nobarId ? createPlaybackWriter(nobarId) : null), [isOwner, nobarId])
  const writerRef = useRef(writer)
  writerRef.current = writer
  const [needTap, setNeedTap] = useState(false)
  const [pickAnime, setPickAnime] = useState(false)
  const seenMember = useRef(false)
  const cleanupInfo = useRef({ nobarId, isOwner, uid: profile?.uid })
  cleanupInfo.current = { nobarId, isOwner, uid: profile?.uid }

  // owner: tandai room online selama terhubung (putus = room ditandai offline oleh server)
  useEffect(() => {
    if (!isOwner || !nobarId) return
    return startHostPresence(nobarId)
  }, [isOwner, nobarId])
  useEffect(() => () => writer?.dispose(), [writer])

  // owner: detak berkala supaya anggota yang baru masuk / tertinggal ikut sejajar
  useEffect(() => {
    if (!isOwner) return
    const t = setInterval(() => {
      const v = videoRef.current
      if (v && !v.paused && !v.ended) writerRef.current?.write({ playing: true, pos: v.currentTime })
    }, 12000)
    return () => clearInterval(t)
  }, [isOwner])

  // anggota: pantau keanggotaan sendiri (kena kick / keluar) dan siapkan pembersihan otomatis kalau koneksi putus
  useEffect(() => {
    if (!nobarId || isOwner || !profile) return
    seenMember.current = false
    const uid = profile.uid
    let disarm: () => void = () => undefined
    const unsub = subscribeMyMembership(nobarId, uid, (m) => {
      if (m) {
        if (!seenMember.current) {
          seenMember.current = true
          disarm = armMemberCleanup(nobarId, uid, m.slot)
        }
        return
      }
      if (!seenMember.current) return
      seenMember.current = false
      void isKicked(nobarId, uid).then((k) => {
        toast(k ? 'Kamu dikeluarkan dari nobar oleh owner' : 'Kamu keluar dari nobar')
        nav.closePlayer()
      })
    })
    return () => {
      unsub()
      disarm()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nobarId, isOwner, profile?.uid])

  // room ditutup (owner stop / dibersihkan): semua keluar
  const roomClosed = useRef(false)
  useEffect(() => {
    if (!nobarId || room !== null || roomClosed.current) return
    roomClosed.current = true
    toast(isOwner ? 'Nobar dihentikan' : 'Nobar dihentikan oleh owner')
    nav.closePlayer()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room, nobarId])

  // owner terputus terlalu lama: room dibersihkan, anggota keluar
  useEffect(() => {
    if (!locked || !nobarId) return
    const t = setInterval(() => {
      const r = roomRef.current
      if (r && !r.online && serverNow() - r.at > NOBAR_STALE_MS) {
        void reapRoom(nobarId)
        toast('Owner terputus terlalu lama, nobar ditutup')
        nav.closePlayer()
      }
    }, 15000)
    return () => clearInterval(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locked, nobarId])

  // keluar dari player nobar (tombol X mini player, Stop, Keluar): owner = tutup room, anggota = keluar room
  useEffect(
    () => () => {
      const c = cleanupInfo.current
      if (!c.nobarId || !c.uid) return
      if (c.isOwner) void stopRoom(c.nobarId).catch(() => undefined)
      else if (seenMember.current) void leaveRoom(c.nobarId, c.uid).catch(() => undefined)
    },
    [],
  )

  // anggota: samakan video dengan status room (play/jeda/posisi)
  const applyRoom = useCallback((tolerance?: number) => {
    const v = videoRef.current
    const r = roomRef.current
    if (!lockedRef.current || !v || !r) return
    if (r.ep !== epIdRef.current) return // episode belum sama, tunggu
    if (v.readyState < 1 || !Number.isFinite(v.duration)) return
    const exp = expectedPos(r)
    const tol = tolerance ?? (r.playing ? NOBAR_DRIFT_PLAYING : NOBAR_DRIFT_PAUSED)
    if (Math.abs(v.currentTime - exp) > tol) v.currentTime = Math.min(exp, Math.max(0, v.duration - 0.2))
    if (r.playing && v.paused) {
      void v.play().then(() => setNeedTap(false)).catch(() => setNeedTap(true))
    } else if (!r.playing && !v.paused) {
      v.pause()
    }
  }, [])
  const enforceTimer = useRef<ReturnType<typeof setTimeout>>()
  // anggota tidak boleh melawan owner (mis. lewat tombol PiP): kembalikan ke status room
  const enforce = useCallback(() => {
    if (!lockedRef.current) return
    clearTimeout(enforceTimer.current)
    enforceTimer.current = setTimeout(() => applyRoom(), 250)
  }, [applyRoom])
  useEffect(() => () => clearTimeout(enforceTimer.current), [])

  useEffect(() => {
    if (locked) applyRoom(room?.playing ? 1.2 : NOBAR_DRIFT_PAUSED)
  }, [locked, room?.playing, room?.pos, room?.at, room?.ep, epId, applyRoom])
  useEffect(() => {
    if (!locked) return
    const t = setInterval(() => applyRoom(), 4000)
    return () => clearInterval(t)
  }, [locked, applyRoom])

  // anggota: ikuti anime & episode yang dipilih owner
  useEffect(() => {
    if (!locked || !room) return
    if (room.animeId !== anime.id) {
      nav.swapNobar({ id: room.animeId, title: room.animeTitle, poster: room.poster }, room.ep)
      return
    }
    if (room.ep && room.ep !== epId) setEpId(room.ep)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locked, room?.animeId, room?.ep, anime.id, epId])
  useEffect(() => {
    setNeedTap(false)
  }, [epId])

  const notOwner = useCallback(() => toast('Hanya owner yang bisa mengatur pemutaran'), [])

  // owner: ganti anime di room (anggota otomatis ikut pindah)
  const changeAnime = async (a: AnimeLite) => {
    setPickAnime(false)
    if (!isOwner || !nobarId) return
    if (a.id === anime.id) return toast('Itu anime yang sedang ditonton')
    try {
      const list = await animeApi.episodes(a.id)
      if (!list.length) return toast('Anime ini belum punya episode')
      const first = list[0]
      await changeRoomAnime(nobarId, { id: a.id, title: a.title, poster: a.poster }, { id: first.id, number: first.number })
      persistRef.current()
      nav.swapNobar(a, first.id)
      setEpId(first.id)
    } catch {
      toast('Gagal mengganti anime, coba lagi')
    }
  }

  // ---- simpan progress ----
  const persist = useCallback(
    (ended = false) => {
      const v = videoRef.current
      if (!v || !episode || !Number.isFinite(v.duration) || v.duration <= 0) return
      recordProgress({
        anime,
        episode: { id: episode.id, number: episode.number, title: episode.title },
        position: ended ? v.duration : v.currentTime,
        duration: v.duration,
        watched: ended,
      })
    },
    [anime, episode],
  )
  const persistRef = useRef(persist)
  persistRef.current = persist

  useEffect(() => {
    if (!playing) return
    const t = setInterval(() => persistRef.current(), 5000)
    return () => clearInterval(t)
  }, [playing])

  // posisi resume untuk episode ini
  useEffect(() => {
    if (!epId) return
    const p = progressStore.get()[epId]
    resumeAt.current = !nobarId && settings.resume && p && p.d > 0 && p.p / p.d < 0.95 ? Math.max(0, p.p - 2) : 0
    wasPlaying.current = true
    setTime(0)
    setDuration(0)
    setVideoError(null)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [epId])

  // ---- kontrol tampil/sembunyi ----
  const bump = useCallback(() => {
    setShowControls(true)
    clearTimeout(hideTimer.current)
    hideTimer.current = setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused) setShowControls(false)
    }, 3500)
  }, [])
  useEffect(() => {
    if (!playing) {
      clearTimeout(hideTimer.current)
      setShowControls(true)
    } else bump()
  }, [playing, bump])

  // ---- native: PiP, layar menyala ----
  useEffect(() => {
    void native.pipSupported().then(setPipSupported)
    const off = native.onPipChanged((active) => {
      setPip(active)
      if (active) setShowControls(false)
    })
    return off
  }, [])

  useEffect(() => {
    void native.setKeepAwake(playing)
  }, [playing])

  useEffect(() => {
    void native.setPipReady(playing && settings.autoPip)
  }, [playing, settings.autoPip])

  // bersihkan saat keluar dari player
  useEffect(() => {
    return () => {
      persistRef.current()
      void trackerRef.current?.flush()
      clearTimeout(hideTimer.current)
      clearTimeout(tapTimer.current)
      void native.setFullscreen(false)
      void native.setKeepAwake(false)
      void native.setPipReady(false)
    }
  }, [])

  // jeda saat aplikasi ke background (kecuali PiP aktif / akan masuk PiP)
  useEffect(() => {
    const h = () => {
      if (!document.hidden) return
      persistRef.current()
      void trackerRef.current?.flush()
      const willPip = pipRef.current || (settingsStore.get().autoPip && !videoRef.current?.paused)
      if (!willPip) videoRef.current?.pause()
    }
    document.addEventListener('visibilitychange', h)
    return () => document.removeEventListener('visibilitychange', h)
  }, [])

  // ---- aksi ----
  const setFullscreen = useCallback(async (v: boolean) => {
    setFs(v)
    if (!v) setListOpen(false)
    await native.setFullscreen(v)
    setShowControls(true)
  }, [])

  const goEpisode = useCallback((id: string) => {
    if (lockedRef.current) return
    persistRef.current()
    setListOpen(false)
    setEpId(id)
    // nobar: semua peserta menunggu di awal episode (jeda) sampai video owner benar-benar mulai
    const ep = episodesRef.current.find((e) => e.id === id)
    writerRef.current?.write({ ep: id, epNo: ep?.number ?? 0, pos: 0, playing: false })
  }, [])

  const next = epIndex >= 0 && epIndex < episodes.length - 1 ? episodes[epIndex + 1] : undefined
  const prev = epIndex > 0 ? episodes[epIndex - 1] : undefined

  const togglePlay = useCallback(() => {
    const v = videoRef.current
    if (!v) return
    if (lockedRef.current) return notOwner()
    if (v.paused) void v.play().catch(() => setVideoError('Video tidak bisa diputar'))
    else v.pause()
    bump()
  }, [bump, notOwner])

  const seekBy = useCallback((delta: number) => {
    const v = videoRef.current
    if (!v || !Number.isFinite(v.duration)) return
    if (lockedRef.current) return
    v.currentTime = clamp(v.currentTime + delta, 0, v.duration)
    setTime(v.currentTime)
  }, [])

  // Skip Intro: lompat maju sebanyak pengaturan (80/85/90/95 detik). Di nobar hanya owner yang bisa; semua peserta ikut lewat sinkronisasi.
  const introSec = settings.introSkip ?? 90
  const skipIntro = () => {
    if (lockedRef.current) return notOwner()
    seekBy(introSec)
    bump()
  }

  const cycleSpeed = () => {
    if (locked) return notOwner()
    const next = SPEEDS[(SPEEDS.indexOf(speed) + 1) % SPEEDS.length]
    setSpeed(next)
    if (videoRef.current) videoRef.current.playbackRate = next
    bump()
  }

  const changeQuality = (s: StreamSource) => {
    const v = videoRef.current
    if (v) {
      resumeAt.current = v.currentTime
      wasPlaying.current = !v.paused
    }
    prefHeight.current = s.height
    setSrcUrl(s.url)
    setQualityOpen(false)
    setVideoError(null)
  }

  // ---- geser mini player ----
  const onMiniDown = (e: RPointerEvent<HTMLDivElement>) => {
    const el = miniRef.current
    if (!el) return
    const r = el.getBoundingClientRect()
    drag.current = { sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top, moved: false }
    setSnapping(false)
    e.currentTarget.setPointerCapture(e.pointerId)
  }
  const onMiniMove = (e: RPointerEvent<HTMLDivElement>) => {
    const d = drag.current
    const el = miniRef.current
    if (!d || !el) return
    const dx = e.clientX - d.sx
    const dy = e.clientY - d.sy
    if (!d.moved && Math.hypot(dx, dy) < 8) return
    d.moved = true
    const x = clamp(d.ox + dx, 6, window.innerWidth - el.offsetWidth - 6)
    const y = clamp(d.oy + dy, 6, window.innerHeight - el.offsetHeight - 6)
    setMiniPos({ x, y })
  }
  const onMiniUp = () => {
    const d = drag.current
    const el = miniRef.current
    drag.current = null
    if (!d) return
    if (!d.moved) {
      nav.expandPlayer() // ketukan biasa: buka player penuh
      return
    }
    if (el) {
      // tempel ke sisi layar terdekat
      const r = el.getBoundingClientRect()
      const x = r.left + r.width / 2 < window.innerWidth / 2 ? 8 : window.innerWidth - r.width - 8
      const y = clamp(r.top, 8, window.innerHeight - r.height - 8)
      setSnapping(true)
      savedMiniPos = { x, y }
      setMiniPos({ x, y })
    }
  }

  const onTap = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const side: -1 | 1 = e.clientX - rect.left < rect.width / 2 ? -1 : 1
    const now = Date.now()
    if (now - lastTap.current < 300 && !locked) {
      clearTimeout(tapTimer.current)
      lastTap.current = 0
      seekBy(side * settings.seekStep)
      setFlash({ side, k: now })
      bump()
    } else {
      lastTap.current = now
      tapTimer.current = setTimeout(() => {
        if (showControls && playing) setShowControls(false)
        else bump()
      }, 280)
    }
  }

  // tombol Back Android: tutup panel -> keluar fullscreen -> kembali
  useBackHandler(() => {
    if (qualityOpen) {
      setQualityOpen(false)
      return true
    }
    if (listOpen) {
      setListOpen(false)
      return true
    }
    if (fsRef.current) {
      void setFullscreen(false)
      return true
    }
    persistRef.current()
    nav.minimizePlayer()
    return true
  }, 100, !minimized)

  const title = anime.title
  const epTitle = episode ? `Episode ${episode.number}${episode.title && episode.title !== String(episode.number) ? ` · ${episode.title}` : ''}` : ''
  const pct = duration > 0 ? (time / duration) * 100 : 0
  const immersive = fs || pip
  const mini = minimized && !pip
  const noEpisodes = !eps.loading && !eps.error && episodes.length === 0

  return (
    <div
      className={
        mini
          ? `fixed z-[45] w-[228px] overflow-hidden rounded-2xl bg-black shadow-[0_16px_44px_rgba(0,0,0,0.7)] ring-1 ring-white/15 ${
              miniPos ? '' : 'right-3'
            } ${snapping ? 'transition-[left,top] duration-200 ease-out' : ''}`
          : 'fixed inset-0 z-50 flex flex-col bg-ink'
      }
      ref={miniRef}
      style={
        mini
          ? miniPos
            ? { left: miniPos.x, top: miniPos.y }
            : { bottom: 'calc(env(safe-area-inset-bottom, 0px) + 80px)' }
          : undefined
      }
    >
      {/* wadah video: berubah jadi layar penuh tanpa memuat ulang <video> */}
      <div
        className={
          immersive
            ? 'fixed inset-0 z-[70] bg-black'
            : mini
              ? 'relative w-full bg-black'
              : 'pt-safe relative z-10 w-full shrink-0 bg-black'
        }
      >
        <div className={immersive ? 'h-full w-full' : 'relative aspect-video w-full'}>
          <video
            ref={videoRef}
            src={srcUrl}
            className={`h-full w-full bg-black ${fill ? 'object-cover' : 'object-contain'}`}
            playsInline
            preload="metadata"
            onLoadedMetadata={(e) => {
              const v = e.currentTarget
              setDuration(v.duration)
              if (resumeAt.current > 1 && Number.isFinite(v.duration)) {
                v.currentTime = Math.min(resumeAt.current, Math.max(0, v.duration - 2))
              }
              resumeAt.current = 0
              v.playbackRate = speed
              if (lockedRef.current) applyRoom(NOBAR_DRIFT_PAUSED)
              else if (wasPlaying.current) void v.play().catch(() => setPlaying(false))
              persistRef.current()
            }}
            onTimeUpdate={(e) => {
              const v = e.currentTarget
              if (!dragging.current) setTime(v.currentTime)
              trackerRef.current?.tick(v.currentTime, !v.paused, v.playbackRate)
            }}
            onSeeking={() => trackerRef.current?.reset()}
            onSeeked={(e) => {
              if (writerRef.current) writerRef.current.write({ pos: e.currentTarget.currentTime, playing: !e.currentTarget.paused })
            }}
            onPlay={(e) => {
              setPlaying(true)
              if (writerRef.current) writerRef.current.write({ playing: true, pos: e.currentTarget.currentTime })
              else enforce()
            }}
            onPause={(e) => {
              if (writerRef.current && !e.currentTarget.ended) writerRef.current.write({ playing: false, pos: e.currentTarget.currentTime })
              else enforce()
              setPlaying(false)
              persistRef.current()
              trackerRef.current?.reset()
              void trackerRef.current?.flush()
            }}
            onWaiting={() => {
              setBuffering(true)
              trackerRef.current?.reset()
            }}
            onPlaying={() => {
              setBuffering(false)
              setPlaying(true)
              setVideoError(null)
            }}
            onCanPlay={() => setBuffering(false)}
            onEnded={(e) => {
              persistRef.current(true)
              trackerRef.current?.reset()
              void trackerRef.current?.flush()
              if (writerRef.current) writerRef.current.write({ playing: false, pos: e.currentTarget.duration })
              if (!lockedRef.current && settingsStore.get().autoNext && next) goEpisode(next.id)
            }}
            onError={() => setVideoError('Video gagal dimuat. Coba kualitas lain atau ulangi.')}
          />

          {/* lapisan ketuk: 1x tampil/sembunyi kontrol, 2x lompat maju/mundur */}
          {!pip && !mini ? <div className="absolute inset-0" onClick={onTap} /> : null}
          {mini ? (
            <div
              className="absolute inset-0 cursor-grab touch-none"
              onPointerDown={onMiniDown}
              onPointerMove={onMiniMove}
              onPointerUp={onMiniUp}
              onPointerCancel={() => (drag.current = null)}
            />
          ) : null}

          {/* kontrol mini player */}
          {mini ? (
            <>
              <div className="pointer-events-none absolute inset-x-0 top-0 h-10 bg-gradient-to-b from-black/70 to-transparent" />
              <button
                type="button"
                aria-label="Buka player"
                onClick={nav.expandPlayer}
                className="absolute left-1 top-1 flex h-8 w-8 items-center justify-center rounded-full text-white/90 active:bg-white/20"
              >
                <Icon name="fs" size={16} />
              </button>
              <button
                type="button"
                aria-label="Tutup mini player"
                onClick={() => {
                  persist()
                  nav.closePlayer()
                }}
                className="absolute right-1 top-1 flex h-8 w-8 items-center justify-center rounded-full text-white/90 active:bg-white/20"
              >
                <Icon name="x" size={17} />
              </button>
              <button
                type="button"
                aria-label={playing ? 'Jeda' : 'Putar'}
                onClick={togglePlay}
                className="absolute left-1/2 top-1/2 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur active:scale-90"
              >
                <Icon name={playing ? 'pause' : 'play'} size={22} />
              </button>
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[3px] bg-white/20">
                <div className="h-full bg-accent" style={{ width: `${pct}%` }} />
              </div>
              <div className="pointer-events-none absolute inset-x-2 bottom-2 truncate text-[10.5px] font-medium text-white/90 drop-shadow">
                {title}{episode ? ` · Ep ${episode.number}` : ''}
              </div>
            </>
          ) : null}

          {flash ? (
            <div
              key={flash.k}
              className={`pointer-events-none absolute top-1/2 -mt-8 flex h-16 w-16 animate-flash items-center justify-center rounded-full bg-black/50 text-[12px] font-bold text-white ${
                flash.side < 0 ? 'left-[14%]' : 'right-[14%]'
              }`}
            >
              {flash.side < 0 ? '-' : '+'}
              {settings.seekStep}s
            </div>
          ) : null}

          {(buffering || stream.loading || eps.loading) && !videoError && !pip ? (
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              <Spinner size={38} />
            </div>
          ) : null}

          {locked && needTap && !pip && !mini ? (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/60">
              <button
                type="button"
                onClick={() => {
                  setNeedTap(false)
                  applyRoom(0.4)
                }}
                className="flex items-center gap-2 rounded-full bg-accent px-5 py-3 text-[14px] font-extrabold text-ink active:scale-95"
              >
                <Icon name="play" size={20} /> Ketuk untuk ikut menonton
              </button>
            </div>
          ) : null}

          {(videoError || stream.error) && !pip && !mini ? (
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-black/80 px-6 text-center">
              <p className="text-[13.5px] text-white/85">{videoError ?? errMsg(stream.error)}</p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setVideoError(null)
                    resumeAt.current = videoRef.current?.currentTime ?? 0
                    stream.reload()
                  }}
                  className="rounded-full bg-accent px-4 py-2 text-[13px] font-bold text-ink"
                >
                  Coba lagi
                </button>
                {sources.length > 1 ? (
                  <button
                    type="button"
                    onClick={() => setQualityOpen(true)}
                    className="rounded-full bg-white/15 px-4 py-2 text-[13px] font-semibold text-white"
                  >
                    Ganti kualitas
                  </button>
                ) : null}
              </div>
            </div>
          ) : null}

          {/* kontrol */}
          {!pip && !mini ? (
            <div
              className={`pointer-events-none absolute inset-0 flex flex-col justify-between overflow-hidden transition-opacity duration-200 ${
                showControls && !videoError && !stream.error ? 'visible opacity-100' : 'invisible opacity-0'
              }`}
            >
              <div className="pointer-events-auto flex items-start gap-2 bg-gradient-to-b from-black/80 to-transparent px-2.5 pb-3 pt-2">
                <button
                  type="button"
                  aria-label="Kembali"
                  onClick={() => (fs ? void setFullscreen(false) : (persist(), nav.minimizePlayer()))}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-black/55 backdrop-blur active:scale-90"
                >
                  <Icon name="back" size={20} />
                </button>
                <div className="flex min-w-0 flex-1 items-center">
                  {nobarId ? (
                    <span className="flex items-center gap-1.5 rounded-full bg-black/55 px-3 py-2 text-[11.5px] font-extrabold uppercase tracking-wide text-white backdrop-blur">
                      <span className={`h-2 w-2 rounded-full ${room?.online === false ? 'bg-[#f5b94a]' : 'bg-[#4ade80]'}`} />
                      Nobar · {1 + members.length}
                    </span>
                  ) : null}
                </div>
                <div className="flex shrink-0 items-center gap-1.5">
                  <PChip label="Mode tampilan" onClick={() => setFill((f) => !f)}>
                    <Icon name="fill" size={15} /> {fill ? 'Fill' : 'Fit'}
                  </PChip>
                  {!locked ? (
                    <PChip label="Kecepatan" onClick={cycleSpeed}>
                      <Icon name="sliders" size={15} /> {speed}x
                    </PChip>
                  ) : null}
                  {sources.length > 0 ? (
                    <PChip label="Kualitas" onClick={() => setQualityOpen(true)}>
                      HQ
                    </PChip>
                  ) : null}
                  <button
                    type="button"
                    aria-label={fs ? 'Keluar layar penuh' : 'Layar penuh'}
                    onClick={() => void setFullscreen(!fs)}
                    className="flex h-9 w-9 items-center justify-center rounded-full bg-black/55 backdrop-blur active:scale-90"
                  >
                    <Icon name={fs ? 'exitfs' : 'fs'} size={18} />
                  </button>
                </div>
              </div>

              {locked ? (
                <div className="pointer-events-auto self-center rounded-full bg-black/55 px-4 py-2 text-[12px] font-semibold text-white/85 backdrop-blur">
                  Owner yang mengatur pemutaran
                </div>
              ) : (
              <div className={`pointer-events-auto flex items-center justify-center self-center ${fs ? 'gap-4' : 'gap-2.5'}`}>
                <button
                  type="button"
                  aria-label="Episode sebelumnya"
                  disabled={!prev}
                  onClick={() => prev && goEpisode(prev.id)}
                  className="flex h-10 w-10 items-center justify-center rounded-full disabled:opacity-30 active:scale-90"
                >
                  <Icon name="prev" size={22} />
                </button>
                <button
                  type="button"
                  aria-label={`Mundur ${settings.seekStep} detik`}
                  onClick={() => {
                    seekBy(-settings.seekStep)
                    bump()
                  }}
                  className="flex h-10 w-10 items-center justify-center rounded-full active:scale-90"
                >
                  <SkipIcon dir={-1} sec={settings.seekStep} />
                </button>
                <button
                  type="button"
                  aria-label={playing ? 'Jeda' : 'Putar'}
                  onClick={togglePlay}
                  className={`flex items-center justify-center rounded-full bg-accent text-ink shadow-lg active:scale-90 ${fs ? 'h-[60px] w-[60px]' : 'h-[50px] w-[50px]'}`}
                >
                  <Icon name={playing ? 'pause' : 'play'} size={28} />
                </button>
                <button
                  type="button"
                  aria-label={`Maju ${settings.seekStep} detik`}
                  onClick={() => {
                    seekBy(settings.seekStep)
                    bump()
                  }}
                  className="flex h-10 w-10 items-center justify-center rounded-full active:scale-90"
                >
                  <SkipIcon dir={1} sec={settings.seekStep} />
                </button>
                <button
                  type="button"
                  aria-label="Episode berikutnya"
                  disabled={!next}
                  onClick={() => next && goEpisode(next.id)}
                  className="flex h-10 w-10 items-center justify-center rounded-full disabled:opacity-30 active:scale-90"
                >
                  <Icon name="next" size={22} />
                </button>
              </div>
              )}

              <div className="pointer-events-auto bg-gradient-to-t from-black/85 to-transparent px-3 pb-1 pt-3">
                <div className="flex items-end justify-between px-0.5 text-[12px] font-semibold tabular-nums text-white">
                  <span>
                    {fmtTime(time)} / {fmtTime(duration)}
                  </span>
                  <span className="flex items-center gap-2">
                    {!locked && duration > introSec + 5 ? (
                      <button
                        type="button"
                        aria-label={`Skip intro ${introSec} detik`}
                        onClick={skipIntro}
                        className="flex h-6 items-center gap-1 rounded-full bg-white/20 px-2.5 text-[11px] font-bold text-white backdrop-blur active:scale-95"
                      >
                        Skip Intro <Icon name="next" size={12} />
                      </button>
                    ) : null}
                    {currentSource?.quality ?? ''}
                  </span>
                </div>
                <input
                  type="range"
                  className="seek"
                  aria-label="Posisi video"
                  disabled={locked}
                  min={0}
                  max={duration || 0}
                  step={0.1}
                  value={Math.min(time, duration || 0)}
                  style={{ ['--p' as string]: `${pct}%` }}
                  onPointerDown={() => (dragging.current = true)}
                  onPointerUp={() => (dragging.current = false)}
                  onPointerCancel={() => (dragging.current = false)}
                  onChange={(e) => {
                    const t = Number(e.target.value)
                    setTime(t)
                    if (videoRef.current) videoRef.current.currentTime = t
                    bump()
                  }}
                />
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    aria-label={muted ? 'Suarakan' : 'Bisukan'}
                    onClick={() => {
                      const m = !muted
                      setMuted(m)
                      if (videoRef.current) videoRef.current.muted = m
                    }}
                    className="flex h-8 w-8 items-center justify-center rounded-full active:bg-white/15"
                  >
                    <Icon name={muted || volume === 0 ? 'mute' : 'volume'} size={18} />
                  </button>
                  <input
                    type="range"
                    className="seek !w-20"
                    aria-label="Volume"
                    min={0}
                    max={1}
                    step={0.05}
                    value={muted ? 0 : volume}
                    style={{ ['--p' as string]: `${(muted ? 0 : volume) * 100}%` }}
                    onChange={(e) => {
                      const val = Number(e.target.value)
                      setVolume(val)
                      setMuted(val === 0)
                      if (videoRef.current) {
                        videoRef.current.volume = val
                        videoRef.current.muted = val === 0
                      }
                      bump()
                    }}
                  />
                  <div className="ml-auto flex items-center gap-0.5">
                    {fs && !locked ? (
                      <button
                        type="button"
                        aria-label="Daftar episode"
                        onClick={() => setListOpen(true)}
                        className="flex h-8 w-8 items-center justify-center rounded-full active:bg-white/15"
                      >
                        <Icon name="list" size={18} />
                      </button>
                    ) : null}
                    {pipSupported ? (
                      <button
                        type="button"
                        aria-label="Picture-in-Picture"
                        onClick={() => void native.enterPip()}
                        className="flex h-8 w-8 items-center justify-center rounded-full active:bg-white/15"
                      >
                        <Icon name="pip" size={18} />
                      </button>
                    ) : null}
                  </div>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* nobar: info singkat + panel room (owner, peserta, komentar) */}
      {!immersive && !mini && nobarId ? (
        <div className="flex min-h-0 flex-1 flex-col">
          <div className="flex shrink-0 items-center gap-3 px-4 pt-3">
            <Poster src={anime.poster} alt={title} className="h-[62px] w-[43px] shrink-0 rounded-lg ring-1 ring-line" />
            <div className="min-w-0 flex-1">
              <h1 className="line-clamp-2 text-[14.5px] font-bold leading-tight text-white">{title}</h1>
              <p className="mt-1 flex items-center gap-2.5 text-[12.5px] text-white/70">
                {episode || room ? <span className="font-semibold text-white">Episode {episode?.number ?? room?.epNo}</span> : null}
                {sources.length > 0 ? (
                  <button
                    type="button"
                    onClick={() => setQualityOpen(true)}
                    className="flex items-center gap-1 rounded-full bg-raise px-2.5 py-1 text-[11.5px] font-semibold text-white active:scale-95"
                  >
                    <Icon name="sliders" size={12} /> {currentSource?.quality ?? 'HQ'}
                  </button>
                ) : null}
              </p>
            </div>
          </div>
          <div className="min-h-0 flex-1">
            {room ? (
              <NobarPanel
                room={room}
                isOwner={isOwner}
                members={members}
                episodes={episodes}
                epId={epId}
                onPickEpisode={goEpisode}
                onChangeAnime={() => setPickAnime(true)}
                onStop={() => nav.closePlayer()}
                onLeave={() => nav.closePlayer()}
              />
            ) : (
              <div className="flex justify-center py-10">
                <Spinner size={26} />
              </div>
            )}
          </div>
        </div>
      ) : null}

      {/* info, episode, komunitas, komentar (mode portrait) */}
      {!immersive && !mini && !nobarId ? (
        <div className="min-h-0 flex-1 overflow-y-auto pb-8">
          <div className="flex gap-3 px-4 pt-3.5">
            <Poster src={anime.poster} alt={title} className="h-[116px] w-[78px] shrink-0 rounded-lg ring-1 ring-line" />
            <div className="min-w-0 flex-1">
              <h1 className="line-clamp-2 text-[15.5px] font-bold leading-tight text-white">{title}</h1>
              <p className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[12.5px] text-white/75">
                {episode ? <span className="font-semibold text-white">Episode {episode.number}</span> : null}
                {fmtCount(detail.data?.anime.views ?? anime.views) ? (
                  <span className="flex items-center gap-1">
                    <Icon name="eye" size={13} /> {fmtCount(detail.data?.anime.views ?? anime.views)}
                  </span>
                ) : null}
                {episode?.date ? <span>· {episode.date}</span> : null}
              </p>
              <div className="mt-2.5 flex flex-wrap gap-2">
                {sources.length > 0 ? (
                  <button
                    type="button"
                    onClick={() => setQualityOpen(true)}
                    className="flex items-center gap-1.5 rounded-full bg-raise px-3 py-1.5 text-[12px] font-semibold text-white active:scale-95"
                  >
                    <Icon name="sliders" size={14} /> {currentSource?.quality ?? ''} Quality
                  </button>
                ) : null}
                <button
                  type="button"
                  onClick={() => toast(toggleFavorite(anime) ? 'Ditambahkan ke favorit' : 'Dihapus dari favorit')}
                  className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-semibold active:scale-95 ${
                    fav ? 'bg-accent/15 text-accent' : 'bg-raise text-white'
                  }`}
                >
                  <Icon name={fav ? 'heartFill' : 'heart'} size={14} /> Favorit
                </button>
              </div>
            </div>
          </div>

          {detail.data?.anime.synopsis ? (
            <div className="mt-3 px-4">
              <p className={`text-[13px] leading-relaxed text-white/70 ${synMore ? '' : 'line-clamp-3'}`}>
                {detail.data.anime.synopsis}
              </p>
              {detail.data.anime.synopsis.length > 140 ? (
                <button type="button" onClick={() => setSynMore((m) => !m)} className="mt-0.5 text-[12.5px] font-semibold text-accent">
                  {synMore ? 'Sembunyikan' : 'Selengkapnya'}
                </button>
              ) : null}
            </div>
          ) : null}

          <div className="mt-4 flex items-center justify-between px-4">
            <h2 className="text-[19px] font-bold tracking-tight text-white">Episode List</h2>
            <button
              type="button"
              aria-label={epCollapsed ? 'Buka daftar episode' : 'Tutup daftar episode'}
              onClick={() => setEpCollapsed((c) => !c)}
              className="flex h-8 w-8 items-center justify-center rounded-lg bg-raise ring-1 ring-line active:scale-90"
            >
              <span className={`transition-transform ${epCollapsed ? '-rotate-90' : 'rotate-90'}`}>
                <Icon name="chevron" size={16} />
              </span>
            </button>
          </div>
          {!epCollapsed ? (
            <div className="mt-2.5">
              {eps.loading ? (
                <div className="flex gap-2 px-4">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="shimmer h-[50px] w-[50px] shrink-0 rounded-xl" />
                  ))}
                </div>
              ) : eps.error ? (
                <ErrorState compact message={errMsg(eps.error)} onRetry={eps.reload} />
              ) : noEpisodes ? (
                <div className="mx-4 rounded-2xl bg-raise/70 px-4 py-6 text-center">
                  <p className="text-[13px] text-muted">Server belum mengirim daftar episode untuk anime ini.</p>
                  <button
                    type="button"
                    onClick={eps.reload}
                    className="mt-3 rounded-full bg-accent px-5 py-2 text-[13px] font-bold text-ink active:scale-95"
                  >
                    Muat ulang episode
                  </button>
                </div>
              ) : (
                <EpisodeTiles episodes={episodes} currentId={epId} onSelect={(e) => goEpisode(e.id)} />
              )}
            </div>
          ) : null}

          {/* panduan komunitas */}
          <div className="mt-4 flex items-start gap-3 bg-raise/60 px-4 py-3">
            <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent/20 text-accent">
              <Icon name="info" size={17} />
            </span>
            <p className="text-[12px] leading-snug text-white/75">
              Ingatlah untuk selalu memberikan komentar yang sopan dengan mengikuti Pedoman Komunitas {APP_NAME}.{' '}
              <button type="button" onClick={() => setRulesOpen(true)} className="font-semibold text-accent">
                Pelajari lebih lanjut &gt;&gt;
              </button>
            </p>
          </div>

          {epId ? <Comments key={epId} animeId={anime.id} episodeId={epId} /> : null}
        </div>
      ) : null}

      {/* daftar episode saat fullscreen */}
      {fs && listOpen ? (
        <div className="fixed inset-0 z-[75] flex justify-end">
          <div className="absolute inset-0" onClick={() => setListOpen(false)} />
          <div className="relative h-full w-[min(340px,60%)] overflow-y-auto border-l border-white/10 bg-black/90 px-3 py-4 backdrop-blur-xl">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[15px] font-semibold text-white">Episode</h2>
              <button
                type="button"
                aria-label="Tutup"
                onClick={() => setListOpen(false)}
                className="flex h-8 w-8 items-center justify-center rounded-full active:bg-white/15"
              >
                <Icon name="x" size={18} />
              </button>
            </div>
            <EpisodeList episodes={episodes} currentId={epId} onSelect={(e) => goEpisode(e.id)} anime={anime} />
          </div>
        </div>
      ) : null}

      <Sheet open={pickAnime} onClose={() => setPickAnime(false)} title="Ganti anime nobar">
        <p className="mb-3 text-[12.5px] text-muted">Semua peserta ikut pindah ke anime yang kamu pilih.</p>
        <NobarAnimePicker onPick={(a) => void changeAnime(a)} />
      </Sheet>

      <Sheet open={rulesOpen} onClose={() => setRulesOpen(false)} title="Pedoman Komunitas">
        <ul className="list-disc space-y-2 pl-5 text-[13.5px] leading-relaxed text-white/75">
          <li>Gunakan bahasa yang sopan dan saling menghormati.</li>
          <li>Dilarang spam, promosi, atau menyebarkan tautan berbahaya.</li>
          <li>Hindari spoiler tanpa peringatan.</li>
          <li>Dilarang menghina, melecehkan, atau menyebarkan ujaran kebencian.</li>
          <li>Moderator dapat menghapus komentar yang melanggar pedoman.</li>
        </ul>
      </Sheet>

      <Sheet open={qualityOpen} onClose={() => setQualityOpen(false)} title="Kualitas video">
        <ul className="space-y-2">
          {sources.map((s) => (
            <li key={s.url}>
              <button
                type="button"
                onClick={() => changeQuality(s)}
                className={`flex w-full items-center justify-between rounded-2xl px-4 py-3 text-[14px] font-medium active:opacity-80 ${
                  s.url === srcUrl ? 'bg-accent text-ink' : 'bg-raise text-white'
                }`}
              >
                {s.quality}
                {s.url === srcUrl ? <Icon name="check" size={18} /> : null}
              </button>
            </li>
          ))}
        </ul>
      </Sheet>
    </div>
  )
}
