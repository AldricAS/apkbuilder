import { useState } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { useBoard, type BoardRow } from '../services/leaderboardService'
import { useLiveUsers } from '../services/liveProfiles'
import type { UserProfile } from '../services/userService'
import { PERIODS, PERIOD_LABEL, periodRange, type Period } from '../lib/board'
import { fmtNum } from '../lib/xp'
import { PageHeader } from '../components/PageHeader'
import { Avatar, LevelPill, RoleBadge, RoleCheck } from '../components/UserBadges'
import { EmptyState, ErrorState, Spinner } from '../components/States'
import { CrownIcon, RANK_COLOR, displayNameOf } from '../components/LeaderboardUi'

type Live = Map<string, UserProfile | null | undefined>

const PODIUM_BG = [
  'from-[#6b4a14]/70 to-[#2a1d08]/90 ring-[#F4C96B]/60',
  'from-[#3a4660]/70 to-[#1a2033]/90 ring-white/20',
  'from-[#5b3a22]/70 to-[#25170d]/90 ring-[#D58B5A]/40',
]

function Podium({ rows, live, meUid }: { rows: BoardRow[]; live: Live; meUid: string }) {
  const nav = useNav()
  // urutan tampil: peringkat 2, 1, 3
  const slots = [1, 0, 2]
  return (
    <div className="mx-4 grid grid-cols-3 items-end gap-2 rounded-3xl bg-gradient-to-b from-[#2b2257] to-[#171533] p-3 ring-1 ring-white/10">
      {slots.map((i) => {
        const r = rows[i]
        if (!r) return <div key={i} />
        const p = live.get(r.uid)
        const first = i === 0
        const name = displayNameOf(p)
        return (
          <button
            key={r.uid}
            type="button"
            onClick={() => nav.openProfile(r.uid)}
            className={`flex flex-col items-center rounded-2xl bg-gradient-to-b px-1.5 pb-3 pt-3 ring-1 active:scale-[0.97] ${PODIUM_BG[i]} ${first ? 'pb-4 pt-4' : ''} ${
              r.uid === meUid ? 'outline outline-2 outline-accent/70' : ''
            }`}
          >
            <div className="relative">
              {first ? (
                <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-[#F4C96B]">
                  <CrownIcon size={20} />
                </span>
              ) : null}
              <Avatar url={p?.photoURL} name={name} size={first ? 70 : 58} />
              <span
                className="absolute -bottom-1 -right-1 flex h-[22px] w-[22px] items-center justify-center rounded-full border-2 border-[#171533] text-[11px] font-extrabold text-[#1a1305]"
                style={{ background: RANK_COLOR[i] }}
              >
                {i + 1}
              </span>
            </div>
            <div className="mt-2.5 flex max-w-full items-center gap-1">
              <span className="min-w-0 truncate text-[13px] font-bold text-white">{name}</span>
              {p ? <RoleCheck role={p.role} verified={p.verified} size={13} /> : null}
            </div>
            {p ? (
              <div className="mt-1">
                <LevelPill level={p.level} />
              </div>
            ) : null}
            <p className="mt-1.5 text-[13px] font-extrabold" style={{ color: RANK_COLOR[i] }}>
              +{fmtNum(r.xp)}
            </p>
          </button>
        )
      })}
    </div>
  )
}

function Row({ rank, r, live, own }: { rank: number; r: BoardRow; live: Live; own: boolean }) {
  const nav = useNav()
  const p = live.get(r.uid)
  const name = displayNameOf(p)
  return (
    <button
      type="button"
      onClick={() => nav.openProfile(r.uid)}
      className={`flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left active:bg-white/5 ${own ? 'bg-accent/10 ring-1 ring-accent/30' : ''}`}
    >
      <span className="w-9 shrink-0 text-center text-[15px] font-extrabold text-[#F4C96B]">#{rank}</span>
      <Avatar url={p?.photoURL} name={name} size={46} />
      <div className="min-w-0 flex-1">
        <div className="flex min-w-0 items-center gap-1.5">
          <span className="min-w-0 truncate text-[14.5px] font-bold text-white">{name}</span>
          {p ? <RoleCheck role={p.role} verified={p.verified} size={14} /> : null}
          {p ? <span className="shrink-0 text-[11px] text-muted">#{p.userId}</span> : null}
        </div>
        {p ? (
          <div className="mt-1 flex items-center gap-1.5">
            {p.role === 'user' ? (
              <span className="rounded-md bg-white/10 px-1.5 py-[1px] text-[9.5px] font-extrabold leading-[14px] tracking-wide text-white/70">USER</span>
            ) : (
              <RoleBadge role={p.role} />
            )}
            <LevelPill level={p.level} />
          </div>
        ) : null}
      </div>
      <span className="shrink-0 text-[15px] font-extrabold text-[#F4C96B]">+{fmtNum(r.xp)}</span>
    </button>
  )
}

export function LeaderboardPage() {
  const nav = useNav()
  const me = useProfile()
  const [period, setPeriod] = useState<Period>('daily')
  const board = useBoard(period, 50)
  const rows = board.status === 'ok' ? board.rows : []
  const live = useLiveUsers(rows.map((r) => r.uid))
  const myIndex = rows.findIndex((r) => r.uid === me.uid)

  return (
    <div className="absolute inset-0 overflow-y-auto pb-12">
      <PageHeader title="Leaderboard XP" onBack={nav.pop} />

      <div className="relative mx-4 mt-1 grid grid-cols-3 rounded-full bg-raise/80 p-1">
        <div
          className="absolute bottom-1 left-1 top-1 rounded-full bg-[#2a7bff] transition-transform duration-300 ease-out"
          style={{ width: 'calc((100% - 8px) / 3)', transform: `translateX(${PERIODS.indexOf(period) * 100}%)` }}
        />
        {PERIODS.map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => setPeriod(p)}
            className={`relative z-10 py-2.5 text-[14px] font-bold transition-colors ${period === p ? 'text-white' : 'text-white/55'}`}
          >
            {PERIOD_LABEL[p]}
          </button>
        ))}
      </div>

      <p className="mx-4 mb-4 mt-4 text-[13.5px] font-medium tracking-wide text-muted">{periodRange(period)}</p>

      {board.status === 'loading' ? (
        <div className="flex justify-center py-20">
          <Spinner size={28} />
        </div>
      ) : board.status === 'error' ? (
        <ErrorState message={`Leaderboard tidak bisa dimuat: ${board.message}`} />
      ) : rows.length === 0 ? (
        <EmptyState icon="clock" title="Belum ada data" hint="Tonton anime untuk mendapat XP dan masuk leaderboard periode ini." />
      ) : (
        <div className="animate-fadeIn">
          <Podium rows={rows} live={live} meUid={me.uid} />
          <ul className="mt-3 space-y-0.5 px-2">
            {rows.slice(3).map((r, i) => (
              <li key={r.uid}>
                <Row rank={i + 4} r={r} live={live} own={r.uid === me.uid} />
              </li>
            ))}
          </ul>
          <p className="mt-4 px-4 text-center text-[12px] text-muted">
            {myIndex >= 0 ? `Peringkatmu: #${myIndex + 1}` : 'Kamu belum masuk 50 besar periode ini.'}
          </p>
        </div>
      )}
    </div>
  )
}
