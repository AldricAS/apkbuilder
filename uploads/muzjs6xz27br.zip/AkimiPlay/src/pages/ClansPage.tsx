import { useEffect, useState, type ReactNode } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import {
  CLAN_CREATE_COST,
  CLAN_DEFAULT_COLOR,
  CLAN_DESC_MAX,
  CLAN_EMBLEMS,
  CLAN_NAME_MAX,
  CLAN_SLOT_START,
  CLAN_TAG_MAX,
  cancelRequest,
  clanLevel,
  createClan,
  fmtCompact,
  normalizeTag,
  searchClans,
  useClan,
  useMyClanId,
  useMyRequest,
  useTopClans,
  type Clan,
} from '../services/clanService'
import { errMsg } from '../lib/format'
import { fmtNum } from '../lib/xp'
import { ClanBadge } from '../components/ClanBadge'
import { PixelEmblem } from '../components/PixelEmblem'
import { Icon } from '../components/Icon'
import { Spinner } from '../components/States'
import { Sheet, toast } from '../components/Feedback'

function Pill({ children, className }: { children: ReactNode; className: string }) {
  return <span className={`rounded-full px-3 py-1 text-[12.5px] font-bold ${className}`}>{children}</span>
}

// Tombol khas AkimiPlay: dasar hitam dengan aksen pink (#FF7AA2).
const BTN_PRIMARY = {
  background: 'linear-gradient(135deg, #FF7AA2 0%, #7A2A48 36%, #0B0B10 100%)',
  boxShadow: '0 0 18px rgba(255,122,162,0.28), inset 0 1px 0 rgba(255,255,255,0.18)',
} as const
const BTN_SECONDARY = {
  background: 'linear-gradient(135deg, #0B0B10 0%, #1A1117 100%)',
  boxShadow: '0 0 14px rgba(255,122,162,0.12)',
} as const

/** Satu baris clan (Top Clans / hasil pencarian). */
export function ClanRow({ clan, rank, onOpen }: { clan: Clan; rank?: number; onOpen: () => void }) {
  return (
    <button type="button" onClick={onOpen} className="w-full rounded-2xl bg-white/[0.04] px-3.5 py-3 text-left active:scale-[0.99] active:bg-white/[0.07]">
      <div className="flex items-center gap-3">
        {rank ? <span className="w-8 shrink-0 text-[17px] font-extrabold text-[#F4C96B]">#{rank}</span> : null}
        <ClanBadge tag={clan.tag} color={clan.color} emblem={clan.emblem} tier={clan.tier} height={30} />
        <span className="min-w-0 flex-1 truncate text-[17px] font-extrabold text-white">{clan.name}</span>
      </div>
      <div className={`mt-2.5 flex flex-wrap gap-2 ${rank ? 'pl-11' : ''}`}>
        <Pill className="bg-[#2b2650] text-[#A99CFF]">Lv {clanLevel(clan.xp)}</Pill>
        <Pill className="bg-[#173a3a] text-[#5EEAD4]">{fmtNum(clan.members)} member</Pill>
        <Pill className="bg-[#3a3418] text-[#F4C96B]">{fmtCompact(clan.xp)} XP</Pill>
      </div>
    </button>
  )
}

function CreateClanSheet({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (id: string) => void }) {
  const me = useProfile()
  const [name, setName] = useState('')
  const [tag, setTag] = useState('')
  const [desc, setDesc] = useState('')
  const [emblem, setEmblem] = useState(0)
  const [busy, setBusy] = useState(false)

  const shard = me.shard ?? 0
  const enough = shard >= CLAN_CREATE_COST
  const ok = name.trim().length >= 3 && tag.length >= 2 && enough
  const submit = async () => {
    if (!ok || busy) return
    setBusy(true)
    try {
      const id = await createClan(me, { name, tag, desc, emblem })
      toast('Clan berhasil dibuat. Kamu jadi leader!')
      onClose()
      onCreated(id)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title="Buat Clan">
      <div className="space-y-4">
        <div className="flex justify-center rounded-2xl bg-white/[0.04] py-4">
          <ClanBadge tag={tag || 'TAG'} color={CLAN_DEFAULT_COLOR} emblem={emblem} height={38} />
        </div>
        <div>
          <label className="mb-1.5 block text-[12.5px] font-semibold text-muted">Nama clan</label>
          <input
            value={name}
            maxLength={CLAN_NAME_MAX}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-2xl bg-raise px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-[12.5px] font-semibold text-muted">Tag (2-{CLAN_TAG_MAX} huruf/angka, unik)</label>
          <input
            value={tag}
            maxLength={CLAN_TAG_MAX}
            onChange={(e) => setTag(normalizeTag(e.target.value))}
            autoCapitalize="characters"
            className="w-full rounded-2xl bg-raise px-4 py-3 text-[15px] font-bold tracking-wider text-white focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-[12.5px] font-semibold text-muted">Deskripsi (opsional)</label>
          <textarea
            value={desc}
            maxLength={CLAN_DESC_MAX}
            rows={2}
            onChange={(e) => setDesc(e.target.value)}
            className="w-full resize-none rounded-2xl bg-raise px-4 py-3 text-[14.5px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
          />
        </div>
        <div>
          <p className="mb-2 text-[12.5px] font-semibold text-muted">Emblem</p>
          <div className="grid grid-cols-4 gap-2.5">
            {CLAN_EMBLEMS.map((name, i) => (
              <button
                key={name}
                type="button"
                aria-pressed={emblem === i}
                onClick={() => setEmblem(i)}
                className="min-w-0 text-center active:scale-95"
              >
                <span
                  className={`relative flex aspect-square w-full items-center justify-center rounded-[20px] bg-[#131a2c] ${
                    emblem === i ? 'ring-2 ring-accent' : ''
                  }`}
                >
                  <span
                    className={`absolute left-2 top-2 h-[14px] w-[14px] rounded-full ${
                      emblem === i ? 'bg-accent ring-2 ring-white/70' : 'bg-white/30'
                    }`}
                  />
                  <PixelEmblem index={i} size={46} />
                </span>
                <span className="mt-1.5 block truncate text-[12.5px] font-bold text-white">{name}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between rounded-2xl bg-white/[0.05] px-4 py-3">
          <div>
            <p className="text-[12px] text-muted">Biaya membuat clan</p>
            <p className="text-[18px] font-extrabold text-[#F4C96B]">{fmtNum(CLAN_CREATE_COST)} AkimiShard</p>
          </div>
          <div className="text-right">
            <p className="text-[12px] text-muted">Saldo kamu</p>
            <p className={`text-[18px] font-extrabold ${enough ? 'text-white' : 'text-[#FF8A9A]'}`}>{fmtNum(shard)}</p>
          </div>
        </div>
        {!enough ? <p className="text-[12.5px] text-[#FF8A9A]">AkimiShard kamu belum cukup. Kurang {fmtNum(CLAN_CREATE_COST - shard)}.</p> : null}
        <p className="text-[12px] leading-snug text-muted">
          Kamu jadi leader dan mendapat {CLAN_SLOT_START} slot anggota gratis. Warna awal clan putih; warna lain didapat lewat Spin Warna di Shop Clan. Nama, tag,
          dan emblem tidak bisa diubah setelah clan dibuat.
        </p>
        <button
          type="button"
          disabled={!ok || busy}
          onClick={() => void submit()}
          style={BTN_PRIMARY}
          className="flex w-full items-center justify-center gap-2 rounded-full border border-accent/50 py-3.5 text-[15px] font-extrabold text-white active:scale-[0.98] disabled:opacity-40"
        >
          {busy ? <Spinner size={18} /> : null} Buat Clan · {fmtNum(CLAN_CREATE_COST)} Shard
        </button>
      </div>
    </Sheet>
  )
}

/** Halaman Clans: buat clan, cari clan, dan Top Clans. Dibuka dari AkimiGames bila user belum punya clan. */
export function ClansPage() {
  const nav = useNav()
  const me = useProfile()
  const myClanId = useMyClanId(me.uid)
  const myReqId = useMyRequest(me.uid)
  const myClan = useClan(myClanId)
  const reqClan = useClan(myReqId)
  const top = useTopClans(30)

  const [creating, setCreating] = useState(false)
  const [searching, setSearching] = useState(false)
  const [q, setQ] = useState('')
  const [results, setResults] = useState<Clan[] | null>(null)
  const [busy, setBusy] = useState(false)

  const open = (id: string) => nav.push({ name: 'clan', id })

  useEffect(() => {
    if (!searching) return
    const term = q.trim()
    if (!term) {
      setResults(null)
      return
    }
    setBusy(true)
    const t = setTimeout(() => {
      searchClans(term)
        .then(setResults)
        .catch(() => {
          setResults([])
          toast('Pencarian gagal')
        })
        .finally(() => setBusy(false))
    }, 350)
    return () => clearTimeout(t)
  }, [q, searching])

  const startCreate = () => {
    if (myClanId) return toast('Kamu sudah berada di sebuah clan')
    setCreating(true)
  }
  const list = searching && q.trim() ? results : top

  return (
    <div className="absolute inset-0 overflow-y-auto bg-ink pb-24">
      <header className="pt-safe">
        <div className="flex items-start gap-3 px-4 pb-2 pt-3">
          <button type="button" aria-label="Kembali" onClick={nav.pop} className="-ml-1 mt-0.5 flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10">
            <Icon name="back" size={26} />
          </button>
          <div>
            <h1 className="text-[34px] font-extrabold leading-tight tracking-tight text-white">Clans</h1>
            <p className="text-[15px] text-muted">Bangun squad, donasi &amp; tumbuh bersama</p>
          </div>
        </div>
      </header>

      <div className="mx-4 mt-3 flex items-center gap-4 rounded-3xl bg-white/[0.05] p-4">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-[#1b2a4a] text-[26px]">💎</div>
        <div className="min-w-0 flex-1">
          <p className="text-[15px] text-muted">AkimiShard</p>
          <p className="text-[28px] font-extrabold leading-tight text-white">{fmtNum(me.shard ?? 0)}</p>
        </div>
        <div className="text-right">
          <p className="text-[12.5px] text-muted">Clan kamu</p>
          <p className="text-[17px] font-extrabold text-[#5EEAD4]">{myClan ? myClan.tag : '—'}</p>
        </div>
      </div>

      {myClan ? (
        <button
          type="button"
          onClick={() => open(myClan.id)}
          className="mx-4 mt-3 flex w-[calc(100%-2rem)] items-center gap-3 rounded-3xl border border-[#8B5CF6]/40 bg-[#8B5CF6]/10 p-3.5 text-left active:scale-[0.99]"
        >
          <ClanBadge tag={myClan.tag} color={myClan.color} emblem={myClan.emblem} tier={myClan.tier} height={30} />
          <span className="min-w-0 flex-1 truncate text-[16px] font-extrabold text-white">{myClan.name}</span>
          <span className="text-[13px] font-bold text-[#C4B5FD]">Buka</span>
          <Icon name="chevron" size={18} className="text-[#C4B5FD]" />
        </button>
      ) : null}

      {!myClanId && myReqId ? (
        <div className="mx-4 mt-3 rounded-3xl bg-white/[0.05] p-4">
          <p className="text-[14px] text-white/80">
            Permintaan ke <span className="font-bold text-white">{reqClan?.name ?? 'clan'}</span> sedang menunggu persetujuan leader.
          </p>
          <button
            type="button"
            onClick={() => cancelRequest(me.uid, myReqId).then(() => toast('Permintaan dibatalkan')).catch((e) => toast(errMsg(e)))}
            className="mt-3 rounded-full bg-raise px-4 py-2 text-[13.5px] font-semibold text-accent active:scale-95"
          >
            Batalkan permintaan
          </button>
        </div>
      ) : null}

      <div className="mx-4 mt-3 flex gap-3 rounded-3xl bg-white/[0.05] p-3">
        {/* sudah masuk clan: tombol Buat Clan disembunyikan, tinggal Cari Clan */}
        {myClanId === null ? (
          <button
            type="button"
            onClick={startCreate}
            style={BTN_PRIMARY}
            className="flex-1 rounded-full border border-accent/50 py-4 text-[17px] font-extrabold text-white active:scale-[0.98]"
          >
            Buat Clan
          </button>
        ) : null}
        <button
          type="button"
          onClick={() => setSearching((s) => !s)}
          style={BTN_SECONDARY}
          className="flex-1 rounded-full border border-accent/60 py-4 text-[17px] font-extrabold text-accent active:scale-[0.98]"
        >
          {searching ? 'Tutup Cari' : 'Cari Clan'}
        </button>
      </div>

      <div className="mx-4 mt-3 rounded-3xl bg-white/[0.05] p-4">
        {searching ? (
          <div className="mb-4 flex items-center gap-2 rounded-full bg-raise px-4">
            <Icon name="search" size={18} className="text-muted" />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Nama atau tag clan"
              className="h-11 min-w-0 flex-1 bg-transparent text-[15px] text-white placeholder:text-muted focus:outline-none"
            />
            {busy ? <Spinner size={16} /> : null}
          </div>
        ) : null}
        <h2 className="mb-3 text-[24px] font-extrabold text-[#F4C96B]">{searching && q.trim() ? 'Hasil pencarian' : 'Top Clans'}</h2>
        {list === undefined || list === null ? (
          <div className="flex justify-center py-10">
            <Spinner size={26} />
          </div>
        ) : list.length === 0 ? (
          <p className="py-8 text-center text-[14px] text-muted">
            {searching && q.trim() ? 'Clan tidak ditemukan.' : 'Belum ada clan. Jadilah yang pertama!'}
          </p>
        ) : (
          <div className="space-y-2.5">
            {list.map((c, i) => (
              <ClanRow key={c.id} clan={c} rank={searching && q.trim() ? undefined : i + 1} onOpen={() => open(c.id)} />
            ))}
          </div>
        )}
      </div>

      <CreateClanSheet open={creating} onClose={() => setCreating(false)} onCreated={open} />
    </div>
  )
}
