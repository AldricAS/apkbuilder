import type { ReactNode } from 'react'
import { useState } from 'react'
import { animeApi } from '../services/animeApi'
import { useAsync } from '../hooks/hooks'
import { useNav } from '../nav/router'
import { historyStore, toggleFavorite, useIsFavorite, useStore } from '../storage/stores'
import type { Anime, AnimeLite } from '../types'
import { errMsg, statusLabel } from '../lib/format'
import { AnimeRow } from '../components/Section'
import { EpisodeList } from '../components/EpisodeList'
import { ErrorState, Spinner } from '../components/States'
import { Icon } from '../components/Icon'
import { Poster } from '../components/Poster'
import { toast } from '../components/Feedback'
import { DownloadSheet } from '../components/DownloadUi'

function Meta({ label, value }: { label: string; value?: string | number }) {
  if (value === undefined || value === '') return null
  return (
    <div className="rounded-2xl bg-raise/70 px-3.5 py-2.5">
      <p className="text-[11px] text-muted">{label}</p>
      <p className="mt-0.5 text-[13.5px] font-medium text-white">{value}</p>
    </div>
  )
}

export function DetailPage({ id, hint }: { id: string; hint?: AnimeLite }) {
  const nav = useNav()
  const detail = useAsync(() => animeApi.detail(id), [id])
  const eps = useAsync(() => animeApi.episodes(id), [id])
  const detailReady = !detail.loading
  const recs = useAsync(
    () => {
      if (!detailReady) return null
      const base = detail.data?.anime ?? (hint as Anime | undefined)
      if (!base) return null
      if (detail.data?.recommendations.length) return Promise.resolve(detail.data.recommendations)
      return animeApi.recommendations(base as Anime)
    },
    [id, detailReady],
  )

  const history = useStore(historyStore)
  const fav = useIsFavorite(id)
  const [more, setMore] = useState(false)
  const [dlOpen, setDlOpen] = useState(false)

  const anime: (AnimeLite & Partial<Anime>) | undefined = detail.data?.anime ?? hint
  const entry = history.find((h) => h.animeId === id)
  const episodes = eps.data ?? []

  if (!anime) {
    return (
      <div className="absolute inset-0 overflow-y-auto">
        <BackBar onBack={nav.pop} />
        {detail.loading ? (
          <div className="flex justify-center py-32">
            <Spinner size={30} />
          </div>
        ) : (
          <ErrorState message={errMsg(detail.error)} onRetry={detail.reload} />
        )}
      </div>
    )
  }

  const lite: AnimeLite = { id: anime.id, title: anime.title, poster: anime.poster }
  const total = anime.totalEpisodes ?? (episodes.length || undefined)
  const bg = anime.banner ?? anime.poster

  return (
    <div className="absolute inset-0 overflow-y-auto pb-16">
      {/* latar blur dari banner / poster */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[430px] overflow-hidden">
        <Poster src={bg} alt="" className="h-full w-full scale-125 opacity-40 blur-2xl" />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/30 via-ink/70 to-ink" />
      </div>

      <div className="relative">
        <BackBar
          onBack={nav.pop}
          right={
            <button
              type="button"
              aria-label={fav ? 'Hapus dari favorit' : 'Tambah ke favorit'}
              onClick={() => toast(toggleFavorite(anime) ? 'Ditambahkan ke favorit' : 'Dihapus dari favorit')}
              className={`flex h-10 w-10 items-center justify-center rounded-full glass ${fav ? 'text-accent' : 'text-white'}`}
            >
              <Icon name={fav ? 'heartFill' : 'heart'} size={20} />
            </button>
          }
        />

        <div className="flex gap-4 px-4 pt-2">
          <Poster
            src={anime.poster}
            alt={anime.title}
            className="h-[204px] w-[136px] shrink-0 rounded-2xl shadow-[0_14px_40px_rgba(0,0,0,0.65)] ring-1 ring-white/15"
          />
          <div className="flex min-w-0 flex-1 flex-col justify-end pb-1">
            <h1 className="text-[22px] font-extrabold leading-tight tracking-tight text-white">{anime.title}</h1>
            {anime.japaneseTitle ? (
              <p className="mt-1 line-clamp-2 text-[12.5px] text-white/60">{anime.japaneseTitle}</p>
            ) : null}
            <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[12.5px] text-white/80">
              {anime.score ? (
                <span className="flex items-center gap-1 font-semibold text-white">
                  <Icon name="star" size={14} className="text-accent" />
                  {anime.score.toFixed(1)}
                </span>
              ) : null}
              {anime.year ? <span>{anime.year}</span> : null}
              {anime.type ? <span>{anime.type}</span> : null}
              {statusLabel(anime.status) ? (
                <span className="rounded-md bg-accent px-1.5 py-0.5 text-[10.5px] font-bold text-ink">
                  {statusLabel(anime.status)}
                </span>
              ) : null}
            </div>
          </div>
        </div>

        {/* aksi */}
        <div className="mt-5 flex gap-2.5 px-4">
          <button
            type="button"
            onClick={() => nav.play(lite, episodes[0]?.id)}
            className="flex flex-1 items-center justify-center gap-2 rounded-full bg-accent py-3 text-[14px] font-bold text-ink active:scale-[0.97]"
          >
            <Icon name="play" size={18} /> Mulai Nonton
          </button>
          {entry ? (
            <button
              type="button"
              onClick={() => nav.play(lite, entry.episodeId)}
              className="glass flex flex-1 items-center justify-center gap-2 rounded-full py-3 text-[14px] font-semibold text-white active:scale-[0.97]"
            >
              Lanjutkan · Ep {entry.episodeNumber}
            </button>
          ) : null}
        </div>
        <div className="mt-2.5 px-4">
          <button
            type="button"
            onClick={() => toast(toggleFavorite(anime) ? 'Ditambahkan ke favorit' : 'Dihapus dari favorit')}
            className={`flex w-full items-center justify-center gap-2 rounded-full py-2.5 text-[13.5px] font-semibold active:scale-[0.98] ${
              fav ? 'bg-accent/15 text-accent' : 'bg-raise text-white/85'
            }`}
          >
            <Icon name={fav ? 'heartFill' : 'heart'} size={17} /> {fav ? 'Favorit' : 'Tambah ke Favorit'}
          </button>
        </div>

        {detail.error ? (
          <div className="mx-4 mt-4 flex items-center justify-between rounded-2xl bg-[#2a1720] px-4 py-3 text-[12.5px] text-accent">
            <span>Detail lengkap belum termuat.</span>
            <button type="button" onClick={detail.reload} className="font-bold underline">
              Coba lagi
            </button>
          </div>
        ) : null}

        {/* genre */}
        {anime.genres?.length ? (
          <div className="no-scrollbar mt-5 flex gap-2 overflow-x-auto px-4">
            {anime.genres.map((g, i) => (
              <button
                key={g}
                type="button"
                onClick={() => anime.genreIds?.[i] && nav.push({ name: 'genre', id: anime.genreIds[i], title: g })}
                className="shrink-0 rounded-full bg-raise px-3.5 py-1.5 text-[12.5px] font-medium text-white/85"
              >
                {g}
              </button>
            ))}
          </div>
        ) : null}

        {/* sinopsis */}
        {anime.synopsis ? (
          <div className="mt-5 px-4">
            <h2 className="text-[16px] font-semibold text-white">Sinopsis</h2>
            <p className={`mt-1.5 text-[13.5px] leading-relaxed text-white/75 ${more ? '' : 'line-clamp-4'}`}>
              {anime.synopsis}
            </p>
            {anime.synopsis.length > 200 ? (
              <button type="button" onClick={() => setMore((m) => !m)} className="mt-1 text-[13px] font-semibold text-accent">
                {more ? 'Sembunyikan' : 'Selengkapnya'}
              </button>
            ) : null}
          </div>
        ) : null}

        {/* info */}
        <div className="mt-5 grid grid-cols-2 gap-2.5 px-4">
          <Meta label="Studio" value={anime.studios?.join(', ')} />
          <Meta label="Tahun" value={anime.year} />
          <Meta label="Tipe" value={anime.type} />
          <Meta label="Status" value={statusLabel(anime.status)} />
          <Meta label="Total Episode" value={total} />
          <Meta label="Rating" value={anime.score ? anime.score.toFixed(1) : undefined} />
        </div>

        {/* episode */}
        <section className="mt-7 px-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-[17px] font-semibold text-white">
              Episode{episodes.length ? <span className="ml-2 text-[13px] font-normal text-muted">{episodes.length}</span> : null}
            </h2>
            {episodes.length ? (
              <button
                type="button"
                onClick={() => setDlOpen(true)}
                className="flex items-center gap-1.5 rounded-full bg-raise px-3.5 py-1.5 text-[12.5px] font-semibold text-white active:scale-95"
              >
                <Icon name="download" size={15} /> Download
              </button>
            ) : null}
          </div>
          {eps.loading ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="shimmer h-14 rounded-2xl" />
              ))}
            </div>
          ) : eps.error ? (
            <ErrorState compact message={errMsg(eps.error)} onRetry={eps.reload} />
          ) : episodes.length ? (
            <EpisodeList
              episodes={episodes}
              currentId={entry?.episodeId}
              onSelect={(e) => nav.play(lite, e.id)}
              anime={anime}
            />
          ) : (
            <div className="rounded-2xl bg-raise/70 px-4 py-6 text-center">
              <p className="text-[13px] text-muted">Server belum mengirim daftar episode untuk anime ini.</p>
              <button
                type="button"
                onClick={eps.reload}
                className="mt-3 rounded-full bg-accent px-5 py-2 text-[13px] font-bold text-ink active:scale-95"
              >
                Muat ulang episode
              </button>
            </div>
          )}
        </section>

        <DownloadSheet open={dlOpen} onClose={() => setDlOpen(false)} anime={anime} episodes={episodes} />

        {recs.loading ? null : <AnimeRow title="Rekomendasi" items={recs.data ?? []} onOpen={nav.openAnime} />}
      </div>
    </div>
  )
}

function BackBar({ onBack, right }: { onBack: () => void; right?: ReactNode }) {
  return (
    <div className="pt-safe">
      <div className="flex h-14 items-center justify-between px-3">
        <button
          type="button"
          aria-label="Kembali"
          onClick={onBack}
          className="glass flex h-10 w-10 items-center justify-center rounded-full active:scale-90"
        >
          <Icon name="back" size={22} />
        </button>
        {right}
      </div>
    </div>
  )
}
