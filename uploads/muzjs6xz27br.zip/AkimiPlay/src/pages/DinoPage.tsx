import { lazy, Suspense, useEffect, useState, type ReactNode } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { useBackHandler } from '../native/native'
import {
  BY_RARITY, DINO, RARITIES, RAR_KEYS, RUN_CAP, SELL_PRICE, SKINS, gamesToday, ownedCount, selectSkin, sellDuplicate, useDino,
  type DinoState, type Rarity, type SkinDef, DinoError,
} from '../services/dinoService'
import { SpriteView, skinKey } from '../dino/SpriteView'
import { Btn } from '../dino/ui'
import { closeAudio, isMuted, setMuted, sfx } from '../dino/sfx'
import { releaseSheets } from '../dino/engine'
import { ConfirmDialog, toast } from '../components/Feedback'
import { Icon } from '../components/Icon'

// mesin game & layar spin dimuat saat dibutuhkan (kode + sprite tidak dimuat sebelum user membuka Dino)
const GameScreen = lazy(() => import('../dino/GameScreen'))
const SpinScreen = lazy(() => import('../dino/SpinScreen'))

type View = { v: 'menu' } | { v: 'collection' } | { v: 'detail'; id: number } | { v: 'spin' } | { v: 'play' }

const fmt = (n: number) => n.toLocaleString('id-ID')
const STARS = Array.from({ length: 26 }, (_, i) => ({ x: (i * 41 + 7) % 100, y: (i * 29 + 11) % 100, s: i % 4 === 0 ? 2 : 1, d: 2 + (i % 4) }))

function Stars() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {STARS.map((s, i) => (<span key={i} className="absolute animate-twinkle bg-white" style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s * 2, height: s.s * 2, animationDuration: `${s.d}s`, animationDelay: `${i * 0.2}s`, opacity: 0.5 }} />))}
    </div>
  )
}

function RarityTag({ r, small = false }: { r: Rarity; small?: boolean }) {
  const x = RARITIES[r]
  return (
    <span className={`inline-flex items-center gap-1 border-2 border-[#05040e] font-mono font-extrabold tracking-widest ${small ? 'px-1.5 py-[1px] text-[8.5px]' : 'px-2 py-0.5 text-[10px]'}`} style={{ background: x.glow, color: '#fff' }}>
      ♛ {x.label}
    </span>
  )
}

function TopBar({ title, onBack, right }: { title: string; onBack: () => void; right?: ReactNode }) {
  return (
    <header className="pt-safe sticky top-0 z-20 bg-[#0a0820]/95">
      <div className="flex h-14 items-center gap-2 px-3">
        <button type="button" aria-label="Kembali" onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"><Icon name="back" size={22} /></button>
        <h1 className="min-w-0 flex-1 truncate font-mono text-[16px] font-extrabold tracking-widest text-white">{title}</h1>
        {right}
      </div>
    </header>
  )
}

/** Kartu Dino di koleksi. Locked = siluet gelap. */
function Card({ s, owned, count, selected, onClick }: { s: SkinDef; owned: boolean; count: number; selected: boolean; onClick: () => void }) {
  const r = RARITIES[s.rarity]
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative flex flex-col items-center overflow-hidden rounded-sm p-1.5 pb-2 text-center active:scale-[0.97] ${owned && s.rarity !== 'common' ? 'px-pulse' : ''}`}
      style={{ background: owned ? `linear-gradient(180deg, ${r.glow}55, #12102a 70%)` : '#0d0b22', border: `3px solid ${owned ? r.color : '#241f4a'}`, boxShadow: '0 3px 0 #05040e', ['--ring' as string]: r.ring }}
    >
      {selected ? <span className="absolute left-1 top-1 bg-[#2fbf5d] px-1 font-mono text-[8px] font-extrabold text-[#06280f]">DIPAKAI</span> : null}
      {count > 1 ? <span className="absolute right-1 top-1 bg-[#05040e] px-1 font-mono text-[9px] font-extrabold text-[#ffd84a]">×{count}</span> : null}
      <SpriteView skin={s.key} anim="idle" scale={2} locked={!owned} className="mt-3" />
      <p className="mt-1 font-mono text-[11px] font-extrabold" style={{ color: owned ? r.color : '#5a5490' }}>{owned ? s.name : '???'}</p>
      <p className="font-mono text-[8.5px] font-bold tracking-widest text-white/40">{owned ? 'OWNED' : '🔒 LOCKED'}</p>
    </button>
  )
}

function Collection({ st, onBack, onOpen }: { st: DinoState; onBack: () => void; onOpen: (id: number) => void }) {
  const total = ownedCount(st)
  return (
    <div className="absolute inset-0 overflow-y-auto overflow-x-hidden bg-[#0a0820] pb-24 text-white [touch-action:pan-y]">
      <Stars />
      <TopBar title="DINO COLLECTION" onBack={onBack} />
      <div className="relative mx-4 mt-1">
        <p className="font-mono text-[22px] font-extrabold tracking-wider text-white">{total} <span className="text-white/45">/ {SKINS.length}</span> <span className="text-[13px] tracking-widest text-white/55">OWNED</span></p>
        <div className="mt-2 grid grid-cols-4 gap-2">
          {RAR_KEYS.map((r) => {
            const list = BY_RARITY(r); const have = list.filter((s) => st.own[s.id]).length
            return (
              <div key={r} className="px-panel rounded-sm p-1.5 text-center" style={{ ['--edge' as string]: RARITIES[r].glow }}>
                <p className="font-mono text-[8.5px] font-extrabold tracking-wider" style={{ color: RARITIES[r].color }}>{RARITIES[r].label}</p>
                <p className="font-mono text-[13px] font-extrabold text-white">{have}/{list.length}</p>
              </div>
            )
          })}
        </div>
      </div>
      {RAR_KEYS.map((r) => (
        <section key={r} className="relative mx-4 mt-5">
          <p className="mb-2 flex items-center gap-2 font-mono text-[12px] font-extrabold tracking-[.2em]" style={{ color: RARITIES[r].color }}><span className="h-[3px] w-5" style={{ background: RARITIES[r].color }} />{RARITIES[r].label}</p>
          <div className={`grid gap-2 ${r === 'mythic' ? 'grid-cols-1 px-[22%]' : r === 'legend' ? 'grid-cols-3' : 'grid-cols-4'}`}>
            {BY_RARITY(r).map((s) => (<Card key={s.id} s={s} owned={!!st.own[s.id]} count={st.own[s.id] ?? 0} selected={st.selected === s.id} onClick={() => { sfx('click'); onOpen(s.id) }} />))}
          </div>
        </section>
      ))}
    </div>
  )
}

function Detail({ id, st, uid, onBack, onProgress }: { id: number; st: DinoState; uid: string; onBack: () => void; onProgress: () => void }) {
  const s = SKINS[id]; const r = RARITIES[s.rarity]
  const own = st.own[id] ?? 0; const owned = own > 0
  const [busy, setBusy] = useState(false)
  const [ask, setAsk] = useState(false)
  const use = async () => {
    setBusy(true)
    try { await selectSkin(uid, id); sfx('click'); toast(`${s.name} dipakai`) } catch (e) { toast(e instanceof DinoError ? e.message : 'Gagal') } finally { setBusy(false) }
  }
  return (
    <div className="absolute inset-0 overflow-y-auto overflow-x-hidden pb-28 text-white [touch-action:pan-y]" style={{ background: `radial-gradient(ellipse at 50% 18%, ${r.glow}66, #0a0820 62%)` }}>
      <Stars />
      <TopBar title={owned ? s.name.toUpperCase() : '???'} onBack={onBack} right={<RarityTag r={s.rarity} />} />
      <div className="relative mx-4 mt-2">
        <div className="px-panel flex flex-col items-center rounded-sm py-5" style={{ ['--edge' as string]: r.color }}>
          <div className={owned ? 'px-bob' : ''}><SpriteView skin={s.key} anim="idle" scale={7} locked={!owned} /></div>
          <p className="mt-2 font-mono text-[22px] font-extrabold tracking-widest" style={{ color: owned ? r.color : '#6a63a8' }}>{s.name.toUpperCase()}</p>
          <p className="mt-1 px-5 text-center font-mono text-[11.5px] leading-relaxed text-white/70">{s.desc}</p>
          <p className="mt-2 font-mono text-[11px] font-extrabold tracking-widest" style={{ color: owned ? '#6cff9a' : '#ff8a9c' }}>{owned ? `OWNED${own > 1 ? ` ×${own}` : ''}` : '🔒 LOCKED'}</p>
        </div>

        <div className="px-panel mt-3 rounded-sm p-3">
          <p className="mb-2 font-mono text-[11px] font-extrabold tracking-widest text-white/60">ANIMASI</p>
          <div className="grid grid-cols-3 gap-2 text-center">
            {(['run', 'jump', 'crouch'] as const).map((a) => (
              <div key={a} className="flex flex-col items-center rounded-sm bg-[#0b0920] py-2">
                <SpriteView skin={s.key} anim={a} scale={2} locked={!owned} />
                <p className="font-mono text-[9.5px] font-extrabold tracking-widest text-white/55">{a.toUpperCase()}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="px-panel mt-3 rounded-sm p-3">
          <p className="mb-2 font-mono text-[11px] font-extrabold tracking-widest text-white/60">EFEK</p>
          <ul className="space-y-1 font-mono text-[11.5px] text-white/80">
            {s.fx.map((f) => (<li key={f} className="flex gap-2"><span style={{ color: r.color }}>■</span>{owned || s.rarity === 'common' ? f : '???'}</li>))}
          </ul>
          <p className="mt-2 font-mono text-[10.5px] text-white/45">Hadiah AkimiShard: 1 skor = 1 shard, maksimal {RUN_CAP(s.id).toLocaleString('id-ID')} per game · {DINO.DAILY_MAX} game/hari.</p>
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 space-y-2 bg-gradient-to-t from-[#0a0820] via-[#0a0820]/95 to-transparent px-4 pb-5 pt-6" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom,0px) + 16px)' }}>
        {owned ? (
          <>
            <Btn tone="green" disabled={busy || st.selected === id} onClick={() => void use()}>{st.selected === id ? 'Sedang dipakai ✓' : 'Pakai dino'}</Btn>
            {own > 1 ? <Btn tone="gold" small onClick={() => setAsk(true)}>Jual 1 duplikat · +{SELL_PRICE(id)} shard</Btn> : null}
          </>
        ) : (
          <>
            <Btn tone="dark" disabled onClick={() => undefined}>🔒 Terkunci</Btn>
            <Btn tone="purple" onClick={onProgress}>Lihat progres</Btn>
          </>
        )}
      </div>
      <ConfirmDialog
        open={ask}
        title={`Jual 1 ${s.name}?`}
        message={`Kamu mendapat ${SELL_PRICE(id)} AkimiShard. Satu salinan tetap tersimpan di koleksi.`}
        confirmLabel="Jual"
        onCancel={() => setAsk(false)}
        onConfirm={() => {
          setAsk(false)
          void sellDuplicate(uid, id).then((p) => { sfx('coin'); toast(`Terjual +${p} AkimiShard`) }).catch((e) => toast(e instanceof DinoError ? e.message : 'Gagal menjual'))
        }}
      />
    </div>
  )
}

function Menu({ st, shard, onBack, onPlay, onCollection, onSpin }: { st: DinoState; shard: number; onBack: () => void; onPlay: () => void; onCollection: () => void; onSpin: () => void }) {
  const used = gamesToday(st)
  const left = DINO.DAILY_MAX - used
  const sel = st.selected
  const [mute, setMute] = useState(isMuted())
  const none = ownedCount(st) === 0
  return (
    <div className="absolute inset-0 overflow-y-auto overflow-x-hidden bg-gradient-to-b from-[#0a0f2e] via-[#150c3a] to-[#0a0820] pb-10 text-white [touch-action:pan-y]">
      <Stars />
      <TopBar
        title="AKIMIGAME"
        onBack={onBack}
        right={
          <>
            <span className="px-panel rounded-sm px-2 py-1 font-mono text-[11.5px] font-extrabold text-[#6cff9a]" style={{ ['--edge' as string]: '#1f6b3a' }}>◆ {fmt(shard)}</span>
            <button type="button" aria-label={mute ? 'Nyalakan suara' : 'Matikan suara'} onClick={() => { setMuted(!mute); setMute(!mute) }} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"><Icon name={mute ? 'mute' : 'volume'} size={20} /></button>
          </>
        }
      />
      <div className="relative px-4 pt-2 text-center">
        <p className="font-mono text-[11px] font-extrabold tracking-[.4em] text-[#ff7ac8]">AKIMIGAME</p>
        <h2 className="font-mono text-[34px] font-extrabold leading-none tracking-widest text-white" style={{ textShadow: '0 4px 0 #5b21b6, 0 8px 0 #05040e' }}>DINO RUN</h2>
      </div>

      <div className="relative mx-auto mt-4 flex w-[260px] flex-col items-center">
        <div className="px-panel w-full rounded-sm py-5" style={{ ['--edge' as string]: sel >= 0 ? RARITIES[SKINS[sel].rarity].color : '#7C3AED' }}>
          <div className="flex justify-center"><div className="px-bob"><SpriteView skin={skinKey(sel)} anim="run" scale={6} /></div></div>
          <div className="mx-auto mt-1 h-1 w-40 bg-black/40" />
          <p className="mt-2 text-center font-mono text-[12px] font-extrabold tracking-widest" style={{ color: sel >= 0 ? RARITIES[SKINS[sel].rarity].color : '#ff9fc0' }}>{sel >= 0 ? SKINS[sel].name.toUpperCase() : 'AKIMI ORB'}</p>
          <p className="text-center font-mono text-[9.5px] tracking-wider text-white/45">{sel >= 0 ? RARITIES[SKINS[sel].rarity].label : 'AVATAR NETRAL (BUKAN DINO)'}</p>
        </div>
      </div>

      <div className="relative mx-4 mt-4 grid grid-cols-3 gap-2 text-center font-mono">
        <div className="px-panel rounded-sm p-2"><p className="text-[8.5px] font-bold tracking-widest text-white/50">GAME HARI INI</p><p className="text-[17px] font-extrabold text-[#ffd84a]">{used} / {DINO.DAILY_MAX}</p></div>
        <div className="px-panel rounded-sm p-2"><p className="text-[8.5px] font-bold tracking-widest text-white/50">BEST</p><p className="text-[17px] font-extrabold text-white tabular-nums">{fmt(st.best)}</p></div>
        <div className="px-panel rounded-sm p-2"><p className="text-[8.5px] font-bold tracking-widest text-white/50">KOLEKSI</p><p className="text-[17px] font-extrabold text-[#ff7ac8]">{ownedCount(st)}/{SKINS.length}</p></div>
      </div>

      {none ? (
        <div className="px-panel relative mx-4 mt-3 rounded-sm p-3" style={{ ['--edge' as string]: '#c98a00' }}>
          <p className="font-mono text-[11.5px] leading-relaxed text-white/80"><b className="text-[#ffd84a]">Belum ada Dino.</b> Main dulu dengan Akimi Orb untuk mengumpulkan AkimiShard, lalu Unlock Pertama (Common) hanya ◆ {DINO.FIRST_UNLOCK}.</p>
        </div>
      ) : null}

      <div className="relative mx-4 mt-4 space-y-2.5">
        {left > 0 ? (
          <Btn tone="green" onClick={() => { sfx('click'); onPlay() }}>▶ Main</Btn>
        ) : (
          <div className="px-panel rounded-sm p-3 text-center font-mono text-[12px] text-[#ffb36b]">Kesempatan bermain hari ini sudah habis.<br /><span className="text-[10px] text-white/45">Reset otomatis besok (WIB)</span></div>
        )}
        <Btn tone="purple" onClick={() => { sfx('click'); onCollection() }}>Dino collection</Btn>
        <Btn tone="pink" onClick={() => { sfx('click'); onSpin() }}>{none ? 'Unlock / spin dino' : 'Spin dino'}</Btn>
      </div>
    </div>
  )
}

/** Pintu masuk AkimiGame: Dino Run. */
export function DinoPage() {
  const nav = useNav()
  const me = useProfile()
  const st = useDino(me.uid)
  const [view, setView] = useState<View>({ v: 'menu' })
  const [stack, setStack] = useState<View[]>([])
  const go = (v: View) => { setStack((s) => [...s, view]); setView(v) }
  const back = () => {
    if (stack.length) { const p = stack[stack.length - 1]; setStack(stack.slice(0, -1)); setView(p) } else nav.pop()
  }
  useBackHandler(() => { if (view.v === 'play') return false; back(); return true }, 40, true)
  useEffect(() => () => { closeAudio(); releaseSheets([]) }, [])

  if (!st) return <div className="absolute inset-0 flex items-center justify-center bg-[#0a0820] font-mono text-[13px] font-bold tracking-widest text-white/60">MEMUAT…</div>
  const shard = me.shard ?? 0
  const Loading = <div className="absolute inset-0 flex items-center justify-center bg-[#0a0820] font-mono text-[13px] font-bold tracking-widest text-white/60">MEMUAT…</div>

  switch (view.v) {
    case 'collection':
      return <Collection st={st} onBack={back} onOpen={(id) => go({ v: 'detail', id })} />
    case 'detail':
      return <Detail id={view.id} st={st} uid={me.uid} onBack={back} onProgress={() => go({ v: 'spin' })} />
    case 'spin':
      return (
        <Suspense fallback={Loading}>
          <SpinScreen uid={me.uid} state={st} shard={shard} onBack={back} onOpen={(id) => go({ v: 'detail', id })} />
        </Suspense>
      )
    case 'play':
      return (
        <Suspense fallback={Loading}>
          <GameScreen uid={me.uid} state={st} gamesUsed={gamesToday(st)} onExit={back} onCollection={() => { setView({ v: 'collection' }) }} />
        </Suspense>
      )
    default:
      return <Menu st={st} shard={shard} onBack={nav.pop} onPlay={() => go({ v: 'play' })} onCollection={() => go({ v: 'collection' })} onSpin={() => go({ v: 'spin' })} />
  }
}

