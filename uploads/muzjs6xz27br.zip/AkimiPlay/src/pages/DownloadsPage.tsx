// Anime yang di-download: daftar, pemutar offline, dan mode offline (Home saat tidak ada internet).
// Komponen di file ini TIDAK memakai useNav/useAuth supaya bisa tampil sebelum login/profil termuat.
import { useEffect, useMemo, useRef, useState } from 'react'
import type { AnimeLite, DownloadAnime, DownloadEntry } from '../types'
import {
  cancelDownload,
  localFileUrl,
  removeAnimeDownloads,
  removeDownload,
  retryDownload,
  useDownloadProgress,
  useDownloadedAnime,
  useDownloads,
} from '../services/downloadService'
import { downloadAnimeStore, progressStore, recordProgress, useStore } from '../storage/stores'
import { native, useBackHandler } from '../native/native'
import { fmtBytes, fmtTime } from '../lib/format'
import { AnimeCard } from '../components/AnimeCard'
import { ConfirmDialog, OfflineBanner, ToastHost } from '../components/Feedback'
import { EmptyState } from '../components/States'
import { Icon } from '../components/Icon'
import { Logo, APP_NAME } from '../components/Logo'
import { PageHeader } from '../components/PageHeader'
import { Poster } from '../components/Poster'

const posterOf = (a: DownloadAnime) => (a.posterPath ? localFileUrl(a.posterPath) : a.poster)
const totalSize = (eps: DownloadEntry[]) => eps.reduce((n, e) => n + (e.size || 0), 0)

// ---------- pemutar offline ----------
function OfflinePlayer({
  anime,
  episodes,
  startId,
  onClose,
}: {
  anime: DownloadAnime
  episodes: DownloadEntry[]
  startId: string
  onClose: () => void
}) {
  const [epId, setEpId] = useState(startId)
  const [fs, setFs] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const lastSave = useRef(0)

  const idx = Math.max(0, episodes.findIndex((e) => e.id === epId))
  const ep = episodes[idx]
  const prev = idx > 0 ? episodes[idx - 1] : undefined
  const next = idx < episodes.length - 1 ? episodes[idx + 1] : undefined
  const lite: AnimeLite = { id: anime.id, title: anime.title, poster: anime.poster }

  const save = (done = false) => {
    const v = videoRef.current
    if (!v || !ep || !Number.isFinite(v.duration) || v.duration <= 0) return
    recordProgress({
      anime: lite,
      episode: { id: ep.id, number: ep.episodeNumber, title: ep.episodeTitle },
      position: v.currentTime,
      duration: v.duration,
      watched: done,
    })
  }
  const saveRef = useRef(save)
  saveRef.current = save

  useBackHandler(
    () => {
      if (fs) {
        setFs(false)
        return true
      }
      onClose()
      return true
    },
    200,
  )

  useEffect(() => {
    void native.setFullscreen(fs)
  }, [fs])

  useEffect(() => {
    void native.setKeepAwake(true)
    return () => {
      saveRef.current()
      void native.setKeepAwake(false)
      void native.setFullscreen(false)
    }
  }, [])

  useEffect(() => {
    setError(null)
  }, [epId])

  if (!ep || !ep.path) return null

  return (
    <div className="fixed inset-0 z-[80] flex flex-col bg-black">
      {!fs ? (
        <div className="pt-safe flex items-center gap-2 px-3 pb-2 pt-3">
          <button
            type="button"
            aria-label="Tutup"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"
          >
            <Icon name="back" size={24} />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[14.5px] font-semibold text-white">{anime.title}</p>
            <p className="text-[12px] text-muted">
              Episode {ep.episodeNumber}
              {ep.quality ? ` · ${ep.quality}` : ''} · Offline
            </p>
          </div>
        </div>
      ) : null}

      <div className="relative flex min-h-0 flex-1 items-center justify-center bg-black">
        <video
          key={ep.id}
          ref={videoRef}
          src={localFileUrl(ep.path)}
          className="h-full w-full bg-black object-contain"
          controls
          autoPlay
          playsInline
          onLoadedMetadata={(e) => {
            const v = e.currentTarget
            const p = progressStore.get()[ep.id]
            if (p && p.p > 5 && !p.w && Number.isFinite(v.duration)) v.currentTime = Math.min(p.p, Math.max(0, v.duration - 3))
          }}
          onTimeUpdate={(e) => {
            const now = Date.now()
            if (now - lastSave.current > 5000 && !e.currentTarget.paused) {
              lastSave.current = now
              saveRef.current()
            }
          }}
          onPause={() => saveRef.current()}
          onEnded={() => {
            saveRef.current(true)
            if (next) setEpId(next.id)
          }}
          onError={() => setError('File video tidak bisa diputar. Coba download ulang episode ini.')}
        />
        {error ? (
          <div className="absolute inset-x-6 rounded-2xl bg-black/80 px-4 py-3 text-center text-[13px] text-white/90">{error}</div>
        ) : null}
        <button
          type="button"
          aria-label={fs ? 'Keluar layar penuh' : 'Layar penuh'}
          onClick={() => setFs((f) => !f)}
          className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur active:scale-90"
        >
          <Icon name={fs ? 'exitfs' : 'fs'} size={20} />
        </button>
      </div>

      {!fs ? (
        <div className="flex items-center justify-between gap-3 px-4 pb-6 pt-3">
          <button
            type="button"
            disabled={!prev}
            onClick={() => prev && setEpId(prev.id)}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-raise py-2.5 text-[13px] font-semibold text-white active:scale-95 disabled:opacity-35"
          >
            <Icon name="prev" size={16} /> Sebelumnya
          </button>
          <button
            type="button"
            disabled={!next}
            onClick={() => next && setEpId(next.id)}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-accent py-2.5 text-[13px] font-bold text-ink active:scale-95 disabled:opacity-35"
          >
            Berikutnya <Icon name="next" size={16} />
          </button>
        </div>
      ) : null}
    </div>
  )
}

// ---------- unduhan yang sedang berjalan / gagal ----------
function ActiveList({ entries }: { entries: DownloadEntry[] }) {
  const prog = useDownloadProgress()
  const animes = useStore(downloadAnimeStore)
  if (!entries.length) return null
  return (
    <section className="mt-4 px-4">
      <h2 className="text-[16px] font-bold text-white">Sedang di-download</h2>
      <ul className="mt-2 space-y-2">
        {entries.map((e) => {
          const p = prog[e.id]
          const ratio = p && p.total > 0 ? p.received / p.total : 0
          return (
            <li key={e.id} className="rounded-2xl bg-raise/70 px-3.5 py-2.5">
              <div className="flex items-center gap-2">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-semibold text-white">{animes[e.animeId]?.title ?? 'Anime'}</p>
                  <p className="text-[11.5px] text-muted">
                    Episode {e.episodeNumber}
                    {e.status === 'queued'
                      ? ' · Antre'
                      : e.status === 'error'
                        ? ` · ${e.error ?? 'Gagal'}`
                        : p
                          ? ` · ${fmtBytes(p.received)}${p.total > 0 ? ` / ${fmtBytes(p.total)}` : ''}`
                          : ' · Menyiapkan...'}
                  </p>
                </div>
                {e.status === 'error' ? (
                  <button
                    type="button"
                    aria-label="Coba lagi"
                    onClick={() => retryDownload(e.id)}
                    className="flex h-9 w-9 items-center justify-center rounded-full text-accent active:bg-white/10"
                  >
                    <Icon name="refresh" size={18} />
                  </button>
                ) : null}
                <button
                  type="button"
                  aria-label="Batalkan"
                  onClick={() => cancelDownload(e.id)}
                  className="flex h-9 w-9 items-center justify-center rounded-full text-white/70 active:bg-white/10"
                >
                  <Icon name="x" size={18} />
                </button>
              </div>
              {e.status === 'downloading' ? (
                <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full bg-accent" style={{ width: `${Math.max(2, ratio * 100)}%` }} />
                </div>
              ) : null}
            </li>
          )
        })}
      </ul>
    </section>
  )
}

// ---------- detail satu anime yang di-download ----------
function AnimeDownloads({
  anime,
  episodes,
  onBack,
  onPlay,
}: {
  anime: DownloadAnime
  episodes: DownloadEntry[]
  onBack: () => void
  onPlay: (id: string) => void
}) {
  const [delEp, setDelEp] = useState<DownloadEntry | null>(null)
  const [delAll, setDelAll] = useState(false)
  const progress = useStore(progressStore)

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto bg-ink pb-24">
      <PageHeader
        title={anime.title}
        onBack={onBack}
        right={
          <button
            type="button"
            aria-label="Hapus semua unduhan anime ini"
            onClick={() => setDelAll(true)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-white/70 active:bg-white/10"
          >
            <Icon name="trash" size={20} />
          </button>
        }
      />
      <div className="flex gap-3 px-4 pt-1">
        <Poster src={posterOf(anime)} alt={anime.title} className="h-[120px] w-[80px] shrink-0 rounded-xl ring-1 ring-line" />
        <div className="min-w-0 flex-1 self-end pb-1">
          <p className="text-[13px] text-white/80">{episodes.length} episode di-download</p>
          <p className="mt-0.5 text-[12px] text-muted">{fmtBytes(totalSize(episodes))} · tersimpan di AkimiPlay</p>
          <button
            type="button"
            onClick={() => onPlay(episodes[0].id)}
            className="mt-3 flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-[13.5px] font-bold text-ink active:scale-95"
          >
            <Icon name="play" size={16} /> Putar
          </button>
        </div>
      </div>

      <ul className="mt-5 space-y-2 px-4">
        {episodes.map((e) => {
          const p = progress[e.id]
          const ratio = p && p.d > 0 && !p.w ? Math.min(1, p.p / p.d) : 0
          return (
            <li key={e.id} className="relative">
              <button
                type="button"
                onClick={() => onPlay(e.id)}
                className="relative flex w-full items-center gap-3 overflow-hidden rounded-2xl bg-raise/70 px-3 py-2.5 pr-14 text-left active:opacity-80"
              >
                <span className="flex h-10 min-w-[2.5rem] items-center justify-center rounded-xl bg-white/[0.07] px-1.5 text-[13px] font-bold text-white">
                  {e.episodeNumber}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13.5px] font-medium text-white">
                    {e.episodeTitle && e.episodeTitle !== String(e.episodeNumber) ? e.episodeTitle : `Episode ${e.episodeNumber}`}
                  </span>
                  <span className="block text-[11.5px] text-muted">
                    {fmtBytes(e.size)}
                    {e.quality ? ` · ${e.quality}` : ''}
                    {p?.w ? ' · Ditonton' : p && p.p > 5 ? ` · ${fmtTime(p.p)}` : ''}
                  </span>
                </span>
                {ratio > 0 ? (
                  <span className="absolute inset-x-0 bottom-0 h-[3px] bg-white/10">
                    <span className="block h-full bg-accent" style={{ width: `${ratio * 100}%` }} />
                  </span>
                ) : null}
              </button>
              <button
                type="button"
                aria-label={`Hapus episode ${e.episodeNumber}`}
                onClick={() => setDelEp(e)}
                className="absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full text-white/60 active:bg-white/10"
              >
                <Icon name="trash" size={18} />
              </button>
            </li>
          )
        })}
      </ul>

      <ConfirmDialog
        open={!!delEp}
        title="Hapus download?"
        message={delEp ? `Episode ${delEp.episodeNumber} akan dihapus dari penyimpanan aplikasi.` : ''}
        confirmLabel="Hapus"
        onCancel={() => setDelEp(null)}
        onConfirm={() => {
          if (delEp) void removeDownload(delEp.id)
          setDelEp(null)
        }}
      />
      <ConfirmDialog
        open={delAll}
        title="Hapus semua episode?"
        message={`Semua episode ${anime.title} yang di-download akan dihapus dari penyimpanan aplikasi.`}
        confirmLabel="Hapus semua"
        onCancel={() => setDelAll(false)}
        onConfirm={() => {
          setDelAll(false)
          void removeAnimeDownloads(anime.id)
          onBack()
        }}
      />
    </div>
  )
}

// ---------- halaman utama unduhan ----------
/**
 * Daftar "Anime yang di download".
 * - offline: dipakai sebagai Home saat tidak ada internet (hanya menampilkan anime yang sudah di-download).
 * - onBack: dipakai sebagai halaman biasa (dari Home saat online).
 */
export function DownloadsHome({
  offline = false,
  onBack,
  initialAnimeId,
}: {
  offline?: boolean
  onBack?: () => void
  initialAnimeId?: string
}) {
  const downloaded = useDownloadedAnime()
  const entries = useDownloads()
  const [selected, setSelected] = useState<string | undefined>(initialAnimeId)
  const [playing, setPlaying] = useState<{ animeId: string; epId: string } | null>(null)

  const current = downloaded.find((d) => d.anime.id === selected)
  const active = useMemo(
    () => Object.values(entries).filter((e) => e.status !== 'done').sort((a, b) => a.createdAt - b.createdAt),
    [entries],
  )
  const playingItem = playing ? downloaded.find((d) => d.anime.id === playing.animeId) : undefined

  // jika anime yang dibuka sudah tidak punya episode (dihapus semua), kembali ke daftar
  useEffect(() => {
    if (selected && !current) setSelected(undefined)
  }, [selected, current])

  useBackHandler(
    () => {
      if (!selected) return false
      setSelected(undefined)
      return true
    },
    50,
    !!selected,
  )

  return (
    <div className="absolute inset-0 overflow-y-auto pb-28">
      {onBack ? (
        <PageHeader title="Anime yang di download" onBack={onBack} />
      ) : (
        <header className="pt-safe sticky top-0 z-20 bg-ink/85 backdrop-blur-xl">
          <div className="flex h-14 items-center gap-2.5 px-4">
            <Logo size={28} />
            <h1 className="min-w-0 flex-1 truncate text-[20px] font-bold tracking-tight text-white">{APP_NAME}</h1>
            {offline ? (
              <span className="flex items-center gap-1.5 rounded-full bg-[#2a1720] px-3 py-1 text-[11.5px] font-semibold text-accent">
                <Icon name="offline" size={13} /> Mode offline
              </span>
            ) : null}
          </div>
        </header>
      )}

      {!onBack ? (
        <h2 className="mt-2 px-4 text-[18px] font-bold tracking-tight text-white">Anime yang di download</h2>
      ) : null}

      {!offline ? <ActiveList entries={active} /> : null}

      {downloaded.length ? (
        <div className="mt-3 grid grid-cols-3 gap-x-2.5 gap-y-4 px-4">
          {downloaded.map(({ anime, episodes }) => (
            <AnimeCard
              key={anime.id}
              variant="grid"
              anime={{ id: anime.id, title: anime.title, poster: posterOf(anime) }}
              badge={`${episodes.length} Eps`}
              onOpen={() => setSelected(anime.id)}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          icon="download"
          title="Belum ada anime yang di-download"
          hint={
            offline
              ? 'Saat online, buka anime lalu ketuk tombol Download di daftar episode. Setelah itu anime-nya bisa ditonton di sini tanpa internet.'
              : 'Buka halaman anime lalu ketuk tombol Download di daftar episode.'
          }
        />
      )}

      {current ? (
        <AnimeDownloads
          anime={current.anime}
          episodes={current.episodes}
          onBack={() => setSelected(undefined)}
          onPlay={(epId) => setPlaying({ animeId: current.anime.id, epId })}
        />
      ) : null}

      {playing && playingItem ? (
        <OfflinePlayer
          anime={playingItem.anime}
          episodes={playingItem.episodes}
          startId={playing.epId}
          onClose={() => setPlaying(null)}
        />
      ) : null}
    </div>
  )
}

// ---------- baris di Home (saat online) ----------
export function DownloadedRow({ onOpen, onManage }: { onOpen: (animeId: string) => void; onManage: () => void }) {
  const downloaded = useDownloadedAnime()
  const entries = useDownloads()
  const activeCount = Object.values(entries).filter((e) => e.status !== 'done').length
  if (!downloaded.length && !activeCount) return null
  return (
    <section className="mt-6">
      <div className="flex items-center justify-between px-4">
        <h2 className="text-[18px] font-bold tracking-tight text-white">Anime yang di download</h2>
        <button type="button" onClick={onManage} className="flex items-center gap-0.5 text-[12px] font-semibold text-accent active:opacity-70">
          Kelola <Icon name="chevron" size={14} />
        </button>
      </div>
      {downloaded.length ? (
        <div className="no-scrollbar mt-2.5 flex snap-x gap-2.5 overflow-x-auto px-4 pb-1">
          {downloaded.slice(0, 20).map(({ anime, episodes }) => (
            <AnimeCard
              key={anime.id}
              anime={{ id: anime.id, title: anime.title, poster: posterOf(anime) }}
              badge={`${episodes.length} Eps`}
              onOpen={() => onOpen(anime.id)}
            />
          ))}
        </div>
      ) : null}
      {activeCount ? (
        <button
          type="button"
          onClick={onManage}
          className="mx-4 mt-2.5 flex w-[calc(100%-2rem)] items-center gap-2 rounded-xl bg-raise px-3.5 py-2.5 text-left text-[12.5px] text-white/80 ring-1 ring-line active:opacity-80"
        >
          <Icon name="download" size={16} className="text-accent" /> {activeCount} episode sedang diproses
        </button>
      ) : null}
    </section>
  )
}

// ---------- aplikasi mode offline penuh (saat dibuka tanpa internet & belum login/profil) ----------
export function OfflineApp({ online, onExit }: { online: boolean; onExit: () => void }) {
  return (
    <div className="relative h-full w-full overflow-hidden bg-ink">
      <DownloadsHome offline />
      {online ? (
        <div className="pointer-events-none fixed inset-x-0 bottom-6 z-[90] flex justify-center px-4">
          <button
            type="button"
            onClick={onExit}
            className="pointer-events-auto flex items-center gap-2 rounded-full bg-accent px-5 py-3 text-[13.5px] font-bold text-ink shadow-lg active:scale-95"
          >
            Kamu sudah online · Buka AkimiPlay
          </button>
        </div>
      ) : null}
      <OfflineBanner />
      <ToastHost />
    </div>
  )
}

