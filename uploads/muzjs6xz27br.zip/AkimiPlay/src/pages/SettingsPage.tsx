import type { ReactNode } from 'react'
import { useState } from 'react'
import { animeApi, clearApiCache } from '../services/animeApi'
import { clearHistory, DEFAULT_SETTINGS, settingsStore, useStore } from '../storage/stores'
import { APP_NAME, APP_VERSION } from '../components/Logo'
import { ConfirmDialog, Chip, Sheet, toast, Toggle } from '../components/Feedback'
import { Icon, type IconName } from '../components/Icon'
import { PageHeader } from '../components/PageHeader'
import { useAuth, useProfile } from '../auth/AuthProvider'
import { useNav } from '../nav/router'
import { errMsg } from '../lib/format'
import { findList, toAnime, toEpisodes, toHome, unwrap } from '../services/adapters'
import { DevPanel } from './DevPanel'
import { isDeveloper } from '../services/broadcastService'
import { applyNotifySetting, notifStatus, openNotifSettings, requestNotifPermission } from '../services/notifyService'

function Row({
  icon,
  label,
  value,
  onClick,
}: {
  icon: IconName
  label: string
  value?: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-2xl bg-raise/70 px-4 py-3.5 text-left active:opacity-75"
    >
      <Icon name={icon} size={20} className="text-accent" />
      <span className="flex-1 text-[14px] font-medium text-white">{label}</span>
      {value ? <span className="text-[12.5px] text-muted">{value}</span> : null}
      <Icon name="chevron" size={16} className="text-muted" />
    </button>
  )
}

function SettingLine({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="rounded-2xl bg-raise/70 px-4 py-3">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[14px] font-medium text-white">{label}</p>
          {hint ? <p className="mt-0.5 text-[12px] leading-snug text-muted">{hint}</p> : null}
        </div>
        {children}
      </div>
    </div>
  )
}

type Panel = null | 'player' | 'about' | 'privacy' | 'diag' | 'notif' | 'dev'
type Confirm = null | 'history' | 'logout'

/** Halaman Pengaturan: dibuka dari tombol gerigi di halaman Akun. */
export function SettingsPage() {
  const nav = useNav()
  const profile = useProfile()
  const { signOut } = useAuth()
  const settings = useStore(settingsStore)

  const [panel, setPanel] = useState<Panel>(null)
  const [confirm, setConfirm] = useState<Confirm>(null)
  const close = () => setPanel(null)
  const set = (patch: Partial<typeof settings>) => settingsStore.set((s) => ({ ...s, ...patch }))

  const toggleNotify = async (on: boolean) => {
    set({ notify: on })
    void applyNotifySetting(on)
    if (!on) return
    let st = await notifStatus()
    if (!st.granted) st = await requestNotifPermission()
    if (!st.granted) {
      toast('Izin notifikasi belum diberikan. Aktifkan dari pengaturan HP.')
      openNotifSettings()
    }
  }

  return (
    <div className="absolute inset-0 overflow-y-auto pb-12">
      <PageHeader title="Pengaturan" onBack={nav.pop} />

      <div className="space-y-2.5 px-4 pt-3">
        <Row icon="sliders" label="Pengaturan Player" onClick={() => setPanel('player')} />
        <Row
          icon="broom"
          label="Clear cache"
          onClick={() => {
            clearApiCache()
            toast('Cache dibersihkan')
          }}
        />
        <Row icon="trash" label="Clear history" onClick={() => setConfirm('history')} />
        <Row icon="bell" label="Notifikasi" value={settings.notify === false ? 'Mati' : 'Aktif'} onClick={() => setPanel('notif')} />
        {isDeveloper(profile) ? <Row icon="shield" label="Panel Developer" onClick={() => setPanel('dev')} /> : null}
        <Row icon="shield" label="Privacy" onClick={() => setPanel('privacy')} />
        {isDeveloper(profile) ? <Row icon="bug" label="Diagnostik API" onClick={() => setPanel('diag')} /> : null}
        <Row icon="info" label="About" onClick={() => setPanel('about')} />
        <Row icon="logout" label="Logout" onClick={() => setConfirm('logout')} />
        <Row icon="gear" label="Versi aplikasi" value={APP_VERSION} onClick={() => toast(`${APP_NAME} v${APP_VERSION}`)} />
      </div>

      {/* notifikasi */}
      <Sheet open={panel === 'notif'} onClose={close} title="Notifikasi">
        <div className="space-y-2.5">
          <SettingLine label="Notifikasi aplikasi" hint="Kabar episode baru dan pesan dari developer muncul sebagai notifikasi HP, juga saat aplikasi ditutup.">
            <Toggle on={settings.notify !== false} onChange={(v) => void toggleNotify(v)} />
          </SettingLine>
          <button
            type="button"
            onClick={() => openNotifSettings()}
            className="w-full py-2 text-[13px] font-semibold text-accent"
          >
            Buka pengaturan notifikasi HP
          </button>
        </div>
      </Sheet>

      {panel === 'dev' ? <DevPanel onClose={close} /> : null}

      {/* setting player */}
      <Sheet open={panel === 'player'} onClose={close} title="Pengaturan Player">
        <div className="space-y-2.5">
          <SettingLine label="Putar episode berikutnya" hint="Otomatis lanjut saat episode selesai.">
            <Toggle on={settings.autoNext} onChange={(v) => set({ autoNext: v })} />
          </SettingLine>
          <SettingLine label="Lanjutkan dari posisi terakhir" hint="Video dilanjutkan di detik terakhir kamu menonton.">
            <Toggle on={settings.resume} onChange={(v) => set({ resume: v })} />
          </SettingLine>
          <SettingLine label="Picture-in-Picture otomatis" hint="Video mengecil saat kamu menekan Home.">
            <Toggle on={settings.autoPip} onChange={(v) => set({ autoPip: v })} />
          </SettingLine>
          <div className="rounded-2xl bg-raise/70 px-4 py-3">
            <p className="text-[14px] font-medium text-white">Kualitas default</p>
            <p className="mt-0.5 text-[12px] text-muted">Hanya kualitas yang tersedia di episode yang akan dipakai.</p>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {[0, 360, 480, 720, 1080].map((q) => (
                <Chip key={q} active={settings.defaultQuality === q} onClick={() => set({ defaultQuality: q })}>
                  {q === 0 ? 'Otomatis' : `${q}p`}
                </Chip>
              ))}
            </div>
          </div>
          <div className="rounded-2xl bg-raise/70 px-4 py-3">
            <p className="text-[14px] font-medium text-white">Lompat ketuk dua kali</p>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {[5, 10, 15, 30].map((s) => (
                <Chip key={s} active={settings.seekStep === s} onClick={() => set({ seekStep: s })}>
                  {s} detik
                </Chip>
              ))}
            </div>
          </div>
          <div className="rounded-2xl bg-raise/70 px-4 py-3">
            <p className="text-[14px] font-medium text-white">Tombol Skip Intro</p>
            <p className="mt-0.5 text-[12px] text-muted">Berapa detik yang dilewati saat tombol Skip Intro di kontrol video ditekan.</p>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {[80, 85, 90, 95].map((s) => (
                <Chip key={s} active={(settings.introSkip ?? 90) === s} onClick={() => set({ introSkip: s })}>
                  {s} detik
                </Chip>
              ))}
            </div>
          </div>
          <button
            type="button"
            onClick={() => settingsStore.set(DEFAULT_SETTINGS)}
            className="w-full py-2 text-[13px] font-semibold text-accent"
          >
            Kembalikan ke default
          </button>
        </div>
      </Sheet>

      <Sheet open={panel === 'privacy'} onClose={close} title="Privacy">
        <div className="space-y-3 text-[13.5px] leading-relaxed text-white/75">
          <p>{APP_NAME} tidak memakai akun dan tidak mengirim data pribadi ke server milik kami.</p>
          <p>Favorit, histori, posisi video, dan pengaturan disimpan hanya di penyimpanan lokal perangkat ini.</p>
          <p>
            Data anime dan video diambil dari layanan pihak ketiga (AnimeInWeb API). Saat kamu membuka anime atau
            memutar video, perangkatmu menghubungi layanan tersebut.
          </p>
        </div>
      </Sheet>

      <Sheet open={panel === 'about'} onClose={close} title="About">
        <div className="space-y-3 text-[13.5px] leading-relaxed text-white/75">
          <p>
            {APP_NAME} v{APP_VERSION}: aplikasi Android untuk menonton anime, dibuat dengan React dan Capacitor.
          </p>
          <p>
            Sumber data adalah AnimeInWeb API tidak resmi. {APP_NAME} tidak menyimpan atau menghosting video apa pun
            dan tidak berafiliasi dengan animeinweb.com.
          </p>
        </div>
      </Sheet>

      <Sheet open={panel === 'diag' && isDeveloper(profile)} onClose={close} title="Diagnostik API">
        <Diagnostics />
      </Sheet>

      <ConfirmDialog
        open={confirm === 'logout'}
        title="Keluar dari akun?"
        message="Kamu bisa login lagi kapan saja dengan akun Google yang sama. ID dan level tidak berubah."
        confirmLabel="Keluar"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          setConfirm(null)
          void signOut()
        }}
      />

      <ConfirmDialog
        open={confirm === 'history'}
        title="Hapus semua histori?"
        message="Riwayat tontonan dan posisi terakhir video akan dihapus."
        confirmLabel="Hapus"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          clearHistory()
          setConfirm(null)
          toast('Histori dihapus')
        }}
      />
    </div>
  )
}

const TESTS: { label: string; path: string; params?: Record<string, string> }[] = [
  { label: 'parse-anime', path: '/homepage' },
  { label: 'parse-episodes', path: '/homepage' },
  { label: 'homepage', path: '/homepage' },
  { label: 'search', path: '/search', params: { q: 'naruto', page: '0' } },
  { label: 'genres', path: '/genres' },
  { label: 'schedule', path: '/schedule', params: { day: 'SENIN' } },
]

function Diagnostics() {
  const [out, setOut] = useState('Pilih endpoint untuk melihat respons mentahnya.')
  const [busy, setBusy] = useState(false)

  const run = async (t: (typeof TESTS)[number]) => {
    setBusy(true)
    setOut('Memuat...')
    try {
      const json = await animeApi.raw(t.path, t.params)
      if (t.label === 'parse-episodes') {
        const h = toHome(json)
        const a = [...h.today, ...h.new, ...h.hot, ...h.popular][0]
        if (!a) {
          setOut('Tidak ada anime di homepage untuk dites.')
          return
        }
        const rawEps = await animeApi.raw(`/anime/${encodeURIComponent(a.id)}/episodes`)
        const parsed = toEpisodes(rawEps)
        setOut(`Anime: ${a.title} (id ${a.id})\nEpisode terbaca: ${parsed.length}\n\nRAW:\n${JSON.stringify(rawEps, null, 1)?.slice(0, 1800)}`)
        return
      }
      if (t.label === 'parse-anime') {
        const root = unwrap(json) as Record<string, unknown>
        const first = Array.isArray(root) ? root : Object.values(root ?? {}).map((v) => findList(v)).find((l) => l.length) ?? []
        const raw = first[0]
        setOut(`RAW anime pertama:\n${JSON.stringify(raw, null, 1)?.slice(0, 1800)}\n\nHASIL PARSE:\n${JSON.stringify(toAnime(raw), null, 1)}`)
        return
      }
      const keys = json && typeof json === 'object' ? Object.keys(json as object).join(', ') : typeof json
      setOut(`GET ${t.path}\nKey teratas: ${keys}\n\n${JSON.stringify(json, null, 1).slice(0, 2500)}`)
    } catch (e) {
      setOut(`GET ${t.path}\nGAGAL: ${errMsg(e)}`)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <p className="mb-3 text-[12.5px] leading-snug text-muted">
        Untuk memeriksa bentuk data API. Jika ada bagian yang tidak tampil di aplikasi, salin hasil di sini.
      </p>
      <div className="flex flex-wrap gap-2">
        {TESTS.map((t) => (
          <Chip key={t.label} onClick={() => !busy && void run(t)}>
            {t.label}
          </Chip>
        ))}
      </div>
      <pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap break-all rounded-2xl bg-black/50 p-3 text-[11px] leading-snug text-white/80 [user-select:text]">
        {out}
      </pre>
      <button
        type="button"
        onClick={() => {
          void navigator.clipboard?.writeText(out).then(() => toast('Disalin'))
        }}
        className="mt-3 w-full rounded-full bg-raise py-2.5 text-[13px] font-semibold text-white"
      >
        Salin hasil
      </button>
    </div>
  )
}
