import { useMemo, useState } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import {
  CLAN_SLOT_COST,
  CLAN_SLOT_MAX,
  CLAN_SLOT_PACK,
  CLAN_TIER_COST,
  CLAN_TIER_MAX,
  CLAN_TIER_NAME,
  CLAN_ROLE_BADGE,
  CLAN_ROLE_COLOR,
  CLAN_ROLE_NAME,
  SHARD_TO_XP,
  acceptRequest,
  assignableRoles,
  canKick,
  canManageClan,
  canManageRequests,
  cancelRequest,
  roleRank,
  setMemberRole,
  transferLeader,
  useMyRole,
  clanProgress,
  disbandClan,
  donateShard,
  fmtCompact,
  kickMember,
  leaveClan,
  requestJoin,
  upgradeSlots,
  upgradeTier,
  useClan,
  useClanMembers,
  useClanRequests,
  useMyClanId,
  useMyRequest,
  usePeriodDonations,
  type Clan,
  type ClanRole,
  type DonationPeriod,
  type ClanMember,
} from '../services/clanService'
import { useLiveUsers } from '../services/liveProfiles'
import { errMsg } from '../lib/format'
import { fmtNum } from '../lib/xp'
import { PERIOD_LABEL, periodRange, type Period } from '../lib/board'
import { ClanBadge } from '../components/ClanBadge'
import { Avatar, ClanPill, LevelPill, RoleCheck } from '../components/UserBadges'
import { Icon } from '../components/Icon'
import { EmptyState, Spinner } from '../components/States'
import { ConfirmDialog, Sheet, toast } from '../components/Feedback'

type Tab = 'members' | 'donasi' | 'requests'
const DON_FILTERS: { key: DonationPeriod; label: string }[] = [
  { key: 'daily', label: PERIOD_LABEL.daily },
  { key: 'weekly', label: PERIOD_LABEL.weekly },
  { key: 'monthly', label: PERIOD_LABEL.monthly },
  { key: 'full', label: 'Full' },
]
const DON_HINT: Record<DonationPeriod, string> = {
  daily: 'Reset setiap hari (00.00 WIB)',
  weekly: 'Reset setiap Senin (00.00 WIB)',
  monthly: 'Reset setiap tanggal 1 (00.00 WIB)',
  full: 'Total sepanjang masa, tidak pernah reset',
}

function DonateSheet({ open, onClose, clan }: { open: boolean; onClose: () => void; clan: Clan }) {
  const me = useProfile()
  const balance = me.shard ?? 0
  const [raw, setRaw] = useState('')
  const [busy, setBusy] = useState(false)
  const amount = Number(raw)
  const valid = Number.isInteger(amount) && amount >= 1 && amount <= balance

  const submit = async () => {
    if (!valid || busy) return
    setBusy(true)
    try {
      await donateShard(me, clan, amount)
      toast(`Setor ${fmtNum(amount)} AkimiShard berhasil`)
      setRaw('')
      onClose()
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  return (
    <Sheet open={open} onClose={onClose} title="Setor AkimiShard">
      <div className="space-y-4">
        <div className="flex items-center justify-between rounded-2xl bg-white/[0.05] px-4 py-3">
          <span className="text-[13.5px] text-muted">Saldo kamu</span>
          <span className="text-[18px] font-extrabold text-white">💎 {fmtNum(balance)}</span>
        </div>
        <input
          value={raw}
          inputMode="numeric"
          onChange={(e) => setRaw(e.target.value.replace(/\D/g, '').slice(0, 10))}
          placeholder="Jumlah AkimiShard"
          className="w-full rounded-2xl bg-raise px-4 py-3 text-[17px] font-bold text-white focus:outline-none focus:ring-1 focus:ring-accent"
        />
        <div className="flex flex-wrap gap-2">
          {[10, 50, 100, 500].map((v) => (
            <button
              key={v}
              type="button"
              disabled={v > balance}
              onClick={() => setRaw(String(v))}
              className="rounded-full bg-raise px-4 py-2 text-[13.5px] font-semibold text-white active:scale-95 disabled:opacity-35"
            >
              {fmtNum(v)}
            </button>
          ))}
          <button
            type="button"
            disabled={balance < 1}
            onClick={() => setRaw(String(balance))}
            className="rounded-full bg-raise px-4 py-2 text-[13.5px] font-semibold text-white active:scale-95 disabled:opacity-35"
          >
            Semua
          </button>
        </div>
        <p className="text-[12px] leading-snug text-muted">
          {SHARD_TO_XP === 1 ? '1 AkimiShard = 1 XP clan.' : `1 AkimiShard = ${SHARD_TO_XP} XP clan.`} XP masuk ke peringkat Top Clans dan menambah XP tersedia
          clan yang dipakai leader untuk upgrade slot. Setoran tidak bisa ditarik kembali.
        </p>
        {balance < 1 ? <p className="text-[12.5px] text-[#FF8A9A]">Kamu belum punya AkimiShard.</p> : null}
        <button
          type="button"
          disabled={!valid || busy}
          onClick={() => void submit()}
          className="flex w-full items-center justify-center gap-2 rounded-full bg-accent py-3.5 text-[15px] font-extrabold text-ink active:scale-[0.98] disabled:opacity-40"
        >
          {busy ? <Spinner size={18} /> : null} Setor {valid ? fmtNum(amount) : ''}
        </button>
      </div>
    </Sheet>
  )
}

function ManageSheet({ open, onClose, clan, role }: { open: boolean; onClose: () => void; clan: Clan; role: ClanRole }) {
  const isLeader = role === 'leader'
  const me = useProfile()
  const nav = useNav()
  const [busy, setBusy] = useState(false)
  const [confirmDisband, setConfirmDisband] = useState(false)
  const maxed = clan.slots + CLAN_SLOT_PACK > CLAN_SLOT_MAX
  const canUpgrade = !maxed && clan.xpBalance >= CLAN_SLOT_COST
  const tierMaxed = clan.tier >= CLAN_TIER_MAX
  const nextTier = clan.tier + 1
  const tierCost = tierMaxed ? 0 : CLAN_TIER_COST[nextTier]
  const canTier = !tierMaxed && clan.xpBalance >= tierCost

  const upgrade = async () => {
    setBusy(true)
    try {
      await upgradeSlots(me, clan)
      toast(`Slot bertambah ${CLAN_SLOT_PACK}`)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  const upTier = async () => {
    setBusy(true)
    try {
      const t = await upgradeTier(me, clan)
      toast(`Clan naik ke Tier ${t}`)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  return (
    <Sheet open={open} onClose={onClose} title="Shop Clan">
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-white/[0.05] p-3.5">
            <p className="text-[12px] text-muted">XP tersedia</p>
            <p className="mt-0.5 text-[22px] font-extrabold text-[#F4C96B]">{fmtNum(clan.xpBalance)}</p>
          </div>
          <div className="rounded-2xl bg-white/[0.05] p-3.5">
            <p className="text-[12px] text-muted">Slot anggota</p>
            <p className="mt-0.5 text-[22px] font-extrabold text-white">
              {clan.members}/{clan.slots}
            </p>
          </div>
        </div>

        {!isLeader ? (
          <p className="rounded-2xl bg-white/[0.06] px-4 py-3 text-center text-[12.5px] text-muted">
            Sebagai {CLAN_ROLE_NAME[role]} kamu bisa upgrade tier dan memutar warna. Beli slot dan membubarkan clan hanya untuk Leader.
          </p>
        ) : null}

        {isLeader ? (
        <div className="rounded-2xl bg-white/[0.05] p-4">
          <p className="text-[15px] font-bold text-white">
            Tambah +{CLAN_SLOT_PACK} slot <span className="text-[#F4C96B]">· {fmtNum(CLAN_SLOT_COST)} XP</span>
          </p>
          <p className="mt-1 text-[12px] leading-snug text-muted">
            XP yang dipakai hanya mengurangi XP tersedia di halaman clan. XP di Top Clans tidak berkurang. Slot maksimal {CLAN_SLOT_MAX}.
          </p>
          <button
            type="button"
            disabled={!canUpgrade || busy}
            onClick={() => void upgrade()}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-[#A78BFA] py-3 text-[14.5px] font-extrabold text-ink active:scale-[0.98] disabled:opacity-40"
          >
            {busy ? <Spinner size={18} /> : null}
            {maxed ? 'Slot sudah maksimal' : canUpgrade ? `Upgrade slot (${clan.slots} → ${clan.slots + CLAN_SLOT_PACK})` : 'XP tersedia belum cukup'}
          </button>
        </div>
        ) : null}

        <div className="rounded-2xl bg-white/[0.05] p-4">
          <p className="text-[15px] font-bold text-white">
            Tier clan <span className="text-[#F4C96B]">· Tier {clan.tier} ({CLAN_TIER_NAME[clan.tier]})</span>
          </p>
          <p className="mt-1 text-[12px] leading-snug text-muted">
            Naikkan tier untuk mengubah bentuk lencana clan di komentar, chat, dan profil. Naik satu tier setiap kali, tidak bisa langsung ke tier akhir.
          </p>
          <div className="mt-3 flex items-center justify-center gap-3 rounded-2xl bg-black/20 px-3 py-3.5">
            <ClanBadge tag={clan.tag} color={clan.color} emblem={clan.emblem} tier={clan.tier} height={30} />
            {tierMaxed ? null : (
              <>
                <Icon name="chevron" size={18} className="shrink-0 text-muted" />
                <ClanBadge tag={clan.tag} color={clan.color} emblem={clan.emblem} tier={nextTier} height={30} />
              </>
            )}
          </div>
          <button
            type="button"
            disabled={!canTier || busy}
            onClick={() => void upTier()}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#F4C96B] to-[#E9A23B] py-3 text-[14.5px] font-extrabold text-[#2B1B00] active:scale-[0.98] disabled:opacity-40"
          >
            {busy ? <Spinner size={18} /> : null}
            {tierMaxed ? 'Tier sudah maksimal' : canTier ? `Upgrade ke Tier ${nextTier} · ${fmtNum(tierCost)} XP` : `Butuh ${fmtNum(tierCost)} XP tersedia`}
          </button>
        </div>

        <div className="rounded-2xl bg-white/[0.05] p-4">
          <p className="text-[15px] font-bold text-white">Warna clan</p>
          <p className="mt-1 text-[12px] leading-snug text-muted">
            Putar gacha dengan XP clan untuk mendapat warna Common, Rare, atau Legend, lalu pakai warna favoritmu dari koleksi.
          </p>
          <div className="mt-3 flex items-center gap-3">
            <ClanBadge tag={clan.tag} color={clan.color} emblem={clan.emblem} tier={clan.tier} height={28} />
            <button
              type="button"
              onClick={() => {
                onClose()
                nav.push({ name: 'clanColors', id: clan.id })
              }}
              className="ml-auto rounded-full bg-gradient-to-r from-[#F43F5E] to-[#FB923C] px-5 py-2.5 text-[14px] font-extrabold text-white active:scale-95"
            >
              Spin Warna
            </button>
          </div>
        </div>

        {isLeader ? (
        <div className="rounded-2xl bg-white/[0.05] p-4">
          <p className="text-[15px] font-bold text-white">Bubarkan clan</p>
          <p className="mt-1 text-[12px] leading-snug text-muted">
            {clan.members === 1
              ? 'Clan akan dihapus permanen beserta XP-nya. Tag bisa dipakai lagi.'
              : 'Hanya bisa dilakukan saat tidak ada anggota lain. Keluarkan semua anggota dulu.'}
          </p>
          <button
            type="button"
            disabled={clan.members !== 1}
            onClick={() => setConfirmDisband(true)}
            className="mt-3 w-full rounded-full bg-raise py-3 text-[14px] font-semibold text-accent active:scale-[0.98] disabled:opacity-35"
          >
            Bubarkan clan
          </button>
        </div>
        ) : null}
      </div>
      <ConfirmDialog
        open={confirmDisband}
        title="Bubarkan clan?"
        message="Clan, XP, dan tag-nya dihapus permanen. Tindakan ini tidak bisa dibatalkan."
        confirmLabel="Bubarkan"
        onCancel={() => setConfirmDisband(false)}
        onConfirm={() => {
          setConfirmDisband(false)
          disbandClan(me, clan)
            .then(() => {
              toast('Clan dibubarkan')
              onClose()
              nav.pop()
            })
            .catch((e) => toast(errMsg(e)))
        }}
      />
    </Sheet>
  )
}

export function ClanPage({ id }: { id: string }) {
  const nav = useNav()
  const me = useProfile()
  const clan = useClan(id)
  const members = useClanMembers(id)
  const myClanId = useMyClanId(me.uid)
  const myReqId = useMyRequest(me.uid)
  const isMember = myClanId === id
  const isLeader = isMember && clan?.leaderUid === me.uid
  const roleDb = useMyRole(isMember ? id : null, me.uid)
  const myRole: ClanRole | null = isLeader ? 'leader' : isMember ? roleDb ?? null : null
  const canReq = canManageRequests(myRole)
  const canShop = canManageClan(myRole)
  const requests = useClanRequests(id, canReq)

  const [tab, setTab] = useState<Tab>('members')
  const [q, setQ] = useState('')
  const [byDonation, setByDonation] = useState(true)
  const [donate, setDonate] = useState(false)
  const [donPeriod, setDonPeriod] = useState<DonationPeriod>('daily')
  const [manage, setManage] = useState(false)
  const [confirmLeave, setConfirmLeave] = useState(false)
  const [target, setTarget] = useState<ClanMember | null>(null)
  const [confirmKick, setConfirmKick] = useState<ClanMember | null>(null)
  const [confirmTransfer, setConfirmTransfer] = useState<ClanMember | null>(null)
  const [busy, setBusy] = useState<string | null>(null)

  const uids = useMemo(() => [...(members ?? []).map((m) => m.uid), ...(requests ?? []).map((r) => r.uid)], [members, requests])
  const live = useLiveUsers(uids)
  const nameOf = (uid: string) => {
    const p = live.get(uid)
    return p ? p.username?.trim() || p.displayName : '…'
  }

  const sorted = useMemo(() => {
    const term = q.trim().toLowerCase().replace(/^#/, '')
    const list = (members ?? []).filter((m) => {
      if (!term) return true
      const p = live.get(m.uid)
      const name = (p?.username?.trim() || p?.displayName || '').toLowerCase()
      return name.includes(term) || String(p?.userId ?? '').includes(term)
    })
    return list.sort((a, b) => {
      if (a.role !== b.role) return roleRank(b.role) - roleRank(a.role)
      return byDonation ? b.donated - a.donated || a.joinedAt - b.joinedAt : b.joinedAt - a.joinedAt
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [members, q, byDonation, live])

  const periodDon = usePeriodDonations(id, donPeriod === 'full' ? null : (donPeriod as Period))
  // Full = total sepanjang masa (field donated); selain itu pakai angka periode berjalan.
  const donors = useMemo(() => {
    const amountOf = (m: ClanMember) => (donPeriod === 'full' ? m.donated : periodDon?.[m.uid] ?? 0)
    return (members ?? [])
      .map((m) => ({ ...m, donated: amountOf(m) }))
      .filter((m) => m.donated > 0)
      .sort((a, b) => b.donated - a.donated || a.joinedAt - b.joinedAt)
  }, [members, periodDon, donPeriod])

  const run = async (key: string, fn: () => Promise<void>, ok?: string) => {
    setBusy(key)
    try {
      await fn()
      if (ok) toast(ok)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(null)
    }
  }

  if (clan === undefined) {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-ink">
        <Spinner size={30} />
      </div>
    )
  }
  if (clan === null) {
    return (
      <div className="absolute inset-0 bg-ink">
        <header className="pt-safe px-3 py-3">
          <button type="button" aria-label="Kembali" onClick={nav.pop} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10">
            <Icon name="back" size={26} />
          </button>
        </header>
        <EmptyState icon="users" title="Clan tidak ditemukan." hint="Clan ini mungkin sudah dibubarkan." />
      </div>
    )
  }

  const prog = clanProgress(clan.xp)
  const full = clan.members >= clan.slots
  const pendingHere = myReqId === id
  const tabs: { key: Tab; label: string }[] = [
    { key: 'members', label: 'Members' },
    { key: 'donasi', label: 'Donasi' },
    ...(canReq ? [{ key: 'requests' as Tab, label: `Permintaan${requests?.length ? ` (${requests.length})` : ''}` }] : []),
  ]

  /** Ada aksi yang boleh dilakukan role-ku terhadap anggota ini (ubah role, kick, atau transfer leader)? */
  const hasActions = (m: ClanMember) =>
    m.uid !== me.uid && (isLeader || assignableRoles(myRole, m.role).length > 0 || canKick(myRole, m.role))
  const memberRow = (m: ClanMember, rank?: number) => {
    const p = live.get(m.uid)
    const name = nameOf(m.uid)
    return (
      <button
        key={m.uid}
        type="button"
        onClick={() => (hasActions(m) ? setTarget(m) : nav.openProfile(m.uid))}
        className="flex w-full items-center gap-3 py-2.5 text-left active:opacity-80"
      >
        {rank ? <span className="w-7 shrink-0 text-center text-[15px] font-extrabold text-[#F4C96B]">{rank}</span> : null}
        <div className="relative shrink-0 pb-2.5">
          <Avatar url={p?.photoURL} name={name} size={50} />
          {m.role !== 'member' ? (
            <span
              className="absolute -bottom-0 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md px-1.5 py-[1px] text-[9.5px] font-extrabold text-ink"
              style={{ backgroundColor: CLAN_ROLE_COLOR[m.role] }}
            >
              {CLAN_ROLE_BADGE[m.role]}
            </span>
          ) : null}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="truncate text-[16.5px] font-extrabold text-white">{name}</span>
            {p?.userId !== undefined ? <span className="shrink-0 text-[12.5px] text-muted">#{String(p.userId)}</span> : null}
            {p ? <RoleCheck role={p.role} verified={p.verified} size={15} /> : null}
          </div>
          <div className="mt-1 flex items-center gap-1.5">
            <ClanPill tag={clan.tag} clan={clan} />
            {p ? <LevelPill level={p.level ?? 1} /> : null}
          </div>
        </div>
        <span className="shrink-0 rounded-full bg-[#14233f] px-3.5 py-2 text-[14px] font-extrabold text-white ring-1 ring-[#2c4676]">
          💎 {fmtCompact(m.donated)}
        </span>
      </button>
    )
  }

  return (
    <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-[#2a1650] via-[#120d2b] to-ink pb-24">
      <header className="pt-safe">
        <div className="flex h-14 items-center justify-between px-3">
          <button type="button" aria-label="Kembali" onClick={nav.pop} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10">
            <Icon name="back" size={26} />
          </button>
          {isMember ? (
            <button
              type="button"
              onClick={() => nav.push({ name: 'clans' })}
              className="rounded-full bg-white/10 px-4 py-2 text-[13px] font-bold text-white active:scale-95"
            >
              Top Clans
            </button>
          ) : null}
        </div>
      </header>

      <div className="px-5 pt-2">
        <div className="flex items-start justify-between gap-3">
          <h1 className="min-w-0 break-words text-[30px] font-extrabold leading-tight tracking-tight text-white">{clan.name}</h1>
          <span className="mt-1 flex shrink-0 items-center gap-2 rounded-full bg-white/10 px-4 py-2.5 text-[16px] font-bold text-white">
            <Icon name="users" size={18} className="text-white/70" />
            {clan.members}/{clan.slots}
          </span>
        </div>
        <div className="mt-2.5 flex items-center gap-2.5">
          <ClanBadge tag={clan.tag} color={clan.color} emblem={clan.emblem} tier={clan.tier} height={28} />
          <span className="rounded-md bg-gradient-to-r from-[#F4B63F] to-[#C98A1B] px-2 py-[3px] text-[12px] font-extrabold text-ink">Lv.{prog.level}</span>
        </div>
        {clan.desc ? <p className="mt-3 text-[14px] leading-snug text-white/70">{clan.desc}</p> : null}

        <div className="mt-5 flex items-end justify-between text-[14px]">
          <span className="text-muted">Menuju Level {prog.level + 1}</span>
          <span className="font-bold text-white">
            {fmtCompact(prog.current)} / {fmtCompact(prog.required)} XP
          </span>
        </div>
        <div className="mt-2 h-3 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full bg-gradient-to-r from-[#F43F5E] to-[#FB923C]" style={{ width: `${Math.max(3, prog.ratio * 100)}%` }} />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-white/[0.06] p-3.5">
            <p className="text-[12px] text-muted">XP tersedia</p>
            <p className="mt-0.5 text-[22px] font-extrabold text-[#F4C96B]">{fmtNum(clan.xpBalance)}</p>
          </div>
          <div className="rounded-2xl bg-white/[0.06] p-3.5">
            <p className="text-[12px] text-muted">Total XP (Top Clans)</p>
            <p className="mt-0.5 text-[22px] font-extrabold text-white">{fmtCompact(clan.xp)}</p>
          </div>
        </div>
      </div>

      <div className="mt-5 px-5">
        {isMember ? (
          <>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setDonate(true)}
                className="flex-1 rounded-[22px] bg-gradient-to-r from-[#F43F5E] to-[#FB923C] py-4 text-[16px] font-extrabold text-white active:scale-[0.98]"
              >
                💎 Setor Shard
              </button>
              {canShop ? (
                <button
                  type="button"
                  onClick={() => setManage(true)}
                  className="flex-1 rounded-[22px] border border-white/20 bg-white/[0.07] py-4 text-[16px] font-extrabold text-white active:scale-[0.98]"
                >
                  Shop Clan
                </button>
              ) : null}
            </div>
            {!isLeader ? (
              <button type="button" onClick={() => setConfirmLeave(true)} className="mx-auto mt-4 block text-[15px] font-bold text-[#FF7A9A] active:opacity-70">
                Keluar Clan
              </button>
            ) : null}
          </>
        ) : pendingHere ? (
          <button
            type="button"
            disabled={busy === 'req'}
            onClick={() => void run('req', () => cancelRequest(me.uid, id), 'Permintaan dibatalkan')}
            className="w-full rounded-[22px] bg-white/10 py-4 text-[16px] font-extrabold text-white active:scale-[0.98]"
          >
            Menunggu persetujuan · Batalkan
          </button>
        ) : myClanId ? (
          <p className="rounded-2xl bg-white/[0.06] px-4 py-3.5 text-center text-[13.5px] text-muted">Kamu sudah berada di clan lain.</p>
        ) : myReqId ? (
          <p className="rounded-2xl bg-white/[0.06] px-4 py-3.5 text-center text-[13.5px] text-muted">
            Kamu masih punya permintaan ke clan lain. Batalkan dulu di halaman Clans.
          </p>
        ) : (
          <button
            type="button"
            disabled={full || busy === 'req'}
            onClick={() => void run('req', () => requestJoin(me.uid, id), 'Permintaan terkirim ke pengurus clan')}
            className="w-full rounded-[22px] bg-gradient-to-r from-[#8B5CF6] to-[#6366F1] py-4 text-[16px] font-extrabold text-white active:scale-[0.98] disabled:opacity-40"
          >
            {full ? 'Clan penuh' : 'Minta Gabung'}
          </button>
        )}
      </div>

      <div className="mx-5 mt-6 flex rounded-full border border-white/10 bg-white/[0.04] p-1.5">
        {tabs.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={`flex-1 rounded-full py-3 text-[15px] font-extrabold ${
              tab === t.key ? 'bg-gradient-to-r from-[#F43F5E] to-[#FB923C] text-white' : 'text-muted'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="px-5 pt-4">
        {tab === 'members' ? (
          <>
            <div className="flex gap-3">
              <div className="flex min-w-0 flex-1 items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4">
                <Icon name="search" size={18} className="text-muted" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Cari member (nama atau ID)"
                  className="h-12 min-w-0 flex-1 bg-transparent text-[14.5px] text-white placeholder:text-muted focus:outline-none"
                />
              </div>
              <button
                type="button"
                aria-label={byDonation ? 'Urutkan: donasi terbanyak' : 'Urutkan: terbaru'}
                onClick={() => setByDonation((v) => !v)}
                className="flex h-12 shrink-0 items-center gap-1 rounded-2xl border border-white/10 bg-white/[0.04] px-3 text-[12px] font-bold text-white active:scale-95"
              >
                {byDonation ? '💎' : 'Baru'}
              </button>
            </div>
            <div className="mt-2 divide-y divide-white/5">
              {members === undefined ? (
                <div className="flex justify-center py-10">
                  <Spinner size={24} />
                </div>
              ) : sorted.length ? (
                sorted.map((m) => memberRow(m))
              ) : (
                <p className="py-8 text-center text-[14px] text-muted">Member tidak ditemukan.</p>
              )}
            </div>
          </>
        ) : tab === 'donasi' ? (
          <>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {DON_FILTERS.map((f) => (
                <button
                  key={f.key}
                  type="button"
                  onClick={() => setDonPeriod(f.key)}
                  className={`shrink-0 rounded-full px-4 py-2 text-[13px] font-extrabold active:scale-95 ${
                    donPeriod === f.key ? 'bg-white text-ink' : 'border border-white/10 bg-white/[0.04] text-muted'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
            <p className="mt-2 text-[12px] text-muted">
              {donPeriod === 'full' ? DON_HINT.full : `${periodRange(donPeriod as Period)} · ${DON_HINT[donPeriod]}`}
            </p>
            {donPeriod !== 'full' && periodDon === undefined ? (
              <div className="flex justify-center py-10">
                <Spinner size={24} />
              </div>
            ) : donors.length ? (
              <div className="mt-1 divide-y divide-white/5">{donors.map((m, i) => memberRow(m, i + 1))}</div>
            ) : (
              <p className="py-10 text-center text-[14px] text-muted">
                {donPeriod === 'full' ? 'Belum ada donasi. Jadilah yang pertama!' : 'Belum ada donasi di periode ini.'}
              </p>
            )}
          </>
        ) : requests === undefined ? (
          <div className="flex justify-center py-10">
            <Spinner size={24} />
          </div>
        ) : requests.length === 0 ? (
          <p className="py-10 text-center text-[14px] text-muted">Tidak ada permintaan masuk.</p>
        ) : (
          <div className="space-y-3">
            {requests.map((r) => {
              const p = live.get(r.uid)
              const name = nameOf(r.uid)
              return (
                <div key={r.uid} className="rounded-2xl bg-white/[0.05] p-3.5">
                  <button type="button" onClick={() => nav.openProfile(r.uid)} className="flex w-full items-center gap-3 text-left">
                    <Avatar url={p?.photoURL} name={name} size={46} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[16px] font-extrabold text-white">{name}</span>
                        {p ? <RoleCheck role={p.role} verified={p.verified} size={15} /> : null}
                      </div>
                      <div className="mt-1">{p ? <LevelPill level={p.level ?? 1} /> : null}</div>
                    </div>
                  </button>
                  <div className="mt-3 flex gap-2.5">
                    <button
                      type="button"
                      disabled={busy === `a${r.uid}` || full}
                      onClick={() => void run(`a${r.uid}`, () => acceptRequest(id, r.uid), `${name} diterima`)}
                      className="flex-1 rounded-full bg-[#3B8CFF] py-2.5 text-[14px] font-bold text-white active:scale-95 disabled:opacity-40"
                    >
                      {full ? 'Slot penuh' : 'Terima'}
                    </button>
                    <button
                      type="button"
                      disabled={busy === `r${r.uid}`}
                      onClick={() => void run(`r${r.uid}`, () => cancelRequest(r.uid, id), 'Permintaan ditolak')}
                      className="flex-1 rounded-full bg-raise py-2.5 text-[14px] font-bold text-white active:scale-95"
                    >
                      Tolak
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      <DonateSheet open={donate} onClose={() => setDonate(false)} clan={clan} />
      {myRole ? <ManageSheet open={manage} onClose={() => setManage(false)} clan={clan} role={myRole} /> : null}
      <ConfirmDialog
        open={confirmLeave}
        title="Keluar dari clan?"
        message="Donasi yang sudah masuk tetap menjadi milik clan dan tidak dikembalikan."
        confirmLabel="Keluar"
        onCancel={() => setConfirmLeave(false)}
        onConfirm={() => {
          setConfirmLeave(false)
          void run('leave', () => leaveClan(me, clan), 'Kamu keluar dari clan')
        }}
      />
      <Sheet open={!!target} onClose={() => setTarget(null)} title={target ? nameOf(target.uid) : ''}>
        {target ? (
          <div className="space-y-2.5">
            <p className="text-center text-[13px] text-muted">
              Role sekarang:{' '}
              <span className="font-extrabold" style={{ color: CLAN_ROLE_COLOR[target.role] }}>
                {CLAN_ROLE_NAME[target.role]}
              </span>
            </p>
            <button
              type="button"
              onClick={() => {
                const t = target
                setTarget(null)
                if (t) nav.openProfile(t.uid)
              }}
              className="w-full rounded-full bg-raise py-3 text-[14px] font-semibold text-white active:scale-[0.98]"
            >
              Lihat profil
            </button>
            {assignableRoles(myRole, target.role).length ? (
              <div className="rounded-2xl bg-white/[0.04] p-3">
                <p className="mb-2 text-[12px] font-bold uppercase tracking-wide text-muted">Ubah role</p>
                <div className="grid grid-cols-2 gap-2">
                  {assignableRoles(myRole, target.role).map((r) => (
                    <button
                      key={r}
                      type="button"
                      disabled={busy !== null}
                      onClick={() => {
                        const t = target
                        setTarget(null)
                        void run('role', () => setMemberRole(me, clan, t.uid, r), `${nameOf(t.uid)} sekarang ${CLAN_ROLE_NAME[r]}`)
                      }}
                      className="rounded-full py-2.5 text-[13.5px] font-extrabold text-ink active:scale-[0.97] disabled:opacity-40"
                      style={{ backgroundColor: CLAN_ROLE_COLOR[r] }}
                    >
                      {CLAN_ROLE_NAME[r]}
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
            {isLeader ? (
              <button
                type="button"
                onClick={() => {
                  setConfirmTransfer(target)
                  setTarget(null)
                }}
                className="w-full rounded-full bg-[#2a1f4d] py-3 text-[14px] font-extrabold text-[#C4B5FD] ring-1 ring-[#A78BFA]/40 active:scale-[0.98]"
              >
                Jadikan Leader
              </button>
            ) : null}
            {canKick(myRole, target.role) ? (
              <button
                type="button"
                onClick={() => {
                  setConfirmKick(target)
                  setTarget(null)
                }}
                className="w-full rounded-full bg-raise py-3 text-[14px] font-semibold text-accent active:scale-[0.98]"
              >
                Keluarkan dari clan
              </button>
            ) : null}
          </div>
        ) : null}
      </Sheet>
      <ConfirmDialog
        open={!!confirmTransfer}
        title="Pindahkan jabatan Leader?"
        message={confirmTransfer ? `${nameOf(confirmTransfer.uid)} akan menjadi Leader clan. Kamu otomatis menjadi Vice-Leader dan tidak bisa mengambil jabatan Leader kembali tanpa persetujuannya.` : ''}
        confirmLabel="Pindahkan"
        onCancel={() => setConfirmTransfer(null)}
        onConfirm={() => {
          const m = confirmTransfer
          setConfirmTransfer(null)
          if (m) void run('transfer', () => transferLeader(me, clan, m.uid), `${nameOf(m.uid)} sekarang Leader`)
        }}
      />
      <ConfirmDialog
        open={!!confirmKick}
        title="Keluarkan anggota?"
        message={confirmKick ? `${nameOf(confirmKick.uid)} akan dikeluarkan dari clan.` : ''}
        confirmLabel="Keluarkan"
        onCancel={() => setConfirmKick(null)}
        onConfirm={() => {
          const m = confirmKick
          setConfirmKick(null)
          if (m) void run('kick', () => kickMember(me, clan, m.uid), 'Anggota dikeluarkan')
        }}
      />
    </div>
  )
}
