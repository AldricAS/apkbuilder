import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { Avatar, RoleCheck } from '../components/UserBadges'
import { Icon } from '../components/Icon'
import { toast } from '../components/Feedback'
import { useMyClanId } from '../services/clanService'
import { Logo } from '../components/Logo'

// bintang latar: posisi tetap (tidak acak tiap render)
const STARS = Array.from({ length: 36 }, (_, i) => ({
  x: (i * 53 + 11) % 100,
  y: (i * 37 + 7) % 100,
  s: 1 + (i % 3),
  o: 0.2 + ((i * 17) % 50) / 100,
}))

type Shape = 'star' | 'diamond' | 'circle' | 'square'
type IconKey = 'shield' | 'dino' | 'info' | 'nobar'
type MenuItem = { key: string; label: string; icon: IconKey; from: string; to: string; edge: string; shape: Shape; size: number; soon?: boolean }
const MENU: MenuItem[] = [
  { key: 'clan', label: 'Clan', icon: 'shield', from: '#9F7BFF', to: '#4C1D95', edge: '#D9CCFF', shape: 'star', size: 188 },
  { key: 'nobar', label: 'Nobar', icon: 'nobar', from: '#FF8FB3', to: '#8B1F6B', edge: '#FFD3E3', shape: 'square', size: 104 },
  { key: 'dino', label: 'Dino', icon: 'dino', from: '#5BE38B', to: '#146B39', edge: '#C2F7D6', shape: 'diamond', size: 132 },
  { key: 'info', label: 'Info', icon: 'info', from: '#4FB4FF', to: '#1A4FD1', edge: '#BFE3FF', shape: 'circle', size: 76, soon: true },
]

// bintang 5 sudut (kanvas 100x100). Ujung-ujungnya dibulatkan dengan garis tebal yang berwarna sama.
// Bintang dipanjangkan ke bawah (y x 1.28) dengan menghitung ulang titiknya, bukan menarik SVG, supaya tebal garis tetap rata.
const STAR_STRETCH = 1.28
const stretch = (pts: string) =>
  pts
    .split(' ')
    .map((pt) => {
      const [x, y] = pt.split(',').map(Number)
      return `${x},${+(10 + (y - 10) * STAR_STRETCH).toFixed(1)}`
    })
    .join(' ')
const STAR_PTS = stretch('50,10 60.5,38.5 90,38.5 66.5,56 75.5,86 50,68.5 24.5,86 33.5,56 10,38.5 39.5,38.5')
const STAR_INNER = stretch('50,24 57,43 77,43 61,54.5 67,75 50,63 33,75 39,54.5 23,43 43,43')
const STAR_VB_H = 118

/** Ikon vektor (kanvas 24x24) yang digambar di tengah tombol; menggantikan emoji. */
function GameIcon({ icon }: { icon: IconKey }) {
  if (icon === 'shield') {
    return (
      <g>
        <path d="M12 2.6 19.6 5.4v6.1c0 4.6-3.2 8.4-7.6 10-4.4-1.6-7.6-5.4-7.6-10V5.4z" fill="#D5EEF2" stroke="#6FA6B8" strokeWidth="1.2" strokeLinejoin="round" />
        <path d="M12 2.6v18.9c4.4-1.6 7.6-5.4 7.6-10V5.4z" fill="#9DB7C4" />
        <path d="M12 4.6 17.8 6.7v4.8c0 3.5-2.3 6.5-5.8 8z" fill="#fff" opacity="0.18" />
        <path d="M12 2.6 19.6 5.4v6.1c0 4.6-3.2 8.4-7.6 10-4.4-1.6-7.6-5.4-7.6-10V5.4z" fill="none" stroke="#fff" strokeOpacity="0.55" strokeWidth="0.6" strokeLinejoin="round" />
      </g>
    )
  }
  if (icon === 'dino') {
    // T-rex menghadap kanan: gabungan bentuk sederhana berwarna sama (siluet), mata & gigi sebagai detail
    return (
      <g transform="translate(-1.4 -1.6) scale(0.85)">
        <g fill="#F4FFF7" stroke="#F4FFF7" strokeWidth="0.4" strokeLinejoin="round">
          <ellipse cx="14" cy="16.6" rx="7.6" ry="5.4" />
          <path d="M8 13.3Q3.4 15.4 1.6 20.6Q6.4 19.6 9.6 19.4Z" />
          <path d="M16.2 12 20.6 6.4 24.2 8.2 20.4 15.6Z" />
          <rect x="19.4" y="3.6" width="10.8" height="6.4" rx="3" />
          <rect x="20.8" y="8.8" width="8.6" height="2.8" rx="1.4" />
          <rect x="10.2" y="19.6" width="3.8" height="7.6" rx="1.7" />
          <rect x="16.2" y="19.6" width="3.8" height="7.6" rx="1.7" />
          <rect x="9" y="25.8" width="6.6" height="2.5" rx="1.25" />
          <rect x="15" y="25.8" width="6.6" height="2.5" rx="1.25" />
          <rect x="19.4" y="14.4" width="4.6" height="1.9" rx="0.95" transform="rotate(18 19.4 14.4)" />
        </g>
        {/* corak punggung */}
        <g fill="#2E9B5C" opacity="0.55">
          <path d="M9.2 12.2 10.6 9.6 12 11.8Z" />
          <path d="M12.8 11 14.4 8.4 15.6 11Z" />
        </g>
        <circle cx="25.6" cy="6.2" r="1.05" fill="#0F3D24" />
        <path d="M22.4 10 23.2 11.3 24 10ZM25 10 25.8 11.3 26.6 10Z" fill="#0F3D24" opacity="0.6" />
      </g>
    )
  }
  if (icon === 'nobar') {
    // layar TV dengan tombol play + dua siluet penonton kecil di bawahnya
    return (
      <g>
        <rect x="2.4" y="3.4" width="19.2" height="12.4" rx="3" fill="#fff" fillOpacity="0.95" />
        <path d="M10 6.6v6.2l5.4-3.1z" fill="#B8326F" />
        <circle cx="8" cy="19" r="1.5" fill="#fff" />
        <path d="M5.2 22.4c.2-1.7 1.3-2.5 2.8-2.5s2.6.8 2.8 2.5z" fill="#fff" />
        <circle cx="16" cy="19" r="1.5" fill="#fff" />
        <path d="M13.2 22.4c.2-1.7 1.3-2.5 2.8-2.5s2.6.8 2.8 2.5z" fill="#fff" />
      </g>
    )
  }
  return (
    <g>
      <circle cx="12" cy="6.4" r="1.9" fill="#fff" />
      <rect x="10.3" y="10" width="3.4" height="9.4" rx="1.7" fill="#fff" />
    </g>
  )
}

/** Satu tombol menu berbentuk bintang / ketupat / bulat, digambar sebagai SVG berlapis (gradasi, tepi, kilap, ikon vektor). */
function GameShape({ m, uid }: { m: MenuItem; uid: string }) {
  const fill = `url(#${uid}f)`
  const rim = `url(#${uid}r)`
  return (
    <svg viewBox={`0 0 100 ${m.shape === 'star' ? STAR_VB_H : 100}`} width={m.size} height={m.shape === 'star' ? (m.size * STAR_VB_H) / 100 : m.size} aria-hidden style={{ overflow: 'visible' }}>
      <defs>
        <linearGradient id={`${uid}f`} x1="0.15" y1="0" x2="0.85" y2="1">
          <stop offset="0" stopColor={m.from} />
          <stop offset="1" stopColor={m.to} />
        </linearGradient>
        <linearGradient id={`${uid}r`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={m.edge} />
          <stop offset="0.55" stopColor={m.edge} stopOpacity="0.25" />
          <stop offset="1" stopColor={m.edge} stopOpacity="0.5" />
        </linearGradient>
        <radialGradient id={`${uid}g`} cx="0.32" cy="0.22" r="0.8">
          <stop offset="0" stopColor="#fff" stopOpacity="0.55" />
          <stop offset="0.6" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <clipPath id={`${uid}c`}>
          {m.shape === 'star' ? <polygon points={STAR_PTS} strokeLinejoin="round" /> : null}
          {m.shape === 'diamond' ? <polygon points="50,6 94,50 50,94 6,50" /> : null}
          {m.shape === 'circle' ? <circle cx="50" cy="50" r="46" /> : null}
          {m.shape === 'square' ? <rect x="6" y="6" width="88" height="88" rx="22" /> : null}
        </clipPath>
      </defs>

      {m.shape === 'star' ? (
        <>
          <polygon points={STAR_PTS} fill={fill} stroke={fill} strokeWidth="9" strokeLinejoin="round" />
          <polygon points={STAR_PTS} fill="none" stroke={rim} strokeWidth="9" strokeLinejoin="round" opacity="0.9" />
          <polygon points={STAR_PTS} fill={fill} stroke={fill} strokeWidth="7.4" strokeLinejoin="round" />
          <polygon points={STAR_INNER} fill="#fff" opacity="0.1" stroke="#fff" strokeOpacity="0.12" strokeWidth="5" strokeLinejoin="round" />
          <g clipPath={`url(#${uid}c)`}>
            <rect x="0" y="0" width="100" height="100" fill={`url(#${uid}g)`} />
          </g>
        </>
      ) : null}

      {m.shape === 'diamond' ? (
        <>
          <polygon points="50,6 94,50 50,94 6,50" fill={fill} stroke={rim} strokeWidth="5" strokeLinejoin="round" />
          {/* sisi permata: separuh atas-kiri lebih terang, separuh bawah-kanan lebih gelap */}
          <g clipPath={`url(#${uid}c)`}>
            <polygon points="6,50 50,6 94,50 50,50" fill="#fff" opacity="0.14" />
            <polygon points="50,50 94,50 50,94 6,50" fill="#000" opacity="0.14" />
            <rect x="0" y="0" width="100" height="100" fill={`url(#${uid}g)`} />
          </g>
          <polygon points="50,19 81,50 50,81 19,50" fill="none" stroke="#fff" strokeOpacity="0.28" strokeWidth="1.6" strokeLinejoin="round" />
        </>
      ) : null}

      {m.shape === 'square' ? (
        <>
          <rect x="6" y="6" width="88" height="88" rx="22" fill={fill} stroke={rim} strokeWidth="5" />
          <g clipPath={`url(#${uid}c)`}>
            <rect x="0" y="0" width="100" height="46" fill="#fff" opacity="0.12" />
            <rect x="0" y="0" width="100" height="100" fill={`url(#${uid}g)`} />
          </g>
          <rect x="17" y="17" width="66" height="66" rx="15" fill="none" stroke="#fff" strokeOpacity="0.25" strokeWidth="1.6" />
        </>
      ) : null}

      {m.shape === 'circle' ? (
        <>
          <circle cx="50" cy="50" r="46" fill={fill} stroke={rim} strokeWidth="5" />
          <circle cx="50" cy="50" r="37" fill="none" stroke="#fff" strokeOpacity="0.22" strokeWidth="1.6" />
          <g clipPath={`url(#${uid}c)`}>
            <rect x="0" y="0" width="100" height="100" fill={`url(#${uid}g)`} />
          </g>
        </>
      ) : null}

      {/* ikon vektor di tengah */}
      <g
        transform={
          m.shape === 'star'
            ? 'translate(29.5 47) scale(1.7)'
            : m.shape === 'diamond'
              ? 'translate(30.5 30.5) scale(1.6)'
              : m.shape === 'square'
                ? 'translate(27 27) scale(1.9)'
                : 'translate(26 26) scale(2)'
        }
        style={{ filter: 'drop-shadow(0 1.2px 1.2px rgba(0,0,0,0.35))' }}
      >
        <GameIcon icon={m.icon} />
      </g>
    </svg>
  )
}

// kelopak sakura: ciri khas AkimiPlay (pink). Posisi & waktu tetap supaya tidak acak tiap render.
const PETALS = Array.from({ length: 11 }, (_, i) => ({
  x: (i * 61 + 8) % 100,
  s: 7 + (i % 4) * 2,
  d: 11 + (i % 5) * 2.4,
  delay: -((i * 1.7) % 13),
  sway: (i % 2 ? 1 : -1) * (30 + (i % 4) * 14),
}))

/** Partikel latar: bintang berkelip, kelopak sakura jatuh, bintang jatuh, dan cahaya lembut. */
function Particles() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <div className="absolute -left-20 top-28 h-72 w-72 rounded-full bg-[#7C3AED]/25 blur-3xl" />
      <div className="absolute -right-24 top-[46%] h-72 w-72 rounded-full bg-[#FF7AA2]/18 blur-3xl" />
      <div className="absolute -bottom-16 left-1/4 h-60 w-60 rounded-full bg-[#1A4FD1]/20 blur-3xl" />
      {STARS.map((st, i) => (
        <span
          key={i}
          className="absolute animate-twinkle rounded-full bg-white"
          style={{ left: `${st.x}%`, top: `${st.y}%`, width: st.s, height: st.s, opacity: st.o, animationDuration: `${3 + (i % 5)}s`, animationDelay: `${(i % 9) * 0.35}s` }}
        />
      ))}
      {PETALS.map((p, i) => (
        <span
          key={`p${i}`}
          className="absolute -top-4 animate-petal"
          style={{
            left: `${p.x}%`,
            width: p.s,
            height: p.s * 1.35,
            borderRadius: '70% 0 70% 0',
            background: 'linear-gradient(135deg, #FFC2D6, #FF7AA2)',
            animationDuration: `${p.d}s`,
            animationDelay: `${p.delay}s`,
            ['--sway' as string]: `${p.sway}px`,
          }}
        />
      ))}
      <span className="absolute right-[18%] top-[14%] h-px w-24 animate-shoot bg-gradient-to-r from-transparent via-white to-transparent" style={{ animationDelay: '2s' }} />
      <span className="absolute right-[40%] top-[34%] h-px w-20 animate-shoot bg-gradient-to-r from-transparent via-[#FFC2D6] to-transparent" style={{ animationDelay: '6.5s' }} />
    </div>
  )
}

/** Hiasan di sekitar bintang besar: cincin orbit, garis rasi bintang bertitik, dan titik cahaya. */
function StarDecor() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 200 240" fill="none" aria-hidden>
      <g className="origin-center animate-orbit" style={{ transformOrigin: '100px 130px' }}>
        <ellipse cx="100" cy="130" rx="92" ry="104" stroke="#C4B0FF" strokeOpacity="0.28" strokeWidth="1" strokeDasharray="3 7" />
        <circle cx="100" cy="26" r="3.2" fill="#FFC2D6" />
        <circle cx="192" cy="130" r="2.2" fill="#C4B0FF" />
        <circle cx="8" cy="130" r="2.2" fill="#9CC8FF" />
      </g>
      <polyline points="14,40 40,70 22,108 44,146" stroke="#FFFFFF" strokeOpacity="0.22" strokeWidth="1" strokeDasharray="4 4" className="animate-dash" />
      <polyline points="186,52 168,84 190,122" stroke="#FFFFFF" strokeOpacity="0.22" strokeWidth="1" strokeDasharray="4 4" className="animate-dash" />
      {[[14, 40], [40, 70], [22, 108], [44, 146], [186, 52], [168, 84], [190, 122]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="2.1" fill="#fff" fillOpacity="0.8" className="animate-twinkle" style={{ animationDelay: `${i * 0.5}s` }} />
      ))}
    </svg>
  )
}

/** Halaman AkimiGames (BETA). Clan & Nobar aktif; fitur lain ditandai segera hadir. */
export function AkimiGamesPage() {
  const nav = useNav()
  const profile = useProfile()
  const name = profile.username?.trim() || profile.displayName
  const myClanId = useMyClanId(profile.uid)

  // sudah punya clan: langsung ke clan-nya; belum: ke halaman buat clan / gabung clan
  const openClan = () => {
    if (myClanId === undefined) return toast('Memuat data clan…')
    nav.push(myClanId ? { name: 'clan', id: myClanId } : { name: 'clans' })
  }
  const onMenu = (m: MenuItem) => {
    if (m.key === 'clan') return openClan()
    if (m.key === 'nobar') return nav.push({ name: 'nobar' })
    if (m.key === 'dino') return nav.push({ name: 'dino' })
    toast(`${m.label} segera hadir`)
  }

  const renderBtn = (m: MenuItem, extra = '') => (
    <button
      key={m.key}
      type="button"
      onClick={() => onMenu(m)}
      className={`flex flex-col items-center gap-2 transition-transform active:scale-95 ${m.soon ? 'opacity-80' : ''} ${extra}`}
    >
      <span className="relative flex items-center justify-center" style={{ width: m.size, height: m.shape === 'star' ? (m.size * STAR_VB_H) / 100 : m.size }}>
        {/* aura lembut di belakang tombol */}
        <span
          aria-hidden
          className={`absolute inset-[-14%] rounded-full blur-2xl ${m.soon ? 'opacity-40' : 'animate-glow'}`}
          style={{ background: `radial-gradient(circle, ${m.from}88 0%, transparent 70%)` }}
        />
        <span className={`relative ${m.shape === 'star' ? 'animate-floaty' : ''}`} style={{ filter: `drop-shadow(0 8px 14px ${m.to}aa)` }}>
          <GameShape m={m} uid={`gm${m.key}`} />
        </span>
      </span>
      <span className="text-[17px] font-extrabold text-white">{m.label}</span>
      {m.soon ? (
        <span className="-mt-1 rounded-full bg-white/10 px-2 py-[2px] text-[10px] font-bold uppercase tracking-wide text-white/70">Segera</span>
      ) : null}
    </button>
  )

  const byKey = (k: string) => MENU.find((m) => m.key === k) as MenuItem

  return (
    <div className="absolute inset-0 overflow-y-auto overflow-x-hidden overscroll-x-none [touch-action:pan-y] bg-gradient-to-b from-[#0a0f24] via-[#0b0a1d] to-ink pb-24">
      <Particles />
      {/* logo AkimiPlay samar sebagai watermark */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
        <div className="absolute -right-10 bottom-24 opacity-[0.06]">
          <Logo size={260} />
        </div>
      </div>

      <header className="pt-safe relative">
        <div className="flex h-16 items-center gap-3 px-4">
          <button
            type="button"
            aria-label="Kembali"
            onClick={nav.pop}
            className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10"
          >
            <Icon name="back" size={24} />
          </button>
          <h1 className="text-[28px] font-extrabold tracking-tight text-white">AkimiGames</h1>
          <span className="rounded-lg bg-[#1d3b2c] px-2.5 py-1 text-[12px] font-extrabold tracking-wide text-[#5BE08A]">BETA</span>
        </div>
      </header>

      <div className="relative mx-4 mt-3 flex items-center gap-3.5 rounded-3xl border border-white/10 bg-white/[0.05] p-4 backdrop-blur-sm">
        <Avatar url={profile.photoURL} name={name} size={60} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <p className="truncate text-[20px] font-extrabold text-white">{name}</p>
            <RoleCheck role={profile.role} verified={profile.verified} size={18} />
          </div>
          <p className="mt-0.5 text-[14px] text-white/60">Selamat datang!</p>
        </div>
        <span className="shrink-0 opacity-80" aria-hidden>
          <Logo size={34} />
        </span>
      </div>

      <div className="relative mx-5 mt-7 flex items-center gap-3">
        <p className="text-[16px] font-bold text-white/60">Menu</p>
        <span className="h-px flex-1 bg-gradient-to-r from-white/20 to-transparent" />
      </div>

      <div className="relative mx-4 mt-3 flex items-start justify-between gap-2">
        {/* bintang besar di samping kiri, memanjang ke bawah */}
        <div className="relative flex w-[212px] shrink-0 justify-center pb-2 pt-2">
          <div className="absolute inset-0 overflow-hidden">
            <StarDecor />
          </div>
          <div className="relative pt-4">{renderBtn(byKey('clan'))}</div>
        </div>
        {/* sisi kanan: Nobar (kotak) sedikit lebih rendah dari puncak bintang */}
        <div className="flex flex-1 flex-col items-center gap-6 pt-14">
          {renderBtn(byKey('nobar'))}
          <div className="flex items-end justify-center gap-4">
            {renderBtn({ ...byKey('dino'), size: 74 })}
          </div>
        </div>
      </div>

      <div className="relative mx-4 mt-5 flex items-end justify-center gap-10">{renderBtn(byKey('info'))}</div>
    </div>
  )
}
