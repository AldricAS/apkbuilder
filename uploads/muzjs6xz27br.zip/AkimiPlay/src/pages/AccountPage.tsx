import { useProfile } from '../auth/AuthProvider'
import { ProfilePage } from './ProfilePage'

/** Tab Akun: profil milik sendiri. Pengaturan dibuka lewat tombol gerigi di kanan atas. */
export function AccountPage() {
  const me = useProfile()
  return <ProfilePage uid={me.uid} mode="account" />
}
