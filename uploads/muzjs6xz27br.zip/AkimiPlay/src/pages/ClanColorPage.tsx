import { useState } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import {
  CLAN_COLORS,
  COLOR_SPIN5_COST,
  COLOR_SPIN_COST,
  RARITY_LABEL,
  RARITY_RATE,
  clanColorOf,
  equipColor,
  spinColors,
  useClan,
  useClanColors,
  useMyRole,
  canManageClan,
  type Clan,
  type Rarity,
  type SpinResult,
} from '../services/clanService'
import { errMsg } from '../lib/format'
import { fmtNum } from '../lib/xp'
import { ClanBadge } from '../components/ClanBadge'
import { Icon } from '../components/Icon'
import { EmptyState, Spinner } from '../components/States'
import { toast } from '../components/Feedback'

type Tab = 'spin' | 'koleksi'

const RARITY_STYLE: Record<Rarity, { text: string; chip: string; ring: string }> = {
  common: { text: 'text-[#CBD5E1]', chip: 'bg-white/10 text-[#CBD5E1]', ring: 'ring-white/10' },
  rare: { text: 'text-[#7DD3FC]', chip: 'bg-[#12324a] text-[#7DD3FC]', ring: 'ring-[#38BDF8]/40' },
  legend: { text: 'text-[#F4C96B]', chip: 'bg-[#3a3418] text-[#F4C96B]', ring: 'ring-[#F4C96B]/50' },
}
const RARITIES: Rarity[] = ['common', 'rare', 'legend']

/** Hasil spin: kartu muncul satu per satu; Legend diberi bingkai emas. */
function ResultOverlay({ clan, results, onClose }: { clan: Clan; results: SpinResult[]; onClose: () => void }) {
  const best = results.reduce<Rarity>((acc, r) => {
    const rar = clanColorOf(r.color).rarity
    return RARITIES.indexOf(rar) > RARITIES.indexOf(acc) ? rar : acc
  }, 'common')
  return (
    <div className="fixed inset-0 z-[96] flex items-center justify-center px-5">
      <div className="absolute inset-0 animate-fadeIn bg-black/80" onClick={onClose} />
      <div className="relative w-full max-w-sm animate-fadeIn rounded-3xl border border-line bg-panel p-5">
        <p className={`text-center text-[13px] font-bold uppercase tracking-widest ${RARITY_STYLE[best].text}`}>
          {best === 'legend' ? 'Legend didapat!' : best === 'rare' ? 'Ada warna Rare' : 'Hasil spin'}
        </p>
        <div className="mt-4 max-h-[55vh] space-y-2.5 overflow-y-auto">
          {results.map((r, i) => {
            const c = clanColorOf(r.color)
            return (
              <div
                key={i}
                className={`flex animate-fadeIn items-center gap-3 rounded-2xl bg-white/[0.05] px-3.5 py-3 ring-1 [animation-fill-mode:backwards] ${RARITY_STYLE[c.rarity].ring}`}
                style={{ animationDelay: `${i * 160}ms` }}
              >
                <ClanBadge tag={clan.tag} color={r.color} emblem={clan.emblem} tier={clan.tier} height={30} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15px] font-extrabold text-white">{c.name}</p>
                  <p className={`text-[12px] font-bold ${RARITY_STYLE[c.rarity].text}`}>{RARITY_LABEL[c.rarity]}</p>
                </div>
                <span className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-extrabold ${r.isNew ? 'bg-[#16382a] text-[#5BE08A]' : 'bg-white/10 text-muted'}`}>
                  {r.isNew ? 'BARU' : 'Duplikat'}
                </span>
              </div>
            )
          })}
        </div>
        <button type="button" onClick={onClose} className="mt-5 w-full rounded-full bg-white/10 py-3.5 text-[15px] font-extrabold text-white active:scale-[0.98]">
          Tutup
        </button>
      </div>
    </div>
  )
}

export function ClanColorPage({ id }: { id: string }) {
  const nav = useNav()
  const me = useProfile()
  const clan = useClan(id)
  const owned = useClanColors(id)
  const myRole = useMyRole(id, me.uid)
  const [tab, setTab] = useState<Tab>('spin')
  const [busy, setBusy] = useState<'spin1' | 'spin5' | number | null>(null)
  const [results, setResults] = useState<SpinResult[] | null>(null)

  if (clan === undefined || owned === undefined) {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-ink">
        <Spinner size={30} />
      </div>
    )
  }
  if (clan === null) {
    return (
      <div className="absolute inset-0 bg-ink">
        <header className="pt-safe px-3 py-3">
          <button type="button" aria-label="Kembali" onClick={nav.pop} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10">
            <Icon name="back" size={26} />
          </button>
        </header>
        <EmptyState icon="users" title="Clan tidak ditemukan." hint="Clan ini mungkin sudah dibubarkan." />
      </div>
    )
  }

  // Leader dan Vice-Leader boleh memutar & memakai warna.
  const isLeader = clan.leaderUid === me.uid || canManageClan(myRole)
  const xpBal = clan.xpBalance

  const spin = async (times: 1 | 5) => {
    if (busy !== null) return
    setBusy(times === 5 ? 'spin5' : 'spin1')
    try {
      setResults(await spinColors(me, clan, times))
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(null)
    }
  }
  const equip = async (idx: number) => {
    if (busy !== null || idx === clan.color) return
    setBusy(idx)
    try {
      await equipColor(me, clan, idx)
      toast(`Warna ${clanColorOf(idx).name} dipakai`)
    } catch (e) {
      toast(errMsg(e))
    } finally {
      setBusy(null)
    }
  }

  const cur = clanColorOf(clan.color)
  const canSpin1 = isLeader && xpBal >= COLOR_SPIN_COST
  const canSpin5 = isLeader && xpBal >= COLOR_SPIN5_COST

  return (
    <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-[#1b1236] via-[#0f0c22] to-ink pb-24">
      <header className="pt-safe">
        <div className="flex h-14 items-center gap-2 px-3">
          <button type="button" aria-label="Kembali" onClick={nav.pop} className="flex h-10 w-10 items-center justify-center rounded-full active:bg-white/10">
            <Icon name="back" size={26} />
          </button>
          <h1 className="text-[22px] font-extrabold tracking-tight text-white">Warna Clan</h1>
        </div>
      </header>

      <div className="mx-4 mt-2 rounded-3xl border border-white/10 bg-white/[0.05] p-4">
        <div className="flex justify-center py-3">
          <ClanBadge tag={clan.tag} color={clan.color} emblem={clan.emblem} tier={clan.tier} height={46} />
        </div>
        <p className="text-center text-[13px] text-muted">
          Warna dipakai: <span className={`font-bold ${RARITY_STYLE[cur.rarity].text}`}>{cur.name}</span>
        </p>
        <div className="mt-3 flex items-center justify-between rounded-2xl bg-black/20 px-4 py-2.5">
          <span className="text-[13px] text-muted">XP clan tersedia</span>
          <span className="text-[17px] font-extrabold text-[#F4C96B]">{fmtNum(xpBal)}</span>
        </div>
      </div>

      <div className="mx-4 mt-4 flex rounded-full border border-white/10 bg-white/[0.04] p-1.5">
        {(['spin', 'koleksi'] as Tab[]).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={`flex-1 rounded-full py-2.5 text-[14.5px] font-extrabold ${tab === t ? 'bg-gradient-to-r from-[#F43F5E] to-[#FB923C] text-white' : 'text-muted'}`}
          >
            {t === 'spin' ? 'Spin' : `Koleksi ${owned.size}/${CLAN_COLORS.length}`}
          </button>
        ))}
      </div>

      {tab === 'spin' ? (
        <div className="mx-4 mt-4 space-y-3">
          <div className="rounded-3xl bg-white/[0.05] p-4">
            <p className="text-[15px] font-bold text-white">Peluang tiap putaran</p>
            <div className="mt-3 grid grid-cols-3 gap-2.5">
              {RARITIES.map((r) => (
                <div key={r} className={`rounded-2xl bg-black/20 px-2 py-3 text-center ring-1 ${RARITY_STYLE[r].ring}`}>
                  <p className={`text-[12px] font-extrabold uppercase tracking-wide ${RARITY_STYLE[r].text}`}>{RARITY_LABEL[r]}</p>
                  <p className="mt-0.5 text-[19px] font-extrabold text-white">{RARITY_RATE[r]}%</p>
                  <p className="text-[11px] text-muted">{CLAN_COLORS.filter((c) => c.rarity === r).length} warna</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[12px] leading-snug text-muted">
              Legend (Black Shine) berdasar hitam dengan kilau bergerak, dan sangat sulit didapat. Warna yang sudah dimiliki tidak mengembalikan XP. Spin memakai XP clan tersedia (sama seperti beli slot dan tier); XP total di Top Clans tidak berkurang.
            </p>
          </div>

          {!isLeader ? (
            <p className="rounded-2xl bg-white/[0.06] px-4 py-3.5 text-center text-[13.5px] text-muted">Hanya Leader atau Vice-Leader yang bisa memutar warna clan.</p>
          ) : null}

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              disabled={!canSpin1 || busy !== null}
              onClick={() => void spin(1)}
              className="flex flex-col items-center rounded-3xl border border-white/15 bg-white/[0.07] py-4 active:scale-[0.98] disabled:opacity-40"
            >
              <span className="text-[17px] font-extrabold text-white">{busy === 'spin1' ? <Spinner size={18} /> : 'Spin 1×'}</span>
              <span className="mt-0.5 text-[13px] font-bold text-[#F4C96B]">{fmtNum(COLOR_SPIN_COST)} XP</span>
            </button>
            <button
              type="button"
              disabled={!canSpin5 || busy !== null}
              onClick={() => void spin(5)}
              className="relative flex flex-col items-center rounded-3xl bg-gradient-to-r from-[#F43F5E] to-[#FB923C] py-4 active:scale-[0.98] disabled:opacity-40"
            >
              <span className="text-[17px] font-extrabold text-white">{busy === 'spin5' ? <Spinner size={18} /> : 'Spin 5×'}</span>
              <span className="mt-0.5 text-[13px] font-bold text-white/90">{fmtNum(COLOR_SPIN5_COST)} XP</span>
              <span className="absolute -top-2 right-3 rounded-full bg-[#16382a] px-2 py-[2px] text-[10px] font-extrabold text-[#5BE08A]">
                HEMAT {fmtNum(COLOR_SPIN_COST * 5 - COLOR_SPIN5_COST)}
              </span>
            </button>
          </div>
          {isLeader && !canSpin1 ? <p className="text-center text-[12.5px] text-[#FF8A9A]">XP clan belum cukup untuk spin. Setor AkimiShard dulu lewat halaman clan.</p> : null}
        </div>
      ) : (
        <div className="mx-4 mt-4 space-y-5">
          {!isLeader ? <p className="rounded-2xl bg-white/[0.06] px-4 py-3 text-center text-[13px] text-muted">Hanya Leader atau Vice-Leader yang bisa mengganti warna clan.</p> : null}
          {RARITIES.map((r) => (
            <section key={r}>
              <div className="mb-2.5 flex items-center gap-2">
                <h2 className={`text-[15px] font-extrabold uppercase tracking-wide ${RARITY_STYLE[r].text}`}>{RARITY_LABEL[r]}</h2>
                <span className="text-[12px] text-muted">
                  {CLAN_COLORS.filter((c, i) => c.rarity === r && owned.has(i)).length}/{CLAN_COLORS.filter((c) => c.rarity === r).length}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {CLAN_COLORS.map((c, i) => {
                  if (c.rarity !== r) return null
                  const has = owned.has(i)
                  const active = clan.color === i
                  return (
                    <button
                      key={c.name}
                      type="button"
                      disabled={!has || !isLeader || busy !== null}
                      onClick={() => void equip(i)}
                      className={`flex flex-col items-center gap-2 rounded-2xl bg-white/[0.05] px-2 py-3.5 ring-1 active:scale-[0.98] ${
                        active ? 'ring-2 ring-white' : RARITY_STYLE[r].ring
                      }`}
                    >
                      <div className={has ? '' : 'opacity-30 grayscale'}>
                        <ClanBadge tag={clan.tag} color={i} emblem={clan.emblem} tier={clan.tier} height={28} />
                      </div>
                      <p className={`text-[13px] font-bold ${has ? 'text-white' : 'text-muted'}`}>{c.name}</p>
                      <span
                        className={`rounded-full px-3 py-1 text-[11px] font-extrabold ${
                          active ? 'bg-white text-ink' : has ? (isLeader ? 'bg-accent/20 text-accent' : 'bg-white/10 text-white/70') : 'bg-white/5 text-muted'
                        }`}
                      >
                        {busy === i ? '…' : active ? 'Dipakai' : has ? (isLeader ? 'Pakai' : 'Dimiliki') : 'Belum dimiliki'}
                      </span>
                    </button>
                  )
                })}
              </div>
            </section>
          ))}
        </div>
      )}

      {results ? <ResultOverlay clan={clan} results={results} onClose={() => setResults(null)} /> : null}
    </div>
  )
}
