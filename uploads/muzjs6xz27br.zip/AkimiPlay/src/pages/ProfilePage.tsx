import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { useNav } from '../nav/router'
import { useProfile } from '../auth/AuthProvider'
import { copyText } from '../lib/clipboard'
import { isDeveloper } from '../services/broadcastService'
import { canUseBanner, subscribeProfile, updateProfileEdit, type Role, type UserProfile } from '../services/userService'
import {
  cachedAnime,
  cachedEpisode,
  fetchUserComments,
  fetchUserHistory,
  fmtWatchTime,
  resolveAnime,
  seedFromHistory,
  toPublic,
  type PublicProfile,
  type UserComment,
} from '../services/profileService'
import { historyStore, useStore } from '../storage/stores'
import type { HistoryEntry } from '../types'
import { fmtNum, xpProgress } from '../lib/xp'
import { errMsg, fmtTime, timeAgo } from '../lib/format'
import { Avatar, ClanPill, DEMON_ROLE_LABEL, DeveloperBadge, LevelPill, MAOU_ROLE_LABEL, PremiumBadge, RoleCheck, SPECIAL_ROLE_LABEL } from '../components/UserBadges'
import { TopLbBadge, useMonthlyRank } from '../components/LeaderboardUi'
import { Icon, type IconName } from '../components/Icon'
import { LevelIcon } from '../components/LevelIcon'
import { LevelProgressModal } from '../components/LevelProgressModal'
import { Poster } from '../components/Poster'
import { EmptyState, ErrorState, Spinner } from '../components/States'
import { Sheet, toast } from '../components/Feedback'
import { FriendButton } from '../components/FriendButton'
import { RemoteMedia } from '../components/RemoteMedia'
import { FriendComments } from '../components/FriendComments'
import { useIncomingCount, useRelation } from '../services/friendService'

/** Banner profil (URL gambar/GIF). Hanya tampil bila pemiliknya masih Premium aktif / punya role selain user. Gagal muat = diabaikan. */
function BannerImg({ url }: { url?: string }) {
  return <RemoteMedia url={url} className="absolute inset-0 h-full w-full object-cover" />
}

type TabKey = 'overview' | 'history' | 'comments' | 'friends'
const BASE_TABS: { key: TabKey; label: string }[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'history', label: 'History' },
  { key: 'comments', label: 'Comments' },
]
const FRIEND_TAB: { key: TabKey; label: string } = { key: 'friends', label: 'Teman' }

type Load<T> = { status: 'loading' } | { status: 'ok'; data: T } | { status: 'error'; message: string }

const ROLE_STYLE: Record<Role, { label: string; chip: string; ring: string }> = {
  user: { label: 'USER', chip: 'bg-white/10 text-white/80', ring: 'from-accent to-[#7a5cff]' },
  premium: { label: 'PREMIUM', chip: 'bg-[#2E8BFF] text-white', ring: 'from-[#000000] via-[#2E8BFF] to-[#000000]' },
  beta: { label: 'BETA', chip: 'bg-[#FF8A1F] text-white', ring: 'from-[#FF8A1F] to-[#FFC15C]' },
  moderator: { label: 'MODERATOR', chip: 'bg-[#9B7BFF] text-white', ring: 'from-[#9B7BFF] to-[#5b8cff]' },
  admin: { label: 'ADMIN', chip: 'bg-[#FF4D5E] text-white', ring: 'from-[#FF4D5E] to-[#ff9a5c]' },
  developer: { label: 'DEVELOPER', chip: 'bg-[#FF4D5E] text-white', ring: 'from-[#FF4D5E] to-accent' },
  special: {
    label: SPECIAL_ROLE_LABEL.toUpperCase(),
    chip: 'bg-gradient-to-r from-[#050507] via-[#2A1252] to-[#8B3DFF] text-white ring-1 ring-[#8B3DFF]/50',
    ring: 'from-[#050507] to-[#8B3DFF]',
  },
  raja_iblis: {
    label: DEMON_ROLE_LABEL.toUpperCase(),
    chip: 'bg-gradient-to-r from-[#060102] via-[#5C0614] to-[#E0142F] text-white ring-1 ring-[#E0142F]/55',
    ring: 'from-[#060102] to-[#E0142F]',
  },
  maou: {
    label: MAOU_ROLE_LABEL.toUpperCase(),
    chip: 'bg-gradient-to-r from-[#FF1F3D] via-[#7A0A1B] to-[#050001] text-white ring-1 ring-[#FF1F3D]/55',
    ring: 'from-[#FF1F3D] to-[#050001]',
  },
}

function RolePill({ role }: { role: Role }) {
  if (role === 'developer') return <DeveloperBadge size={10.5} />
  if (role === 'premium') return <PremiumBadge size={10.5} />
  const s = ROLE_STYLE[role] ?? ROLE_STYLE.user
  return (
    <span className={`rounded-md px-2 py-[2px] text-[10.5px] font-extrabold leading-[14px] tracking-wider ${s.chip}`}>{s.label}</span>
  )
}

/** mode 'account' = tab Akun milik sendiri (header ringkas + tombol pengaturan); 'page' = halaman profil biasa. */
export function ProfilePage({ uid, mode = 'page' }: { uid: string; mode?: 'page' | 'account' }) {
  const nav = useNav()
  const me = useProfile()
  const own = me.uid === uid
  const isAccount = mode === 'account'
  const { rel } = useRelation(me.uid, own ? null : uid)
  const incomingCount = useIncomingCount(me.uid)
  const staff = isDeveloper(me)
  // komentar teman: pemilik profil dan temannya (developer juga bisa melihat/menulis)
  const showFriendTab = own || rel === 'friends' || staff
  const canPostFriend = !own && (rel === 'friends' || staff)
  const TABS = showFriendTab ? [...BASE_TABS, FRIEND_TAB] : BASE_TABS
  const monthlyRank = useMonthlyRank(uid)

  const [raw, setRaw] = useState<UserProfile | null | undefined>(undefined)
  const [profileError, setProfileError] = useState<string | null>(null)
  const [tabPick, setTab] = useState<TabKey>('overview')
  const tab: TabKey = TABS.some((t) => t.key === tabPick) ? tabPick : 'overview'
  const [coverFailed, setCoverFailed] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [levelOpen, setLevelOpen] = useState(false)
  const [draft, setDraft] = useState('')
  const [bannerDraft, setBannerDraft] = useState('')
  const [saving, setSaving] = useState(false)

  // histori sendiri: pakai penyimpanan lokal (selalu terbaru); histori orang lain: baca dari database
  const localHistory = useStore(historyStore)
  const [remoteHistory, setRemoteHistory] = useState<Load<HistoryEntry[]>>({ status: 'loading' })
  const [comments, setComments] = useState<Load<UserComment[]>>({ status: 'loading' })
  const [reloadKey, setReloadKey] = useState(0)

  useEffect(() => {
    setRaw(undefined)
    setProfileError(null)
    return subscribeProfile(uid, setRaw, (e) => setProfileError(e.message))
  }, [uid])

  useEffect(() => {
    let off = false
    setComments({ status: 'loading' })
    fetchUserComments(uid, reloadKey > 0)
      .then((data) => !off && setComments({ status: 'ok', data }))
      .catch((e: unknown) => !off && setComments({ status: 'error', message: errMsg(e) }))
    return () => {
      off = true
    }
  }, [uid, reloadKey])

  useEffect(() => {
    if (own) return
    let off = false
    setRemoteHistory({ status: 'loading' })
    fetchUserHistory(uid)
      .then((data) => !off && setRemoteHistory({ status: 'ok', data }))
      .catch((e: unknown) => !off && setRemoteHistory({ status: 'error', message: errMsg(e) }))
    return () => {
      off = true
    }
  }, [uid, own, reloadKey])

  const history: Load<HistoryEntry[]> = own
    ? { status: 'ok', data: [...localHistory].sort((a, b) => b.updatedAt - a.updatedAt) }
    : remoteHistory

  const profile: PublicProfile | null = useMemo(() => (raw ? toPublic(raw) : null), [raw])
  // satu nama saja: username yang sudah diubah user, kalau belum ada pakai nama awal
  const shownName = profile ? profile.username?.trim() || profile.displayName : ''
  const xp = profile ? xpProgress(profile.xp) : null
  const stats = {
    watch: profile ? fmtWatchTime(profile.totalWatchMinutes) : '–',
    history: history.status === 'ok' ? fmtNum(history.data.length) : '–',
    comments: comments.status === 'ok' ? fmtNum(comments.data.length) : '–',
  }
  const reload = () => setReloadKey((n) => n + 1)

  return (
    <div className={`absolute inset-0 overflow-y-auto ${isAccount ? 'pb-36' : 'pb-24'}`}>
      {isAccount ? (
        <AccountHeader onSettings={() => nav.push({ name: 'settings' })} />
      ) : (
      <>
      {/* ===== cover + avatar ===== */}
      <div className="relative h-[190px] overflow-hidden bg-gradient-to-br from-[#3a1f3d] via-[#1b1330] to-ink">
        {canUseBanner(profile) && profile?.bannerURL ? <BannerImg url={profile.bannerURL} /> : null}
        {profile?.photoURL && !coverFailed && !(canUseBanner(profile) && profile?.bannerURL) ? (
          <img
            src={profile.photoURL}
            alt=""
            referrerPolicy="no-referrer"
            onError={() => setCoverFailed(true)}
            className="absolute inset-0 h-full w-full scale-150 object-cover opacity-45 blur-2xl"
          />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-ink" />
        <div className="pt-safe absolute inset-x-0 top-0">
          <div className="flex h-14 items-center px-3">
            <button
              type="button"
              aria-label="Kembali"
              onClick={nav.pop}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-black/35 backdrop-blur-md active:scale-90"
            >
              <Icon name="back" size={22} />
            </button>
            {own ? (
              <button
                type="button"
                aria-label="Pengaturan"
                onClick={() => nav.push({ name: 'settings' })}
                className="ml-auto flex h-10 w-10 items-center justify-center rounded-full bg-black/35 backdrop-blur-md active:scale-90"
              >
                <Icon name="gear" size={21} />
              </button>
            ) : null}
          </div>
        </div>
      </div>
      </>
      )}

      {raw === undefined ? (
        profileError ? (
          <ErrorState message={profileError} onRetry={reload} />
        ) : (
          <div className="flex justify-center py-24">
            <Spinner size={28} />
          </div>
        )
      ) : raw === null || !profile ? (
        <EmptyState icon="user" title="Profil tidak ditemukan" hint="Pengguna ini belum punya profil atau sudah dihapus." />
      ) : (
        <div className="animate-fadeIn">
          {isAccount ? null : (
          <div className="relative z-10 -mt-[62px] flex flex-col items-center px-4">
            {!own ? (
              <div className="absolute right-5 top-[26px]">
                <FriendButton uid={uid} variant="circle" />
              </div>
            ) : null}
            <div className={`rounded-full bg-gradient-to-br p-[3px] shadow-[0_10px_36px_rgba(0,0,0,0.55)] ${(ROLE_STYLE[profile.role] ?? ROLE_STYLE.user).ring}`}>
              <div className="rounded-full bg-ink p-[3px]">
                <Avatar url={profile.photoURL} name={shownName} size={108} />
              </div>
            </div>

            <div className="mt-3.5 flex max-w-full items-center gap-2">
              <h1 className="min-w-0 truncate text-[23px] font-extrabold tracking-tight text-white">{shownName}</h1>
              <RoleCheck role={profile.role} verified={profile.verified} size={19} />
            </div>

            <div className="mt-2.5 flex flex-wrap items-center justify-center gap-2">
              <span className="text-[13px] font-semibold text-white/70">#{profile.userId}</span>
              <RolePill role={profile.role} />
              <TopLbBadge rank={monthlyRank} />
              <ClanPill tag={profile.clanTag} />
            </div>
          </div>
          )}

          <div className="flex flex-col items-center px-4">
            {/* level & XP */}
            <div className="mt-4 w-full max-w-[420px] rounded-2xl border border-white/[0.07] bg-white/[0.04] px-4 py-3">
              <div className="flex items-baseline justify-between">
                <button
                  type="button"
                  aria-label="Lihat progress level"
                  onClick={() => setLevelOpen(true)}
                  className="inline-flex items-center gap-2 text-[17px] font-extrabold text-[#F4C96B] active:opacity-70"
                >
                  <LevelIcon level={xp?.level ?? profile.level} size={28} />
                  Lv. {fmtNum(xp?.level ?? profile.level)}
                </button>
                <span className="text-[13px] font-semibold text-white/85">{fmtNum(profile.xp)} XP</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#F4C96B] to-accent transition-[width] duration-700"
                  style={{ width: `${(xp?.ratio ?? 0) * 100}%` }}
                />
              </div>
              {xp ? (
                <p className="mt-1.5 text-right text-[11px] text-muted">
                  {fmtNum(xp.current)} / {fmtNum(xp.required)} XP ke level berikutnya
                </p>
              ) : null}
            </div>

            {own ? (
              <div className="mt-4 flex w-full max-w-[420px] items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setDraft(profile.username ?? '')
                    setBannerDraft(profile.bannerURL ?? '')
                    setEditOpen(true)
                  }}
                  className="flex h-12 min-w-0 flex-1 items-center justify-center gap-2 rounded-full bg-accent text-[14px] font-bold text-ink active:scale-[0.98]"
                >
                  <Icon name="edit" size={17} /> Edit Profile
                </button>
                <button
                  type="button"
                  aria-label="Teman dan permintaan"
                  onClick={() => nav.push({ name: 'connections' })}
                  className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#2F8BFF] text-white shadow-[0_8px_24px_rgba(0,0,0,0.45)] active:scale-90"
                >
                  <Icon name="users" size={23} />
                  {incomingCount ? (
                    <span className="absolute -right-1 -top-1 flex h-[19px] min-w-[19px] items-center justify-center rounded-full border-2 border-ink bg-accent px-1 text-[10.5px] font-extrabold text-ink">
                      {incomingCount > 9 ? '9+' : incomingCount}
                    </span>
                  ) : null}
                </button>
              </div>
            ) : rel === 'friends' ? (
              <button
                type="button"
                onClick={() => nav.push({ name: 'dm', uid })}
                className="mt-4 flex h-12 w-full max-w-[420px] items-center justify-center gap-2 rounded-full bg-accent text-[14px] font-bold text-ink active:scale-[0.98]"
              >
                <Icon name="chat" size={18} /> Kirim Pesan
              </button>
            ) : null}
          </div>

          {/* ===== statistik ===== */}
          <div className="mx-4 mt-5 grid grid-cols-3 overflow-hidden rounded-3xl border border-white/[0.08] bg-gradient-to-b from-white/[0.08] to-white/[0.02]">
            <StatCell icon="eye" label="Watch Time" value={stats.watch} />
            <StatCell icon="clock" label="History" value={stats.history} divider />
            <StatCell icon="chat" label="Comments" value={stats.comments} divider />
          </div>

          {/* ===== tab ===== */}
          <div className="relative mx-4 mt-5 grid rounded-full bg-raise/80 p-1" style={{ gridTemplateColumns: `repeat(${TABS.length}, minmax(0, 1fr))` }}>
            <div
              className="absolute bottom-1 left-1 top-1 rounded-full bg-accent/20 ring-1 ring-accent/30 transition-transform duration-300 ease-out"
              style={{ width: `calc((100% - 8px) / ${TABS.length})`, transform: `translateX(${TABS.findIndex((t) => t.key === tab) * 100}%)` }}
            />
            {TABS.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setTab(t.key)}
                className={`relative z-10 py-2.5 text-[12.5px] font-bold transition-colors ${tab === t.key ? 'text-accent' : 'text-white/60'}`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div key={tab} className="mt-4 animate-fadeIn px-4">
            {tab === 'overview' ? (
              <Overview profile={profile} stats={stats} rank={monthlyRank} uidMode={staff ? 'full' : own ? 'short' : null} />
            ) : tab === 'history' ? (
              <HistoryTab state={history} onRetry={reload} />
            ) : tab === 'friends' ? (
              <FriendComments targetUid={uid} isOwn={own} canPost={canPostFriend} />
            ) : (
              <CommentsTab state={comments} profile={profile} history={history.status === 'ok' ? history.data : []} onRetry={reload} />
            )}
          </div>
        </div>
      )}

      {profile ? (
        <LevelProgressModal
          open={levelOpen}
          onClose={() => setLevelOpen(false)}
          level={xp?.level ?? profile.level}
          xp={profile.xp}
          watchMinutes={profile.totalWatchMinutes}
        />
      ) : null}

      {own && profile ? (
        <Sheet open={editOpen} onClose={() => setEditOpen(false)} title="Edit Profile">
          <label className="text-[12.5px] font-medium text-muted">Nama</label>
          <input
            value={draft}
            maxLength={24}
            placeholder={profile.displayName}
            onChange={(e) => setDraft(e.target.value)}
            className="mt-1.5 w-full rounded-2xl bg-raise px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-1 focus:ring-accent"
          />
          <p className="mt-2 text-[12px] leading-snug text-muted">Nama ini menggantikan nama akun Google di semua tempat (profil, chat, komentar). Kosongkan untuk memakai nama Google. Foto profil mengikuti akun Google.</p>
          <label className="mt-4 flex items-center gap-1.5 text-[12.5px] font-medium text-muted">
            Banner profil (URL GIF/gambar)
            {!canUseBanner(profile) ? <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-bold text-white/70">TERKUNCI</span> : null}
          </label>
          <input
            value={canUseBanner(profile) ? bannerDraft : ''}
            disabled={!canUseBanner(profile)}
            maxLength={1000}
            inputMode="url"
            autoCapitalize="none"
            autoCorrect="off"
            placeholder={canUseBanner(profile) ? 'https://contoh.com/banner.gif' : 'Khusus Premium / role khusus'}
            onChange={(e) => setBannerDraft(e.target.value)}
            className="mt-1.5 w-full rounded-2xl bg-raise px-4 py-3 text-[15px] text-white placeholder:text-muted/70 focus:outline-none focus:ring-1 focus:ring-accent disabled:cursor-not-allowed disabled:opacity-50"
          />
          <p className="mt-2 text-[12px] leading-snug text-muted">
            {canUseBanner(profile)
              ? 'Tempel link gambar/GIF (harus https://). Link Giphy/Imgur/GitHub otomatis dirapikan; link halaman Tenor/Pinterest/Instagram tidak bisa, pakai link file langsung (.gif/.png/.webp/.mp4). Hanya link yang disimpan. Kosongkan untuk menghapus banner.'
              : 'Pasang banner profil butuh Premium aktif atau role khusus. Role user biasa belum bisa mengisi kolom ini.'}
          </p>
          <button
            type="button"
            disabled={saving}
            onClick={() => {
              setSaving(true)
              updateProfileEdit(profile, draft, bannerDraft)
                .then(() => {
                  toast('Profil disimpan')
                  setEditOpen(false)
                })
                .catch((e: unknown) => toast(e instanceof Error && e.message.startsWith('URL banner') ? e.message : 'Gagal menyimpan profil'))
                .finally(() => setSaving(false))
            }}
            className="mt-4 w-full rounded-full bg-accent py-3 text-[14px] font-bold text-ink active:scale-[0.98] disabled:opacity-60"
          >
            Simpan
          </button>
        </Sheet>
      ) : null}
    </div>
  )
}

function StatCell({ icon, label, value, divider }: { icon: IconName; label: string; value: string; divider?: boolean }) {
  return (
    <div className={`flex flex-col items-center px-1 py-4 ${divider ? 'border-l border-white/[0.07]' : ''}`}>
      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-accent/15 text-accent">
        <Icon name={icon} size={16} />
      </span>
      <p className="mt-2 text-[10px] font-bold uppercase tracking-[0.14em] text-muted">{label}</p>
      <p className="mt-0.5 text-[20px] font-extrabold tracking-tight text-white">{value}</p>
    </div>
  )
}

// ---------- Overview ----------
function InfoRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 px-4 py-3.5">
      <span className="text-[13px] text-muted">{label}</span>
      <span className="min-w-0 truncate text-right text-[14px] font-semibold text-white">{children}</span>
    </div>
  )
}

function Overview({ profile, stats, rank, uidMode }: { profile: PublicProfile; rank: number | null; uidMode: 'full' | 'short' | null; stats: { watch: string; history: string; comments: string } }) {
  const joined = profile.createdAt
    ? new Date(profile.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
    : '–'
  return (
    <div className="divide-y divide-white/[0.06] overflow-hidden rounded-3xl border border-white/[0.07] bg-raise/60">
      <InfoRow label="Nama">{profile.username?.trim() || profile.displayName}</InfoRow>
      <InfoRow label="User ID">#{profile.userId}</InfoRow>
      {uidMode ? (
        <InfoRow label={uidMode === 'full' ? 'UID (developer)' : 'UID'}>
          <button
            type="button"
            aria-label="Salin UID"
            onClick={() => void copyText(profile.uid).then((ok) => toast(ok ? 'UID disalin' : 'Gagal menyalin UID'))}
            className="inline-flex max-w-full items-center gap-1.5 font-mono text-[12px] active:opacity-70"
          >
            <span className="truncate">{uidMode === 'full' ? profile.uid : profile.uid.slice(0, 8)}</span>
            <Icon name="copy" size={14} className="shrink-0 text-muted" />
          </button>
        </InfoRow>
      ) : null}
      <InfoRow label="Role">
        <span className="inline-flex items-center gap-1.5">
          <RolePill role={profile.role} />
          <TopLbBadge rank={rank} />
        </span>
      </InfoRow>
      <InfoRow label="Level">
        <span className="inline-flex items-center gap-1.5">
          <LevelIcon level={profile.level} size={20} />
          Lv. {fmtNum(profile.level)}
        </span>
      </InfoRow>
      <InfoRow label="XP">{fmtNum(profile.xp)} XP</InfoRow>
      <InfoRow label="Total waktu menonton">{stats.watch}</InfoRow>
      <InfoRow label="Jumlah history">{stats.history}</InfoRow>
      <InfoRow label="Jumlah comments">{stats.comments}</InfoRow>
      <InfoRow label="Bergabung">{joined}</InfoRow>
    </div>
  )
}

// ---------- History ----------
function HistoryTab({ state, onRetry }: { state: Load<HistoryEntry[]>; onRetry: () => void }) {
  const nav = useNav()
  const [limit, setLimit] = useState(15)
  if (state.status === 'loading')
    return (
      <div className="flex justify-center py-12">
        <Spinner />
      </div>
    )
  if (state.status === 'error')
    return <ErrorState compact message="History pengguna ini tidak bisa dimuat. Pastikan Security Rules terbaru sudah dipublikasikan." onRetry={onRetry} />
  if (!state.data.length) return <EmptyState icon="clock" title="Belum ada history" hint="Belum ada anime yang ditonton." />

  return (
    <>
      <ul className="space-y-3">
        {state.data.slice(0, limit).map((h) => {
          const pct = h.duration > 0 ? Math.min(100, Math.round((h.position / h.duration) * 100)) : 0
          return (
            <li key={h.animeId}>
              <button
                type="button"
                onClick={() => nav.openAnime({ id: h.animeId, title: h.title, poster: h.poster })}
                className="flex w-full gap-3 rounded-2xl border border-white/[0.06] bg-raise/70 p-2.5 text-left active:opacity-80"
              >
                <Poster src={h.poster} alt={h.title} className="h-[96px] w-[64px] shrink-0 rounded-xl" />
                <div className="flex min-w-0 flex-1 flex-col">
                  <p className="line-clamp-2 text-[14px] font-semibold leading-tight text-white">{h.title}</p>
                  <p className="mt-0.5 text-[12.5px] text-white/75">Episode {h.episodeNumber}</p>
                  <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-accent" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="mt-1.5 text-[11.5px] text-muted">
                    Progress {fmtTime(h.position)} / {fmtTime(h.duration)}
                  </p>
                  <p className="mt-auto pt-1.5 text-[11px] text-muted">Terakhir ditonton {timeAgo(h.updatedAt)}</p>
                </div>
              </button>
            </li>
          )
        })}
      </ul>
      {state.data.length > limit ? <MoreButton onClick={() => setLimit((n) => n + 15)} /> : null}
    </>
  )
}

function MoreButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="mx-auto mt-4 block rounded-full bg-raise px-5 py-2.5 text-[13px] font-semibold text-white/85 active:scale-95"
    >
      Muat lebih banyak
    </button>
  )
}

// ---------- Comments ----------
function CommentsTab({
  state,
  profile,
  history,
  onRetry,
}: {
  state: Load<UserComment[]>
  profile: PublicProfile
  history: HistoryEntry[]
  onRetry: () => void
}) {
  const nav = useNav()
  const [limit, setLimit] = useState(15)
  const [, bump] = useState(0)
  const list = state.status === 'ok' ? state.data : []
  const shown = list.slice(0, limit)
  const name = profile.username?.trim() || profile.displayName

  // judul & nomor episode: dari history bila ada, selebihnya dari API anime (hanya untuk item yang tampil)
  useEffect(() => {
    seedFromHistory(history)
    bump((n) => n + 1)
  }, [history])

  const ids = useMemo(() => [...new Set(shown.map((c) => c.animeId))].join('\u0001'), [shown])
  useEffect(() => {
    if (!ids) return
    let off = false
    const queue = ids.split('\u0001')
    const worker = async () => {
      for (let id = queue.shift(); id !== undefined && !off; id = queue.shift()) {
        await resolveAnime(id)
        if (!off) bump((n) => n + 1)
      }
    }
    void Promise.all([worker(), worker(), worker()])
    return () => {
      off = true
    }
  }, [ids])

  if (state.status === 'loading')
    return (
      <div className="flex justify-center py-12">
        <Spinner />
      </div>
    )
  if (state.status === 'error')
    return <ErrorState compact message={`Komentar tidak bisa dimuat: ${state.message}`} onRetry={onRetry} />
  if (!list.length) return <EmptyState icon="chat" title="Belum ada komentar" hint="Pengguna ini belum pernah berkomentar." />

  return (
    <>
      <ul className="space-y-3">
        {shown.map((c) => {
          const meta = cachedAnime(c.animeId)
          const epNo = cachedEpisode(c.animeId, c.episodeId)
          const isReply = c.kind === 'reply'
          return (
            <li
              key={c.key}
              className={`rounded-2xl border border-white/[0.06] bg-raise/70 p-3.5 ${isReply ? 'ml-4 border-l-2 border-l-accent/50' : ''}`}
            >
              <div className="flex items-center gap-2.5">
                <Avatar url={profile.photoURL} name={name} size={32} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13.5px] font-bold text-white">{name}</p>
                </div>
                <span className="shrink-0 text-[11px] text-muted">{timeAgo(c.ts)}</span>
              </div>

              {isReply ? (
                <div className="mt-2.5">
                  <p className="flex items-center gap-1.5 text-[12px] font-semibold text-accent">
                    <Icon name="reply" size={13} /> Membalas @{c.replyTo || c.parentName || 'pengguna'}
                  </p>
                  {c.parentText ? (
                    <p className="mt-1 line-clamp-2 rounded-lg bg-white/[0.04] px-2.5 py-1.5 text-[12px] leading-snug text-white/60">{c.parentText}</p>
                  ) : null}
                </div>
              ) : null}

              <p className="mt-2 whitespace-pre-wrap break-words text-[14px] leading-snug text-white">
                {c.text}
                {c.edited ? <span className="ml-1.5 text-[10.5px] text-muted">(diedit)</span> : null}
              </p>

              <button
                type="button"
                onClick={() => nav.openAnime({ id: c.animeId, title: meta?.title ?? 'Anime', poster: meta?.poster })}
                className="mt-3 flex w-full items-center gap-2.5 rounded-xl bg-white/[0.05] p-2 text-left active:opacity-75"
              >
                <Poster src={meta?.poster} alt="" className="h-[38px] w-[27px] shrink-0 rounded-md" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12.5px] font-semibold text-white/90">{meta ? meta.title : 'Memuat judul…'}</span>
                  <span className="block text-[11.5px] text-muted">{epNo !== undefined ? `Episode ${epNo}` : 'Episode'}</span>
                </span>
                <Icon name="chevron" size={15} className="text-muted" />
              </button>
            </li>
          )
        })}
      </ul>
      {list.length > limit ? <MoreButton onClick={() => setLimit((n) => n + 15)} /> : null}
    </>
  )
}

// ---------- header ringkas untuk tab Akun ----------
function AccountHeader({ onSettings }: { onSettings: () => void }) {
  const me = useProfile()
  const lvl = xpProgress(me.xp).level
  const ring = (ROLE_STYLE[me.role] ?? ROLE_STYLE.user).ring
  const hasBanner = canUseBanner(me) && !!me.bannerURL
  return (
    <header className="pt-safe relative overflow-hidden bg-gradient-to-b from-[#241830] via-[#14101f] to-ink">
      {hasBanner ? (
        <>
          <BannerImg url={me.bannerURL} />
          <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-black/35 to-ink" />
        </>
      ) : null}
      <div className="relative flex items-start gap-3.5 px-4 pb-5 pt-5">
        <div className={`shrink-0 rounded-full bg-gradient-to-br p-[2.5px] ${ring}`}>
          <div className="rounded-full bg-ink p-[2.5px]">
            <Avatar url={me.photoURL} name={me.username?.trim() || me.displayName} size={72} />
          </div>
        </div>
        <div className="min-w-0 flex-1 pt-0.5">
          <div className="flex min-w-0 items-center gap-1.5">
            <h1 className="min-w-0 truncate text-[20px] font-extrabold leading-tight tracking-tight text-white">{me.username?.trim() || me.displayName}</h1>
            <RoleCheck role={me.role} verified={me.verified} size={17} />
          </div>
          <p className="text-[12.5px] font-semibold text-muted">#{me.userId}</p>
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <LevelPill level={lvl} />
            <RolePill role={me.role} />
            <ClanPill tag={me.clanTag} />
          </div>
        </div>
        <button
          type="button"
          aria-label="Pengaturan"
          onClick={onSettings}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/10 text-white active:scale-90"
        >
          <Icon name="gear" size={22} />
        </button>
      </div>
    </header>
  )
}
