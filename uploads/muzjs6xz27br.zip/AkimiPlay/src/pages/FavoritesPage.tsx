import { useNav } from '../nav/router'
import { favoritesStore, removeFavorite, useStore } from '../storage/stores'
import { AnimeCard } from '../components/AnimeCard'
import { EmptyState } from '../components/States'
import { PageHeader } from '../components/PageHeader'
import { toast } from '../components/Feedback'

export function FavoritesPage() {
  const nav = useNav()
  const favs = useStore(favoritesStore)

  return (
    <div className="absolute inset-0 overflow-y-auto pb-36">
      <PageHeader
        title="Favorit"
        right={favs.length ? <span className="text-[13px] text-muted">{favs.length} anime</span> : undefined}
      />
      {favs.length === 0 ? (
        <EmptyState
          icon="heart"
          title="Belum ada favorit"
          hint="Ketuk tombol Favorit di halaman detail anime untuk menyimpannya di sini."
        />
      ) : (
        <div className="grid grid-cols-3 gap-x-3 gap-y-4 px-4">
          {favs.map((f) => (
            <AnimeCard
              key={f.id}
              anime={f}
              variant="grid"
              onOpen={nav.openAnime}
              onRemove={() => {
                removeFavorite(f.id)
                toast('Dihapus dari favorit')
              }}
            />
          ))}
        </div>
      )}
    </div>
  )
}
