import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App'
import { loadAllStores } from './storage/stores'
import { initNative } from './native/native'
import { initDownloads } from './services/downloadService'

async function boot() {
  await loadAllStores().catch(() => undefined)
  initNative()
  initDownloads()
  createRoot(document.getElementById('root')!).render(<App />)
}

void boot()
