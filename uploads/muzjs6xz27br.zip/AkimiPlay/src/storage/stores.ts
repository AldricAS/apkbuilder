// Penyimpanan lokal (Capacitor Preferences = SharedPreferences di Android).
// Data tetap ada setelah aplikasi ditutup. Di browser (mode dev) otomatis memakai localStorage.
import { Preferences } from '@capacitor/preferences'
import { useSyncExternalStore } from 'react'
import type {
  AnimeLite,
  DownloadAnime,
  DownloadEntry,
  Episode,
  FavEntry,
  HistoryEntry,
  Profile,
  ProgressEntry,
  Settings,
} from '../types'

type Listener = () => void

export function createStore<T>(key: string, initial: T) {
  let state = initial
  const listeners = new Set<Listener>()
  let timer: ReturnType<typeof setTimeout> | null = null
  let dirty = false

  const persist = async () => {
    timer = null
    if (!dirty) return
    dirty = false
    try {
      await Preferences.set({ key, value: JSON.stringify(state) })
    } catch {
      /* penyimpanan gagal: data tetap ada di memori */
    }
  }

  return {
    get: () => state,
    set(next: T | ((prev: T) => T)) {
      state = typeof next === 'function' ? (next as (p: T) => T)(state) : next
      dirty = true
      listeners.forEach((l) => l())
      if (!timer) timer = setTimeout(persist, 500)
    },
    subscribe(l: Listener) {
      listeners.add(l)
      return () => {
        listeners.delete(l)
      }
    },
    async load() {
      try {
        const { value } = await Preferences.get({ key })
        if (value) {
          const parsed = JSON.parse(value)
          const isPlainObject = typeof initial === 'object' && initial !== null && !Array.isArray(initial)
          state = isPlainObject ? ({ ...initial, ...parsed } as T) : (parsed as T)
        }
      } catch {
        /* data rusak diabaikan, pakai nilai awal */
      }
      listeners.forEach((l) => l())
    },
    async flush() {
      if (timer) clearTimeout(timer)
      await persist()
    },
  }
}

export function useStore<T>(store: { get: () => T; subscribe: (l: Listener) => () => void }): T {
  return useSyncExternalStore(store.subscribe, store.get)
}

export const DEFAULT_SETTINGS: Settings = {
  autoNext: true,
  resume: true,
  autoPip: true,
  defaultQuality: 0,
  seekStep: 10,
  introSkip: 90,
  notify: true,
}

export const favoritesStore = createStore<FavEntry[]>('akimi.favorites', [])
export const historyStore = createStore<HistoryEntry[]>('akimi.history', [])
export const progressStore = createStore<Record<string, ProgressEntry>>('akimi.progress', {})
export const settingsStore = createStore<Settings>('akimi.settings', DEFAULT_SETTINGS)
export const profileStore = createStore<Profile>('akimi.profile', { username: 'Akimi' })

/** Rentang detik yang sudah ditonton per episode (anti-abuse XP), disimpan lokal. */
export const coverageStore = createStore<Record<string, string>>('akimi.coverage', {})

/** Daftar episode yang sudah/sedang di-download (metadata; file videonya ada di folder privat aplikasi). */
export const downloadsStore = createStore<Record<string, DownloadEntry>>('akimi.downloads', {})
export const downloadAnimeStore = createStore<Record<string, DownloadAnime>>('akimi.downloadAnime', {})

const all = [
  favoritesStore,
  historyStore,
  progressStore,
  settingsStore,
  profileStore,
  coverageStore,
  downloadsStore,
  downloadAnimeStore,
]
export const loadAllStores = () => Promise.all(all.map((s) => s.load()))
export const flushAllStores = () => Promise.all(all.map((s) => s.flush()))

// ---------- Favorit ----------
export function toggleFavorite(a: AnimeLite): boolean {
  const exists = favoritesStore.get().some((f) => f.id === a.id)
  if (exists) {
    favoritesStore.set((l) => l.filter((f) => f.id !== a.id))
    return false
  }
  const entry: FavEntry = {
    id: a.id,
    title: a.title,
    poster: a.poster,
    type: a.type,
    status: a.status,
    score: a.score,
    latestEpisode: a.latestEpisode,
    genres: a.genres,
    addedAt: Date.now(),
  }
  favoritesStore.set((l) => [entry, ...l])
  return true
}

export function removeFavorite(id: string) {
  favoritesStore.set((l) => l.filter((f) => f.id !== id))
}

export function useIsFavorite(id: string): boolean {
  return useStore(favoritesStore).some((f) => f.id === id)
}

// ---------- Histori & progress ----------
const MAX_HISTORY = 200
const MAX_PROGRESS = 1500

export function recordProgress(args: {
  anime: AnimeLite
  episode: Pick<Episode, 'id' | 'number' | 'title'>
  position: number
  duration: number
  watched?: boolean
}) {
  const { anime, episode, position, duration, watched } = args
  if (!Number.isFinite(duration) || duration <= 0) return
  const now = Date.now()
  const done = !!watched || position / duration >= 0.92

  progressStore.set((p) => {
    const next = { ...p, [episode.id]: { a: anime.id, p: position, d: duration, u: now, w: done || p[episode.id]?.w } }
    const keys = Object.keys(next)
    if (keys.length > MAX_PROGRESS) {
      keys
        .sort((x, y) => next[x].u - next[y].u)
        .slice(0, keys.length - MAX_PROGRESS + 200)
        .forEach((k) => delete next[k])
    }
    return next
  })

  const entry: HistoryEntry = {
    animeId: anime.id,
    title: anime.title,
    poster: anime.poster,
    banner: anime.banner,
    episodeId: episode.id,
    episodeNumber: episode.number,
    episodeTitle: episode.title,
    position,
    duration,
    updatedAt: now,
  }
  historyStore.set((h) => [entry, ...h.filter((x) => x.animeId !== anime.id)].slice(0, MAX_HISTORY))
}

export function removeHistory(animeId: string) {
  historyStore.set((h) => h.filter((x) => x.animeId !== animeId))
  progressStore.set((p) => Object.fromEntries(Object.entries(p).filter(([, v]) => v.a !== animeId)))
}

export function clearHistory() {
  historyStore.set([])
  progressStore.set({})
}

export function isWatched(p?: ProgressEntry): boolean {
  return !!p && (!!p.w || (p.d > 0 && p.p / p.d >= 0.9))
}

/** Episode yang harus diputar saat menekan "Mulai Nonton" / "Lanjutkan". */
export function pickResumeEpisode(episodes: Episode[], animeId: string): string | undefined {
  if (!episodes.length) return undefined
  const h = historyStore.get().find((x) => x.animeId === animeId)
  if (!h) return episodes[0].id
  const idx = episodes.findIndex((e) => e.id === h.episodeId)
  if (idx < 0) return episodes[0].id
  const finished = h.duration > 0 && h.position / h.duration >= 0.95
  return finished && idx < episodes.length - 1 ? episodes[idx + 1].id : episodes[idx].id
}

export function computeStats() {
  const progress = Object.values(progressStore.get())
  return {
    favorites: favoritesStore.get().length,
    anime: historyStore.get().length,
    episodes: progress.filter(isWatched).length,
  }
}
