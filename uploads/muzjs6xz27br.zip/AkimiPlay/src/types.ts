export type AnimeStatus = 'ONGOING' | 'FINISHED' | 'WAITING'

export type Anime = {
  id: string
  title: string
  japaneseTitle?: string
  poster?: string
  banner?: string
  synopsis?: string
  type?: string
  status?: AnimeStatus
  score?: number
  year?: number
  genres?: string[]
  genreIds?: string[]
  studios?: string[]
  totalEpisodes?: number
  latestEpisode?: string
  airTime?: string
  views?: number
}

/** Data minimal anime yang dibawa antar halaman. */
export type AnimeLite = Pick<Anime, 'id' | 'title' | 'poster'> & Partial<Anime>

export type Genre = { id: string; name: string }

export type Episode = {
  id: string
  number: number
  title?: string
  date?: string
}

export type StreamSource = {
  url: string
  /** Label yang ditampilkan, contoh "720p". */
  quality: string
  /** Tinggi video (0 jika tidak diketahui). */
  height: number
}

export type EpisodeStream = { sources: StreamSource[] }

export type HomeData = {
  slider: Anime[]
  hot: Anime[]
  new: Anime[]
  today: Anime[]
  popular: Anime[]
  random: Anime[]
  waiting: Anime[]
}

export type Paged<T> = { items: T[]; hasMore: boolean }

export type SearchParams = {
  q?: string
  page?: number
  sort?: 'views' | 'latest' | 'favorites'
  genreIds?: string[]
  status?: AnimeStatus
  type?: string
}

export type DetailData = { anime: Anime; recommendations: Anime[] }

// ---- data lokal ----
export type FavEntry = AnimeLite & { addedAt: number }

export type HistoryEntry = {
  animeId: string
  title: string
  poster?: string
  banner?: string
  episodeId: string
  episodeNumber: number
  episodeTitle?: string
  position: number
  duration: number
  updatedAt: number
}

export type ProgressEntry = {
  a: string // animeId
  p: number // posisi (detik)
  d: number // durasi (detik)
  u: number // waktu update
  w?: boolean // sudah ditonton
}

export type Settings = {
  autoNext: boolean
  resume: boolean
  autoPip: boolean
  /** 0 = otomatis */
  defaultQuality: number
  seekStep: number
  /** Detik yang dilewati tombol Skip Intro (80, 85, 90, atau 95). */
  introSkip: number
  /** Notifikasi APK (pesan developer & episode baru). undefined dianggap aktif. */
  notify?: boolean
}

export type Profile = { username: string }

// ---- download offline ----
export type DownloadStatus = 'queued' | 'downloading' | 'done' | 'error'

/** Satu episode yang di-download. Video disimpan di folder privat aplikasi (bukan galeri). */
export type DownloadEntry = {
  /** episodeId */
  id: string
  animeId: string
  episodeNumber: number
  episodeTitle?: string
  fileName: string
  /** path absolut file di penyimpanan aplikasi (terisi saat selesai) */
  path?: string
  size: number
  quality: string
  status: DownloadStatus
  error?: string
  createdAt: number
}

/** Info anime untuk daftar offline (poster disalin lokal agar tampil tanpa internet). */
export type DownloadAnime = {
  id: string
  title: string
  poster?: string
  /** path absolut poster lokal */
  posterPath?: string
  totalEpisodes?: number
  addedAt: number
}
