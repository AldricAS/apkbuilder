import { useCallback, useEffect, useRef, useState } from 'react'

export function useDebounce<T>(value: T, ms: number): T {
  const [v, setV] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms)
    return () => clearTimeout(t)
  }, [value, ms])
  return v
}

export function useOnline(): boolean {
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine)
  useEffect(() => {
    const on = () => setOnline(true)
    const off = () => setOnline(false)
    window.addEventListener('online', on)
    window.addEventListener('offline', off)
    return () => {
      window.removeEventListener('online', on)
      window.removeEventListener('offline', off)
    }
  }, [])
  return online
}

export type AsyncState<T> = {
  data?: T
  error?: Error
  loading: boolean
  reload: () => void
}

/** Menjalankan fungsi async; kembalikan null dari fn untuk melewati (tidak loading). */
export function useAsync<T>(fn: () => Promise<T> | null, deps: unknown[]): AsyncState<T> {
  const [state, setState] = useState<{ data?: T; error?: Error; loading: boolean }>({ loading: true })
  const [tick, setTick] = useState(0)
  const fnRef = useRef(fn)
  fnRef.current = fn

  useEffect(() => {
    let alive = true
    const p = fnRef.current()
    if (!p) {
      setState({ loading: false })
      return
    }
    setState({ loading: true })
    p.then((data) => alive && setState({ data, loading: false })).catch(
      (error) => alive && setState({ error: error instanceof Error ? error : new Error(String(error)), loading: false }),
    )
    return () => {
      alive = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick])

  const reload = useCallback(() => setTick((t) => t + 1), [])
  return { ...state, reload }
}
