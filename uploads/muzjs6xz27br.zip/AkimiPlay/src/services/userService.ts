import { mediaUrlProblem, normalizeMediaUrl } from '../lib/media'
import type { User } from 'firebase/auth'
import { get, onValue, ref, runTransaction, serverTimestamp, set, update } from 'firebase/database'
import { db } from '../firebase/config'

/**
 * Role yang TERSIMPAN di database tidak pernah 'premium'. Nilai 'premium' hanya muncul sebagai role TAMPILAN di klien
 * (lihat normalizeProfile): akun ber-role user biasa yang masih punya Premium aktif.
 */
export type Role = 'user' | 'premium' | 'beta' | 'moderator' | 'admin' | 'developer' | 'special' | 'raja_iblis' | 'maou'

export type UserProfile = {
  uid: string
  userId: number
  email: string
  displayName: string
  username?: string
  photoURL?: string
  role: Role
  /** Premium berlaku sampai waktu ini (ms). Hanya developer yang bisa mengisinya. */
  premiumUntil?: number
  /** Hanya di sisi klien: role asli di database bila berbeda dari role tampilan (user biasa yang sedang Premium). */
  roleRaw?: Role
  verified?: boolean
  clanTag?: string
  /** Banner profil (URL gambar/GIF, hanya URL yang disimpan). Hanya bisa dipasang Premium aktif atau role selain user. */
  bannerURL?: string
  level: number
  xp: number
  totalWatchMinutes: number
  /** AkimiShard. Hanya bisa ditambah/diubah dari Firebase Console (aplikasi tidak bisa menulisnya). */
  shard?: number
  createdAt: number
  xpAt: number
  updatedAt?: number
  lastLoginAt?: number
}

/** Premium aktif = punya premiumUntil yang belum lewat. */
export const isPremiumActive = (p: { premiumUntil?: number } | null | undefined, now = Date.now()): boolean =>
  typeof p?.premiumUntil === 'number' && p.premiumUntil > now

/**
 * Premium BUKAN role: hanya masa berlaku (premiumUntil) di samping role. Role apa pun (moderator, admin, developer, dst.)
 * tidak pernah tertimpa; badge, centang, dan warna nama Premium hanya tampil bila role di database adalah "user" biasa.
 * Hasilnya dipakai di seluruh aplikasi (profil sendiri, profil live, daftar teman) supaya tampilan seragam dan Premium
 * yang habis otomatis hilang. `roleRaw` menyimpan role asli di database (dipakai saat menulis pesan: rules mencocokkannya).
 */
export function normalizeProfile<T extends { role: Role; premiumUntil?: number; roleRaw?: Role }>(p: T): T {
  const active = isPremiumActive(p)
  // sisa data lama: role "premium" sempat tersimpan di database. Dirapikan developer lewat tab Role; sementara itu ikut aturan yang sama.
  if (p.role === 'premium') return { ...p, role: active ? 'premium' : 'user', roleRaw: 'premium' }
  if (p.role === 'user' && active) return { ...p, role: 'premium', roleRaw: 'user' }
  return p
}

/** Banner profil hanya untuk Premium aktif atau role selain "user" (role tampilan 'premium' sudah mencakup Premium aktif). */
export const canUseBanner = (p: { role: Role } | null | undefined): boolean => !!p && p.role !== 'user'

export const BANNER_URL_MAX = 1000

/** Rapikan & validasi URL banner. Kosong = hapus banner (null). Hanya https. */
export function parseBannerUrl(raw: string): string | null {
  const v = normalizeMediaUrl(raw)
  if (!v) return null
  if (v.length > BANNER_URL_MAX) throw new Error('URL banner terlalu panjang')
  if (!/^https:\/\/[^\s]+$/i.test(v)) throw new Error('URL banner harus diawali https:// (contoh: https://.../banner.gif)')
  const bad = mediaUrlProblem(v)
  if (bad) throw new Error('URL banner: ' + bad)
  return v
}

const clean = <T extends object>(o: T): T => JSON.parse(JSON.stringify(o))

function isPermissionDenied(e: unknown): boolean {
  const m = e instanceof Error ? e.message.toLowerCase() : ''
  return m.includes('permission_denied') || m.includes('permission denied')
}

/**
 * Mengalokasikan ID numerik unik TANPA Cloud Functions.
 *
 * 1. Transaction atomik pada /meta/userIdCounter mengubah { value: n, lastUid: uid } menjadi { value: n+1, lastUid: uid }.
 *    Jika dua user login bersamaan, Firebase menjalankan ulang transaction sehingga mereka mendapat angka berbeda.
 * 2. Profile hanya boleh dibuat jika userId == counter saat ini DAN lastUid == uid sendiri (dicek oleh Security Rules).
 *    Jika user lain sempat menaikkan counter di antara langkah 1 dan 2, penulisan ditolak dan alokasi diulang
 *    (angka itu hangus, tidak pernah diberikan dua kali).
 */
async function createProfile(user: User): Promise<void> {
  const uref = ref(db, `users/${user.uid}`)
  let lastError: unknown
  for (let attempt = 0; attempt < 6; attempt++) {
    const tx = await runTransaction(ref(db, 'meta/userIdCounter'), (cur) => ({
      value: (cur && typeof cur.value === 'number' ? cur.value : 0) + 1,
      lastUid: user.uid,
    }))
    if (!tx.committed) continue
    const value = (tx.snapshot.val() as { value: number }).value
    const profile = clean({
      uid: user.uid,
      userId: value,
      email: user.email ?? '',
      displayName: (user.displayName || 'Pengguna').slice(0, 40),
      photoURL: user.photoURL && user.photoURL.length <= 600 ? user.photoURL : undefined,
      role: 'user',
      verified: false,
      level: 1,
      xp: 0,
      totalWatchMinutes: 0,
    })
    try {
      await set(uref, {
        ...profile,
        createdAt: serverTimestamp(),
        xpAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        lastLoginAt: serverTimestamp(),
      })
      return
    } catch (e) {
      lastError = e
      if (!isPermissionDenied(e)) throw e
      // kemungkinan besar counter sudah dinaikkan user lain: alokasi ulang
    }
  }
  throw lastError ?? new Error('Gagal membuat profile.')
}

/** Membuat profile jika belum ada; jika sudah ada, userId lama dipakai dan data login disinkronkan. */
export async function ensureProfile(user: User): Promise<void> {
  const uref = ref(db, `users/${user.uid}`)
  const snap = await get(uref)
  if (!snap.exists()) {
    await createProfile(user)
    return
  }
  const cur = snap.val() as UserProfile
  const patch: Record<string, unknown> = { lastLoginAt: serverTimestamp() }
  const name = (user.displayName || '').slice(0, 40)
  if (name && name !== cur.displayName) patch.displayName = name
  if (user.photoURL && user.photoURL.length <= 600 && user.photoURL !== cur.photoURL) patch.photoURL = user.photoURL
  if (user.email && user.email !== cur.email) patch.email = user.email
  await update(uref, patch).catch(() => undefined)
}

export function subscribeProfile(uid: string, cb: (p: UserProfile | null) => void, onError?: (e: Error) => void) {
  return onValue(
    ref(db, `users/${uid}`),
    (s) => cb(s.exists() ? normalizeProfile(s.val() as UserProfile) : null),
    (e) => onError?.(e),
  )
}

export async function updateUsername(uid: string, username: string): Promise<void> {
  const clean = username.trim().replace(/[^\p{L}\p{N}_. -]/gu, '').slice(0, 24)
  await update(ref(db, `users/${uid}`), { username: clean, updatedAt: serverTimestamp() })
}

/** Simpan nama + banner profil. Banner hanya berupa URL (tidak ada file yang diunggah, jadi database tidak membengkak). */
export async function updateProfileEdit(profile: Pick<UserProfile, 'uid' | 'role'>, username: string, bannerRaw: string): Promise<void> {
  const name = username.trim().replace(/[^\p{L}\p{N}_. -]/gu, '').slice(0, 24)
  const patch: Record<string, unknown> = { username: name, updatedAt: serverTimestamp() }
  if (canUseBanner(profile)) patch.bannerURL = parseBannerUrl(bannerRaw)
  await update(ref(db, `users/${profile.uid}`), patch)
}
