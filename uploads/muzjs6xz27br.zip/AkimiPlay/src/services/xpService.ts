import { get, ref, serverTimestamp, update } from 'firebase/database'
import { db, encodeKey } from '../firebase/config'
import { levelFromXp, XP_PER_SECOND } from '../lib/xp'
import { addRange, mergeRanges, parseRanges, serializeRanges, type Range } from '../lib/ranges'
import { coverageStore } from '../storage/stores'
import type { UserProfile } from './userService'
import { recordBoardXp } from './leaderboardService'
import { withTimeout } from './serverTime'

/**
 * Menghitung XP dari waktu menonton yang BENAR-BENAR berjalan.
 *
 * - Hanya kemajuan putar alami yang dihitung (lompatan seek diabaikan).
 * - Kemajuan dibatasi oleh waktu nyata (speed 2x tidak melipatgandakan XP).
 * - Detik yang sudah pernah ditonton (rentang tersimpan lokal + cloud) tidak diberi XP lagi,
 *   jadi mundur lalu menonton ulang tidak memberi XP berulang.
 * - XP dikirim ke database tiap ~30 detik. Security Rules membatasi kenaikan XP maksimal
 *   240 XP per menit waktu server, sehingga client tidak bisa menulis XP sembarangan.
 */
export class WatchXpTracker {
  private cov: Range[] = []
  private epKey: string | null = null
  private ready = false
  private last: { cur: number; wall: number } | null = null
  private pending = 0 // detik baru yang belum dikirim
  private busy = false

  constructor(
    private uid: string,
    private getProfile: () => UserProfile | null,
  ) {}

  async start(episodeId: string) {
    await this.flush()
    const key = encodeKey(episodeId)
    this.epKey = key
    this.ready = false
    this.last = null
    this.cov = parseRanges(coverageStore.get()[key])
    const mine = key
    try {
      const snap = await withTimeout(get(ref(db, `watch/${this.uid}/${key}`)), 8000, 'timeout')
      if (this.epKey !== mine) return
      this.cov = mergeRanges([...this.cov, ...parseRanges(snap.val() as string | null)])
    } catch {
      /* offline: pakai data lokal saja */
    }
    if (this.epKey === mine) this.ready = true
  }

  reset() {
    this.last = null
  }

  tick(cur: number, playing: boolean, rate: number) {
    if (!this.ready || !playing || !Number.isFinite(cur)) {
      this.last = null
      return
    }
    const now = performance.now()
    if (this.last) {
      const wall = (now - this.last.wall) / 1000
      const delta = cur - this.last.cur
      const natural = delta > 0 && wall > 0 && delta <= wall * Math.max(rate, 1) * 1.6 + 0.6
      if (natural) {
        const step = Math.min(delta, wall) // batasi dengan waktu nyata
        const r = addRange(this.cov, this.last.cur, this.last.cur + step)
        this.cov = r.ranges
        this.pending += r.added
      }
    }
    this.last = { cur, wall: now }
  }

  private saveLocal() {
    if (!this.epKey) return
    const key = this.epKey
    const value = serializeRanges(this.cov)
    coverageStore.set((c) => {
      const next = { ...c, [key]: value }
      const keys = Object.keys(next)
      if (keys.length > 300) for (const k of keys.slice(0, keys.length - 300)) delete next[k]
      return next
    })
  }

  async flush() {
    this.saveLocal()
    const secs = Math.floor(this.pending)
    if (secs < 1 || this.busy) return
    const p = this.getProfile()
    if (!p) return
    this.busy = true
    try {
      const xp = p.xp + Math.round(secs * XP_PER_SECOND)
      const updates: Record<string, unknown> = {
        [`users/${this.uid}/xp`]: xp,
        [`users/${this.uid}/level`]: levelFromXp(xp),
        [`users/${this.uid}/totalWatchMinutes`]: Math.round((p.totalWatchMinutes + secs / 60) * 10000) / 10000,
        [`users/${this.uid}/xpAt`]: serverTimestamp(),
        [`users/${this.uid}/updatedAt`]: serverTimestamp(),
      }
      if (this.epKey) updates[`watch/${this.uid}/${this.epKey}`] = serializeRanges(this.cov)
      await update(ref(db), updates)
      this.pending -= secs
      void recordBoardXp(this.uid, Math.round(secs * XP_PER_SECOND)) // leaderboard: terpisah & best-effort
    } catch {
      this.pending = Math.min(this.pending, 600) // tolak/ offline: coba lagi di flush berikutnya
    } finally {
      this.busy = false
    }
  }
}
