// Identitas (nama, foto, role, level, verified, clan) di pesan chat & komentar disalin saat pesan dikirim,
// sehingga jadi "foto lama". Modul ini membaca users/{uid} secara realtime (data yang SUDAH ADA) lalu
// menimpa tampilan identitas, tanpa mengubah isi pesan/komentar di database.
import { useEffect, useMemo, useState } from 'react'
import { onValue, ref } from 'firebase/database'
import { db } from '../firebase/config'
import { normalizeProfile, type Role, type UserProfile } from './userService'

type Entry = {
  profile: UserProfile | null | undefined
  subs: Set<() => void>
  off?: () => void
  timer?: ReturnType<typeof setTimeout>
}

const entries = new Map<string, Entry>()

function watch(uid: string, cb: () => void): () => void {
  let e = entries.get(uid)
  if (!e) {
    e = { profile: undefined, subs: new Set() }
    entries.set(uid, e)
    const entry = e
    entry.off = onValue(
      ref(db, `users/${uid}`),
      (s) => {
        entry.profile = s.exists() ? normalizeProfile(s.val() as UserProfile) : null
        entry.subs.forEach((f) => f())
      },
      () => {
        entry.profile = null
      },
    )
  }
  clearTimeout(e.timer)
  e.subs.add(cb)
  const entry = e
  return () => {
    entry.subs.delete(cb)
    if (entry.subs.size === 0) {
      // beri jeda agar scroll/render ulang tidak berulang kali berlangganan dari nol
      entry.timer = setTimeout(() => {
        if (entry.subs.size === 0) {
          entry.off?.()
          entries.delete(uid)
        }
      }, 15_000)
    }
  }
}

type Identityish = {
  uid: string
  name: string
  photoURL?: string
  role: Role
  verified?: boolean
  level: number
  clanTag?: string
}

/** Menimpa field identitas dengan data profile terbaru (jika sudah termuat). */
export function liveOf<T extends Identityish>(x: T, p?: UserProfile | null): T {
  if (!p) return x
  return {
    ...x,
    name: p.username?.trim() || p.displayName || x.name,
    photoURL: p.photoURL ?? x.photoURL,
    role: p.role ?? x.role,
    verified: !!p.verified,
    level: p.level ?? x.level,
    clanTag: p.clanTag,
  }
}

/** Berlangganan profile beberapa user sekaligus; mengembalikan map uid -> profile terbaru. */
export function useLiveUsers(uids: string[]): Map<string, UserProfile | null | undefined> {
  const key = useMemo(() => [...new Set(uids)].sort().join('\u0001'), [uids])
  const [, bump] = useState(0)
  useEffect(() => {
    if (!key) return
    const offs = key.split('\u0001').map((uid) => watch(uid, () => bump((n) => n + 1)))
    return () => offs.forEach((o) => o())
  }, [key])
  const map = new Map<string, UserProfile | null | undefined>()
  if (key) for (const uid of key.split('\u0001')) map.set(uid, entries.get(uid)?.profile)
  return map
}
