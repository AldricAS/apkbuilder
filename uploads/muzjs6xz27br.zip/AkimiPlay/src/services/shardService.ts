// AkimiShard: hanya developer yang boleh mengubahnya. Penjagaan sebenarnya ada di database.rules.json
// (users/$uid/shard); pengecekan di sini hanya agar pesan error lebih jelas.
import { get, ref, runTransaction, set } from 'firebase/database'
import { db } from '../firebase/config'
import { isDeveloper } from './broadcastService'
import type { UserProfile } from './userService'

export const SHARD_MAX = 1_000_000_000

export type ShardTarget = { uid: string; name: string; userId: unknown; shard: number }

function assertDev(me: UserProfile) {
  if (!isDeveloper(me)) throw new Error('Hanya developer yang boleh mengubah AkimiShard.')
}

/** Cari user berdasarkan UID Firebase (salin dari halaman Akun). */
export async function findShardTarget(me: UserProfile, uid: string): Promise<ShardTarget> {
  assertDev(me)
  const id = uid.trim()
  if (!id || /[.#$\[\]/]/.test(id)) throw new Error('UID tidak valid.')
  const snap = await get(ref(db, `users/${id}`))
  if (!snap.exists()) throw new Error('User dengan UID itu tidak ditemukan.')
  const u = snap.val() as Partial<UserProfile>
  return { uid: id, name: u.username?.trim() || u.displayName || id, userId: u.userId, shard: typeof u.shard === 'number' ? u.shard : 0 }
}

/** Tambah (atau kurangi bila negatif) shard secara atomik. Hasil dibatasi 0..SHARD_MAX. */
export async function addShard(me: UserProfile, uid: string, delta: number): Promise<number> {
  assertDev(me)
  if (!Number.isInteger(delta) || delta === 0) throw new Error('Jumlah harus bilangan bulat.')
  const res = await runTransaction(ref(db, `users/${uid}/shard`), (cur: unknown) => {
    const next = (typeof cur === 'number' ? cur : 0) + delta
    return next < 0 || next > SHARD_MAX ? undefined : next
  })
  if (!res.committed) throw new Error(`Hasil harus di antara 0 dan ${SHARD_MAX.toLocaleString('id-ID')}.`)
  return res.snapshot.val() as number
}

/** Atur shard ke angka tertentu. */
export async function setShard(me: UserProfile, uid: string, value: number): Promise<void> {
  assertDev(me)
  if (!Number.isInteger(value) || value < 0 || value > SHARD_MAX) throw new Error(`Angka harus bulat antara 0 dan ${SHARD_MAX.toLocaleString('id-ID')}.`)
  await set(ref(db, `users/${uid}/shard`), value)
}
