// Semua request ke AnimeInWeb API ada di file ini (UI tidak boleh memanggil fetch sendiri).
// Dokumentasi endpoint: https://animeinweb-api.vercel.app
//   GET /api/homepage
//   GET /api/search?q&page&sort&genre_in&status&type
//   GET /api/anime/<anime_id>
//   GET /api/anime/<anime_id>/episodes
//   GET /api/episode/<episode_id>/stream
//   GET /api/schedule?day
//   GET /api/genres
import { Capacitor, CapacitorHttp } from '@capacitor/core'
import type {
  Anime,
  AnimeStatus,
  DetailData,
  Episode,
  EpisodeStream,
  Genre,
  HomeData,
  Paged,
  SearchParams,
} from '../types'
import { isObj, pick, toAnime, toAnimeList, toEpisodes, toGenres, toHome, toStream, unwrap } from './adapters'

export const API_BASE = 'https://animeinweb-api.vercel.app/api'

export class ApiError extends Error {
  status?: number
  constructor(message: string, status?: number) {
    super(message)
    this.name = 'ApiError'
    this.status = status
  }
}

type Params = Record<string, string | number | undefined | null>

const cache = new Map<string, { t: number; v: unknown }>()
const inflight = new Map<string, Promise<unknown>>()

export function clearApiCache() {
  cache.clear()
  inflight.clear()
}

function buildUrl(path: string, params?: Params): string {
  const qs = new URLSearchParams()
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') qs.set(k, String(v))
    }
  }
  const q = qs.toString()
  return `${API_BASE}${path}${q ? `?${q}` : ''}`
}

function toApiError(e: unknown): ApiError {
  if (e instanceof ApiError) return e
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return new ApiError('Tidak ada koneksi internet')
  const msg = e instanceof Error ? `${e.name} ${e.message}`.toLowerCase() : ''
  if (msg.includes('abort') || msg.includes('timeout')) return new ApiError('Server terlalu lama merespons')
  return new ApiError('Gagal terhubung ke server')
}

function statusError(status: number): ApiError {
  return new ApiError(status === 404 ? 'Data tidak ditemukan' : `Server bermasalah (kode ${status})`, status)
}

// Di Android, request memakai HTTP native (bebas CORS). Di browser (mode dev) memakai fetch biasa.
async function request(url: string): Promise<unknown> {
  if (Capacitor.isNativePlatform()) {
    try {
      const r = await CapacitorHttp.get({
        url,
        headers: { Accept: 'application/json' },
        connectTimeout: 15000,
        readTimeout: 20000,
      })
      if (r.status < 200 || r.status >= 300) throw statusError(r.status)
      if (typeof r.data === 'string') {
        try {
          return JSON.parse(r.data)
        } catch {
          throw new ApiError('Respons server tidak valid')
        }
      }
      return r.data
    } catch (e) {
      throw toApiError(e)
    }
  }
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), 20000)
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { Accept: 'application/json' } })
    if (!res.ok) throw statusError(res.status)
    try {
      return await res.json()
    } catch {
      throw new ApiError('Respons server tidak valid')
    }
  } catch (e) {
    throw toApiError(e)
  } finally {
    clearTimeout(timer)
  }
}

async function get(path: string, params?: Params, ttl = 5 * 60_000): Promise<unknown> {
  const url = buildUrl(path, params)
  if (ttl > 0) {
    const hit = cache.get(url)
    if (hit && Date.now() - hit.t < ttl) return hit.v
  }
  const pending = inflight.get(url)
  if (pending) return pending
  const p = request(url)
    .then((v) => {
      if (ttl > 0) cache.set(url, { t: Date.now(), v })
      return v
    })
    .finally(() => inflight.delete(url))
  inflight.set(url, p)
  return p
}

const DAYS = ['SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUMAT', 'SABTU', 'MINGGU'] as const
export const DAY_LABELS: Record<(typeof DAYS)[number], string> = {
  SENIN: 'Senin', SELASA: 'Selasa', RABU: 'Rabu', KAMIS: 'Kamis', JUMAT: 'Jumat', SABTU: 'Sabtu', MINGGU: 'Minggu',
}
export type Day = (typeof DAYS)[number]
export const DAY_LIST: Day[] = [...DAYS]
export function todayKey(): Day {
  const d = new Date().getDay() // 0 = Minggu
  return DAYS[(d + 6) % 7]
}

async function search(p: SearchParams = {}): Promise<Paged<Anime>> {
  const data = await get('/search', {
    q: p.q?.trim(),
    page: p.page ?? 0,
    sort: p.sort,
    genre_in: p.genreIds?.length ? p.genreIds.join(',') : undefined,
    status: p.status,
    type: p.type,
  })
  // Jumlah halaman tidak diberikan API, jadi hasMore dianggap true; UI berhenti setelah beberapa halaman kosong.
  return { items: toAnimeList(unwrap(data)), hasMore: true }
}

async function schedule(day: Day): Promise<Anime[]> {
  return toAnimeList(unwrap(await get('/schedule', { day })))
}

export const animeApi = {
  async home(): Promise<HomeData> {
    return toHome(await get('/homepage'))
  },

  search,

  /** Anime yang baru diperbarui (dipakai untuk "Episode Terbaru"). */
  async latest(): Promise<Anime[]> {
    return (await search({ sort: 'latest', page: 0 })).items
  },

  /** Kumpulkan `count` anime dengan tipe tertentu (filter tipe dilakukan server per halaman, jadi bisa jarang). */
  async byType(type: string, count: number): Promise<Anime[]> {
    const out: Anime[] = []
    const seen = new Set<string>()
    let empties = 0
    for (let page = 0; page < 8 && out.length < count && empties < 3; page++) {
      const r = await search({ type, page, sort: 'latest' })
      let added = 0
      for (const a of r.items) {
        if (!seen.has(a.id)) {
          seen.add(a.id)
          out.push(a)
          added++
        }
      }
      empties = added ? 0 : empties + 1
    }
    return out.slice(0, count)
  },

  /** Anime yang paling banyak difavoritkan. */
  async topFavorites(): Promise<Anime[]> {
    return (await search({ sort: 'favorites', page: 0 })).items
  },

  /** Sekitar 2 halaman anime ongoing untuk baris di Home. */
  async ongoingPreview(): Promise<Anime[]> {
    const [a, b] = await Promise.allSettled([animeApi.ongoing(0), animeApi.ongoing(1)])
    const seen = new Set<string>()
    const out: Anime[] = []
    for (const r of [a, b]) {
      if (r.status !== 'fulfilled') continue
      for (const x of r.value.items) if (!seen.has(x.id)) (seen.add(x.id), out.push(x))
    }
    return out
  },

  async genres(): Promise<Genre[]> {
    return toGenres(await get('/genres', undefined, 60 * 60_000))
  },

  async detail(id: string): Promise<DetailData> {
    const root = unwrap(await get(`/anime/${encodeURIComponent(id)}`))
    const inner = isObj(root) ? pick(root, ['anime', 'detail', 'details', 'info']) ?? root : root
    const anime = toAnime(inner) ?? toAnime({ ...(isObj(root) ? root : {}), id, title: 'Tanpa judul' })
    if (!anime) throw new ApiError('Data anime tidak lengkap')
    if (!anime.totalEpisodes && isObj(inner) && Array.isArray(inner.episodes)) {
      anime.totalEpisodes = inner.episodes.length
    }
    const recRaw = isObj(root) ? pick(root, ['recommendations', 'recommendation', 'related', 'similar']) : undefined
    return { anime, recommendations: recRaw ? toAnimeList(recRaw).filter((a) => a.id !== id) : [] }
  },

  /**
   * Daftar episode lengkap. Jika API membatasi jumlah per respons, halaman berikutnya
   * (?page=1,2,...) dimuat sampai tidak ada episode baru lagi.
   */
  async episodes(animeId: string): Promise<Episode[]> {
    const path = `/anime/${encodeURIComponent(animeId)}/episodes`
    let first = toEpisodes(await get(path))
    if (!first.length) {
      // Jangan simpan hasil kosong di cache; coba sekali lagi, lalu cari di data detail anime.
      cache.delete(buildUrl(path))
      try {
        first = toEpisodes(await get(path, undefined, 0))
      } catch {
        /* lanjut ke fallback */
      }
    }
    if (!first.length) {
      try {
        first = toEpisodes(await get(`/anime/${encodeURIComponent(animeId)}`))
      } catch {
        /* biarkan kosong */
      }
    }
    const all = new Map(first.map((e) => [e.id, e]))
    if (first.length >= 10) {
      // batch 4 halaman paralel; cukup toleran untuk indeks halaman 0 maupun 1
      for (let start = 1; start <= 120; start += 4) {
        const res = await Promise.allSettled([0, 1, 2, 3].map((i) => get(path, { page: start + i })))
        let added = 0
        for (const r of res) {
          if (r.status !== 'fulfilled') continue
          for (const e of toEpisodes(r.value)) {
            if (!all.has(e.id)) {
              all.set(e.id, e)
              added++
            }
          }
        }
        if (added === 0) break
      }
    }
    return [...all.values()].sort((a, b) => a.number - b.number)
  },

  /** Sumber video sebuah episode. Tidak di-cache karena URL streaming bisa kedaluwarsa. */
  async stream(episodeId: string): Promise<EpisodeStream> {
    const s = toStream(await get(`/episode/${encodeURIComponent(episodeId)}/stream`, undefined, 0))
    if (!s.sources.length) throw new ApiError('Episode ini belum punya sumber video')
    return s
  },

  schedule,

  /** Semua anime yang sedang tayang. Jika pencarian status ONGOING kosong, gabungkan jadwal 7 hari. */
  async ongoing(page: number, extra: { q?: string; genreIds?: string[] } = {}): Promise<Paged<Anime>> {
    const r = await search({ ...extra, status: 'ONGOING', sort: 'latest', page })
    if (page === 0 && r.items.length === 0 && !extra.q && !extra.genreIds?.length) {
      const all = await Promise.allSettled(DAYS.map((d) => schedule(d)))
      const seen = new Set<string>()
      const items: Anime[] = []
      for (const x of all) {
        if (x.status !== 'fulfilled') continue
        for (const a of x.value) if (!seen.has(a.id)) (seen.add(a.id), items.push(a))
      }
      return { items, hasMore: false }
    }
    return r
  },

  async recommendations(anime: Anime): Promise<Anime[]> {
    const ids = anime.genreIds?.slice(0, 2)
    let items: Anime[] = []
    if (ids?.length) {
      try {
        items = (await search({ genreIds: ids, sort: 'views' })).items
      } catch {
        items = []
      }
    }
    if (!items.length) {
      try {
        const h = await animeApi.home()
        items = h.random.length ? h.random : h.popular
      } catch {
        items = []
      }
    }
    return items.filter((a) => a.id !== anime.id).slice(0, 15)
  },

  /** JSON mentah, dipakai layar Diagnostik API di halaman Akun. */
  async raw(path: string, params?: Params): Promise<unknown> {
    return request(buildUrl(path, params))
  },
}

export type { AnimeStatus }
