// Clan: dibuat user, dipimpin leader, tumbuh lewat donasi AkimiShard.
//
// Data (Realtime Database):
//   clans/{id}                 data publik clan (xp = total untuk Top Clans; xpBalance = XP tersedia untuk dibelanjakan)
//   clanMembers/{id}/{uid}     { role, joinedAt, donated }   role: leader | vice | admiral | officer | member   (donated = total sepanjang masa / "Full", tidak pernah reset)
//   clanDonations/{id}/{period}/{key}/{uid}   total donasi per periode (daily/weekly/monthly); node periode baru otomatis = reset
//   clanRequests/{id}/{uid}    permintaan gabung (hanya leader, vice-leader, dan admiral yang boleh membaca)
//   userClan/{uid}             clan tempat user berada
//   userClanReq/{uid}          permintaan gabung user yang sedang menunggu (maksimal satu)
//   clanTags/{TAG}             indeks agar tag unik
//
// Semua angka di bawah HARUS sama dengan database.rules.json (ketat di sisi server).
import { useEffect, useReducer, useState } from 'react'
import {
  endAt,
  equalTo,
  get,
  limitToFirst,
  limitToLast,
  onValue,
  orderByChild,
  push,
  query,
  ref,
  serverTimestamp,
  startAt,
  update,
} from 'firebase/database'
import { db } from '../firebase/config'
import { PERIODS, periodKey, type Period } from '../lib/board'
import { sanitizeText } from './identity'
import type { UserProfile } from './userService'

export const CLAN_SLOT_START = 30
export const CLAN_SLOT_PACK = 5
export const CLAN_SLOT_COST = 1000 // XP tersedia untuk satu paket +5 slot
export const CLAN_SLOT_MAX = 100
export const CLAN_NAME_MIN = 3
export const CLAN_NAME_MAX = 24
export const CLAN_TAG_MIN = 2
export const CLAN_TAG_MAX = 5
export const CLAN_DESC_MAX = 120
/** 1 AkimiShard yang didonasikan = 1 XP clan. */
export const SHARD_TO_XP = 1

/** Biaya membuat clan (AkimiShard milik calon leader). Harus sama dengan database.rules.json. */
export const CLAN_CREATE_COST = 3500
/** Gacha warna clan, dibayar dengan XP clan tersedia (xpBalance), sama seperti slot member dan tier. Harga 5x lebih murah dari 5 x 1x (diskon 10%). Harus sama dengan database.rules.json. */
export const COLOR_SPIN_COST = 250
export const COLOR_SPIN5_COST = 1125
/** Warna bawaan clan baru (putih). */
export const CLAN_DEFAULT_COLOR = 0

/** Tier clan (bentuk lencana). Naik satu tier per pembelian, dibayar dengan XP clan (xpBalance) oleh leader. Harus sama dengan rules. */
export const CLAN_TIER_MAX = 3
export const CLAN_TIER_COST: Record<number, number> = { 2: 3000, 3: 8000 }
export const CLAN_TIER_NAME: Record<number, string> = { 1: 'Lancip', 2: 'Berbingkai', 3: 'Mahkota' }
export const clampTier = (n: unknown): number => (typeof n === 'number' && n >= 1 ? Math.min(CLAN_TIER_MAX, Math.floor(n)) : 1)

export type Rarity = 'common' | 'rare' | 'legend'
export type ClanColor = {
  name: string
  rarity: Rarity
  from: string
  /** warna tengah gradasi (opsional) */
  mid?: string
  to: string
  /** warna garis tepi */
  edge: string
  /** warna teks tag di atas lencana */
  ink: string
  /** efek cahaya bergerak (khusus Legend) */
  shine?: boolean
}

/**
 * Indeks array = nilai `color` yang disimpan di database (0-14). JANGAN diubah urutannya.
 * 0 = White = warna awal setiap clan baru.
 */
export const CLAN_COLORS: readonly ClanColor[] = [
  // COMMON
  { name: 'White', rarity: 'common', from: '#FFFFFF', to: '#D5D9E2', edge: '#FFFFFF', ink: '#1B1F2A' },
  { name: 'Blue', rarity: 'common', from: '#4F8DF7', to: '#1D4ED8', edge: '#9CC2FF', ink: '#FFFFFF' },
  { name: 'Pink', rarity: 'common', from: '#F77DBA', to: '#BE185D', edge: '#FBC8E2', ink: '#FFFFFF' },
  { name: 'Green', rarity: 'common', from: '#4ADE80', to: '#15803D', edge: '#B6F3CC', ink: '#FFFFFF' },
  { name: 'Purple', rarity: 'common', from: '#A98BFF', to: '#6D28D9', edge: '#D9CEFF', ink: '#FFFFFF' },
  { name: 'Yellow', rarity: 'common', from: '#FDE047', to: '#D49A06', edge: '#FEF3A6', ink: '#2B1B00' },
  { name: 'Orange', rarity: 'common', from: '#FDA25A', to: '#C2410C', edge: '#FFD3AE', ink: '#FFFFFF' },
  { name: 'Cyan', rarity: 'common', from: '#22D3EE', to: '#0E7490', edge: '#A5F0FB', ink: '#FFFFFF' },
  // RARE
  { name: 'Neon Blue', rarity: 'rare', from: '#3D7BFF', to: '#0A1FD6', edge: '#7DF9FF', ink: '#FFFFFF' },
  { name: 'Crimson', rarity: 'rare', from: '#E11D48', to: '#6B0A22', edge: '#FF7C95', ink: '#FFFFFF' },
  { name: 'Aqua', rarity: 'rare', from: '#5EF2D6', to: '#0D9488', edge: '#D2FFF6', ink: '#04302B' },
  { name: 'Violet', rarity: 'rare', from: '#9D2CFF', to: '#42008A', edge: '#D7A6FF', ink: '#FFFFFF' },
  { name: 'Emerald', rarity: 'rare', from: '#18D67E', to: '#04573A', edge: '#7DFFBE', ink: '#FFFFFF' },
  { name: 'Gold', rarity: 'rare', from: '#FFE27A', mid: '#E9B422', to: '#9A6A06', edge: '#FFF2B3', ink: '#3A2800' },
  // LEGEND
  { name: 'Black Shine', rarity: 'legend', from: '#17171C', mid: '#050507', to: '#1F1F27', edge: '#8E8EA0', ink: '#FFFFFF', shine: true },
] as const

export const RARITY_LABEL: Record<Rarity, string> = { common: 'Common', rare: 'Rare', legend: 'Legend' }
/** Peluang per putaran (persen). Legend sengaja sangat langka. */
export const RARITY_RATE: Record<Rarity, number> = { common: 75, rare: 24, legend: 1 }

export const clanColorOf = (idx: number): ClanColor => CLAN_COLORS[((idx % CLAN_COLORS.length) + CLAN_COLORS.length) % CLAN_COLORS.length]

/** Satu hasil putaran gacha. Rarity dipilih dulu (75/24/1), lalu warnanya diacak di dalam rarity itu. */
export function rollColor(rand: () => number = Math.random): number {
  const r = rand() * 100
  const rarity: Rarity = r < RARITY_RATE.legend ? 'legend' : r < RARITY_RATE.legend + RARITY_RATE.rare ? 'rare' : 'common'
  const pool = CLAN_COLORS.map((c, i) => ({ c, i })).filter((x) => x.c.rarity === rarity)
  return pool[Math.floor(rand() * pool.length)].i
}
/** Nama emblem; urutan = indeks yang disimpan di database (gambar pixel-nya ada di components/PixelEmblem.tsx). */
export const CLAN_EMBLEMS = ['Pedang', 'Perisai', 'Naga', 'Api', 'Petir', 'Bulan', 'Bintang', 'Apel', 'Rubah', 'Serigala', 'Tengkorak', 'Mahkota', 'Sakura', 'Gamepad', 'Elang', 'Ombak'] as const

export type Clan = {
  id: string
  name: string
  nameLower: string
  tag: string
  desc?: string
  color: number
  /** 1-3; clan lama tanpa field ini dianggap tier 1 */
  tier: number
  emblem: number
  leaderUid: string
  xp: number
  xpBalance: number
  slots: number
  members: number
  createdAt: number
}
// ---------- role clan ----------
// leader > vice (Vice-Leader, ungu) > admiral > officer > member. Harus sama dengan database.rules.json.
//   leader   : semua hal, termasuk beli slot, bubarkan clan, ubah role siapa pun, dan pindahkan jabatan leader
//   vice     : terima/tolak permintaan, upgrade tier, spin & pakai warna, kick, ubah role anggota di bawahnya (admiral/officer/member)
//   admiral  : terima/tolak permintaan, ubah role officer <-> member
//   officer  : gelar saja (belum punya wewenang khusus)
export type ClanRole = 'leader' | 'vice' | 'admiral' | 'officer' | 'member'
export const CLAN_ROLES: readonly ClanRole[] = ['leader', 'vice', 'admiral', 'officer', 'member']
export const CLAN_ROLE_NAME: Record<ClanRole, string> = { leader: 'Leader', vice: 'Vice-Leader', admiral: 'Admiral', officer: 'Officer', member: 'Member' }
/** Teks lencana kecil di avatar anggota. */
export const CLAN_ROLE_BADGE: Record<ClanRole, string> = { leader: 'LEADER', vice: 'VICE-LEADER', admiral: 'ADMIRAL', officer: 'OFFICER', member: 'MEMBER' }
/** Warna role (vice-leader ungu). */
export const CLAN_ROLE_COLOR: Record<ClanRole, string> = { leader: '#F4B63F', vice: '#A78BFA', admiral: '#38BDF8', officer: '#5BE08A', member: '#94A3B8' }
const ROLE_RANK: Record<ClanRole, number> = { leader: 4, vice: 3, admiral: 2, officer: 1, member: 0 }
export const roleRank = (r: ClanRole) => ROLE_RANK[r]
export const parseRole = (v: unknown): ClanRole => (typeof v === 'string' && (CLAN_ROLES as readonly string[]).includes(v) ? (v as ClanRole) : 'member')

/** Terima / tolak permintaan masuk. */
export const canManageRequests = (r: ClanRole | null | undefined) => r === 'leader' || r === 'vice' || r === 'admiral'
/** Upgrade tier, spin warna, pakai warna. (Beli slot dan bubarkan clan tetap hanya leader.) */
export const canManageClan = (r: ClanRole | null | undefined) => r === 'leader' || r === 'vice'
/** Kick: hanya leader dan vice-leader, dan hanya anggota dengan pangkat lebih rendah (leader tidak pernah bisa di-kick). */
export const canKick = (actor: ClanRole | null | undefined, target: ClanRole): boolean =>
  (actor === 'leader' || actor === 'vice') && target !== 'leader' && ROLE_RANK[actor] > ROLE_RANK[target]
/** Role yang boleh diberikan `actor` kepada anggota yang sekarang berperan `target` (tidak termasuk role yang sudah dimilikinya). */
export function assignableRoles(actor: ClanRole | null | undefined, target: ClanRole): ClanRole[] {
  let pool: ClanRole[] = []
  if (actor === 'leader' && target !== 'leader') pool = ['vice', 'admiral', 'officer', 'member']
  else if (actor === 'vice' && ROLE_RANK[target] < ROLE_RANK.vice) pool = ['admiral', 'officer', 'member']
  else if (actor === 'admiral' && ROLE_RANK[target] < ROLE_RANK.admiral) pool = ['officer', 'member']
  return pool.filter((r) => r !== target)
}

export type ClanMember = { uid: string; role: ClanRole; joinedAt: number; donated: number }
export type ClanRequest = { uid: string; ts: number }

// ---------- level clan (hanya tampilan; dihitung dari XP total) ----------
/** XP total minimum untuk mencapai `level` (level 1 = 0 XP). */
export const clanCumXp = (level: number) => 100 * (level - 1) * (level - 1)
export const clanLevel = (xp: number) => 1 + Math.floor(Math.sqrt(Math.max(0, xp) / 100))
export function clanProgress(xp: number) {
  const level = clanLevel(xp)
  const current = Math.max(0, xp - clanCumXp(level))
  const required = clanCumXp(level + 1) - clanCumXp(level)
  return { level, current, required, ratio: Math.min(1, current / required) }
}

/** 4,3K / 67,1M / 9,19M — tiga angka penting, koma desimal. */
export function fmtCompact(n: number): string {
  const f = (v: number, unit: string) => {
    const d = v < 10 ? 2 : 1
    return `${v.toLocaleString('id-ID', { minimumFractionDigits: d, maximumFractionDigits: d })}${unit}`
  }
  if (n >= 1e9) return f(n / 1e9, 'B')
  if (n >= 1e6) return f(n / 1e6, 'M')
  if (n >= 1e3) return f(n / 1e3, 'K')
  return String(Math.round(n))
}

export const normalizeTag = (raw: string) => raw.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, CLAN_TAG_MAX)

function clanError(e: unknown): Error {
  const m = e instanceof Error ? e.message : String(e)
  if (/permission/i.test(m)) {
    return new Error('Ditolak oleh aturan database. Mungkin datanya baru berubah (coba lagi), atau rules clan terbaru belum dipublikasikan.')
  }
  return e instanceof Error ? e : new Error(m)
}

function toClan(id: string, v: unknown): Clan | null {
  const c = v as Partial<Clan> | null
  if (!c || typeof c.name !== 'string' || typeof c.tag !== 'string' || typeof c.xp !== 'number') return null
  return {
    id,
    name: c.name,
    nameLower: c.nameLower ?? c.name.toLowerCase(),
    tag: c.tag,
    desc: c.desc,
    color: typeof c.color === 'number' ? c.color : 0,
    tier: clampTier((c as { tier?: unknown }).tier),
    emblem: typeof c.emblem === 'number' ? c.emblem : 0,
    leaderUid: c.leaderUid ?? '',
    xp: c.xp,
    xpBalance: typeof c.xpBalance === 'number' ? c.xpBalance : 0,
    slots: typeof c.slots === 'number' ? c.slots : CLAN_SLOT_START,
    members: typeof c.members === 'number' ? c.members : 1,
    createdAt: typeof c.createdAt === 'number' ? c.createdAt : 0,
  }
}

const num = async (path: string): Promise<number> => {
  const s = await get(ref(db, path))
  return typeof s.val() === 'number' ? (s.val() as number) : 0
}

// ---------- aksi ----------
export type CreateClanInput = { name: string; tag: string; desc: string; emblem: number }

export function validateClanInput(input: CreateClanInput): { name: string; tag: string; desc: string } {
  const name = sanitizeText(input.name, CLAN_NAME_MAX).replace(/\s+/g, ' ')
  const tag = normalizeTag(input.tag)
  const desc = sanitizeText(input.desc, CLAN_DESC_MAX).replace(/\s*\n\s*/g, ' ')
  if (name.length < CLAN_NAME_MIN) throw new Error(`Nama clan minimal ${CLAN_NAME_MIN} huruf`)
  if (tag.length < CLAN_TAG_MIN) throw new Error(`Tag clan ${CLAN_TAG_MIN}-${CLAN_TAG_MAX} huruf/angka`)
  return { name, tag, desc }
}

/** Membuat clan baru (biaya 3.500 AkimiShard, warna awal putih); pembuatnya otomatis jadi leader. Slot awal 30 gratis. */
export async function createClan(me: UserProfile, input: CreateClanInput): Promise<string> {
  const { name, tag, desc } = validateClanInput(input)
  if ((await get(ref(db, `userClan/${me.uid}`))).exists()) throw new Error('Kamu sudah berada di sebuah clan')
  if ((await get(ref(db, `clanTags/${tag}`))).exists()) throw new Error(`Tag ${tag} sudah dipakai clan lain`)
  const shard = await num(`users/${me.uid}/shard`)
  if (shard < CLAN_CREATE_COST) throw new Error(`AkimiShard kamu kurang. Butuh ${CLAN_CREATE_COST.toLocaleString('id-ID')} untuk membuat clan.`)
  // permintaan gabung yang masih menunggu dibatalkan dulu
  const pending = (await get(ref(db, `userClanReq/${me.uid}`))).val()
  if (typeof pending === 'string') await cancelRequest(me.uid, pending).catch(() => undefined)

  const id = push(ref(db, 'clans')).key as string
  const clan: Record<string, unknown> = {
    name,
    nameLower: name.toLowerCase(),
    tag,
    color: CLAN_DEFAULT_COLOR,
    tier: 1,
    emblem: input.emblem,
    leaderUid: me.uid,
    xp: 0,
    xpBalance: 0,
    slots: CLAN_SLOT_START,
    members: 1,
    createdAt: serverTimestamp(),
  }
  if (desc) clan.desc = desc
  try {
    await update(ref(db), {
      [`clans/${id}`]: clan,
      [`clanMembers/${id}/${me.uid}`]: { role: 'leader', joinedAt: serverTimestamp(), donated: 0 },
      [`userClan/${me.uid}`]: id,
      [`clanTags/${tag}`]: id,
      [`users/${me.uid}/shard`]: shard - CLAN_CREATE_COST,
    })
  } catch (e) {
    throw clanError(e)
  }
  await update(ref(db), { [`users/${me.uid}/clanTag`]: tag }).catch(() => undefined)
  return id
}

export async function requestJoin(me: string, clanId: string): Promise<void> {
  try {
    await update(ref(db), { [`clanRequests/${clanId}/${me}`]: serverTimestamp(), [`userClanReq/${me}`]: clanId })
  } catch (e) {
    throw clanError(e)
  }
}

/** Dipakai untuk membatalkan (oleh pemohon) maupun menolak (oleh leader / vice-leader / admiral). */
export async function cancelRequest(uid: string, clanId: string): Promise<void> {
  try {
    await update(ref(db), { [`clanRequests/${clanId}/${uid}`]: null, [`userClanReq/${uid}`]: null })
  } catch (e) {
    throw clanError(e)
  }
}

/** Leader, vice-leader, atau admiral menerima permintaan: anggota dibuat, jumlah anggota naik 1. */
export async function acceptRequest(clanId: string, uid: string): Promise<void> {
  // pra-cek supaya penyebab penolakan jelas (aturan database hanya membalas "permission denied")
  const [clanSnap, reqSnap, theirClan, member] = await Promise.all([
    get(ref(db, `clans/${clanId}`)),
    get(ref(db, `clanRequests/${clanId}/${uid}`)),
    get(ref(db, `userClan/${uid}`)),
    get(ref(db, `clanMembers/${clanId}/${uid}`)),
  ])
  const c = clanSnap.val() as Partial<Clan> | null
  if (!c) throw new Error('Clan tidak ditemukan')
  if (typeof c.members !== 'number' || typeof c.slots !== 'number') {
    throw new Error('Data clan dari versi lama (field members/slots belum ada). Buat ulang clan atau minta developer memperbaikinya.')
  }
  if (c.members >= c.slots) throw new Error('Slot anggota penuh. Upgrade slot di Shop Clan.')
  if (member.exists()) throw new Error('Orang ini sudah menjadi anggota')
  if (!reqSnap.exists()) throw new Error('Permintaan ini sudah tidak ada')
  if (theirClan.exists()) {
    // pemohon sudah masuk clan lain: permintaan basi dibersihkan
    await cancelRequest(uid, clanId).catch(() => undefined)
    throw new Error('Orang ini sudah berada di clan lain. Permintaannya dihapus.')
  }
  try {
    await update(ref(db), {
      [`clanMembers/${clanId}/${uid}`]: { role: 'member', joinedAt: serverTimestamp(), donated: 0 },
      [`clanRequests/${clanId}/${uid}`]: null,
      [`userClanReq/${uid}`]: null,
      [`userClan/${uid}`]: clanId,
      // badge clan langsung terpasang di profil anggota baru (rules mengizinkan leader/vice/admiral hanya bersama ACC ini),
      // jadi tidak lagi menunggu anggota membuka aplikasinya
      [`users/${uid}/clanTag`]: c.tag,
      [`clans/${clanId}/members`]: c.members + 1,
      [`clans/${clanId}/inOp`]: { uid, ts: serverTimestamp() },
    })
  } catch (e) {
    throw clanError(e)
  }
}

async function removeMember(clanId: string, uid: string, extra: Record<string, null> = {}): Promise<void> {
  const members = await num(`clans/${clanId}/members`)
  try {
    await update(ref(db), {
      [`clanMembers/${clanId}/${uid}`]: null,
      [`userClan/${uid}`]: null,
      [`clans/${clanId}/members`]: Math.max(1, members - 1),
      [`clans/${clanId}/outOp`]: { uid, ts: serverTimestamp() },
      ...extra,
    })
  } catch (e) {
    throw clanError(e)
  }
}

async function roleOf(clanId: string, uid: string): Promise<ClanRole | null> {
  const snap = await get(ref(db, `clanMembers/${clanId}/${uid}/role`))
  return snap.exists() ? parseRole(snap.val()) : null
}

/** Anggota keluar dari clan (semua role kecuali leader; leader harus memindahkan jabatan dulu, atau membubarkan clan saat sendirian). */
export async function leaveClan(me: UserProfile, clan: Clan): Promise<void> {
  if (me.uid === clan.leaderUid) throw new Error('Leader tidak bisa keluar. Pindahkan jabatan leader ke anggota lain dulu, atau bubarkan clan jika kamu anggota terakhir.')
  await removeMember(clan.id, me.uid, me.clanTag ? { [`users/${me.uid}/clanTag`]: null } : {})
}

/** Kick anggota. Hanya leader dan vice-leader, dan hanya yang pangkatnya lebih rendah. */
export async function kickMember(me: UserProfile, clan: Clan, uid: string): Promise<void> {
  const [mine, theirs] = await Promise.all([roleOf(clan.id, me.uid), roleOf(clan.id, uid)])
  if (!theirs) throw new Error('Anggota ini sudah tidak ada di clan')
  if (uid === me.uid) throw new Error('Kamu tidak bisa mengeluarkan diri sendiri. Gunakan Keluar Clan.')
  if (theirs === 'leader') throw new Error('Leader tidak bisa dikeluarkan')
  if (!canKick(mine, theirs)) throw new Error('Role kamu tidak cukup untuk mengeluarkan anggota ini')
  await removeMember(clan.id, uid)
}

/** Ubah role anggota. Aturan siapa boleh memberi role apa ada di assignableRoles() dan dijaga lagi oleh database.rules.json. */
export async function setMemberRole(me: UserProfile, clan: Clan, uid: string, role: ClanRole): Promise<void> {
  if (uid === me.uid) throw new Error('Kamu tidak bisa mengubah role sendiri')
  const [mine, theirs] = await Promise.all([roleOf(clan.id, me.uid), roleOf(clan.id, uid)])
  if (!mine) throw new Error('Kamu bukan anggota clan ini')
  if (!theirs) throw new Error('Anggota ini sudah tidak ada di clan')
  if (!assignableRoles(mine, theirs).includes(role)) throw new Error('Role kamu tidak cukup untuk mengubah role ini')
  try {
    await update(ref(db), { [`clanMembers/${clan.id}/${uid}/role`]: role })
  } catch (e) {
    throw clanError(e)
  }
  const saved = await get(ref(db, `clanMembers/${clan.id}/${uid}/role`))
  if (saved.val() !== role) throw new Error('Role belum tersimpan di server. Coba lagi.')
}

/** Leader memindahkan jabatan leader ke anggota lain; leader lama otomatis menjadi Vice-Leader. Satu tulisan atomik. */
export async function transferLeader(me: UserProfile, clan: Clan, uid: string): Promise<void> {
  if (me.uid !== clan.leaderUid) throw new Error('Hanya leader yang bisa memindahkan jabatan leader')
  if (uid === me.uid) throw new Error('Pilih anggota lain sebagai leader baru')
  if (!(await roleOf(clan.id, uid))) throw new Error('Anggota ini sudah tidak ada di clan')
  try {
    await update(ref(db), {
      [`clans/${clan.id}/leaderUid`]: uid,
      [`clanMembers/${clan.id}/${uid}/role`]: 'leader',
      [`clanMembers/${clan.id}/${me.uid}/role`]: 'vice',
    })
  } catch (e) {
    throw clanError(e)
  }
  const saved = await get(ref(db, `clans/${clan.id}/leaderUid`))
  if (saved.val() !== uid) throw new Error('Perpindahan leader belum tersimpan di server. Coba lagi.')
}

async function requireManager(me: UserProfile, clan: Clan, what: string): Promise<void> {
  if (!canManageClan(await roleOf(clan.id, me.uid))) throw new Error(`Hanya leader atau vice-leader yang bisa ${what}`)
}

/** Membubarkan clan. Hanya bisa oleh leader saat tidak ada anggota lain. */
export async function disbandClan(me: UserProfile, clan: Clan): Promise<void> {
  if (me.uid !== clan.leaderUid) throw new Error('Hanya leader yang bisa membubarkan clan')
  if ((await num(`clans/${clan.id}/members`)) !== 1) throw new Error('Keluarkan semua anggota dulu sebelum membubarkan clan')
  const patch: Record<string, null> = {
    [`clans/${clan.id}`]: null,
    [`clanMembers/${clan.id}`]: null,
    [`userClan/${me.uid}`]: null,
    [`clanTags/${clan.tag}`]: null,
    [`clanRequests/${clan.id}`]: null,
    [`clanColors/${clan.id}`]: null,
    [`clanColorOp/${clan.id}`]: null,
  }
  if (me.clanTag) patch[`users/${me.uid}/clanTag`] = null
  try {
    await update(ref(db), patch)
  } catch (e) {
    throw clanError(e)
  }
}

/** Setor AkimiShard: shard user berkurang, XP total (Top Clans) dan XP tersedia clan bertambah sama persis. */
export async function donateShard(me: UserProfile, clan: Clan, amount: number): Promise<void> {
  if (!Number.isInteger(amount) || amount < 1) throw new Error('Jumlah setoran harus bilangan bulat minimal 1')
  const [shard, xp, bal, donated] = await Promise.all([
    num(`users/${me.uid}/shard`),
    num(`clans/${clan.id}/xp`),
    num(`clans/${clan.id}/xpBalance`),
    num(`clanMembers/${clan.id}/${me.uid}/donated`),
  ])
  if (amount > shard) throw new Error('AkimiShard kamu tidak cukup')
  const [clanSnap, mem] = await Promise.all([get(ref(db, `clans/${clan.id}`)), get(ref(db, `clanMembers/${clan.id}/${me.uid}`))])
  const raw = clanSnap.val() as Partial<Clan> | null
  if (!raw) throw new Error('Clan tidak ditemukan')
  if (!mem.exists()) throw new Error('Kamu bukan anggota clan ini')
  if (typeof raw.xp !== 'number' || typeof raw.xpBalance !== 'number') {
    throw new Error('Data clan dari versi lama (field XP belum lengkap). Buat ulang clan atau minta developer memperbaikinya.')
  }
  const gain = amount * SHARD_TO_XP
  // Donasi per periode (harian/mingguan/bulanan): tiap periode punya node sendiri, jadi reset terjadi otomatis saat key berganti.
  const periodPaths = PERIODS.map((p) => `clanDonations/${clan.id}/${p}/${periodKey(p)}/${me.uid}`)
  const periodPrev = await Promise.all(periodPaths.map((path) => num(path)))
  const patch: Record<string, unknown> = {
    [`users/${me.uid}/shard`]: shard - amount,
    [`clans/${clan.id}/xp`]: xp + gain,
    [`clans/${clan.id}/xpBalance`]: bal + gain,
    [`clanMembers/${clan.id}/${me.uid}/donated`]: donated + amount,
  }
  periodPaths.forEach((path, i) => {
    patch[path] = periodPrev[i] + amount
  })
  try {
    await update(ref(db), patch)
  } catch (e) {
    throw clanError(e)
  }
}

/** Leader menukar XP tersedia dengan slot: 1.000 XP = +5 slot. XP total di Top Clans tidak berkurang. */
export async function upgradeSlots(me: UserProfile, clan: Clan): Promise<void> {
  if (me.uid !== clan.leaderUid) throw new Error('Hanya leader yang bisa upgrade slot')
  const [slots, bal] = await Promise.all([num(`clans/${clan.id}/slots`), num(`clans/${clan.id}/xpBalance`)])
  if (slots + CLAN_SLOT_PACK > CLAN_SLOT_MAX) throw new Error(`Slot maksimal ${CLAN_SLOT_MAX}`)
  if (bal < CLAN_SLOT_COST) throw new Error(`XP clan tidak cukup (butuh ${CLAN_SLOT_COST.toLocaleString('id-ID')})`)
  try {
    await update(ref(db), {
      [`clans/${clan.id}/slots`]: slots + CLAN_SLOT_PACK,
      [`clans/${clan.id}/xpBalance`]: bal - CLAN_SLOT_COST,
    })
  } catch (e) {
    throw clanError(e)
  }
}

// ---------- warna clan (gacha) ----------
export type SpinResult = { color: number; isNew: boolean }

/**
 * Leader memutar gacha warna: 1x = 250 XP clan, 5x = 1.125 XP clan (dipotong dari xpBalance / "XP tersedia").
 * XP total di Top Clans tidak berkurang. AkimiShard pribadi leader tidak dipakai lagi.
 * Catatan: acak dilakukan di aplikasi karena proyek ini tidak punya server sendiri. Rules database hanya menjamin
 * pembayaran dan bahwa hanya leader yang bisa menambah koleksi; untuk acak yang anti-curang perlu Cloud Function.
 */
export async function spinColors(me: UserProfile, clan: Clan, times: 1 | 5): Promise<SpinResult[]> {
  await requireManager(me, clan, 'memutar warna clan')
  const cost = times === 5 ? COLOR_SPIN5_COST : COLOR_SPIN_COST
  const [bal, ownedSnap] = await Promise.all([num(`clans/${clan.id}/xpBalance`), get(ref(db, `clanColors/${clan.id}`))])
  if (bal < cost) throw new Error(`XP clan kurang. Butuh ${cost.toLocaleString('id-ID')}, tersedia ${bal.toLocaleString('id-ID')}.`)
  const owned = new Set<number>(Object.keys((ownedSnap.val() ?? {}) as Record<string, unknown>).map(Number))
  owned.add(CLAN_DEFAULT_COLOR)
  const results: SpinResult[] = []
  const patch: Record<string, unknown> = {
    [`clans/${clan.id}/xpBalance`]: bal - cost,
    [`clanColorOp/${clan.id}`]: { n: times, ts: serverTimestamp() },
  }
  for (let i = 0; i < times; i++) {
    const color = rollColor()
    const isNew = !owned.has(color)
    owned.add(color)
    results.push({ color, isNew })
    if (isNew) patch[`clanColors/${clan.id}/${color}`] = true
  }
  try {
    await update(ref(db), patch)
  } catch (e) {
    throw clanError(e)
  }
  return results
}

/** Leader memakai salah satu warna dari koleksi (White selalu dimiliki). Hasil diverifikasi dari server. */
export async function equipColor(me: UserProfile, clan: Clan, color: number): Promise<void> {
  await requireManager(me, clan, 'mengganti warna clan')
  try {
    await update(ref(db), { [`clans/${clan.id}/color`]: color })
  } catch (e) {
    throw new Error(
      /permission/i.test(e instanceof Error ? e.message : String(e))
        ? 'Warna tidak bisa dipakai: ditolak database. Pastikan rules database terbaru sudah dipublikasikan dan warna ini ada di koleksimu.'
        : (e instanceof Error ? e.message : 'Gagal memakai warna'),
    )
  }
  // jangan percaya tampilan lokal: baca ulang dari server supaya tidak "terlihat berhasil" padahal tidak tersimpan
  const saved = await get(ref(db, `clans/${clan.id}/color`))
  if (saved.val() !== color) throw new Error('Warna belum tersimpan di server. Coba lagi.')
}

/** Leader menaikkan tier clan satu tingkat (tidak bisa loncat). Biaya diambil dari XP clan yang tersedia. */
export async function upgradeTier(me: UserProfile, clan: Clan): Promise<number> {
  await requireManager(me, clan, 'menaikkan tier clan')
  const [tierSnap, bal] = await Promise.all([get(ref(db, `clans/${clan.id}/tier`)), num(`clans/${clan.id}/xpBalance`)])
  const cur = clampTier(tierSnap.val())
  if (cur >= CLAN_TIER_MAX) throw new Error('Clan sudah di tier tertinggi')
  const next = cur + 1
  const cost = CLAN_TIER_COST[next]
  if (bal < cost) throw new Error(`XP clan kurang. Butuh ${cost.toLocaleString('id-ID')}, tersedia ${bal.toLocaleString('id-ID')}.`)
  try {
    await update(ref(db), { [`clans/${clan.id}/tier`]: next, [`clans/${clan.id}/xpBalance`]: bal - cost })
  } catch (e) {
    throw clanError(e)
  }
  const saved = await get(ref(db, `clans/${clan.id}/tier`))
  if (saved.val() !== next) throw new Error('Tier belum tersimpan di server. Coba lagi.')
  return next
}

// ---------- developer: hapus clan ----------
/**
 * Developer menghapus clan beserta semua datanya dalam SATU update atomik: clan, anggota, permintaan masuk, tag, koleksi warna,
 * penunjuk clan setiap anggota, dan lencana tag mereka. Rules database menolak penghapusan yang tidak lengkap.
 */
export async function adminDeleteClan(me: UserProfile, clan: Clan): Promise<void> {
  if (me.role !== 'developer') throw new Error('Hanya developer yang boleh menghapus clan')
  const [members, requests] = await Promise.all([get(ref(db, `clanMembers/${clan.id}`)), get(ref(db, `clanRequests/${clan.id}`))])
  const patch: Record<string, null> = {
    [`clans/${clan.id}`]: null,
    [`clanMembers/${clan.id}`]: null,
    [`clanRequests/${clan.id}`]: null,
    [`clanColors/${clan.id}`]: null,
    [`clanColorOp/${clan.id}`]: null,
    [`clanTags/${clan.tag}`]: null,
  }
  members.forEach((m) => {
    patch[`userClan/${m.key as string}`] = null
    patch[`users/${m.key as string}/clanTag`] = null
  })
  // pemohon: hanya yang permintaannya memang ke clan ini (penunjuk ke clan lain tidak disentuh)
  const reqUids: string[] = []
  requests.forEach((r) => {
    reqUids.push(r.key as string)
  })
  const pointers = await Promise.all(reqUids.map((uid) => get(ref(db, `userClanReq/${uid}`)).catch(() => null)))
  reqUids.forEach((uid, i) => {
    if (pointers[i]?.val() === clan.id) patch[`userClanReq/${uid}`] = null
  })
  try {
    await update(ref(db), patch)
  } catch (e) {
    throw clanError(e)
  }
}

// ---------- baca data ----------
function useValue<T>(path: string | null, map: (v: unknown) => T): T | null | undefined {
  const [val, setVal] = useState<T | null | undefined>(undefined)
  useEffect(() => {
    setVal(undefined)
    if (!path) {
      setVal(null)
      return
    }
    return onValue(
      ref(db, path),
      (s) => setVal(s.exists() ? map(s.val()) : null),
      () => setVal(null),
    )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path])
  return val
}

/** clanId tempat user berada (null = tidak punya clan, undefined = memuat). */
export const useMyClanId = (uid: string) => useValue<string>(`userClan/${uid}`, (v) => String(v))
/** clanId tujuan permintaan gabung yang sedang menunggu. */
export const useMyRequest = (uid: string) => useValue<string>(`userClanReq/${uid}`, (v) => String(v))
/** Role user di clan tertentu (null = bukan anggota, undefined = memuat). */
export const useMyRole = (clanId: string | null | undefined, uid: string) =>
  useValue<ClanRole>(clanId ? `clanMembers/${clanId}/${uid}/role` : null, parseRole)
export const useClan = (id: string | null | undefined) => useValue<Clan | null>(id ? `clans/${id}` : null, (v) => toClan(id as string, v))

export function useClanMembers(id: string): ClanMember[] | undefined {
  const v = useValue<ClanMember[]>(`clanMembers/${id}`, (raw) =>
    Object.entries((raw ?? {}) as Record<string, Partial<ClanMember>>).map(([uid, m]) => ({
      uid,
      role: parseRole(m.role),
      joinedAt: m.joinedAt ?? 0,
      donated: m.donated ?? 0,
    })),
  )
  return v === null ? [] : v
}

/** Daftar permintaan masuk; hanya terbaca oleh leader / vice-leader / admiral (selain itu `enabled` = false). */
export function useClanRequests(id: string, enabled: boolean): ClanRequest[] | undefined {
  const v = useValue<ClanRequest[]>(enabled ? `clanRequests/${id}` : null, (raw) =>
    Object.entries((raw ?? {}) as Record<string, number>)
      .map(([uid, ts]) => ({ uid, ts: typeof ts === 'number' ? ts : 0 }))
      .sort((a, b) => a.ts - b.ts),
  )
  return v === null ? (enabled ? [] : undefined) : v
}

const byXp = (a: Clan, b: Clan) => b.xp - a.xp || a.createdAt - b.createdAt

export function useTopClans(limit = 30): Clan[] | undefined {
  const [list, setList] = useState<Clan[] | undefined>(undefined)
  useEffect(() => {
    const q = query(ref(db, 'clans'), orderByChild('xp'), limitToLast(limit))
    return onValue(
      q,
      (s) => {
        const out: Clan[] = []
        s.forEach((c) => {
          const clan = toClan(c.key as string, c.val())
          if (clan) out.push(clan)
        })
        setList(out.sort(byXp))
      },
      () => setList([]),
    )
  }, [limit])
  return list
}

/** Cari clan berdasarkan awalan nama atau tag persis. */
export async function searchClans(raw: string): Promise<Clan[]> {
  const q = sanitizeText(raw, CLAN_NAME_MAX).toLowerCase()
  if (!q) return []
  const collect = (snap: Awaited<ReturnType<typeof get>>, into: Map<string, Clan>) =>
    snap.forEach((c) => {
      const clan = toClan(c.key as string, c.val())
      if (clan) into.set(clan.id, clan)
    })
  const found = new Map<string, Clan>()
  const jobs: Promise<void>[] = [
    get(query(ref(db, 'clans'), orderByChild('nameLower'), startAt(q), endAt(`${q}\uf8ff`), limitToFirst(20))).then((s) => collect(s, found)),
  ]
  if (/^[a-z0-9]{2,5}$/.test(q)) {
    jobs.push(get(query(ref(db, 'clans'), orderByChild('tag'), equalTo(q.toUpperCase()), limitToFirst(5))).then((s) => collect(s, found)))
  }
  await Promise.all(jobs)
  return [...found.values()].sort(byXp)
}

/** Koleksi warna milik clan (White selalu termasuk). */
export function useClanColors(id: string | null | undefined): Set<number> | undefined {
  const v = useValue<number[]>(id ? `clanColors/${id}` : null, (raw) => Object.keys((raw ?? {}) as Record<string, unknown>).map(Number))
  if (v === undefined) return undefined
  return new Set<number>([CLAN_DEFAULT_COLOR, ...(v ?? [])])
}

// ---------- clan berdasarkan tag (untuk lencana di komentar, chat, profil) ----------
// Pesan lama hanya menyimpan tag. Warna & emblem dicari lewat tag secara langsung supaya selalu terbaru
// (warna clan bisa diganti), dan satu langganan dipakai bersama oleh semua lencana dengan tag yang sama.
type TagEntry = { clan: Clan | null | undefined; subs: Set<() => void>; offTag?: () => void; offClan?: () => void; timer?: ReturnType<typeof setTimeout> }
const tagCache = new Map<string, TagEntry>()

function startTag(tag: string, e: TagEntry) {
  let lastId: string | null = null
  const notify = () => e.subs.forEach((f) => f())
  e.offTag = onValue(
    ref(db, `clanTags/${tag}`),
    (s) => {
      const id = s.exists() ? String(s.val()) : ''
      if (id === lastId) return
      lastId = id
      e.offClan?.()
      e.offClan = undefined
      if (!id) {
        e.clan = null
        notify()
        return
      }
      e.offClan = onValue(
        ref(db, `clans/${id}`),
        (c) => {
          e.clan = c.exists() ? toClan(id, c.val()) : null
          notify()
        },
        () => {
          e.clan = null
          notify()
        },
      )
    },
    () => {
      e.clan = null
      notify()
    },
  )
}

/** Clan dari tag-nya (undefined = memuat, null = tidak ada). Ringan dipakai di daftar panjang. */
export function useClanByTag(tag?: string): Clan | null | undefined {
  const [, bump] = useReducer((x: number) => x + 1, 0)
  useEffect(() => {
    if (!tag) return
    let e = tagCache.get(tag)
    if (!e) {
      e = { clan: undefined, subs: new Set() }
      tagCache.set(tag, e)
      startTag(tag, e)
    }
    if (e.timer) clearTimeout(e.timer)
    e.subs.add(bump)
    const entry = e
    bump()
    return () => {
      entry.subs.delete(bump)
      if (entry.subs.size === 0) {
        // tahan 30 detik supaya scroll bolak-balik tidak memuat ulang
        entry.timer = setTimeout(() => {
          if (entry.subs.size === 0) {
            entry.offTag?.()
            entry.offClan?.()
            tagCache.delete(tag)
          }
        }, 30_000)
      }
    }
  }, [tag])
  return tag ? tagCache.get(tag)?.clan : null
}


/** Donasi per member untuk satu periode. `full` = total sepanjang masa (clanMembers/.../donated, tidak pernah reset). */
export type DonationPeriod = Period | 'full'

/** { uid: jumlah } untuk periode berjalan. Periode baru (hari/pekan/bulan berganti) otomatis kosong. */
export function usePeriodDonations(clanId: string, period: Period | null): Record<string, number> | undefined {
  const key = period ? periodKey(period) : ''
  const [val, setVal] = useState<Record<string, number> | undefined>(undefined)
  useEffect(() => {
    setVal(undefined)
    if (!period) return
    return onValue(
      ref(db, `clanDonations/${clanId}/${period}/${key}`),
      (s) => {
        const out: Record<string, number> = {}
        const raw = (s.val() ?? {}) as Record<string, unknown>
        for (const [uid, n] of Object.entries(raw)) if (typeof n === 'number' && n > 0) out[uid] = n
        setVal(out)
      },
      () => setVal({}),
    )
  }, [clanId, period, key])
  return period ? val : {}
}
