// Sistem teman di Firebase Realtime Database yang SUDAH dipakai project (bukan Firestore).
// Identifier utama = Firebase UID. User ID publik (#1470) hanya untuk pencarian lewat `userIndex`.
//
//   friends/{uid}/{otherUid}         = ts   -> daftar teman (ditulis dua arah saat accept)
//   friendRequests/{toUid}/{fromUid} = ts   -> permintaan masuk milik `toUid`
//   friendSent/{fromUid}/{toUid}     = ts   -> permintaan terkirim milik `fromUid`
//   userIndex/{userId}               = uid  -> peta ID publik ke UID (dibuat sekali per akun)
//
// Status hubungan: none | pending_sent | pending_received | friends
import { useEffect, useMemo, useState } from 'react'
import { equalTo, get, limitToFirst, onValue, orderByChild, query, ref, remove, serverTimestamp, set, update } from 'firebase/database'
import { db } from '../firebase/config'
import { isDeveloper } from './broadcastService'
import { findUserByUserId } from './userLookupService'
import { normalizeProfile, type UserProfile } from './userService'

export type Relation = 'none' | 'pending_sent' | 'pending_received' | 'friends'
export type UidEntry = { uid: string; ts: number }

const FRIEND_ERR = 'Fitur teman belum aktif. Publikasikan database.rules.json terbaru di Firebase.'

function friendlyError(e: unknown): Error {
  const m = e instanceof Error ? e.message : String(e)
  if (/permission/i.test(m)) return new Error(FRIEND_ERR)
  return e instanceof Error ? e : new Error(m)
}

// ---------- aksi ----------
export async function sendRequest(me: string, other: string): Promise<void> {
  if (me === other) throw new Error('Kamu tidak bisa menambahkan akun sendiri.')
  try {
    await update(ref(db), {
      [`friendSent/${me}/${other}`]: serverTimestamp(),
      [`friendRequests/${other}/${me}`]: serverTimestamp(),
    })
  } catch (e) {
    throw friendlyError(e)
  }
}

/** Membatalkan permintaan yang SAYA kirim. */
export async function cancelRequest(me: string, other: string): Promise<void> {
  try {
    await update(ref(db), {
      [`friendSent/${me}/${other}`]: null,
      [`friendRequests/${other}/${me}`]: null,
    })
  } catch (e) {
    throw friendlyError(e)
  }
}

/** Menolak permintaan masuk dari `from`. */
export async function rejectRequest(me: string, from: string): Promise<void> {
  try {
    await update(ref(db), { [`friendRequests/${me}/${from}`]: null })
  } catch (e) {
    throw friendlyError(e)
  }
  await remove(ref(db, `friendSent/${from}/${me}`)).catch(() => undefined)
}

/**
 * Menerima permintaan masuk dari `from`: kedua sisi menjadi teman, lalu permintaan antar keduanya dibersihkan.
 *
 * Penting: Security Rules menolak "hapus" pada node yang TIDAK ADA, sehingga satu update yang ikut menghapus
 * jalur kosong akan ditolak seluruhnya. Karena itu update utama hanya menyentuh jalur yang pasti ada
 * (permintaan yang sedang diterima), dan semua pembersihan lain dilakukan terpisah dan toleran gagal.
 */
export async function acceptRequest(me: string, from: string): Promise<void> {
  try {
    await update(ref(db), {
      [`friends/${me}/${from}`]: serverTimestamp(),
      [`friends/${from}/${me}`]: serverTimestamp(),
      [`friendRequests/${me}/${from}`]: null,
    })
  } catch (e) {
    throw friendlyError(e)
  }
  await Promise.all([
    remove(ref(db, `friendSent/${from}/${me}`)).catch(() => undefined),
    remove(ref(db, `friendRequests/${from}/${me}`)).catch(() => undefined),
    remove(ref(db, `friendSent/${me}/${from}`)).catch(() => undefined),
  ])
}

export async function removeFriend(me: string, other: string): Promise<void> {
  try {
    await update(ref(db), {
      [`friends/${me}/${other}`]: null,
      [`friends/${other}/${me}`]: null,
    })
  } catch (e) {
    throw friendlyError(e)
  }
}

// ---------- langganan realtime ----------
function derive(v: { f: boolean; s: boolean; r: boolean }): Relation {
  if (v.f) return 'friends'
  if (v.r) return 'pending_received'
  if (v.s) return 'pending_sent'
  return 'none'
}

export function subscribeRelation(me: string, other: string, cb: (r: Relation) => void, onError?: (e: Error) => void): () => void {
  const vals = { f: false, s: false, r: false }
  const ready = { f: false, s: false, r: false }
  const mk = (k: 'f' | 's' | 'r', path: string) =>
    onValue(
      ref(db, path),
      (snap) => {
        vals[k] = snap.exists()
        ready[k] = true
        if (ready.f && ready.s && ready.r) cb(derive(vals))
      },
      (e) => onError?.(e),
    )
  const offs = [mk('f', `friends/${me}/${other}`), mk('s', `friendSent/${me}/${other}`), mk('r', `friendRequests/${me}/${other}`)]
  return () => offs.forEach((o) => o())
}

function subscribeUidList(path: string, cb: (l: UidEntry[]) => void, onError?: (e: Error) => void): () => void {
  return onValue(
    ref(db, path),
    (s) => {
      const out: UidEntry[] = []
      s.forEach((c) => {
        const v = c.val()
        out.push({ uid: c.key as string, ts: typeof v === 'number' ? v : 0 })
      })
      out.sort((a, b) => b.ts - a.ts)
      cb(out)
    },
    (e) => onError?.(e),
  )
}

export type ListKind = 'friends' | 'incoming' | 'sent'
const LIST_PATH: Record<ListKind, string> = { friends: 'friends', incoming: 'friendRequests', sent: 'friendSent' }

/** Daftar uid (teman / permintaan masuk / permintaan terkirim) milik `me`, realtime. */
export function useUidList(me: string, kind: ListKind): { list: UidEntry[] | undefined; error?: string } {
  const [state, setState] = useState<{ list: UidEntry[] | undefined; error?: string }>({ list: undefined })
  useEffect(() => {
    setState({ list: undefined })
    return subscribeUidList(
      `${LIST_PATH[kind]}/${me}`,
      (list) => setState({ list }),
      (e) => setState({ list: [], error: /permission/i.test(e.message) ? FRIEND_ERR : e.message }),
    )
  }, [me, kind])
  return state
}

/** Status hubungan `me` -> `other`. `other` = null untuk akun sendiri (tidak berlangganan). */
export function useRelation(me: string, other: string | null): { rel: Relation | undefined; error?: string } {
  const [state, setState] = useState<{ rel: Relation | undefined; error?: string }>({ rel: undefined })
  useEffect(() => {
    setState({ rel: undefined })
    if (!other || other === me) return
    return subscribeRelation(
      me,
      other,
      (rel) => setState({ rel }),
      (e) => setState({ rel: undefined, error: /permission/i.test(e.message) ? FRIEND_ERR : e.message }),
    )
  }, [me, other])
  return state
}

/** Jumlah permintaan masuk (untuk lencana). */
export function useIncomingCount(me: string): number {
  const { list } = useUidList(me, 'incoming')
  return list?.length ?? 0
}

/** Peta uid -> sedang online, memakai node `presence` yang sudah ada. */
export function useOnlineMap(uids: string[]): Map<string, boolean> {
  const key = useMemo(() => [...new Set(uids)].sort().join('\u0001'), [uids])
  const [online, setOnline] = useState<Record<string, boolean>>({})
  useEffect(() => {
    if (!key) return
    const offs = key.split('\u0001').map((uid) =>
      onValue(
        ref(db, `presence/${uid}`),
        (s) => {
          const on = (s.val() as { state?: string } | null)?.state === 'online'
          setOnline((cur) => (cur[uid] === on ? cur : { ...cur, [uid]: on }))
        },
        () => undefined,
      ),
    )
    return () => offs.forEach((o) => o())
  }, [key])
  return new Map(Object.entries(online))
}

// ---------- cari berdasarkan User ID ----------
/** Mengubah "1470" / "#1470" menjadi "1470". null jika bukan angka. */
export function normalizeUserId(raw: string): string | null {
  const t = raw.trim().replace(/^#/, '').trim()
  if (!/^[0-9]{1,15}$/.test(t)) return null
  return String(Number(t))
}

/** Membuat peta ID publik -> UID untuk akun ini jika belum ada (tidak membuat/ mengubah User ID). */
export async function ensureUserIndex(p: UserProfile): Promise<void> {
  try {
    const r = ref(db, `userIndex/${p.userId}`)
    const snap = await get(r)
    if (!snap.exists()) await set(r, p.uid)
  } catch {
    // diam: pencarian untuk akun ini baru aktif setelah rules terbaru dipublikasikan
  }
}

/** Mengembalikan profile lengkap (tanpa menulis apa pun), atau null jika tidak ada. */
export async function lookupByUserId(me: UserProfile, raw: string): Promise<UserProfile | null> {
  const id = normalizeUserId(raw)
  if (!id) throw new Error('Masukkan User ID berupa angka, contoh 1470 atau #1470.')
  let uid: string | null = null
  try {
    const s = await get(ref(db, `userIndex/${id}`))
    if (s.exists() && typeof s.val() === 'string') uid = s.val() as string
  } catch (e) {
    throw friendlyError(e)
  }
  if (!uid && isDeveloper(me)) {
    // developer boleh mencari langsung di koleksi users (akun lama yang belum punya indeks)
    uid = await findUserByUserId(me, id)
      .then((f) => f.uid)
      .catch(() => null)
  }
  if (!uid) {
    // akun biasa: query persis satu User ID (rules membolehkan equalTo pada userId, maksimal 2 hasil)
    // sehingga akun yang belum punya entri userIndex tetap bisa ditemukan
    try {
      const qs = await get(query(ref(db, 'users'), orderByChild('userId'), equalTo(Number(id)), limitToFirst(1)))
      qs.forEach((c) => {
        uid = c.key as string
        return true
      })
    } catch {
      /* rules lama: abaikan, hasilnya "tidak ditemukan" */
    }
  }
  if (!uid) return null
  const ps = await get(ref(db, `users/${uid}`))
  if (!ps.exists()) return null
  const p = normalizeProfile(ps.val() as UserProfile)
  if (String(p.userId) !== id) return null
  return p
}
