// Leaderboard XP per periode (harian/mingguan/bulanan).
// Data: xpBoard/{period}/{key}/{uid} = { xp, at }. Nama, foto, level, dan role diambil dari users/{uid} (data yang sudah ada).
import { useEffect, useState } from 'react'
import { increment, limitToLast, onValue, orderByChild, query, ref, serverTimestamp, update } from 'firebase/database'
import { db } from '../firebase/config'
import { PERIODS, periodKey, type Period } from '../lib/board'

export type BoardRow = { uid: string; xp: number }
export type BoardState = { status: 'loading' } | { status: 'ok'; rows: BoardRow[] } | { status: 'error'; message: string }

/**
 * Menambah XP yang baru didapat ke papan harian, mingguan, dan bulanan.
 * Dipanggil TERPISAH setelah XP utama tersimpan dan gagalnya tidak mengganggu XP/level
 * (mis. rules belum dipublikasikan atau sedang offline).
 */
export async function recordBoardXp(uid: string, gained: number): Promise<void> {
  if (!Number.isFinite(gained) || gained < 1) return
  const updates: Record<string, unknown> = {}
  for (const p of PERIODS) {
    const base = `xpBoard/${p}/${periodKey(p)}/${uid}`
    updates[`${base}/xp`] = increment(Math.round(gained))
    updates[`${base}/at`] = serverTimestamp()
  }
  try {
    await update(ref(db), updates)
  } catch {
    /* best-effort */
  }
}

export function subscribeBoard(
  period: Period,
  key: string,
  limit: number,
  cb: (rows: BoardRow[]) => void,
  onError?: (e: Error) => void,
): () => void {
  const q = query(ref(db, `xpBoard/${period}/${key}`), orderByChild('xp'), limitToLast(limit))
  return onValue(
    q,
    (s) => {
      const rows: BoardRow[] = []
      s.forEach((c) => {
        const xp = (c.val() as { xp?: number } | null)?.xp
        if (typeof xp === 'number' && xp > 0) rows.push({ uid: c.key as string, xp })
      })
      cb(rows.sort((a, b) => b.xp - a.xp))
    },
    (e) => onError?.(e),
  )
}

export function useBoard(period: Period, limit: number): BoardState {
  const key = periodKey(period)
  const [state, setState] = useState<BoardState>({ status: 'loading' })
  useEffect(() => {
    setState({ status: 'loading' })
    return subscribeBoard(
      period,
      key,
      limit,
      (rows) => setState({ status: 'ok', rows }),
      (e) => setState({ status: 'error', message: e.message }),
    )
  }, [period, key, limit])
  return state
}
