import {
  endAt,
  equalTo,
  get,
  limitToFirst,
  limitToLast,
  off,
  onChildAdded,
  onChildRemoved,
  onDisconnect,
  onValue,
  orderByChild,
  push,
  query,
  ref,
  remove,
  serverTimestamp,
  set,
  update,
} from 'firebase/database'
import { db } from '../firebase/config'
import { identityOf, sanitizeText } from './identity'
import type { Role, UserProfile } from './userService'

export const CHAT_MAX = 300
/** Public Diskusi hanya menyimpan pesan terbaru sebanyak ini; yang lebih lama dihapus dari database (hemat kuota). Harus sama dengan rules (30). */
export const CHAT_KEEP = 30

export type ChatMessage = {
  id: string
  uid: string
  userId: number
  name: string
  photoURL?: string
  role: Role
  verified?: boolean
  level: number
  clanTag?: string
  text: string
  ts: number
  replyTo?: ReplyRef
  /** Id giveaway Premium yang diumumkan lewat pesan ini (kartu Klaim di bawah teks). */
  gid?: string
}

/** Kutipan pesan yang dibalas (disalin saat mengirim, jadi tetap terbaca walau pesan asli dihapus). */
export type ReplyRef = { id: string; uid: string; name: string; text: string }

const chatRef = () => ref(db, 'globalChat')
const withId = (id: string, v: unknown): ChatMessage => ({ ...(v as Omit<ChatMessage, 'id'>), id })

/** Tambahan yang ditulis ATOMIK bersama pesan (mis. pembuatan giveaway). Dipanggil ulang tiap percobaan supaya angka selalu segar. */
export type ChatExtra = { fields?: Record<string, unknown>; patch?: Record<string, unknown> }

export async function sendChat(
  profile: UserProfile,
  raw: string,
  reply?: ReplyRef | null,
  extra?: () => Promise<ChatExtra>,
): Promise<void> {
  const text = sanitizeText(raw, CHAT_MAX)
  if (!text) throw new Error('Pesan kosong')
  const data: Record<string, unknown> = { ...identityOf(profile), text, ts: serverTimestamp() }
  if (reply) {
    data.replyTo = {
      id: reply.id.slice(0, 60),
      uid: reply.uid.slice(0, 60),
      name: reply.name.slice(0, 40),
      text: reply.text.replace(/\s+/g, ' ').slice(0, 120),
    }
  }
  // Setiap pesan punya nomor urut (seq) yang dicatat di meta/chatHead. Rules memakainya untuk tahu pesan mana yang sudah
  // di luar CHAT_KEEP terbaru, sehingga hanya pesan itu yang boleh dihapus siapa pun.
  let seq = 0
  let sent = false
  for (let attempt = 0; attempt < 4 && !sent; attempt++) {
    const head = await get(ref(db, 'meta/chatHead/seq'))
    seq = (typeof head.val() === 'number' ? (head.val() as number) : 0) + 1
    const key = push(chatRef()).key as string
    try {
      const ex = extra ? await extra() : {}
      await update(ref(db), {
        ...(ex.patch ?? {}),
        [`globalChat/${key}`]: { ...data, ...(ex.fields ?? {}), seq },
        'meta/chatHead': { seq, key, uid: profile.uid },
      })
      sent = true
    } catch (e) {
      // kemungkinan besar bentrok nomor urut dengan pengirim lain di detik yang sama: baca ulang lalu coba lagi
      if (attempt === 3) throw e
    }
  }
  void pruneChat(seq)
}

/** Hapus pesan di luar CHAT_KEEP terbaru. Aman dipanggil kapan saja; kalau ditolak atau gagal, dibiarkan dan dicoba lagi pada pesan berikutnya. */
async function pruneChat(seq: number): Promise<void> {
  if (seq < CHAT_KEEP) return
  try {
    const old = await get(query(chatRef(), orderByChild('seq'), endAt(seq - CHAT_KEEP), limitToFirst(200)))
    if (!old.exists()) return
    const patch: Record<string, null> = {}
    old.forEach((c) => {
      patch[`globalChat/${c.key as string}`] = null
    })
    await update(ref(db), patch)
  } catch {
    /* abaikan: bukan masalah bagi pengirim */
  }
}

export async function deleteChat(id: string): Promise<void> {
  await remove(ref(db, `globalChat/${id}`))
}

/** Realtime listener: `limit` pesan terakhir, lalu setiap pesan baru. */
export function subscribeChat(
  limit: number,
  onAdd: (m: ChatMessage) => void,
  onRemoved: (id: string) => void,
  onError?: (e: Error) => void,
): () => void {
  const q = query(chatRef(), orderByChild('ts'), limitToLast(limit))
  const a = onChildAdded(q, (s) => onAdd(withId(s.key as string, s.val())), (e) => onError?.(e))
  const r = onChildRemoved(q, (s) => onRemoved(s.key as string))
  return () => {
    off(q, 'child_added', a)
    off(q, 'child_removed', r)
  }
}

/** Pesan terbaru saja (untuk preview di Home). */
export function subscribeLatest(cb: (m: ChatMessage | null) => void): () => void {
  const q = query(chatRef(), orderByChild('ts'), limitToLast(1))
  return onValue(
    q,
    (s) => {
      let last: ChatMessage | null = null
      s.forEach((c) => {
        last = withId(c.key as string, c.val())
      })
      cb(last)
    },
    () => cb(null),
  )
}

// ---------- Presence ----------
/** Status online nyata: .info/connected + onDisconnect, dan offline saat aplikasi di background. */
export function startPresence(uid: string): () => void {
  const pref = ref(db, `presence/${uid}`)
  const connRef = ref(db, '.info/connected')
  let connected = false
  const goOnline = () => {
    if (!connected || document.hidden) return
    void onDisconnect(pref)
      .set({ state: 'offline', lastSeen: serverTimestamp() })
      .then(() => set(pref, { state: 'online', lastSeen: serverTimestamp() }))
      .catch(() => undefined)
  }
  const goOffline = () => {
    if (connected) void set(pref, { state: 'offline', lastSeen: serverTimestamp() }).catch(() => undefined)
  }
  const unsubConn = onValue(connRef, (s) => {
    connected = s.val() === true
    goOnline()
  })
  const onVis = () => (document.hidden ? goOffline() : goOnline())
  document.addEventListener('visibilitychange', onVis)
  return () => {
    unsubConn()
    document.removeEventListener('visibilitychange', onVis)
    goOffline()
  }
}

export function subscribeConnected(cb: (c: boolean) => void): () => void {
  return onValue(ref(db, '.info/connected'), (s) => cb(s.val() === true))
}

export function subscribeOnlineCount(cb: (n: number) => void): () => void {
  const q = query(ref(db, 'presence'), orderByChild('state'), equalTo('online'), limitToLast(500))
  return onValue(
    q,
    (s) => {
      let n = 0
      s.forEach((c) => {
        if ((c.val() as { state?: string })?.state === 'online') n++
      })
      cb(n)
    },
    () => cb(0),
  )
}
