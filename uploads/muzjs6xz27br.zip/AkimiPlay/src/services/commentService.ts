import {
  equalTo,
  limitToLast,
  onValue,
  orderByChild,
  push,
  query,
  ref,
  remove,
  serverTimestamp,
  set,
  update,
} from 'firebase/database'
import { db, encodeKey } from '../firebase/config'
import { identityOf, sanitizeText } from './identity'
import type { Role, UserProfile } from './userService'

export const COMMENT_MAX = 500

export type Identity = {
  uid: string
  userId: number
  name: string
  photoURL?: string
  role: Role
  verified?: boolean
  level: number
  clanTag?: string
}

export type Reply = Identity & { id: string; text: string; ts: number; editedAt?: number; replyTo?: string }

export type Comment = Identity & {
  id: string
  text: string
  ts: number
  editedAt?: number
  animeId: string
  episodeId: string
  likes: string[] // uid yang menyukai
  replies: Reply[]
}

const base = (animeId: string) => `comments/${encodeKey(animeId)}`

function parse(id: string, v: Record<string, unknown>): Comment {
  const replies = Object.entries((v.replies as Record<string, Omit<Reply, 'id'>>) ?? {})
    .map(([rid, r]) => ({ ...r, id: rid }) as Reply)
    .sort((a, b) => a.ts - b.ts)
  const { replies: _r, likes: _l, ...rest } = v
  void _r
  void _l
  return {
    ...(rest as unknown as Omit<Comment, 'id' | 'likes' | 'replies'>),
    id,
    likes: Object.keys((v.likes as Record<string, boolean>) ?? {}),
    replies,
  }
}

/** Komentar realtime untuk satu anime + satu episode saja (tidak tercampur dengan episode lain). */
export function subscribeComments(
  animeId: string,
  episodeId: string,
  cb: (list: Comment[]) => void,
  onError?: (e: Error) => void,
): () => void {
  const q = query(ref(db, base(animeId)), orderByChild('episodeId'), equalTo(episodeId), limitToLast(150))
  return onValue(
    q,
    (s) => {
      const list: Comment[] = []
      s.forEach((c) => {
        list.push(parse(c.key as string, c.val() as Record<string, unknown>))
      })
      cb(list)
    },
    (e) => onError?.(e),
  )
}

export async function addComment(p: UserProfile, animeId: string, episodeId: string, raw: string) {
  const text = sanitizeText(raw, COMMENT_MAX)
  if (!text) throw new Error('Komentar kosong')
  const r = push(ref(db, base(animeId)))
  await set(r, { ...identityOf(p), text, animeId, episodeId, ts: serverTimestamp() })
}

export async function addReply(p: UserProfile, animeId: string, commentId: string, raw: string, replyTo?: string) {
  const text = sanitizeText(raw, COMMENT_MAX)
  if (!text) throw new Error('Balasan kosong')
  const r = push(ref(db, `${base(animeId)}/${commentId}/replies`))
  const data: Record<string, unknown> = { ...identityOf(p), text, ts: serverTimestamp() }
  if (replyTo) data.replyTo = replyTo.slice(0, 40)
  await set(r, data)
}

export async function editComment(animeId: string, commentId: string, raw: string, replyId?: string) {
  const text = sanitizeText(raw, COMMENT_MAX)
  if (!text) throw new Error('Teks kosong')
  const path = replyId ? `${base(animeId)}/${commentId}/replies/${replyId}` : `${base(animeId)}/${commentId}`
  await update(ref(db, path), { text, editedAt: serverTimestamp() })
}

export async function deleteComment(animeId: string, commentId: string, replyId?: string) {
  const path = replyId ? `${base(animeId)}/${commentId}/replies/${replyId}` : `${base(animeId)}/${commentId}`
  await remove(ref(db, path))
}

export async function toggleLike(animeId: string, commentId: string, uid: string, liked: boolean) {
  const r = ref(db, `${base(animeId)}/${commentId}/likes/${uid}`)
  if (liked) await remove(r)
  else await set(r, true)
}
