// Paket Premium AkimiPlay. Harga & bonus ada di sini saja; pembayaran lewat Sociabuzz (QRIS / e-wallet),
// lalu developer mengaktifkan Premium + bonus shard secara manual dari Panel Developer setelah bukti bayar dicek.

export type PremiumPlan = {
  id: string
  title: string
  days: number
  /** harga dalam rupiah */
  price: number
  /** bonus AkimiShard yang diberikan developer bersama Premium */
  bonusShard: number
}

/** Bonus 2.500 shard per 30 hari; paket panjang lebih murah per bulan. */
export const PREMIUM_PLANS: PremiumPlan[] = [
  { id: 'm1', title: '1 Bulan', days: 30, price: 5000, bonusShard: 2500 },
  { id: 'm3', title: '3 Bulan', days: 90, price: 14000, bonusShard: 7500 },
  { id: 'm6', title: '6 Bulan', days: 180, price: 27000, bonusShard: 15000 },
  { id: 'y1', title: '1 Tahun', days: 365, price: 50000, bonusShard: 30000 },
]

/** Halaman dukungan Sociabuzz AkimiPlay (dibuka di popup dalam aplikasi, bukan browser). */
export const SOCIABUZZ_URL = 'https://sociabuzz.com/stark_akimiplay/support'
/** WhatsApp admin untuk kirim bukti pembayaran (format internasional, tanpa +). */
export const WA_NUMBER = '6287769840134'

export const rupiah = (n: number) => `Rp ${Math.round(n).toLocaleString('id-ID')}`

/** Persen hemat dibanding membeli paket 1 bulan berulang kali (0 untuk paket 1 bulan). */
export function savingPercent(p: PremiumPlan): number {
  const base = PREMIUM_PLANS[0]
  const full = (base.price * p.days) / base.days
  return Math.max(0, Math.round((1 - p.price / full) * 100))
}

export type PayerInfo = { uid: string; userId: number | string; name: string; email: string }

/** Teks WhatsApp yang sudah terisi agar admin langsung tahu akun & paketnya. */
export function waMessage(payer: PayerInfo, plan?: PremiumPlan): string {
  const lines = ['Halo admin AkimiPlay, saya sudah bayar Premium.']
  if (plan) {
    lines.push(`Paket: ${plan.title} (${plan.days} hari) - ${rupiah(plan.price)}`)
    lines.push(`Bonus: ${plan.bonusShard.toLocaleString('id-ID')} AkimiShard`)
  }
  lines.push(`UID: ${payer.uid}`, `ID: #${payer.userId}`, `Nama: ${payer.name}`, 'Bukti pembayaran saya lampirkan di chat ini.')
  return lines.join('\n')
}
