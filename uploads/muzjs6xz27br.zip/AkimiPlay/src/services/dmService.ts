// Chat pribadi antar teman (Realtime Database).
//
//   dm/{uid}/{peerUid}/{mid} = { uid: pengirim, text, ts }   -> kotak masuk milik `uid`
//   dmRead/{uid}/{peerUid}   = ts terakhir `uid` membuka chat dengan `peerUid`
//
// Setiap pesan ditulis ke DUA salinan dalam satu update atomik (salinan pengirim dan salinan penerima).
// Security Rules hanya mengizinkan penulisan jika kedua akun saling berteman.
import { useEffect, useMemo, useState } from 'react'
import {
  endAt,
  get,
  limitToLast,
  off,
  onChildAdded,
  onChildRemoved,
  onValue,
  orderByChild,
  push,
  query,
  ref,
  serverTimestamp,
  set,
  update,
} from 'firebase/database'
import { db } from '../firebase/config'
import { sanitizeText } from './identity'

export const DM_MAX = 300

export type DmMessage = { id: string; uid: string; text: string; ts: number }

const DM_ERR = 'Chat pribadi belum aktif. Publikasikan database.rules.json terbaru di Firebase.'

function dmError(e: unknown): Error {
  const m = e instanceof Error ? e.message : String(e)
  if (/permission/i.test(m)) return new Error('Pesan ditolak. Pastikan kalian masih berteman, atau publikasikan rules terbaru.')
  return e instanceof Error ? e : new Error(m)
}

const box = (me: string, peer: string) => ref(db, `dm/${me}/${peer}`)
const withId = (id: string, v: unknown): DmMessage => ({ ...(v as Omit<DmMessage, 'id'>), id })

export async function sendDm(me: string, peer: string, raw: string): Promise<void> {
  const text = sanitizeText(raw, DM_MAX)
  if (!text) throw new Error('Pesan kosong')
  const mid = push(box(me, peer)).key as string
  const data = { uid: me, text, ts: serverTimestamp() }
  try {
    await update(ref(db), {
      [`dm/${me}/${peer}/${mid}`]: data,
      [`dm/${peer}/${me}/${mid}`]: data,
    })
  } catch (e) {
    throw dmError(e)
  }
}

/** Pesan milik sendiri dihapus di kedua sisi; pesan teman hanya hilang dari kotak masukmu. */
export async function deleteDm(me: string, peer: string, m: DmMessage): Promise<void> {
  const patch: Record<string, null> = { [`dm/${me}/${peer}/${m.id}`]: null }
  if (m.uid === me) patch[`dm/${peer}/${me}/${m.id}`] = null
  try {
    await update(ref(db), patch)
  } catch (e) {
    throw dmError(e)
  }
}

export function subscribeDm(
  me: string,
  peer: string,
  limit: number,
  onAdd: (m: DmMessage) => void,
  onRemoved: (id: string) => void,
  onError?: (e: Error) => void,
): () => void {
  const q = query(box(me, peer), orderByChild('ts'), limitToLast(limit))
  const a = onChildAdded(q, (s) => onAdd(withId(s.key as string, s.val())), (e) => onError?.(e))
  const r = onChildRemoved(q, (s) => onRemoved(s.key as string))
  return () => {
    off(q, 'child_added', a)
    off(q, 'child_removed', r)
  }
}

export async function loadOlderDm(me: string, peer: string, beforeTs: number, count = 30): Promise<DmMessage[]> {
  const q = query(box(me, peer), orderByChild('ts'), endAt(beforeTs), limitToLast(count + 1))
  const snap = await get(q)
  const out: DmMessage[] = []
  snap.forEach((c) => {
    out.push(withId(c.key as string, c.val()))
  })
  return out
}

/** Tandai chat dengan `peer` sudah dibaca. */
export async function markDmRead(me: string, peer: string): Promise<void> {
  await set(ref(db, `dmRead/${me}/${peer}`), serverTimestamp()).catch(() => undefined)
}

export type DmPreview = { last: DmMessage | null; unread: boolean }

/** Pesan terakhir + status belum dibaca untuk satu teman, realtime. */
export function useDmPreview(me: string, peer: string): DmPreview | undefined {
  const [last, setLast] = useState<DmMessage | null | undefined>(undefined)
  const [readAt, setReadAt] = useState<number | undefined>(undefined)
  useEffect(() => {
    setLast(undefined)
    setReadAt(undefined)
    const q = query(box(me, peer), orderByChild('ts'), limitToLast(1))
    const offLast = onValue(
      q,
      (s) => {
        let m: DmMessage | null = null
        s.forEach((c) => {
          m = withId(c.key as string, c.val())
        })
        setLast(m)
      },
      () => setLast(null),
    )
    const offRead = onValue(
      ref(db, `dmRead/${me}/${peer}`),
      (s) => setReadAt(typeof s.val() === 'number' ? (s.val() as number) : 0),
      () => setReadAt(0),
    )
    return () => {
      offLast()
      offRead()
    }
  }, [me, peer])
  return useMemo(() => {
    if (last === undefined || readAt === undefined) return undefined
    return { last, unread: !!last && last.uid !== me && last.ts > readAt }
  }, [last, readAt, me])
}

export { DM_ERR }
