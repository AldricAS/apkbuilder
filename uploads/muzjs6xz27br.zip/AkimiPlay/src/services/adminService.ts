// Alat developer: Premium, ubah User ID, ubah role. Penjagaan sebenarnya ada di database.rules.json
// (hanya role developer, tidak untuk akun sendiri, semua perubahan atomik); pengecekan di sini agar pesan error jelas.
import { equalTo, get, limitToFirst, orderByChild, query, ref, update } from 'firebase/database'
import { db } from '../firebase/config'
import { isDeveloper } from './broadcastService'
import type { Role, UserProfile } from './userService'

export type AdminTarget = {
  uid: string
  name: string
  userId: number | null
  role: Role
  premiumUntil: number | null
  shard: number
}

function assertDev(me: UserProfile) {
  if (!isDeveloper(me)) throw new Error('Hanya developer yang boleh memakai alat ini.')
}
function assertOther(me: UserProfile, uid: string) {
  if (me.uid === uid) throw new Error('Tidak bisa dilakukan pada akun sendiri.')
}
function permissionHint(e: unknown): Error {
  const m = e instanceof Error ? e.message : String(e)
  return /permission/i.test(m) ? new Error('Ditolak oleh aturan database. Pastikan rules terbaru sudah dipublikasikan.') : e instanceof Error ? e : new Error(m)
}

/** Cari user berdasarkan UID Firebase (salin dari halaman Akun). */
export async function findTarget(me: UserProfile, uid: string): Promise<AdminTarget> {
  assertDev(me)
  const id = uid.trim()
  if (!id || /[.#$[\]/]/.test(id)) throw new Error('UID tidak valid.')
  const snap = await get(ref(db, `users/${id}`))
  if (!snap.exists()) throw new Error('User dengan UID itu tidak ditemukan.')
  const u = snap.val() as Partial<UserProfile>
  return {
    uid: id,
    name: u.username?.trim() || u.displayName || id,
    userId: typeof u.userId === 'number' ? u.userId : null,
    role: (u.role ?? 'user') as Role,
    premiumUntil: typeof u.premiumUntil === 'number' ? u.premiumUntil : null,
    shard: typeof u.shard === 'number' ? u.shard : 0,
  }
}

// ---------- Premium ----------
export type PremiumUnit = 'day' | 'month' | 'year'
export const PREMIUM_UNIT_LABEL: Record<PremiumUnit, string> = { day: 'Hari', month: 'Bulan', year: 'Tahun' }
/** Batas total masa Premium dari sekarang (sama dengan rules: 3650 hari). */
export const PREMIUM_MAX_DAYS = 3650
const DAY = 86_400_000

/** Menambah durasi pada waktu `from` (hari = 24 jam; bulan & tahun mengikuti kalender). */
export function addDuration(from: number, amount: number, unit: PremiumUnit): number {
  if (unit === 'day') return from + amount * DAY
  const d = new Date(from)
  d.setMonth(d.getMonth() + (unit === 'year' ? amount * 12 : amount))
  return d.getTime()
}

/** Sisa masa Premium dalam teks singkat, mis. "12 hari" atau "3 bulan 2 hari". */
export function remainingText(until: number | null, now = Date.now()): string {
  if (!until || until <= now) return 'tidak aktif'
  const days = Math.ceil((until - now) / DAY)
  if (days < 60) return `${days} hari`
  const months = Math.floor(days / 30)
  return months >= 24 ? `${(months / 12).toFixed(1).replace('.0', '')} tahun` : `${months} bulan ${days - months * 30} hari`
}

/**
 * Memberi Premium: hanya mengisi masa berlaku (premiumUntil), ROLE TIDAK DIUBAH. Premium bukan role.
 * Role apa pun tetap dengan badge dan centangnya; badge Premium baru tampil bila role-nya user biasa.
 * Jika Premium masih aktif, durasi DITAMBAHKAN di belakang masa yang tersisa.
 */
export async function grantPremium(me: UserProfile, uid: string, amount: number, unit: PremiumUnit): Promise<AdminTarget> {
  assertDev(me)
  assertOther(me, uid)
  if (!Number.isInteger(amount) || amount < 1 || amount > 3650) throw new Error('Jumlah harus bilangan bulat 1 sampai 3650.')
  const cur = await findTarget(me, uid)
  const now = Date.now()
  const base = cur.premiumUntil && cur.premiumUntil > now ? cur.premiumUntil : now
  const until = addDuration(base, amount, unit)
  if (until > now + PREMIUM_MAX_DAYS * DAY) throw new Error(`Total masa Premium maksimal ${PREMIUM_MAX_DAYS} hari (10 tahun) dari sekarang.`)
  const patch: Record<string, unknown> = { [`users/${uid}/premiumUntil`]: until }
  // sisa data lama: role "premium" yang tersimpan dikembalikan jadi user (role tampilan diurus otomatis)
  if (cur.role === 'premium') patch[`users/${uid}/role`] = 'user'
  try {
    await update(ref(db), patch)
  } catch (e) {
    throw permissionHint(e)
  }
  return findTarget(me, uid)
}

/** Mencabut Premium sekarang juga (role tidak disentuh). */
export async function revokePremium(me: UserProfile, uid: string): Promise<AdminTarget> {
  assertDev(me)
  assertOther(me, uid)
  const cur = await findTarget(me, uid)
  if (!cur.premiumUntil) throw new Error('User ini tidak punya data Premium.')
  const patch: Record<string, unknown> = { [`users/${uid}/premiumUntil`]: null }
  if (cur.role === 'premium') patch[`users/${uid}/role`] = 'user' // sisa data lama
  try {
    await update(ref(db), patch)
  } catch (e) {
    throw permissionHint(e)
  }
  return findTarget(me, uid)
}

// ---------- Ubah User ID ----------
export const normalizeNewId = (raw: string): number | null => {
  const t = raw.trim().replace(/^#/, '').trim()
  if (!/^[0-9]{1,9}$/.test(t)) return null
  const n = Number(t)
  return n >= 1 ? n : null
}

/**
 * Mengubah User ID publik (#nomor). Syarat: ID belum dipakai siapa pun dan tidak lebih besar dari counter pendaftaran
 * (supaya akun baru nanti tidak pernah mendapat ID yang sama). Ketiga penulisan (profil, indeks baru, indeks lama) dalam SATU update.
 * Pesan/komentar lama tetap menyimpan ID lama; pesan baru memakai ID baru.
 */
export async function changeUserId(me: UserProfile, uid: string, raw: string): Promise<AdminTarget> {
  assertDev(me)
  const next = normalizeNewId(raw)
  if (next === null) throw new Error('Masukkan ID berupa angka, contoh #10.')
  const cur = await findTarget(me, uid)
  if (cur.userId === next) throw new Error('User ini sudah memakai ID itu.')
  const counter = await get(ref(db, 'meta/userIdCounter/value'))
  const max = typeof counter.val() === 'number' ? (counter.val() as number) : 0
  if (next > max) throw new Error(`ID maksimal #${max} (ID di atas itu akan dipakai pendaftar baru).`)
  const [idx, used] = await Promise.all([
    get(ref(db, `userIndex/${next}`)),
    get(query(ref(db, 'users'), orderByChild('userId'), equalTo(next), limitToFirst(1))),
  ])
  if (idx.exists() || used.exists()) throw new Error(`ID #${next} sudah dipakai user lain.`)
  const patch: Record<string, unknown> = { [`users/${uid}/userId`]: next, [`userIndex/${next}`]: uid }
  if (cur.userId !== null) patch[`userIndex/${cur.userId}`] = null
  try {
    await update(ref(db), patch)
  } catch (e) {
    throw permissionHint(e)
  }
  return findTarget(me, uid)
}

// ---------- Ubah role ----------
/** Teks role yang bisa diketik. "premium" tidak ada: Premium bukan role (tab Shard → Premium). */
export const ASSIGNABLE_ROLES: Role[] = ['user', 'beta', 'moderator', 'admin', 'developer', 'special', 'raja_iblis', 'maou']

export function parseRole(raw: string): Role | 'premium' | null {
  const t = raw.trim().toLowerCase().replace(/[\s-]+/g, '_')
  if (t === 'premium') return 'premium'
  const alias: Record<string, Role> = { raja: 'raja_iblis', iblis: 'raja_iblis', dev: 'developer', mod: 'moderator' }
  const r = (alias[t] ?? t) as Role
  return ASSIGNABLE_ROLES.includes(r) ? r : null
}

export async function changeRole(me: UserProfile, uid: string, raw: string): Promise<{ target: AdminTarget; note?: string }> {
  assertDev(me)
  assertOther(me, uid)
  const parsed = parseRole(raw)
  if (parsed === null) throw new Error(`Role tidak dikenal. Pilihan: ${ASSIGNABLE_ROLES.join(', ')}.`)
  if (parsed === 'premium') throw new Error('Premium bukan role. Berikan lewat tab Shard → Premium; role orang itu tidak berubah.')
  const cur = await findTarget(me, uid)
  const next: Role = parsed
  let note: string | undefined
  if (cur.role === next) throw new Error(`User ini sudah ber-role ${next}.`)
  // Premium aktif tetap berjalan; badge-nya muncul sendiri bila rolenya user biasa
  if (next === 'user' && cur.premiumUntil && cur.premiumUntil > Date.now()) note = 'Role jadi user. Premium-nya masih aktif, jadi badge Premium tampil.'
  try {
    await update(ref(db), { [`users/${uid}/role`]: next })
  } catch (e) {
    throw permissionHint(e)
  }
  return { target: await findTarget(me, uid), note }
}
