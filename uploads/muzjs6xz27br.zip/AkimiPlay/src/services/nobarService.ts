// Nobar (nonton bareng) global.
//
// Data (Realtime Database), semua dikunci per OWNER (uid pembuat room; satu owner = satu room aktif):
//   nobarRooms/{ownerUid}            data room + status putar (playing, pos, at). Hanya owner yang boleh menulis.
//   nobarSlots/{ownerUid}/{1..19}    slot anggota (uid). Node ini yang membatasi jumlah orang: 1 owner + 19 anggota = 20.
//   nobarMembers/{ownerUid}/{uid}    anggota yang sedang ada di room (identitas disalin, dicocokkan rules dengan /users)
//   nobarKicks/{ownerUid}/{uid}      daftar yang di-kick owner: TIDAK bisa masuk lagi ke room milik owner itu
//   nobarChat/{ownerUid}/{id}        komentar di dalam room (hanya owner + anggota yang boleh baca/tulis)
//   nobarRate/{ownerUid}/{uid}       penanda jeda antar komentar (dijaga rules)
//
// Semua angka di bawah HARUS sama dengan database.rules.json.
import { useEffect, useState } from 'react'
import {
  get,
  limitToLast,
  off,
  onChildAdded,
  onChildRemoved,
  onDisconnect,
  onValue,
  orderByChild,
  push,
  query,
  ref,
  serverTimestamp,
  set,
  update,
} from 'firebase/database'
import { db } from '../firebase/config'
import { identityOf, sanitizeText } from './identity'
import { serverNow } from './serverTime'

export { serverNow }
import { isPremiumActive, type Role, type UserProfile } from './userService'

/** Total orang di satu room, TERMASUK owner. */
export const NOBAR_MAX = 20
/** Slot anggota (di luar owner). */
export const NOBAR_SLOTS = NOBAR_MAX - 1
export const NOBAR_CHAT_MAX = 200
/** Tampilkan komentar terbaru saja. */
export const NOBAR_CHAT_KEEP = 80
/** Jeda minimal antar komentar (ms). Rules memakai 1200. */
export const NOBAR_CHAT_GAP_MS = 1500
/** Jeda minimal antar tulisan status putar owner (ms). Rules memakai 250. */
export const NOBAR_WRITE_GAP_MS = 600
/** Owner terputus lebih lama dari ini = room dianggap mati dan boleh dihapus siapa pun. Rules memakai 180000. */
export const NOBAR_STALE_MS = 180_000
/** Selisih posisi (detik) yang masih dianggap sinkron. */
export const NOBAR_DRIFT_PLAYING = 2.5
export const NOBAR_DRIFT_PAUSED = 0.7

/** Siapa yang boleh MEMBUAT room: Premium aktif atau role selain "user". Role tampilan 'premium' sudah mencakup Premium aktif. */
export const canHostNobar = (p: { role: Role } | null | undefined): boolean => !!p && p.role !== 'user'

export type NobarRoom = {
  ownerUid: string
  ownerUserId: number
  ownerName: string
  ownerPhoto?: string
  /** role asli di database */
  ownerRole: Role
  ownerVerified?: boolean
  ownerPremium: boolean
  animeId: string
  animeTitle: string
  poster?: string
  /** episode yang sedang diputar */
  ep: string
  epNo: number
  playing: boolean
  /** posisi (detik) pada saat `at` */
  pos: number
  /** waktu SERVER saat status putar terakhir ditulis */
  at: number
  createdAt: number
  /** false = owner sedang terputus */
  online: boolean
}

export type NobarMember = {
  uid: string
  userId: number
  name: string
  photoURL?: string
  role: Role
  verified?: boolean
  level: number
  slot: number
  joinedAt: number
}

export type NobarMsg = {
  id: string
  uid: string
  userId: number
  name: string
  photoURL?: string
  role: Role
  verified?: boolean
  level: number
  clanTag?: string
  text: string
  ts: number
  replyTo?: { id: string; uid: string; name: string; text: string }
}

const roomsRef = () => ref(db, 'nobarRooms')
const roomRef = (owner: string) => ref(db, `nobarRooms/${owner}`)

/** Posisi (detik) yang seharusnya sedang diputar menurut status room. */
export function expectedPos(r: Pick<NobarRoom, 'playing' | 'pos' | 'at'>): number {
  if (!r.playing) return Math.max(0, r.pos)
  return Math.max(0, r.pos + Math.max(0, (serverNow() - r.at) / 1000))
}

/** Room yang owner-nya terputus terlalu lama (tinggal menunggu dibersihkan). */
export const isRoomStale = (r: NobarRoom): boolean => r.online === false && serverNow() - r.at > NOBAR_STALE_MS

// ---------- baca ----------
function parseRoom(v: unknown): NobarRoom | null {
  if (!v || typeof v !== 'object') return null
  const r = v as Partial<NobarRoom>
  if (typeof r.ownerUid !== 'string' || typeof r.animeId !== 'string' || typeof r.ep !== 'string') return null
  return {
    ownerUid: r.ownerUid,
    ownerUserId: Number(r.ownerUserId) || 0,
    ownerName: String(r.ownerName ?? ''),
    ownerPhoto: r.ownerPhoto,
    ownerRole: (r.ownerRole ?? 'user') as Role,
    ownerVerified: !!r.ownerVerified,
    ownerPremium: !!r.ownerPremium,
    animeId: r.animeId,
    animeTitle: String(r.animeTitle ?? ''),
    poster: r.poster,
    ep: r.ep,
    epNo: Number(r.epNo) || 0,
    playing: r.playing === true,
    pos: Number(r.pos) || 0,
    at: Number(r.at) || 0,
    createdAt: Number(r.createdAt) || 0,
    online: r.online !== false,
  }
}

/** Semua room aktif (terbaru dulu). */
export function subscribeRooms(cb: (rooms: NobarRoom[]) => void, onError?: (e: Error) => void): () => void {
  const q = query(roomsRef(), orderByChild('createdAt'), limitToLast(40))
  return onValue(
    q,
    (s) => {
      const out: NobarRoom[] = []
      s.forEach((c) => {
        const r = parseRoom(c.val())
        if (r) out.push(r)
      })
      cb(out.reverse())
    },
    (e) => onError?.(e),
  )
}

/** Jumlah anggota (tanpa owner) per room. */
export function subscribeSlotCounts(cb: (counts: Record<string, number>) => void): () => void {
  return onValue(
    ref(db, 'nobarSlots'),
    (s) => {
      const out: Record<string, number> = {}
      s.forEach((c) => {
        out[c.key as string] = c.numChildren()
      })
      cb(out)
    },
    () => cb({}),
  )
}

/** undefined = memuat, null = room tidak ada (sudah dihentikan). */
export function useNobarRoom(owner: string | undefined): NobarRoom | null | undefined {
  const [room, setRoom] = useState<NobarRoom | null | undefined>(undefined)
  useEffect(() => {
    if (!owner) {
      setRoom(undefined)
      return
    }
    setRoom(undefined)
    return onValue(
      roomRef(owner),
      (s) => setRoom(s.exists() ? parseRoom(s.val()) : null),
      () => setRoom(null),
    )
  }, [owner])
  return room
}

export function useNobarMembers(owner: string | undefined): NobarMember[] {
  const [list, setList] = useState<NobarMember[]>([])
  useEffect(() => {
    if (!owner) {
      setList([])
      return
    }
    return onValue(
      ref(db, `nobarMembers/${owner}`),
      (s) => {
        const out: NobarMember[] = []
        s.forEach((c) => {
          out.push(c.val() as NobarMember)
        })
        out.sort((a, b) => (a.joinedAt || 0) - (b.joinedAt || 0))
        setList(out)
      },
      () => setList([]),
    )
  }, [owner])
  return list
}

// ---------- aksi owner ----------
export type NobarAnime = { id: string; title: string; poster?: string }
export type NobarEpisode = { id: string; number: number }

function animeFields(a: NobarAnime): Record<string, unknown> {
  const out: Record<string, unknown> = { animeId: a.id.slice(0, 200), animeTitle: (a.title || 'Tanpa judul').slice(0, 200) }
  out.poster = a.poster && /^https:\/\/[^\s]+$/i.test(a.poster) && a.poster.length <= 500 ? a.poster : null
  return out
}

/** Hentikan room (owner) atau bersihkan room yatim: room, slot, anggota, komentar, penanda jeda. Kick TETAP disimpan. */
export async function stopRoom(owner: string): Promise<void> {
  await update(ref(db), {
    [`nobarRooms/${owner}`]: null,
  })
  await update(ref(db), {
    [`nobarSlots/${owner}`]: null,
    [`nobarMembers/${owner}`]: null,
    [`nobarChat/${owner}`]: null,
    [`nobarRate/${owner}`]: null,
  })
}

/** Buat room baru. Room lama milik owner (kalau ada) dihapus dulu. */
export async function createRoom(p: UserProfile, anime: NobarAnime, ep: NobarEpisode): Promise<void> {
  if (!canHostNobar(p)) throw new Error('Membuat nobar hanya untuk Premium atau role khusus')
  await stopRoom(p.uid).catch(() => undefined)
  const id = identityOf(p)
  const room: Record<string, unknown> = {
    ownerUid: p.uid,
    ownerUserId: p.userId,
    ownerName: id.name,
    ownerRole: id.role,
    ownerVerified: !!p.verified,
    // harus sama dengan rules: Premium aktif menurut users/{uid}/premiumUntil
    ownerPremium: isPremiumActive(p),
    ...animeFields(anime),
    ep: ep.id.slice(0, 300),
    epNo: ep.number,
    playing: false,
    pos: 0,
    at: serverTimestamp(),
    createdAt: serverTimestamp(),
    online: true,
  }
  if (p.photoURL) room.ownerPhoto = p.photoURL
  await set(roomRef(p.uid), room)
}

/** Ganti anime yang ditonton (owner). Posisi kembali ke 0. */
export async function changeRoomAnime(owner: string, anime: NobarAnime, ep: NobarEpisode): Promise<void> {
  await update(roomRef(owner), {
    ...animeFields(anime),
    ep: ep.id.slice(0, 300),
    epNo: ep.number,
    playing: false,
    pos: 0,
    at: serverTimestamp(),
  })
}

export type PlaybackPatch = { playing?: boolean; pos?: number; ep?: string; epNo?: number; online?: boolean }

/**
 * Penulis status putar milik owner. Menggabungkan perubahan yang berdekatan dan menjaga jeda antar tulisan
 * (rules menolak tulisan lebih rapat dari 250 ms).
 */
export function createPlaybackWriter(owner: string) {
  let last = 0
  let pending: PlaybackPatch | null = null
  let timer: ReturnType<typeof setTimeout> | undefined
  let dead = false

  const flush = () => {
    timer = undefined
    if (dead || !pending) return
    const patch = pending
    pending = null
    last = Date.now()
    const data: Record<string, unknown> = { at: serverTimestamp() }
    if (patch.playing !== undefined) data.playing = patch.playing
    if (patch.pos !== undefined) data.pos = Math.max(0, Math.round(patch.pos * 10) / 10)
    if (patch.ep !== undefined) data.ep = patch.ep.slice(0, 300)
    if (patch.epNo !== undefined) data.epNo = patch.epNo
    if (patch.online !== undefined) data.online = patch.online
    void update(roomRef(owner), data).catch(() => undefined)
  }

  return {
    write(patch: PlaybackPatch) {
      pending = { ...(pending ?? {}), ...patch }
      if (timer) return
      const wait = Math.max(0, NOBAR_WRITE_GAP_MS - (Date.now() - last))
      timer = setTimeout(flush, wait)
    },
    dispose() {
      dead = true
      if (timer) clearTimeout(timer)
    },
  }
}

/**
 * Menandai room online selama owner terhubung. Jika koneksi owner putus (aplikasi ditutup paksa, sinyal hilang),
 * server otomatis menandai room offline; room yang offline lebih dari 3 menit dibersihkan.
 */
export function startHostPresence(owner: string): () => void {
  const connected = ref(db, '.info/connected')
  let disc: ReturnType<typeof onDisconnect> | null = null
  const off = onValue(connected, (s) => {
    if (s.val() !== true) return
    disc = onDisconnect(roomRef(owner))
    void disc
      .update({ online: false, at: serverTimestamp() })
      .then(() => update(roomRef(owner), { online: true, at: serverTimestamp() }))
      .catch(() => undefined)
  })
  return () => {
    off()
    void disc?.cancel().catch(() => undefined)
  }
}

/** Kick anggota: masuk daftar kick (tidak bisa masuk lagi ke room owner ini) dan dikeluarkan dari room. */
export async function kickMember(owner: string, m: Pick<NobarMember, 'uid' | 'slot'>): Promise<void> {
  await update(ref(db), {
    [`nobarKicks/${owner}/${m.uid}`]: { ts: serverTimestamp() },
    [`nobarMembers/${owner}/${m.uid}`]: null,
    [`nobarSlots/${owner}/${m.slot}`]: null,
  })
}

/** Hapus komentar milik siapa pun di room ini (owner). */
export async function deleteNobarMsg(owner: string, id: string): Promise<void> {
  await set(ref(db, `nobarChat/${owner}/${id}`), null)
}

// ---------- aksi anggota ----------
export class NobarError extends Error {
  constructor(
    public code: 'kicked' | 'gone' | 'full' | 'offline' | 'failed',
    message: string,
  ) {
    super(message)
  }
}

const shuffled = (n: number): number[] => {
  const a = Array.from({ length: n }, (_, i) => i + 1)
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

/** Masuk ke room. Mengambil slot kosong secara atomik; kalau bentrok dengan orang lain, coba slot berikutnya. */
export async function joinRoom(p: UserProfile, owner: string): Promise<NobarRoom> {
  if (owner === p.uid) throw new NobarError('failed', 'Ini room kamu sendiri')
  const kicked = await get(ref(db, `nobarKicks/${owner}/${p.uid}`)).catch(() => null)
  if (kicked?.exists()) throw new NobarError('kicked', 'Kamu dikeluarkan owner dan tidak bisa masuk lagi ke room ini')
  const rs = await get(roomRef(owner))
  const room = rs.exists() ? parseRoom(rs.val()) : null
  if (!room) throw new NobarError('gone', 'Nobar ini sudah dihentikan')
  if (isRoomStale(room)) throw new NobarError('offline', 'Owner sedang terputus')

  const mine = await get(ref(db, `nobarMembers/${owner}/${p.uid}`))
  if (mine.exists()) return room

  const used = await get(ref(db, `nobarSlots/${owner}`))
  const taken = new Set<string>()
  used.forEach((c) => {
    taken.add(c.key as string)
  })
  const free = shuffled(NOBAR_SLOTS).filter((n) => !taken.has(String(n)))
  if (!free.length) throw new NobarError('full', `Room penuh (${NOBAR_MAX}/${NOBAR_MAX})`)

  const id = identityOf(p)
  for (const slot of free.slice(0, 6)) {
    const member: Record<string, unknown> = {
      uid: p.uid,
      userId: p.userId,
      name: id.name,
      role: id.role,
      verified: !!p.verified,
      level: p.level,
      slot,
      joinedAt: serverTimestamp(),
    }
    if (p.photoURL) member.photoURL = p.photoURL
    try {
      await update(ref(db), {
        [`nobarSlots/${owner}/${slot}`]: p.uid,
        [`nobarMembers/${owner}/${p.uid}`]: member,
      })
      return room
    } catch {
      // kemungkinan slot itu baru saja diambil orang lain: cek dulu apakah kita malah sudah masuk, lalu coba slot lain
      const again = await get(ref(db, `nobarMembers/${owner}/${p.uid}`)).catch(() => null)
      if (again?.exists()) return room
      const k = await get(ref(db, `nobarKicks/${owner}/${p.uid}`)).catch(() => null)
      if (k?.exists()) throw new NobarError('kicked', 'Kamu dikeluarkan owner dan tidak bisa masuk lagi ke room ini')
      const r = await get(roomRef(owner)).catch(() => null)
      if (r && !r.exists()) throw new NobarError('gone', 'Nobar ini sudah dihentikan')
    }
  }
  throw new NobarError('full', 'Room penuh atau sedang ramai, coba lagi sebentar')
}

/** Keluar dari room (anggota). */
export async function leaveRoom(owner: string, uid: string): Promise<void> {
  const s = await get(ref(db, `nobarMembers/${owner}/${uid}`))
  const slot = s.exists() ? (s.val() as NobarMember).slot : undefined
  const patch: Record<string, null> = { [`nobarMembers/${owner}/${uid}`]: null }
  if (typeof slot === 'number') patch[`nobarSlots/${owner}/${slot}`] = null
  await update(ref(db), patch)
}

/**
 * Anggota: jika koneksi putus (aplikasi ditutup paksa), server otomatis mengeluarkan anggota dari room
 * supaya slotnya tidak tertahan.
 */
export function armMemberCleanup(owner: string, uid: string, slot: number): () => void {
  const a = onDisconnect(ref(db, `nobarMembers/${owner}/${uid}`))
  const b = onDisconnect(ref(db, `nobarSlots/${owner}/${slot}`))
  void a.remove().catch(() => undefined)
  void b.remove().catch(() => undefined)
  return () => {
    void a.cancel().catch(() => undefined)
    void b.cancel().catch(() => undefined)
  }
}

/** Status keanggotaan saya di room ini (untuk mendeteksi kena kick / keluar). */
export function subscribeMyMembership(owner: string, uid: string, cb: (m: NobarMember | null) => void): () => void {
  return onValue(
    ref(db, `nobarMembers/${owner}/${uid}`),
    (s) => cb(s.exists() ? (s.val() as NobarMember) : null),
    () => cb(null),
  )
}

export async function isKicked(owner: string, uid: string): Promise<boolean> {
  try {
    return (await get(ref(db, `nobarKicks/${owner}/${uid}`))).exists()
  } catch {
    return false
  }
}

/** Bersihkan room yang owner-nya sudah terputus lebih dari 3 menit (siapa pun boleh; ditolak rules kalau belum waktunya). */
export async function reapRoom(owner: string): Promise<void> {
  try {
    await update(ref(db), { [`nobarRooms/${owner}`]: null })
  } catch {
    return
  }
  await stopRoom(owner).catch(() => undefined)
}

// ---------- komentar ----------
export async function sendNobarMsg(
  p: UserProfile,
  owner: string,
  raw: string,
  reply?: { id: string; uid: string; name: string; text: string } | null,
): Promise<void> {
  const text = sanitizeText(raw, NOBAR_CHAT_MAX)
  if (!text) throw new Error('Pesan kosong')
  const data: Record<string, unknown> = { ...identityOf(p), text, ts: serverTimestamp() }
  if (reply) {
    data.replyTo = {
      id: reply.id.slice(0, 60),
      uid: reply.uid.slice(0, 60),
      name: reply.name.slice(0, 40),
      text: reply.text.replace(/\s+/g, ' ').slice(0, 120),
    }
  }
  const key = push(ref(db, `nobarChat/${owner}`)).key as string
  await update(ref(db), {
    [`nobarChat/${owner}/${key}`]: data,
    [`nobarRate/${owner}/${p.uid}`]: serverTimestamp(),
  })
}

export function subscribeNobarChat(
  owner: string,
  onAdd: (m: NobarMsg) => void,
  onRemoved: (id: string) => void,
  onError?: (e: Error) => void,
): () => void {
  const q = query(ref(db, `nobarChat/${owner}`), orderByChild('ts'), limitToLast(NOBAR_CHAT_KEEP))
  const a = onChildAdded(q, (s) => onAdd({ ...(s.val() as Omit<NobarMsg, 'id'>), id: s.key as string }), (e) => onError?.(e))
  const r = onChildRemoved(q, (s) => onRemoved(s.key as string))
  return () => {
    off(q, 'child_added', a)
    off(q, 'child_removed', r)
  }
}
