// Sinkronisasi favorit & histori ke Realtime Database (/userData/{uid}) agar ikut berpindah antar perangkat.
// Penyimpanan lokal tetap jadi sumber utama saat offline.
import { get, onValue, ref, set } from 'firebase/database'
import { db, encodeKey } from '../firebase/config'
import { favoritesStore, historyStore } from '../storage/stores'
import type { FavEntry, HistoryEntry } from '../types'

const clean = <T,>(o: T): T => JSON.parse(JSON.stringify(o))

export function startCloudSync(uid: string): () => void {
  const favRef = ref(db, `userData/${uid}/favorites`)
  const hisRef = ref(db, `userData/${uid}/history`)
  let stopped = false
  let applying = false
  const timers: Array<ReturnType<typeof setTimeout>> = []
  const unsubs: Array<() => void> = []

  const toMap = <T extends { id?: string; animeId?: string }>(list: T[]) =>
    Object.fromEntries(list.map((x) => [encodeKey((x.id ?? x.animeId) as string), clean(x)]))
  const values = <T,>(v: unknown): T[] => (v && typeof v === 'object' ? (Object.values(v) as T[]) : [])

  const mergeHistory = (a: HistoryEntry[], b: HistoryEntry[]): HistoryEntry[] => {
    const m = new Map<string, HistoryEntry>()
    for (const h of [...a, ...b]) {
      const cur = m.get(h.animeId)
      if (!cur || h.updatedAt > cur.updatedAt) m.set(h.animeId, h)
    }
    return [...m.values()].sort((x, y) => y.updatedAt - x.updatedAt).slice(0, 200)
  }

  const debounce = (idx: number, ms: number, fn: () => void) => {
    clearTimeout(timers[idx])
    timers[idx] = setTimeout(fn, ms)
  }

  const pushFav = () => void set(favRef, toMap(favoritesStore.get())).catch(() => undefined)
  const pushHis = () => void set(hisRef, toMap(historyStore.get())).catch(() => undefined)

  ;(async () => {
    try {
      const [fs, hs] = await Promise.all([get(favRef), get(hisRef)])
      if (stopped) return
      // gabungan awal: favorit = union, histori = entri terbaru per anime
      applying = true
      const localFav = favoritesStore.get()
      const cloudFav = values<FavEntry>(fs.val())
      const fm = new Map<string, FavEntry>()
      for (const f of [...cloudFav, ...localFav]) fm.set(f.id, f)
      favoritesStore.set([...fm.values()].sort((x, y) => y.addedAt - x.addedAt))
      historyStore.set(mergeHistory(historyStore.get(), values<HistoryEntry>(hs.val())))
      applying = false
      pushFav()
      pushHis()
    } catch {
      applying = false
    }
    if (stopped) return

    // perubahan lokal -> cloud
    unsubs.push(
      favoritesStore.subscribe(() => !applying && debounce(0, 1500, pushFav)),
      historyStore.subscribe(() => !applying && debounce(1, 20000, pushHis)),
    )

    // perubahan cloud (perangkat lain) -> lokal
    const offFav = onValue(favRef, (s) => {
      const remote = values<FavEntry>(s.val()).sort((x, y) => y.addedAt - x.addedAt)
      const local = favoritesStore.get()
      const same = remote.length === local.length && remote.every((r) => local.some((l) => l.id === r.id))
      if (!same) {
        applying = true
        favoritesStore.set(remote)
        applying = false
      }
    })
    const offHis = onValue(hisRef, (s) => {
      const local = historyStore.get()
      const merged = mergeHistory(local, values<HistoryEntry>(s.val()))
      if (JSON.stringify(merged) !== JSON.stringify(local)) {
        applying = true
        historyStore.set(merged)
        applying = false
      }
    })
    unsubs.push(offFav, offHis)
  })()

  return () => {
    stopped = true
    timers.forEach(clearTimeout)
    unsubs.forEach((u) => u())
    // kirim perubahan terakhir sebelum berhenti
    if (!applying) {
      pushHis()
    }
  }
}
