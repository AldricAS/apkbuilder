// AkimiGame: Dino Run - data pemain.
//
// Semua data penting ada di Realtime Database `dino_game/{uid}` dan DIJAGA OLEH database.rules.json (uid Firebase = identitas pemain):
//   own/{skinId}   jumlah salinan (hanya bertambah lewat hasil undian yang dihitung server, berkurang lewat jual)
//   selected       skin yang dipakai (-1 = avatar netral, bukan Dino)
//   daily          {d: tanggal WIB, n: game hari ini, t: jam server}   maksimal 10 per hari, dihitung dari jam SERVER
//   run            {t, sel, sc?, e?}   satu permainan: skor dan hadiah hanya bisa ditulis sekali, dibatasi laju waktu server
//   best, total    rekor & total skor (hanya bisa naik lewat run yang valid)
//   spin           {seed, pend, mode, n, pr, pl, pm}   undian: seed = jam server saat bayar, pr/pl/pm = hitungan pity
//   last           hasil undian terakhir (harus cocok dengan rumus server)
//   sell           penanda penjualan duplikat
// Client TIDAK bisa memberi Dino, mengubah rarity, menambah shard, atau mengubah batas harian: rules menolaknya.
// Struktur ini mudah dipindah ke backend VPS: ganti isi fungsi di bawah dengan panggilan API, uid tetap uid Firebase.
import { useEffect, useState } from 'react'
import { get, onValue, ref, serverTimestamp, update } from 'firebase/database'
import { db } from '../firebase/config'
import { serverNow } from './serverTime'

export type Rarity = 'common' | 'rare' | 'legend' | 'mythic'
export type SkinDef = { id: number; key: string; name: string; rarity: Rarity; accent: string; desc: string; fx: string[] }

export const RARITIES: Record<Rarity, { label: string; color: string; glow: string; order: number; ring: string }> = {
  common: { label: 'COMMON', color: '#aab6cc', glow: '#6f7c96', order: 0, ring: 'rgba(170,182,204,.35)' },
  rare: { label: 'RARE', color: '#4fb4ff', glow: '#1a6fd1', order: 1, ring: 'rgba(79,180,255,.5)' },
  legend: { label: 'LEGEND', color: '#ffc83d', glow: '#c98a00', order: 2, ring: 'rgba(255,200,61,.6)' },
  mythic: { label: 'MYTHIC', color: '#ff3df0', glow: '#a312b8', order: 3, ring: 'rgba(255,61,240,.7)' },
}

export const SKINS: SkinDef[] = [
  { id: 0, key: 'classic', name: 'Classic', rarity: 'common', accent: '#a0a6ba', desc: 'Dino abu-abu klasik. Sederhana, lincah, dan jadi awal semua koleksi.', fx: ['Debu lari kecil'] },
  { id: 1, key: 'leafy', name: 'Leafy', rarity: 'common', accent: '#6fe05a', desc: 'Dino hutan dengan jambul dan ekor daun.', fx: ['Debu lari kecil', 'Daun beterbangan'] },
  { id: 2, key: 'sand', name: 'Sand', rarity: 'common', accent: '#e0b070', desc: 'Dino gurun berbintik pasir.', fx: ['Debu lari kecil', 'Butir pasir'] },
  { id: 3, key: 'aqua', name: 'Aqua', rarity: 'common', accent: '#4aa8ff', desc: 'Dino kristal biru jernih.', fx: ['Debu lari kecil', 'Percikan air'] },
  { id: 4, key: 'cyber', name: 'Cyber', rarity: 'rare', accent: '#18d2ff', desc: 'Dino siber dengan visor dan sirkuit neon.', fx: ['Aura neon', 'Percikan listrik', 'Jejak sirkuit'] },
  { id: 5, key: 'frost', name: 'Frost', rarity: 'rare', accent: '#bfe9ff', desc: 'Dino es dengan jambul kristal salju.', fx: ['Aura dingin', 'Serpihan salju', 'Jejak es'] },
  { id: 6, key: 'flame', name: 'Flame', rarity: 'rare', accent: '#ff8a3a', desc: 'Dino api dengan jambul menyala.', fx: ['Aura api', 'Bara beterbangan', 'Jejak api'] },
  { id: 7, key: 'shadow', name: 'Shadow', rarity: 'rare', accent: '#9b6bff', desc: 'Dino bayangan berbalut kabut ungu.', fx: ['Aura bayangan', 'Orb gelap', 'Jejak kabut'] },
  { id: 8, key: 'galaxy', name: 'Galaxy', rarity: 'legend', accent: '#8a7bff', desc: 'Dino dari luar angkasa, bersinar dengan kekuatan galaksi.', fx: ['Aura galaksi', 'Jejak bintang', 'Lompat kosmik', 'Pendaratan gelombang bintang', 'Spawn bintang'] },
  { id: 9, key: 'royal', name: 'Royal', rarity: 'legend', accent: '#f2c23a', desc: 'Dino kerajaan yang gagah, dengan mahkota dan kemuliaan.', fx: ['Aura emas', 'Jejak koin cahaya', 'Lompat bersinar', 'Pendaratan megah', 'Spawn kerajaan'] },
  { id: 10, key: 'mecha', name: 'Mecha', rarity: 'legend', accent: '#3ddcff', desc: 'Dino buatan teknologi tinggi, kuat, cepat, dan tak terkalahkan.', fx: ['Aura reaktor', 'Jejak jet', 'Lompat thruster', 'Pendaratan hidrolik', 'Spawn rakitan'] },
  { id: 11, key: 'akimidragon', name: 'Akimi Dragon', rarity: 'mythic', accent: '#ff3df0', desc: 'Naga legendaris dari dunia Akimi, melambangkan kekuatan, kesetiaan, dan harapan.', fx: ['Aura naga ungu', 'Energi naga', 'Partikel bintang', 'Jejak energi', 'Lompat kolom cahaya', 'Pendaratan gelombang naga', 'Spawn pilar naga', 'Efek idle'] },
]
export const skinOf = (id: number): SkinDef | undefined => SKINS[id]
export const BY_RARITY = (r: Rarity) => SKINS.filter((s) => s.rarity === r)

// ---- angka ekonomi: HARUS sama dengan database.rules.json (tools/add_dino_rules.py) ----
export const DINO = {
  DAILY_MAX: 10,
  SPIN_ONE: 150,
  SPIN_FIVE: 650,
  FIRST_UNLOCK: 50,
  PITY_RARE: 10, // rare (atau lebih) dijamin pada undian ke-10 sejak rare terakhir
  PITY_LEGEND: 80, // legend (atau lebih) dijamin pada undian ke-80
  PITY_MYTHIC: 250, // mythic dijamin pada undian ke-250
  /** peluang dasar per 10.000 (kumulatif): mythic 0,2% - legend 2,3% - rare 17,5% - common 80% */
  ODDS: { mythic: 20, legend: 250, rare: 2000 },
  /** detik skor maksimum per detik yang masuk akal (rules menolak skor di atas ini) */
  MAX_SCORE_RATE: 25,
}
export const SELL_PRICE = (id: number): number => (id < 4 ? 30 : id < 8 ? 90 : id < 11 ? 300 : 900)
/** Hadiah AkimiShard per game = 1 skor : 1 shard, dengan batas per game menurut Dino yang dipakai (pengaman dari skor palsu). Sama dengan rules. */
export const RUN_CAP = (sel: number): number => (sel < 0 ? 1500 : sel < 4 ? 2500 : sel < 8 ? 3500 : sel < 11 ? 5000 : 7500)
export const runReward = (score: number, sel: number): number => Math.min(Math.floor(score), RUN_CAP(sel))

export type Spin = { seed: number; pend: number; mode: number; n: number; pr: number; pl: number; pm: number }
export type RunRec = { t: number; sel: number; sc?: number; e?: number }
export type DinoState = {
  own: Record<number, number>
  selected: number
  best: number
  total: number
  daily: { d: number; n: number; t: number } | null
  run: RunRec | null
  spin: Spin | null
  last: { s: number; rar: number; idx: number; ts: number } | null
}
const EMPTY: DinoState = { own: {}, selected: -1, best: 0, total: 0, daily: null, run: null, spin: null, last: null }

/** Nomor hari WIB (UTC+7) dari jam server. Sama dengan rules. */
export const dayNumber = (ms: number): number => Math.floor((ms + 25_200_000) / 86_400_000)

const num = (v: unknown, d = 0): number => (typeof v === 'number' && Number.isFinite(v) ? v : d)

export function parseDino(v: unknown): DinoState {
  if (!v || typeof v !== 'object') return { ...EMPTY }
  const o = v as Record<string, any>
  const own: Record<number, number> = {}
  if (o.own && typeof o.own === 'object') {
    for (const [k, c] of Object.entries(o.own)) {
      const id = Number(k)
      if (Number.isInteger(id) && id >= 0 && id < SKINS.length && num(c) > 0) own[id] = num(c)
    }
  }
  const sp = o.spin
  return {
    own,
    selected: Number.isInteger(o.selected) && own[o.selected as number] ? (o.selected as number) : -1,
    best: num(o.best),
    total: num(o.total),
    daily: o.daily && typeof o.daily === 'object' ? { d: num(o.daily.d), n: num(o.daily.n), t: num(o.daily.t) } : null,
    run: o.run && typeof o.run === 'object' ? { t: num(o.run.t), sel: num(o.run.sel, -1), sc: o.run.sc === undefined ? undefined : num(o.run.sc), e: o.run.e === undefined ? undefined : num(o.run.e) } : null,
    spin: sp && typeof sp === 'object' ? { seed: num(sp.seed), pend: num(sp.pend), mode: num(sp.mode), n: num(sp.n), pr: num(sp.pr), pl: num(sp.pl), pm: num(sp.pm) } : null,
    last: o.last && typeof o.last === 'object' ? { s: num(o.last.s), rar: num(o.last.rar), idx: num(o.last.idx), ts: num(o.last.ts) } : null,
  }
}

/** undefined = memuat. */
export function useDino(uid: string | undefined): DinoState | undefined {
  const [s, setS] = useState<DinoState | undefined>(undefined)
  useEffect(() => {
    if (!uid) return setS(undefined)
    setS(undefined)
    return onValue(
      ref(db, `dino_game/${uid}`),
      (snap) => setS(parseDino(snap.val())),
      () => setS({ ...EMPTY }),
    )
  }, [uid])
  return s
}

export const ownedCount = (s: DinoState): number => Object.keys(s.own).length
/** Game yang sudah dipakai hari ini (menurut jam server). */
export function gamesToday(s: DinoState): number {
  return s.daily && s.daily.d === dayNumber(serverNow()) ? s.daily.n : 0
}

// ---------------- undian (rumus sama dengan rules) ----------------
const LENS = [4, 4, 3, 1]
const BASES = [0, 4, 8, 11]
export type SpinResult = { s: number; rar: number; idx: number; roll: number }
export function spinOutcome(sp: Spin): SpinResult {
  const roll = (sp.seed + sp.n * 7919) % 10000
  const roll2 = (sp.seed * 7 + sp.n * 104729 + 31) % 9973
  const rar = sp.mode === 2 ? 0 : sp.pm >= DINO.PITY_MYTHIC - 1 || roll < DINO.ODDS.mythic ? 3 : sp.pl >= DINO.PITY_LEGEND - 1 || roll < DINO.ODDS.legend ? 2 : sp.pr >= DINO.PITY_RARE - 1 || roll < DINO.ODDS.rare ? 1 : 0
  const idx = roll2 % LENS[rar]
  return { s: BASES[rar] + idx, rar, idx, roll }
}
export const rarityOfId = (id: number): Rarity => SKINS[id].rarity
const RAR_KEYS: Rarity[] = ['common', 'rare', 'legend', 'mythic']

export class DinoError extends Error {}
const fail = (e: unknown, fallback: string): never => {
  const m = e instanceof Error ? e.message.toLowerCase() : ''
  if (m.includes('permission')) throw new DinoError('Ditolak server. Pastikan rules terbaru (Dino) sudah dipublikasikan dan saldo cukup.')
  throw new DinoError(fallback)
}
const read = async <T>(path: string): Promise<T | null> => {
  const s = await get(ref(db, path))
  return s.exists() ? (s.val() as T) : null
}

async function pay(uid: string, mode: 0 | 1 | 2): Promise<void> {
  const cost = mode === 0 ? DINO.SPIN_ONE : mode === 1 ? DINO.SPIN_FIVE : DINO.FIRST_UNLOCK
  const [shard, cur] = await Promise.all([read<number>(`users/${uid}/shard`), read<Spin>(`dino_game/${uid}/spin`)])
  if (cur && cur.pend > 0) throw new DinoError('Masih ada hasil undian yang belum dibuka')
  if ((shard ?? 0) < cost) throw new DinoError(`AkimiShard tidak cukup (butuh ${cost})`)
  const sp = { seed: serverTimestamp(), pend: mode === 1 ? 5 : 1, mode, n: cur?.n ?? 0, pr: cur?.pr ?? 0, pl: cur?.pl ?? 0, pm: cur?.pm ?? 0 }
  try {
    await update(ref(db), { [`dino_game/${uid}/spin`]: sp, [`users/${uid}/shard`]: (shard ?? 0) - cost })
  } catch (e) {
    fail(e, 'Gagal membayar. Cek sinyal lalu coba lagi')
  }
}
/** Unlock pertama: satu Dino Common acak (hanya bila belum punya Dino). */
export const payFirstUnlock = (uid: string) => pay(uid, 2)
export const paySpin = (uid: string, five: boolean) => pay(uid, five ? 1 : 0)

export type Reveal = SpinResult & { isNew: boolean; remaining: number }
/** Buka SATU hasil undian yang sudah dibayar. Hasilnya ditentukan server (seed + hitungan), client hanya menuliskannya. */
export async function revealNext(uid: string): Promise<Reveal> {
  const [sp, own] = await Promise.all([read<Spin>(`dino_game/${uid}/spin`), read<Record<string, number>>(`dino_game/${uid}/own`)])
  if (!sp || sp.pend < 1) throw new DinoError('Tidak ada undian yang menunggu')
  const o = spinOutcome(sp)
  const ns: Spin = {
    seed: sp.seed,
    pend: sp.pend - 1,
    mode: sp.mode,
    n: sp.n + 1,
    pr: sp.mode === 2 ? sp.pr : o.rar >= 1 ? 0 : sp.pr + 1,
    pl: sp.mode === 2 ? sp.pl : o.rar >= 2 ? 0 : sp.pl + 1,
    pm: sp.mode === 2 ? sp.pm : o.rar === 3 ? 0 : sp.pm + 1,
  }
  const had = Number(own?.[String(o.s)] ?? 0)
  try {
    await update(ref(db), {
      [`dino_game/${uid}/spin`]: ns,
      [`dino_game/${uid}/last`]: { s: o.s, rar: o.rar, idx: o.idx, roll: o.roll, ts: serverTimestamp(), n: sp.n },
      [`dino_game/${uid}/own/${o.s}`]: had + 1,
    })
  } catch (e) {
    fail(e, 'Gagal membuka hasil. Cek sinyal lalu coba lagi')
  }
  return { ...o, isNew: had === 0, remaining: ns.pend }
}

export async function sellDuplicate(uid: string, id: number): Promise<number> {
  const [own, shard] = await Promise.all([read<number>(`dino_game/${uid}/own/${id}`), read<number>(`users/${uid}/shard`)])
  if (!own || own < 2) throw new DinoError('Hanya duplikat yang bisa dijual (Dino terakhir tidak bisa)')
  const price = SELL_PRICE(id)
  try {
    await update(ref(db), {
      [`dino_game/${uid}/sell`]: { s: id, ts: serverTimestamp() },
      [`dino_game/${uid}/own/${id}`]: own - 1,
      [`users/${uid}/shard`]: (shard ?? 0) + price,
    })
  } catch (e) {
    fail(e, 'Gagal menjual. Coba lagi')
  }
  return price
}

export async function selectSkin(uid: string, id: number): Promise<void> {
  try {
    await update(ref(db), { [`dino_game/${uid}/selected`]: id })
  } catch (e) {
    fail(e, 'Gagal memakai Dino')
  }
}

/** Mulai satu permainan: mencatat batas harian + run dalam satu penulisan. Mengembalikan false bila jatah habis. */
export async function startRun(uid: string, sel: number): Promise<boolean> {
  const daily = await read<{ d: number; n: number }>(`dino_game/${uid}/daily`)
  const today = dayNumber(serverNow())
  const n = daily && daily.d === today ? daily.n + 1 : 1
  if (n > DINO.DAILY_MAX) return false
  try {
    await update(ref(db), {
      [`dino_game/${uid}/run`]: { t: serverTimestamp(), sel },
      [`dino_game/${uid}/daily`]: { d: today, n, t: serverTimestamp() },
    })
  } catch (e) {
    fail(e, 'Tidak bisa memulai game. Cek sinyal lalu coba lagi')
  }
  return true
}

export type RunResult = { score: number; best: number; reward: number; newBest: boolean }
/** Selesaikan permainan: skor, rekor, total, dan hadiah AkimiShard. Hanya berhasil bila masuk akal menurut waktu server. */
export async function finishRun(uid: string, score: number): Promise<RunResult> {
  const s = parseDino((await read<unknown>(`dino_game/${uid}`)) ?? {})
  const run = s.run
  const sc = Math.max(0, Math.floor(score))
  if (!run || run.sc !== undefined) return { score: sc, best: s.best, reward: 0, newBest: false }
  const reward = runReward(sc, run.sel)
  const patch: Record<string, unknown> = { [`dino_game/${uid}/run/sc`]: sc, [`dino_game/${uid}/run/e`]: reward, [`dino_game/${uid}/total`]: s.total + sc }
  const newBest = sc > s.best
  if (newBest) patch[`dino_game/${uid}/best`] = sc
  if (reward > 0) patch[`users/${uid}/shard`] = ((await read<number>(`users/${uid}/shard`)) ?? 0) + reward
  try {
    await update(ref(db), patch)
  } catch {
    // skor tidak masuk akal / jaringan putus: tidak ada hadiah, game tetap dihitung
    return { score: sc, best: s.best, reward: 0, newBest: false }
  }
  return { score: sc, best: newBest ? sc : s.best, reward, newBest }
}

export { RAR_KEYS }
