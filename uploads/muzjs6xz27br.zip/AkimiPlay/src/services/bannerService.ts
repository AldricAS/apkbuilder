// Banner pengumuman dari developer: satu banner aktif di `banner` (judul + teks).
// Tampil di semua HP setiap aplikasi dibuka, sampai developer menghapus atau menggantinya.
// Penjagaan sebenarnya ada di database.rules.json (hanya role developer yang boleh menulis).
import { onValue, ref, remove, serverTimestamp, set } from 'firebase/database'
import { db } from '../firebase/config'
import { sanitizeText } from './identity'
import { isDeveloper } from './broadcastService'
import type { UserProfile } from './userService'

export const BANNER_TITLE_MAX = 60
export const BANNER_TEXT_MAX = 600
export const BANNER_BTN_MAX = 30
export const BANNER_LINK_MAX = 500

/** btn + link hanya ada bila tombol dinyalakan (on) oleh developer. */
export type Banner = { title: string; text: string; ts: number; byId?: number | string; btn?: string; link?: string }

/** Rapikan link tombol: tambahkan https:// bila lupa, tolak selain https. */
export function parseBannerLink(raw: string): string {
  let v = raw.trim()
  if (v && !/^[a-z][a-z0-9+.-]*:/i.test(v)) v = 'https://' + v
  if (!/^https:\/\/[^\s]+$/i.test(v)) throw new Error('Link tombol harus berupa alamat https:// yang valid')
  if (v.length > BANNER_LINK_MAX) throw new Error('Link tombol terlalu panjang')
  return v
}

const bannerRef = () => ref(db, 'banner')

function bannerError(e: unknown): Error {
  const m = e instanceof Error ? e.message : String(e)
  if (/permission/i.test(m)) {
    return new Error('Ditolak database. Publikasikan database.rules.json terbaru (node "banner") dan pastikan role akun ini "developer".')
  }
  return e instanceof Error ? e : new Error(m)
}

/** Mengirim banner baru. Menggantikan banner lama; semua pengguna akan melihatnya lagi. */
export async function sendBanner(profile: UserProfile, rawTitle: string, rawText: string, button?: { text: string; link: string } | null): Promise<void> {
  if (!isDeveloper(profile)) throw new Error('Hanya developer yang boleh membuat banner')
  const title = sanitizeText(rawTitle, BANNER_TITLE_MAX)
  const text = sanitizeText(rawText, BANNER_TEXT_MAX)
  if (!title) throw new Error('Isi judul banner')
  if (!text) throw new Error('Isi teks banner')
  const data: Record<string, unknown> = { title, text, byId: profile.userId, ts: serverTimestamp() }
  if (button) {
    const btn = sanitizeText(button.text, BANNER_BTN_MAX)
    if (!btn) throw new Error('Isi teks tombol atau matikan tombol')
    data.btn = btn
    data.link = parseBannerLink(button.link)
  }
  try {
    await set(bannerRef(), data)
  } catch (e) {
    throw bannerError(e)
  }
}

/** Menghapus banner aktif (tidak muncul lagi di pembukaan aplikasi berikutnya). */
export async function clearBanner(profile: UserProfile): Promise<void> {
  if (!isDeveloper(profile)) throw new Error('Hanya developer yang boleh menghapus banner')
  try {
    await remove(bannerRef())
  } catch (e) {
    throw bannerError(e)
  }
}

export function subscribeBanner(cb: (b: Banner | null) => void, onError?: (e: Error) => void): () => void {
  return onValue(
    bannerRef(),
    (s) => {
      const v = s.val() as Partial<Banner> | null
      if (v && typeof v.title === 'string' && typeof v.text === 'string' && typeof v.ts === 'number') {
        cb({ title: v.title, text: v.text, ts: v.ts, byId: v.byId, ...(typeof v.btn === 'string' && typeof v.link === 'string' ? { btn: v.btn, link: v.link } : {}) })
      } else cb(null)
    },
    (e) => onError?.(e),
  )
}
