// Notifikasi APK asli: izin, pesan dari developer, dan episode baru.
// Pengecekan saat aplikasi ditutup dilakukan native (NotifyWorker, tiap ~15 menit).
// Saat aplikasi terbuka, pesan developer muncul seketika lewat listener Realtime Database di bawah.
import { limitToLast, onChildAdded, orderByChild, query, ref, get } from 'firebase/database'
import { db, firebaseConfig } from '../firebase/config'
import { isNative, plugin } from '../native/native'
import { API_BASE } from './animeApi'
import { settingsStore } from '../storage/stores'

export type NotifState = { granted: boolean; asked: boolean }

// status pendengar pesan developer (untuk halaman diagnosa di Panel Developer)
let listening = false
let listenError = ''
export const notifListenStatus = () => ({ listening, error: listenError })

/** Menampilkan satu notifikasi uji di HP ini lewat jalur yang sama dengan pesan developer. */
export async function testNotification(): Promise<'ok' | 'web' | 'off' | 'denied' | 'blocked'> {
  if (!isNative) return 'web'
  if (!notifyEnabled()) return 'off'
  await applyNotifySetting(true)
  let st = await notifStatus()
  if (!st.granted) st = await requestNotifPermission()
  if (!st.granted) return 'denied'
  try {
    const r = await plugin.showBroadcast({ ts: Date.now(), from: 'Tes', text: 'Notifikasi di HP ini berfungsi.' })
    return r.shown ? 'ok' : 'blocked'
  } catch {
    return 'blocked'
  }
}

export async function notifStatus(): Promise<NotifState> {
  if (!isNative) return { granted: false, asked: false }
  try {
    return await plugin.notifStatus()
  } catch {
    return { granted: false, asked: false }
  }
}

/** Menampilkan dialog izin notifikasi Android (Android 13+). */
export async function requestNotifPermission(): Promise<NotifState> {
  if (!isNative) return { granted: false, asked: false }
  try {
    return await plugin.requestNotifPermission()
  } catch {
    return { granted: false, asked: true }
  }
}

export function openNotifSettings() {
  if (isNative) void plugin.openNotifSettings().catch(() => undefined)
}

export const notifyEnabled = () => settingsStore.get().notify !== false

/** Menyimpan pengaturan ke sisi native dan menjadwalkan/membatalkan pengecekan latar belakang. */
export async function applyNotifySetting(enabled: boolean): Promise<void> {
  if (!isNative) return
  try {
    await plugin.configureNotifications({ enabled, dbUrl: firebaseConfig.databaseURL, apiBase: API_BASE })
  } catch {
    // abaikan: fitur notifikasi tidak boleh membuat aplikasi gagal
  }
}

/**
 * Dipanggil sekali setelah login. Meminta izin saat pertama kali, mengaktifkan pengecekan latar belakang,
 * dan mendengarkan pesan developer baru saat aplikasi terbuka. Mengembalikan fungsi untuk berhenti.
 */
export function startNotifications(): () => void {
  if (!isNative) return () => undefined
  let stopped = false
  let unsub: (() => void) | undefined

  void (async () => {
    const enabled = notifyEnabled()
    await applyNotifySetting(enabled)
    if (!enabled || stopped) return

    const st = await notifStatus()
    if (!st.granted && !st.asked) await requestNotifPermission()
    if (stopped) return

    const q = query(ref(db, 'broadcasts'), orderByChild('ts'), limitToLast(1))
    try {
      // pesan yang sudah ada sebelum aplikasi dibuka tidak dimunculkan sebagai notifikasi
      const snap = await get(q)
      // belum ada pesan sama sekali: tandai "sudah dicek" (ts=1) supaya pesan pertama nanti tetap muncul
      if (!snap.exists()) void plugin.seedBroadcast({ ts: 1 }).catch(() => undefined)
      snap.forEach((c) => {
        const ts = Number((c.val() as { ts?: number }).ts)
        if (ts > 0) void plugin.seedBroadcast({ ts }).catch(() => undefined)
      })
    } catch (e) {
      listenError = e instanceof Error ? e.message : String(e)
      return
    }
    if (stopped) return
    listening = true
    listenError = ''
    unsub = onChildAdded(
      q,
      (c) => {
        const v = c.val() as { ts?: number; from?: string; text?: string } | null
        if (!v || typeof v.ts !== 'number' || typeof v.text !== 'string') return
        void plugin.showBroadcast({ ts: v.ts, from: String(v.from ?? ''), text: v.text }).catch(() => undefined)
      },
      (e) => {
        listening = false
        listenError = e.message
      },
    )
  })()

  return () => {
    stopped = true
    listening = false
    unsub?.()
  }
}
