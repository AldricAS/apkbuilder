// Giveaway Premium di Public Diskusi.
//
// Alur (tanpa server): pembuat membagikan hari Premium MILIKNYA SENDIRI (tanpa AkimiShard, tanpa pajak/biaya), mendapat
// Bonus XP, dan pesan pengumuman muncul di chat. Siapa pun (selain pembuat, satu kali per giveaway) bisa mengambil tiket
// sampai habis; Premium-nya langsung ditambahkan di belakang masa aktif yang ada. Semua angka dan syarat dijaga
// database.rules.json; angka di sini HARUS sama dengan rules.
//
// Data:
//   giveaways/{gid}                    { uid, name, text, days, slots, claimed, ts }
//   giveawayClaims/{gid}/{uid}         waktu klaim (satu per user)
//   giveawayLastClaim/{uid}            { gid, ts } penunjuk klaim terakhir, dipakai rules untuk menghitung premiumUntil
//   giveawayOp/{uid}                   { gid, ts } penunjuk pembuatan terakhir, dipakai rules untuk memeriksa potongan Premium dan XP
import { get, limitToLast, onValue, orderByChild, push, query, ref, serverTimestamp, update } from 'firebase/database'
import { useEffect, useState } from 'react'
import { db } from '../firebase/config'
import { levelFromXp } from '../lib/xp'
import { sanitizeText } from './identity'
import { sendChat } from './chatService'
import { serverNow, withTimeout } from './serverTime'
import type { UserProfile } from './userService'

/** Pilihan durasi per hadiah (hari). Tampil sebagai 1h / 3h / 7h / 30h. */
export const GIVEAWAY_DAYS = [1, 3, 7, 30] as const
export type GiveawayDays = (typeof GIVEAWAY_DAYS)[number]
export const GIVEAWAY_SLOT_PRESETS = [5, 10, 20, 30, 50] as const
export const GIVEAWAY_SLOTS_MIN = 1
export const GIVEAWAY_SLOTS_MAX = 50
export const GIVEAWAY_TEXT_MAX = 120
/** Bonus XP untuk pembuat per 1 hari Premium per 1 orang (1 hari x 5 orang = 4.500 XP). Harus sama dengan rules. */
export const GIVEAWAY_XP_PER_DAY = 900
const DAY = 86_400_000

/** Hari Premium yang dipakai pembuat: 1 hari x 5 orang = 5 hari. Harus sama dengan rules (days x slots x 86.400.000 ms). */
export const giveawayCostDays = (days: number, slots: number) => days * slots
export const giveawayBonusXp = (days: number, slots: number) => days * slots * GIVEAWAY_XP_PER_DAY

/** Sisa Premium aktif dalam hari penuh (0 bila tidak aktif). */
export const premiumDaysLeft = (premiumUntil: number | undefined, now = Date.now()) =>
  typeof premiumUntil === 'number' && premiumUntil > now ? Math.floor((premiumUntil - now) / DAY) : 0

export type Giveaway = {
  id: string
  uid: string
  name: string
  text: string
  days: number
  slots: number
  claimed: number
  ts: number
}

function toGiveaway(id: string, v: unknown): Giveaway | null {
  const g = v as Partial<Giveaway> | null
  if (!g || typeof g.uid !== 'string' || typeof g.days !== 'number' || typeof g.slots !== 'number') return null
  return {
    id,
    uid: g.uid,
    name: typeof g.name === 'string' ? g.name : '',
    text: typeof g.text === 'string' ? g.text : '',
    days: g.days,
    slots: g.slots,
    claimed: typeof g.claimed === 'number' ? g.claimed : 0,
    ts: typeof g.ts === 'number' ? g.ts : 0,
  }
}

function permissionDenied(e: unknown): boolean {
  const m = e instanceof Error ? e.message.toLowerCase() : ''
  return m.includes('permission_denied') || m.includes('permission denied')
}

const num = async (path: string): Promise<number> => {
  const s = await get(ref(db, path))
  return typeof s.val() === 'number' ? (s.val() as number) : 0
}

export type CreateGiveawayInput = { days: number; slots: number; message: string }

export function validateGiveawayInput(input: CreateGiveawayInput): { days: GiveawayDays; slots: number; text: string } {
  if (!(GIVEAWAY_DAYS as readonly number[]).includes(input.days)) throw new Error('Durasi hadiah tidak valid')
  if (!Number.isInteger(input.slots) || input.slots < GIVEAWAY_SLOTS_MIN || input.slots > GIVEAWAY_SLOTS_MAX) {
    throw new Error(`Jumlah hadiah harus ${GIVEAWAY_SLOTS_MIN}-${GIVEAWAY_SLOTS_MAX}`)
  }
  const text = sanitizeText(input.message, GIVEAWAY_TEXT_MAX)
  if (!text) throw new Error('Isi pesan untuk penonton dulu')
  return { days: input.days as GiveawayDays, slots: input.slots, text }
}

/**
 * Membuat giveaway: hari Premium pembuat berkurang, Bonus XP masuk, giveaway dibuat, dan pesan pengumuman terkirim ke chat,
 * semuanya dalam SATU tulisan atomik (gagal sebagian = tidak ada yang berubah, Premium tidak hilang).
 */
export async function createGiveaway(me: UserProfile, input: CreateGiveawayInput): Promise<void> {
  const { days, slots, text } = validateGiveawayInput(input)
  const costDays = giveawayCostDays(days, slots)
  const bonus = giveawayBonusXp(days, slots)
  const gid = push(ref(db, 'giveaways')).key as string
  const name = (me.username?.trim() || me.displayName).slice(0, 40)
  try {
    await withTimeout(sendChat(me, text, null, async () => {
      // baca ulang tiap percobaan: XP bisa bertambah karena menonton, dan Premium bisa berubah di saat yang sama
      const [until, xp] = await Promise.all([num(`users/${me.uid}/premiumUntil`), num(`users/${me.uid}/xp`)])
      const now = serverNow()
      const left = premiumDaysLeft(until, now)
      if (until <= now) throw new Error('Kamu belum punya Premium aktif untuk dibagikan.')
      if (left < costDays) throw new Error(`Premium kamu kurang. Butuh ${costDays} hari, sisa ${left} hari.`)
      const nextXp = xp + bonus
      return {
        fields: { gid },
        patch: {
          [`users/${me.uid}/premiumUntil`]: until - costDays * DAY,
          [`users/${me.uid}/xp`]: nextXp,
          [`users/${me.uid}/level`]: levelFromXp(nextXp),
          [`giveawayOp/${me.uid}`]: { gid, ts: serverTimestamp() },
          [`giveaways/${gid}`]: { uid: me.uid, name, text, days, slots, claimed: 0, ts: serverTimestamp() },
        },
      }
    }), 25_000, 'Koneksi ke server terlalu lama. Cek sinyal lalu coba lagi (Premium kamu tidak berkurang).')
  } catch (e) {
    if (permissionDenied(e)) {
      throw new Error('Ditolak oleh aturan database. Pastikan rules terbaru (giveaway) sudah dipublikasikan.')
    }
    throw e
  }
}

/** Klaim satu hadiah. Premium ditambahkan di belakang masa aktif yang tersisa. Mengembalikan waktu berakhir Premium (ms). */
export async function claimGiveaway(me: UserProfile, gid: string): Promise<number> {
  const [gSnap, mine, curUntil] = await Promise.all([
    get(ref(db, `giveaways/${gid}`)),
    get(ref(db, `giveawayClaims/${gid}/${me.uid}`)),
    num(`users/${me.uid}/premiumUntil`),
  ])
  const g = toGiveaway(gid, gSnap.val())
  if (!g) throw new Error('Giveaway ini sudah tidak ada')
  if (g.uid === me.uid) throw new Error('Kamu tidak bisa mengklaim giveaway buatanmu sendiri')
  if (mine.exists()) throw new Error('Kamu sudah mengklaim giveaway ini')
  if (g.claimed >= g.slots) throw new Error('Hadiah sudah habis')
  const now = serverNow()
  const until = Math.max(curUntil, now) + g.days * DAY
  if (until > now + 3650 * DAY) throw new Error('Total masa Premium maksimal 10 tahun dari sekarang')
  try {
    await withTimeout(update(ref(db), {
      [`giveaways/${gid}/claimed`]: g.claimed + 1,
      [`giveawayClaims/${gid}/${me.uid}`]: serverTimestamp(),
      [`giveawayLastClaim/${me.uid}`]: { gid, ts: serverTimestamp() },
      [`users/${me.uid}/premiumUntil`]: until,
    }), 25_000, 'Koneksi ke server terlalu lama. Cek sinyal lalu coba lagi.')
  } catch (e) {
    if (!permissionDenied(e)) throw e
    // paling sering: hadiah habis di detik yang sama. Baca ulang supaya pesannya jelas.
    const [again, dup] = await Promise.all([get(ref(db, `giveaways/${gid}`)), get(ref(db, `giveawayClaims/${gid}/${me.uid}`))])
    const g2 = toGiveaway(gid, again.val())
    if (dup.exists()) throw new Error('Kamu sudah mengklaim giveaway ini')
    if (!g2 || g2.claimed >= g2.slots) throw new Error('Hadiah sudah habis')
    throw new Error('Klaim ditolak database. Coba lagi, atau pastikan rules terbaru sudah dipublikasikan.')
  }
  return until
}

// ---------- baca data ----------
export function useGiveaway(gid: string): Giveaway | null | undefined {
  const [v, setV] = useState<Giveaway | null | undefined>(undefined)
  useEffect(() => {
    setV(undefined)
    return onValue(
      ref(db, `giveaways/${gid}`),
      (s) => setV(s.exists() ? toGiveaway(gid, s.val()) : null),
      () => setV(null),
    )
  }, [gid])
  return v
}

/** Sudah mengklaim giveaway ini? (undefined = memuat) */
export function useMyClaim(gid: string, uid: string): boolean | undefined {
  const [v, setV] = useState<boolean | undefined>(undefined)
  useEffect(() => {
    setV(undefined)
    return onValue(
      ref(db, `giveawayClaims/${gid}/${uid}`),
      (s) => setV(s.exists()),
      () => setV(false),
    )
  }, [gid, uid])
  return v
}

/** Giveaway yang masih punya hadiah, terbaru dulu (maksimal `max`). Dipakai untuk bar di atas chat, karena pesan lama dihapus otomatis. */
export function useOpenGiveaways(max = 3): Giveaway[] {
  const [list, setList] = useState<Giveaway[]>([])
  useEffect(() => {
    const q = query(ref(db, 'giveaways'), orderByChild('ts'), limitToLast(20))
    return onValue(
      q,
      (s) => {
        const out: Giveaway[] = []
        s.forEach((c) => {
          const g = toGiveaway(c.key as string, c.val())
          if (g && g.claimed < g.slots) out.push(g)
        })
        setList(out.sort((a, b) => b.ts - a.ts).slice(0, max))
      },
      () => setList([]),
    )
  }, [max])
  return list
}

