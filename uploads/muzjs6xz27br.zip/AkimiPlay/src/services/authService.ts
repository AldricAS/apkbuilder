import { Capacitor } from '@capacitor/core'
import { FirebaseAuthentication } from '@capacitor-firebase/authentication'
import { GoogleAuthProvider, signInWithCredential, signOut as fbSignOut } from 'firebase/auth'
import { auth } from '../firebase/config'

type GoogleOptions = Parameters<typeof FirebaseAuthentication.signInWithGoogle>[0]

const lower = (e: unknown) => (e instanceof Error ? e.message : String(e)).toLowerCase()
const isCancelled = (e: unknown) => /cancel|12501|user_cancelled/.test(lower(e))

/** Perangkat tidak punya Credential Manager (Play Services lama / belum ada akun Google di HP). */
function credentialManagerUnsupported(e: unknown): boolean {
  return /credential manager|doesn't support|does not support|no credential|provider/.test(lower(e))
}

/** Login Google native. Jalur utama Credential Manager; jika HP tidak mendukung, otomatis coba jalur Google Sign-In klasik. */
async function nativeGoogleLogin() {
  try {
    return await FirebaseAuthentication.signInWithGoogle()
  } catch (first) {
    if (isCancelled(first) || !credentialManagerUnsupported(first)) throw first
    try {
      return await FirebaseAuthentication.signInWithGoogle({ useCredentialManager: false } as GoogleOptions)
    } catch (second) {
      if (isCancelled(second)) throw second
      throw first // pesan awal paling jelas untuk pengguna
    }
  }
}

/** Login Google native -> credential -> sesi Firebase (JS SDK). */
export async function signInWithGoogle(): Promise<void> {
  if (!Capacitor.isNativePlatform()) {
    throw new Error('Login Google hanya tersedia di aplikasi Android.')
  }
  const result = await nativeGoogleLogin()
  const idToken = result.credential?.idToken
  if (!idToken) throw new Error('Google tidak mengembalikan token login.')
  await signInWithCredential(auth, GoogleAuthProvider.credential(idToken, result.credential?.accessToken ?? undefined))
}

export async function signOutAll(): Promise<void> {
  await fbSignOut(auth)
  try {
    await FirebaseAuthentication.signOut()
  } catch {
    /* sesi native mungkin tidak ada */
  }
}

export function friendlyAuthError(e: unknown): string {
  const raw = e instanceof Error ? e.message : String(e)
  const m = raw.toLowerCase()
  if (m.includes('cancel') || m.includes('12501') || m.includes('user_cancelled')) return 'Login dibatalkan.'
  if (/credential manager|doesn't support|does not support|no credential|service_missing|service_disabled|service_version_update_required|play services/.test(m)) {
    return 'Login Google belum bisa dipakai di HP ini. Pastikan Google Play Services terpasang dan versi terbaru (Play Store → Google Play Services → Perbarui), ada akun Google di HP (Pengaturan → Akun), lalu coba lagi.'
  }
  if (m.includes('developer_error') || m.includes('10:') || m.includes('sha')) {
    return 'Konfigurasi Google Sign-In tidak cocok (SHA-1 APK belum terdaftar di Firebase). Lihat README bagian "Login Google".'
  }
  if (m.includes('network')) return 'Tidak ada koneksi internet.'
  if (m.includes('requests-from') || m.includes('api-key')) {
    return 'API key Firebase ditolak. Lihat README bagian "Troubleshooting login".'
  }
  return raw || 'Login gagal. Coba lagi.'
}
