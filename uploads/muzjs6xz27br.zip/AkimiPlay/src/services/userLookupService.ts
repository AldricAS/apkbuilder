// Cari user berdasarkan ID persis (#nomor). Hanya developer. Penjagaan sebenarnya ada di database.rules.json
// (membaca/meng-query koleksi `users` hanya untuk role developer); pengecekan di sini agar pesan error jelas.
// Yang dikembalikan hanya nama dan UID.
import { equalTo, get, limitToFirst, orderByChild, query, ref } from 'firebase/database'
import { db } from '../firebase/config'
import { isDeveloper } from './broadcastService'
import type { UserProfile } from './userService'

export type FoundUser = { uid: string; name: string; userId: string | number }

export async function findUserByUserId(me: UserProfile, raw: string): Promise<FoundUser> {
  if (!isDeveloper(me)) throw new Error('Hanya developer yang boleh mencari user.')
  const t = raw.trim().replace(/^#/, '')
  if (!t || t.length > 24) throw new Error('Masukkan ID user yang tepat.')
  // ID normal berupa angka; selain angka dicari persis sebagai teks
  const key: string | number = /^[0-9]{1,15}$/.test(t) ? Number(t) : t
  const snap = await get(query(ref(db, 'users'), orderByChild('userId'), equalTo(key), limitToFirst(2)))
  if (!snap.exists()) throw new Error('ID user tidak ditemukan.')
  let out: FoundUser | null = null
  snap.forEach((c) => {
    if (out) return true
    const u = c.val() as Partial<UserProfile>
    out = { uid: c.key as string, name: u.username?.trim() || u.displayName || '(tanpa nama)', userId: u.userId ?? t }
    return false
  })
  if (!out) throw new Error('ID user tidak ditemukan.')
  return out
}
