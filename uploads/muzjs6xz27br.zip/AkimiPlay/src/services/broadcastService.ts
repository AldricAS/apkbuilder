// Pesan notifikasi dari developer. Penjagaan sebenarnya ada di database.rules.json
// (hanya role developer yang boleh menulis); pengecekan di sini hanya agar pesan error lebih jelas.
import { get, limitToLast, onValue, orderByChild, query, ref, push, remove, serverTimestamp, set } from 'firebase/database'
import { db } from '../firebase/config'
import { sanitizeText } from './identity'
import type { UserProfile } from './userService'

export const BROADCAST_FROM_MAX = 40
export const BROADCAST_TEXT_MAX = 200
export const BROADCAST_COOLDOWN_MS = 10_000

export type Broadcast = { id: string; byId: number; from: string; text: string; ts: number }

export const isDeveloper = (p: Pick<UserProfile, 'role'> | null | undefined): boolean => p?.role === 'developer'

export async function sendBroadcast(profile: UserProfile, rawFrom: string, rawText: string): Promise<void> {
  if (!isDeveloper(profile)) throw new Error('Hanya developer yang boleh mengirim notifikasi')
  const from = sanitizeText(rawFrom, BROADCAST_FROM_MAX)
  const text = sanitizeText(rawText, BROADCAST_TEXT_MAX)
  if (!from) throw new Error('Isi kolom "Pesan dari"')
  if (!text) throw new Error('Teks pesan kosong')
  const id = push(ref(db, 'broadcasts')).key
  if (!id) throw new Error('Gagal membuat pesan')
  try {
    await set(ref(db, `broadcasts/${id}`), { byId: profile.userId, from, text, ts: serverTimestamp() })
  } catch (e) {
    const code = (e as { code?: string })?.code ?? ''
    const msg = e instanceof Error ? e.message : String(e)
    // tampilkan penyebab asli agar mudah dilacak
    let hint = ''
    if (/permission/i.test(code + msg)) {
      // baca data akun langsung dari database untuk membandingkannya dengan syarat di rules
      try {
        const u = (await get(ref(db, `users/${profile.uid}`))).val() as { role?: unknown; userId?: unknown } | null
        const dbRole = u?.role
        if (dbRole !== 'developer') hint = ` | role di database: ${JSON.stringify(dbRole ?? null)} (harus "developer")`
        else if (u?.userId !== profile.userId) hint = ` | userId di database ${JSON.stringify(u?.userId ?? null)} tidak sama dengan ${profile.userId}`
        else hint = ' | role & userId sudah benar: periksa apakah rules /broadcasts yang dipublikasikan sama dengan database.rules.json'
      } catch {
        hint = ' | gagal membaca data akun untuk diagnosa'
      }
    }
    throw new Error(`Gagal kirim [${code || 'error'}] ${msg}${hint}`)
  }
}

export async function deleteBroadcast(profile: UserProfile, id: string): Promise<void> {
  if (!isDeveloper(profile)) throw new Error('Hanya developer yang boleh menghapus notifikasi')
  await remove(ref(db, `broadcasts/${id}`))
}

export function subscribeBroadcasts(cb: (list: Broadcast[]) => void, onError?: (e: Error) => void) {
  return onValue(
    query(ref(db, 'broadcasts'), orderByChild('ts'), limitToLast(15)),
    (s) => {
      const out: Broadcast[] = []
      s.forEach((c) => {
        out.push({ ...(c.val() as Omit<Broadcast, 'id'>), id: c.key as string })
      })
      cb(out.reverse())
    },
    (e) => onError?.(e),
  )
}
