// Adapter: mengubah respons AnimeInWeb API (yang nama field-nya bisa berbeda-beda)
// menjadi model internal yang konsisten. Semua UI hanya memakai tipe dari ../types.
import type {
  Anime,
  AnimeStatus,
  Episode,
  EpisodeStream,
  Genre,
  HomeData,
  StreamSource,
} from '../types'

type Obj = Record<string, unknown>
export const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v)

export function pick(o: unknown, keys: string[]): unknown {
  if (!isObj(o)) return undefined
  for (const k of keys) {
    const v = o[k]
    if (v !== undefined && v !== null && v !== '') return v
  }
  return undefined
}

export function str(v: unknown): string | undefined {
  if (typeof v === 'string') {
    const t = v.trim()
    return t || undefined
  }
  if (typeof v === 'number' && Number.isFinite(v)) return String(v)
  if (Array.isArray(v)) return v.length ? str(v[0]) : undefined
  if (isObj(v)) return str(pick(v, ['name', 'title', 'label', 'url', 'src', 'value', 'large', 'medium', 'original']))
  return undefined
}

export function num(v: unknown): number | undefined {
  if (typeof v === 'number') return Number.isFinite(v) ? v : undefined
  if (typeof v === 'string') {
    const n = parseFloat(v.replace(',', '.'))
    return Number.isFinite(n) ? n : undefined
  }
  return undefined
}

function parseCount(v: unknown): number | undefined {
  if (typeof v === 'number') return Number.isFinite(v) ? v : undefined
  if (typeof v !== 'string') return undefined
  const m = v.trim().match(/^([\d.,]+)\s*([kKmM])?$/)
  if (!m) return undefined
  const n = parseFloat(m[1].replace(',', '.'))
  if (!Number.isFinite(n)) return undefined
  return m[2] ? n * (m[2].toLowerCase() === 'k' ? 1e3 : 1e6) : n
}

function strList(v: unknown): string[] | undefined {
  if (Array.isArray(v)) {
    const l = v.map((x) => str(x)).filter((x): x is string => !!x)
    return l.length ? l : undefined
  }
  if (typeof v === 'string' && v.trim()) {
    return v.split(/[,;|]/).map((s) => s.trim()).filter(Boolean)
  }
  if (isObj(v)) {
    const s = str(v)
    return s ? [s] : undefined
  }
  return undefined
}

function idList(v: unknown): string[] | undefined {
  if (!Array.isArray(v)) return undefined
  const l = v
    .map((x) => (isObj(x) ? str(pick(x, ['id', 'genre_id', 'genreId', 'slug'])) : undefined))
    .filter((x): x is string => !!x)
  return l.length ? l : undefined
}

const IMG_EXT = /\.(jpe?g|png|webp|avif|gif)(\?|#|$)/i
const IMG_OBJ_KEYS = ['url', 'src', 'large', 'original', 'medium', 'poster', 'image', 'cover', 'path', 'small', 'default']

function img(v: unknown, depth = 0): string | undefined {
  if (isObj(v) && depth < 3) return img(pick(v, IMG_OBJ_KEYS), depth + 1)
  if (Array.isArray(v) && depth < 3) return v.length ? img(v[0], depth + 1) : undefined
  const s = str(v)
  if (!s || /\s/.test(s)) return undefined
  if (s.startsWith('//')) return `https:${s}`
  if (s.startsWith('/')) return `https://animeinweb.com${s}`
  return s
}

/** Cari field gambar berdasarkan potongan nama key (mis. "poster_path", "coverImage"). */
function findImage(o: Obj, hints: string[], skip: string[] = []): string | undefined {
  for (const [k, v] of Object.entries(o)) {
    const key = k.toLowerCase()
    if (!hints.some((h) => key.includes(h)) || skip.some((x) => key.includes(x))) continue
    const s = img(v)
    if (s) return s
  }
  return undefined
}

const BANNER_HINTS = ['banner', 'backdrop', 'background', 'wide', 'landscape']

/** Membuka pembungkus umum seperti { data: ... } / { result: ... }. */
export function unwrap(v: unknown): unknown {
  let cur = v
  for (let i = 0; i < 3; i++) {
    if (isObj(cur)) {
      const inner = pick(cur, ['data', 'result', 'response', 'payload'])
      if (inner !== undefined && (isObj(inner) || Array.isArray(inner))) {
        cur = inner
        continue
      }
    }
    break
  }
  return cur
}

const LIST_KEYS = [
  'results', 'items', 'list', 'animes', 'anime', 'episodes', 'data', 'content', 'rows', 'docs', 'schedule',
]

export function findList(v: unknown, extra: string[] = [], depth = 0): unknown[] {
  if (Array.isArray(v)) return v
  if (!isObj(v) || depth > 3) return []
  const keys = [...extra, ...LIST_KEYS]
  for (const k of keys) {
    const x = v[k]
    if (Array.isArray(x)) return x
  }
  for (const k of keys) {
    const x = v[k]
    if (isObj(x)) {
      const r = findList(x, extra, depth + 1)
      if (r.length) return r
    }
  }
  return []
}

function normStatus(v: unknown): AnimeStatus | undefined {
  const s = str(v)?.toUpperCase()
  if (!s) return undefined
  if (/ONGOING|AIRING|CURRENTLY|BERLANGSUNG|TAYANG|RUNNING/.test(s)) return 'ONGOING'
  if (/FINISH|COMPLETE|TAMAT|SELESAI|ENDED/.test(s)) return 'FINISHED'
  if (/WAIT|UPCOMING|NOT_YET|SOON|SEGERA/.test(s)) return 'WAITING'
  return undefined
}

function yearOf(raw: unknown): number | undefined {
  const direct = num(pick(raw, ['year', 'release_year', 'releaseYear', 'aired_year', 'season_year']))
  if (direct && direct > 1900 && direct < 2100) return Math.round(direct)
  const text = str(pick(raw, ['released', 'aired', 'release_date', 'releaseDate', 'premiered', 'start_date', 'season']))
  const m = text?.match(/(19|20)\d{2}/)
  return m ? parseInt(m[0], 10) : undefined
}

export function toAnime(raw: unknown): Anime | null {
  if (!isObj(raw)) return null
  // Beberapa endpoint (mis. schedule) membungkus anime di dalam field "anime".
  const nested = isObj(raw.anime) && !pick(raw, ['title', 'name']) ? (raw.anime as Obj) : undefined
  const src: Obj = nested ?? raw

  const id = str(pick(src, ['id', 'anime_id', 'animeId', '_id', 'slug', 'uuid']))
  const title = str(pick(src, ['title', 'name', 'anime_title', 'title_english', 'title_en', 'title_romaji']))
  if (!id || !title) return null

  let score = num(pick(src, ['score', 'rating', 'mal_score', 'vote', 'rate', 'average_score']))
  if (score !== undefined) {
    if (score > 10) score = score / 10
    if (score <= 0) score = undefined
  }

  const total = num(
    pick(src, ['total_episodes', 'totalEpisodes', 'episode_count', 'episodes_count', 'episodes_total', 'eps']) ??
      (typeof src.episodes === 'number' ? src.episodes : undefined),
  )

  const latestRaw = pick(raw, [
    'latest_episode', 'latestEpisode', 'last_episode', 'current_episode', 'episode', 'episode_number', 'new_episode',
    'latest', 'episode_label',
  ]) ?? pick(src, ['latest_episode', 'latestEpisode', 'last_episode', 'current_episode', 'episode_number'])

  return {
    id,
    title,
    japaneseTitle: str(
      pick(src, [
        'japanese_title', 'japaneseTitle', 'title_jp', 'title_japanese', 'native_title', 'title_native',
        'alternative_title', 'alternativeTitle', 'original_title', 'synonym',
      ]),
    ),
    poster:
      img(pick(src, ['poster', 'poster_url', 'posterUrl', 'image', 'image_url', 'cover', 'cover_url', 'thumbnail', 'thumb', 'img', 'picture', 'images'])) ??
      findImage(src, ['poster', 'cover', 'image', 'thumb', 'img', 'picture', 'photo'], BANNER_HINTS) ??
      Object.values(src).map((v) => (typeof v === 'string' && IMG_EXT.test(v) ? img(v) : undefined)).find(Boolean),
    banner:
      img(pick(src, ['banner', 'banner_url', 'bannerUrl', 'backdrop', 'background', 'wide_image', 'landscape', 'trailer_thumbnail'])) ??
      findImage(src, BANNER_HINTS),
    synopsis: str(pick(src, ['synopsis', 'description', 'sinopsis', 'overview', 'plot', 'summary'])),
    type: str(pick(src, ['type', 'format', 'kind', 'media_type'])),
    status: normStatus(pick(src, ['status', 'anime_status', 'airing_status'])),
    score,
    year: yearOf(src),
    genres: strList(pick(src, ['genres', 'genre', 'tags', 'categories'])),
    genreIds: idList(pick(src, ['genres', 'genre', 'categories'])),
    studios: strList(pick(src, ['studios', 'studio', 'producers', 'producer'])),
    totalEpisodes: total ? Math.round(total) : undefined,
    latestEpisode: str(latestRaw),
    airTime: str(
      pick(raw, [
        'time', 'air_time', 'airTime', 'jam', 'schedule_time', 'scheduleTime', 'broadcast_time', 'broadcast',
        'aired_at', 'airing_at', 'release_time', 'start_time', 'next_episode_at', 'next_air_date',
      ]) ?? pick(src, ['time', 'air_time', 'airTime', 'jam', 'schedule_time', 'broadcast_time', 'broadcast']),
    ),
    views: parseCount(pick(src, ['views', 'view_count', 'viewCount', 'total_views', 'view'])),
  }
}

export function toAnimeList(v: unknown): Anime[] {
  const seen = new Set<string>()
  const out: Anime[] = []
  for (const r of findList(v)) {
    const a = toAnime(r)
    if (a && !seen.has(a.id)) {
      seen.add(a.id)
      out.push(a)
    }
  }
  return out
}

export function toHome(root: unknown): HomeData {
  const r = unwrap(root)
  const get = (keys: string[]) => toAnimeList(pick(r, keys))
  return {
    slider: get(['slider', 'sliders', 'banner', 'banners', 'carousel']),
    hot: get(['hot', 'trending']),
    new: get(['new', 'latest', 'newest']),
    today: get(['today', 'airing_today']),
    popular: get(['popular', 'top']),
    random: get(['random', 'recommended', 'recommendation']),
    waiting: get(['waiting', 'upcoming']),
  }
}

export function toGenres(root: unknown): Genre[] {
  const out: Genre[] = []
  const seen = new Set<string>()
  for (const g of findList(unwrap(root), ['genres'])) {
    let id: string | undefined
    let name: string | undefined
    if (typeof g === 'string') {
      id = g
      name = g
    } else if (isObj(g)) {
      id = str(pick(g, ['id', 'genre_id', 'genreId', 'slug', 'value', 'name']))
      name = str(pick(g, ['name', 'title', 'label', 'genre']))
    }
    if (id && name && !seen.has(id)) {
      seen.add(id)
      out.push({ id, name })
    }
  }
  return out
}

export function fmtDate(s?: string): string | undefined {
  if (!s) return undefined
  const t = Date.parse(s)
  if (Number.isNaN(t)) return s
  return new Date(t).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })
}

const EP_ID_KEYS = ['id', 'episode_id', 'episodeId', '_id', 'uuid', 'video_id', 'videoId', 'slug']

/** Meratakan daftar yang berkelompok (mis. per season: [{ season, episodes: [...] }]). */
function flattenEpisodes(list: unknown[], depth = 0): unknown[] {
  const out: unknown[] = []
  for (const r of list) {
    if (isObj(r) && !str(pick(r, EP_ID_KEYS)) && depth < 3) {
      const inner = findList(r, ['episodes', 'items', 'list'])
      if (inner.length) {
        out.push(...flattenEpisodes(inner, depth + 1))
        continue
      }
    }
    out.push(r)
  }
  return out
}

export function toEpisodes(root: unknown): Episode[] {
  const list = flattenEpisodes(findList(unwrap(root), ['episodes']))
  const out: Episode[] = []
  const seen = new Set<string>()
  list.forEach((r, i) => {
    if (!isObj(r)) return
    const id = str(pick(r, EP_ID_KEYS))
    if (!id || seen.has(id)) return
    seen.add(id)
    const title = str(pick(r, ['title', 'name', 'episode_title']))
    let number = num(pick(r, ['number', 'episode', 'episode_number', 'ep', 'no', 'index', 'order']))
    if (number === undefined && title) {
      const m = title.match(/(\d+(?:\.\d+)?)/)
      if (m) number = parseFloat(m[1])
    }
    out.push({
      id,
      number: number ?? i + 1,
      title,
      date: fmtDate(
        str(pick(r, ['date', 'aired', 'air_date', 'release_date', 'released', 'published_at', 'created_at', 'updated_at', 'uploaded_at'])),
      ),
    })
  })
  return out.sort((a, b) => a.number - b.number)
}

const URL_KEYS = ['url', 'src', 'file', 'link', 'video', 'stream', 'href', 'source']
const LABEL_KEYS = ['quality', 'label', 'resolution', 'name', 'res', 'height', 'size', 'format']

function heightOf(label: string | undefined): number {
  if (!label) return 0
  const m = label.match(/(\d{3,4})\s*p?/i)
  if (m) return parseInt(m[1], 10)
  if (/fhd/i.test(label)) return 1080
  if (/hd/i.test(label)) return 720
  if (/sd/i.test(label)) return 480
  return 0
}

export function toStream(root: unknown): EpisodeStream {
  const r = unwrap(root)
  const found: StreamSource[] = []
  const push = (url: unknown, label: unknown) => {
    const u = str(url)
    if (!u || !/^https?:\/\//i.test(u)) return
    const raw = str(label)
    const h = heightOf(raw)
    found.push({ url: u, height: h, quality: h ? `${h}p` : raw ?? 'Default' })
  }

  const list = findList(r, ['sources', 'streams', 'videos', 'qualities', 'links', 'urls', 'servers'])
  for (const item of list) {
    if (typeof item === 'string') push(item, undefined)
    else if (isObj(item)) push(pick(item, URL_KEYS), pick(item, LABEL_KEYS))
  }

  if (!found.length && isObj(r)) {
    // Bentuk peta: { "360p": "https://...", "720p": "https://..." }
    const map = pick(r, ['sources', 'streams', 'qualities', 'videos', 'links']) ?? r
    if (isObj(map)) for (const [k, v] of Object.entries(map)) if (typeof v === 'string') push(v, k)
    // Bentuk tunggal: { url: "https://..." }
    if (!found.length) push(pick(r, URL_KEYS), pick(r, LABEL_KEYS))
  }

  const seen = new Set<string>()
  const sources = found
    .filter((s) => (seen.has(s.url) ? false : (seen.add(s.url), true)))
    .sort((a, b) => b.height - a.height)
  return { sources }
}
