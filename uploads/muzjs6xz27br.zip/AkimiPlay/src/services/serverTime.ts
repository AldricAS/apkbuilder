// Jam server (ms) dari selisih jam perangkat. Satu pendengar tetap untuk seluruh aplikasi.
//
// Catatan bug lama: giveawayService membaca `.info/serverTimeOffset` dengan onValue sekali pakai yang memanggil `off()` di dalam
// callback. Begitu nilai sudah ada di cache, callback berjalan SINKRON sebelum `off` terdefinisi (ReferenceError), `resolve()`
// tidak pernah terpanggil, dan tombol "Sebarkan Premium" memuat selamanya. Pendengar tetap di bawah ini tidak punya masalah itu.
import { onValue, ref } from 'firebase/database'
import { db } from '../firebase/config'

let offsetMs = 0
let started = false

function start() {
  if (started) return
  started = true
  onValue(
    ref(db, '.info/serverTimeOffset'),
    (s) => {
      const v = s.val()
      offsetMs = typeof v === 'number' ? v : 0
    },
    () => undefined,
  )
}

/** Waktu server saat ini (ms). Sebelum terhubung, memakai jam perangkat. */
export function serverNow(): number {
  start()
  return Date.now() + offsetMs
}

/** Jalankan `p`, tetapi gagal dengan pesan jelas bila lebih dari `ms` (supaya tombol tidak memuat tanpa akhir). */
export function withTimeout<T>(p: Promise<T>, ms: number, message: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(message)), ms)
    p.then(
      (v) => {
        clearTimeout(t)
        resolve(v)
      },
      (e) => {
        clearTimeout(t)
        reject(e)
      },
    )
  })
}
