// Force update / optional update. Sumber keputusan SELALU: versi APK yang sedang berjalan vs app_config di Realtime Database.
// Tidak ada flag lokal "sudah update" dan versi terpasang tidak di-cache.
import { App } from '@capacitor/app'
import { onValue, ref } from 'firebase/database'
import { db } from '../firebase/config'
import { APP_VERSION } from '../components/Logo'
import { isNative, native } from '../native/native'
import { parseAppConfig, parseInstalledVersion, type AppConfig, type Version } from '../lib/version'

export type Installed = { raw: string | null; version: Version | null }

/**
 * Versi yang BENAR-BENAR terpasang di perangkat (versionName dari APK lewat @capacitor/app), dibaca ulang setiap dipanggil.
 * Hanya di browser (mode dev, bukan APK) dipakai versi build. Gagal membaca -> null (aplikasi tidak diblokir).
 */
export async function getInstalledVersion(): Promise<Installed> {
  if (!isNative) return { raw: APP_VERSION, version: parseInstalledVersion(APP_VERSION) }
  try {
    const info = await App.getInfo()
    return { raw: info.version, version: parseInstalledVersion(info.version) }
  } catch {
    return { raw: null, version: null }
  }
}

export type ConfigResult = { ok: true; config: AppConfig | null } | { ok: false; error: string }

/** Pantau app_config (hanya baca). Gagal / ditolak rules -> ok:false; tidak pernah melempar error. */
export function subscribeAppConfig(cb: (r: ConfigResult) => void): () => void {
  try {
    return onValue(
      ref(db, 'app_config'),
      (s) => {
        try {
          cb({ ok: true, config: s.exists() ? parseAppConfig(s.val()) : null })
        } catch {
          cb({ ok: true, config: null })
        }
      },
      (e) => cb({ ok: false, error: e?.message ?? 'Gagal membaca konfigurasi update' }),
    )
  } catch (e) {
    cb({ ok: false, error: e instanceof Error ? e.message : 'Gagal membaca konfigurasi update' })
    return () => undefined
  }
}

/** Buka link update (sudah divalidasi https) di peramban eksternal Android. */
export async function openUpdateUrl(url: string): Promise<void> {
  if (await native.openUrl(url)) return
  window.open(url, '_blank', 'noopener')
}
