import type { UserProfile } from './userService'

/** Data identitas yang disalin ke pesan/komentar. Security Rules memastikan nilainya sama dengan profile asli. */
export function identityOf(p: UserProfile) {
  const out: Record<string, unknown> = {
    uid: p.uid,
    userId: p.userId,
    name: p.username?.trim() || p.displayName,
    // role asli di database (Security Rules mencocokkannya), bukan role tampilan
    role: p.roleRaw ?? p.role,
    verified: !!p.verified,
    level: p.level,
  }
  if (p.photoURL) out.photoURL = p.photoURL
  if (p.clanTag) out.clanTag = p.clanTag
  return out
}

/** Membersihkan teks: hapus tag HTML & karakter kontrol, rapikan spasi, batasi panjang. */
export function sanitizeText(input: string, max: number): string {
  return input
    .replace(/<[^>]*>/g, '')
    .replace(/[<>]/g, '')
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, max)
}
