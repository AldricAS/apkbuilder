// Membaca data yang SUDAH ADA di Realtime Database untuk halaman View Profile.
// Tidak membuat struktur data baru dan tidak menulis apa pun.
//   - users/{uid}                  -> profile (email sengaja dibuang di sini)
//   - userData/{uid}/history       -> history tontonan
//   - comments/{animeId}/{cid}     -> komentar & balasan (dipindai lalu difilter berdasarkan uid)
import { get, ref, type DataSnapshot } from 'firebase/database'
import { db } from '../firebase/config'
import { animeApi } from './animeApi'
import type { HistoryEntry } from '../types'
import type { UserProfile } from './userService'

/** Profile publik: tanpa email. */
export type PublicProfile = Omit<UserProfile, 'email'>

export function toPublic(p: UserProfile): PublicProfile {
  const { email: _email, ...rest } = p
  void _email
  return rest
}

export function fmtWatchTime(minutes: number): string {
  const total = Math.max(0, Math.floor(Number.isFinite(minutes) ? minutes : 0))
  const h = Math.floor(total / 60)
  const m = total % 60
  return h > 0 ? `${h}j ${m}m` : `${m}m`
}

// ---------- history ----------
export async function fetchUserHistory(uid: string): Promise<HistoryEntry[]> {
  const snap = await get(ref(db, `userData/${uid}/history`))
  const v = snap.val()
  const list = v && typeof v === 'object' ? (Object.values(v) as HistoryEntry[]) : []
  return list
    .filter((h) => h && typeof h.animeId === 'string' && typeof h.title === 'string')
    .sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0))
}

// ---------- comments ----------
export type UserComment = {
  key: string
  kind: 'comment' | 'reply'
  animeId: string
  episodeId: string
  text: string
  ts: number
  edited: boolean
  /** hanya untuk reply */
  replyTo?: string
  parentName?: string
  parentText?: string
}

type RawReply = { uid?: string; text?: string; ts?: number; editedAt?: number; replyTo?: string }
type RawComment = {
  uid?: string
  name?: string
  text?: string
  animeId?: string
  episodeId?: string
  ts?: number
  editedAt?: number
  replies?: Record<string, RawReply>
}

let treeCache: { t: number; p: Promise<DataSnapshot> } | null = null
const TREE_TTL = 30_000

function loadTree(force: boolean): Promise<DataSnapshot> {
  if (!force && treeCache && Date.now() - treeCache.t < TREE_TTL) return treeCache.p
  const p = get(ref(db, 'comments'))
  treeCache = { t: Date.now(), p }
  p.catch(() => {
    if (treeCache?.p === p) treeCache = null
  })
  return p
}

/** Semua komentar + balasan milik `uid`, terbaru dulu. */
export async function fetchUserComments(uid: string, force = false): Promise<UserComment[]> {
  const tree = await loadTree(force)
  const out: UserComment[] = []
  tree.forEach((animeSnap) => {
    animeSnap.forEach((cSnap) => {
      const c = cSnap.val() as RawComment | null
      if (!c || typeof c.animeId !== 'string' || typeof c.episodeId !== 'string') return
      if (c.uid === uid && typeof c.text === 'string') {
        out.push({
          key: `c:${animeSnap.key}:${cSnap.key}`,
          kind: 'comment',
          animeId: c.animeId,
          episodeId: c.episodeId,
          text: c.text,
          ts: c.ts ?? 0,
          edited: !!c.editedAt,
        })
      }
      for (const [rid, r] of Object.entries(c.replies ?? {})) {
        if (r?.uid !== uid || typeof r.text !== 'string') continue
        out.push({
          key: `r:${animeSnap.key}:${cSnap.key}:${rid}`,
          kind: 'reply',
          animeId: c.animeId,
          episodeId: c.episodeId,
          text: r.text,
          ts: r.ts ?? 0,
          edited: !!r.editedAt,
          replyTo: r.replyTo,
          parentName: c.name,
          parentText: c.text,
        })
      }
    })
  })
  return out.sort((a, b) => b.ts - a.ts)
}

// ---------- judul anime & nomor episode untuk komentar ----------
// Komentar hanya menyimpan animeId + episodeId, jadi judul/nomor episode diambil dari API anime yang sudah ada.
export type AnimeMeta = { title: string; poster?: string }

const animeCache = new Map<string, AnimeMeta | null>()
const epCache = new Map<string, number>()
const resolved = new Set<string>()
const epKey = (animeId: string, episodeId: string) => `${animeId}\u0000${episodeId}`

export const cachedAnime = (animeId: string) => animeCache.get(animeId)
export const cachedEpisode = (animeId: string, episodeId: string) => epCache.get(epKey(animeId, episodeId))

export function seedFromHistory(list: HistoryEntry[]) {
  for (const h of list) {
    if (!animeCache.get(h.animeId)) animeCache.set(h.animeId, { title: h.title, poster: h.poster })
    if (h.episodeId && Number.isFinite(h.episodeNumber)) epCache.set(epKey(h.animeId, h.episodeId), h.episodeNumber)
  }
}

/** Isi cache untuk satu anime (judul + semua nomor episode). Gagal = diabaikan. */
export async function resolveAnime(animeId: string): Promise<void> {
  if (resolved.has(animeId)) return
  resolved.add(animeId)
  const [d, e] = await Promise.allSettled([animeApi.detail(animeId), animeApi.episodes(animeId)])
  if (d.status === 'fulfilled') {
    animeCache.set(animeId, { title: d.value.anime.title, poster: d.value.anime.poster })
  } else if (!animeCache.has(animeId)) {
    animeCache.set(animeId, null)
    resolved.delete(animeId) // boleh dicoba lagi nanti
  }
  if (e.status === 'fulfilled') for (const ep of e.value) epCache.set(epKey(animeId, ep.id), ep.number)
}
