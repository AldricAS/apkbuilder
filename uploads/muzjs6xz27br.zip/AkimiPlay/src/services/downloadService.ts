// Download episode untuk ditonton offline.
//
// - Video diunduh oleh kode native Android (AkimiNativePlugin) ke folder PRIVAT aplikasi
//   (files/downloads), jadi TIDAK muncul di galeri / folder Download dan hanya bisa diputar di AkimiPlay.
// - Metadata (episode, anime, status) disimpan di penyimpanan lokal aplikasi (Capacitor Preferences,
//   sama seperti favorit & histori), sehingga daftar unduhan tetap ada saat offline.
import { Capacitor } from '@capacitor/core'
import { useSyncExternalStore } from 'react'
import { animeApi } from './animeApi'
import { isNative, plugin } from '../native/native'
import { downloadAnimeStore, downloadsStore, settingsStore, useStore } from '../storage/stores'
import type { Anime, AnimeLite, DownloadAnime, DownloadEntry, Episode, StreamSource } from '../types'
import { toast } from '../components/Feedback'

const MAX_PARALLEL = 2
const REFERER = 'https://animeinweb.com/'

// ---------- util ----------
const safe = (s: string) => s.replace(/[^A-Za-z0-9._-]/g, '_')

function hash(s: string): string {
  let h = 5381
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0
  return h.toString(36)
}

function extOf(url: string): string {
  const m = url.split('?')[0].match(/\.(mp4|webm|m4v|mov|mkv)$/i)
  return m ? m[1].toLowerCase() : 'mp4'
}

function fileNameFor(episodeId: string, ext = 'mp4'): string {
  return `ep_${safe(episodeId).slice(0, 60)}_${hash(episodeId)}.${ext}`
}

/** Pilih sumber: kualitas favorit user, atau (otomatis) tertinggi sampai 720p supaya ukuran file wajar. */
function pickSource(sources: StreamSource[], pref: number, prefer?: string): StreamSource {
  if (prefer) {
    const same = sources.find((s) => s.quality === prefer)
    if (same) return same
  }
  const known = sources.filter((s) => s.height > 0)
  if (!known.length) return sources[0]
  const limit = pref > 0 ? pref : 720
  return known.find((s) => s.height <= limit) ?? known[known.length - 1]
}

/** URL yang bisa dipakai <video>/<img> untuk file di penyimpanan aplikasi. */
export function localFileUrl(path: string): string {
  return Capacitor.convertFileSrc(path)
}

// ---------- progress (hanya di memori, tidak disimpan) ----------
type Prog = { received: number; total: number }
let progress: Record<string, Prog> = {}
const progListeners = new Set<() => void>()
const setProgress = (id: string, p: Prog | null) => {
  const next = { ...progress }
  if (p) next[id] = p
  else delete next[id]
  progress = next
  progListeners.forEach((l) => l())
}
export function useDownloadProgress(): Record<string, Prog> {
  return useSyncExternalStore(
    (l) => {
      progListeners.add(l)
      return () => {
        progListeners.delete(l)
      }
    },
    () => progress,
  )
}

// ---------- hooks data ----------
export function useDownloads(): Record<string, DownloadEntry> {
  return useStore(downloadsStore)
}

export type DownloadedAnime = { anime: DownloadAnime; episodes: DownloadEntry[] }

/** Anime yang punya minimal 1 episode selesai di-download (urut terbaru). Episode diurutkan naik. */
export function selectDownloadedAnime(
  entries: Record<string, DownloadEntry>,
  animes: Record<string, DownloadAnime>,
): DownloadedAnime[] {
  const byAnime = new Map<string, DownloadEntry[]>()
  for (const e of Object.values(entries)) {
    if (e.status !== 'done' || !e.path) continue
    const l = byAnime.get(e.animeId) ?? []
    l.push(e)
    byAnime.set(e.animeId, l)
  }
  const out: DownloadedAnime[] = []
  for (const [id, eps] of byAnime) {
    const anime = animes[id]
    if (!anime) continue
    out.push({ anime, episodes: eps.sort((a, b) => a.episodeNumber - b.episodeNumber) })
  }
  return out.sort((a, b) => b.anime.addedAt - a.anime.addedAt)
}

export function useDownloadedAnime(): DownloadedAnime[] {
  const entries = useStore(downloadsStore)
  const animes = useStore(downloadAnimeStore)
  return selectDownloadedAnime(entries, animes)
}

export function hasDownloads(): boolean {
  return selectDownloadedAnime(downloadsStore.get(), downloadAnimeStore.get()).length > 0
}

// ---------- antrean ----------
const queue: string[] = []
const running = new Set<string>()
const cancelling = new Set<string>()

function patch(id: string, p: Partial<DownloadEntry>) {
  downloadsStore.set((d) => (d[id] ? { ...d, [id]: { ...d[id], ...p } } : d))
}

function dropEntry(id: string) {
  downloadsStore.set((d) => {
    if (!d[id]) return d
    const next = { ...d }
    delete next[id]
    return next
  })
  setProgress(id, null)
}

function pump() {
  while (running.size < MAX_PARALLEL && queue.length) {
    const id = queue.shift() as string
    if (!downloadsStore.get()[id]) continue
    running.add(id)
    void runJob(id).finally(() => {
      running.delete(id)
      pump()
    })
  }
}

async function runJob(id: string) {
  const entry = downloadsStore.get()[id]
  if (!entry) return
  patch(id, { status: 'downloading', error: undefined })
  try {
    const stream = await animeApi.stream(id)
    if (cancelling.has(id)) throw new Error('cancelled')
    const first = pickSource(stream.sources, settingsStore.get().defaultQuality, entry.quality || undefined)
    // Jika sumber pilihan ditolak server (403/404/...), coba sumber lain (kualitas lain) secara berurutan.
    const candidates = [first, ...stream.sources.filter((s) => s.url !== first.url)]
    let res: { path: string; size: number } | null = null
    let lastErr = ''
    for (const src of candidates) {
      if (cancelling.has(id)) throw new Error('cancelled')
      const fileName = fileNameFor(id, extOf(src.url))
      // kualitas / format berbeda dari percobaan sebelumnya: buang sisa file parsial agar tidak rusak
      const prev = downloadsStore.get()[id]
      if (prev && prev.quality && (prev.quality !== src.quality || prev.fileName !== fileName)) {
        await plugin.deleteDownload({ fileName: prev.fileName }).catch(() => undefined)
      }
      patch(id, { quality: src.quality, fileName })
      try {
        res = await plugin.downloadFile({ id, url: src.url, fileName, referer: REFERER })
        break
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e)
        if (msg === 'cancelled' || cancelling.has(id)) throw e
        lastErr = msg
        setProgress(id, null)
      }
    }
    if (!res) throw new Error(lastErr || 'Download gagal')
    if (cancelling.has(id)) throw new Error('cancelled')
    patch(id, { status: 'done', path: res.path, size: res.size, error: undefined })
    setProgress(id, null)
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    if (cancelling.has(id) || msg === 'cancelled') {
      cancelling.delete(id)
      const fn = downloadsStore.get()[id]?.fileName
      if (fn) await plugin.deleteDownload({ fileName: fn }).catch(() => undefined)
      dropEntry(id)
      cleanupAnimeIfEmpty(entry.animeId)
      return
    }
    patch(id, { status: 'error', error: msg || 'Download gagal' })
    setProgress(id, null)
  }
}

// ---------- API publik ----------
/** Menambahkan episode ke antrean download. Mengembalikan jumlah episode yang benar-benar ditambahkan. */
export function enqueueDownloads(anime: AnimeLite & Partial<Anime>, episodes: Episode[]): number {
  if (!isNative) {
    toast('Download hanya tersedia di aplikasi Android')
    return 0
  }
  const existing = downloadsStore.get()
  const fresh = episodes.filter((e) => {
    const cur = existing[e.id]
    return !cur || cur.status === 'error'
  })
  if (!fresh.length) {
    toast(episodes.length > 1 ? 'Semua episode itu sudah di-download' : 'Episode ini sudah ada di unduhan')
    return 0
  }

  const now = Date.now()
  downloadsStore.set((d) => {
    const next = { ...d }
    for (const e of fresh) {
      next[e.id] = {
        id: e.id,
        animeId: anime.id,
        episodeNumber: e.number,
        episodeTitle: e.title,
        fileName: fileNameFor(e.id),
        size: 0,
        quality: next[e.id]?.quality ?? '',
        status: 'queued',
        createdAt: now,
      }
    }
    return next
  })

  if (!downloadAnimeStore.get()[anime.id]) {
    const meta: DownloadAnime = {
      id: anime.id,
      title: anime.title,
      poster: anime.poster,
      totalEpisodes: anime.totalEpisodes,
      addedAt: now,
    }
    downloadAnimeStore.set((a) => ({ ...a, [anime.id]: meta }))
    void savePoster(anime.id, anime.poster)
  }

  for (const e of fresh) if (!queue.includes(e.id) && !running.has(e.id)) queue.push(e.id)
  pump()
  toast(fresh.length > 1 ? `${fresh.length} episode masuk antrean download` : 'Download dimulai')
  return fresh.length
}

async function savePoster(animeId: string, url?: string) {
  if (!url || !/^https?:\/\//i.test(url)) return
  try {
    const res = await plugin.downloadFile({
      id: `poster:${animeId}`,
      url,
      fileName: `poster_${safe(animeId).slice(0, 40)}_${hash(animeId)}.jpg`,
      referer: REFERER,
      video: false,
    })
    downloadAnimeStore.set((a) => (a[animeId] ? { ...a, [animeId]: { ...a[animeId], posterPath: res.path } } : a))
  } catch {
    /* poster opsional: tanpa poster lokal, offline tampil logo */
  }
}

export function retryDownload(id: string) {
  const e = downloadsStore.get()[id]
  if (!e || e.status !== 'error') return
  patch(id, { status: 'queued', error: undefined })
  if (!queue.includes(id) && !running.has(id)) queue.push(id)
  pump()
}

/** Membatalkan download yang sedang berjalan / antre (entri & file parsial dibuang). */
export function cancelDownload(id: string) {
  const e = downloadsStore.get()[id]
  if (!e) return
  if (running.has(id)) {
    cancelling.add(id)
    void plugin.cancelDownload({ id }).catch(() => undefined)
    return
  }
  const qi = queue.indexOf(id)
  if (qi >= 0) queue.splice(qi, 1)
  void plugin.deleteDownload({ fileName: e.fileName }).catch(() => undefined)
  dropEntry(id)
  cleanupAnimeIfEmpty(e.animeId)
}

function cleanupAnimeIfEmpty(animeId: string) {
  const left = Object.values(downloadsStore.get()).some((e) => e.animeId === animeId)
  if (left) return
  const meta = downloadAnimeStore.get()[animeId]
  if (meta?.posterPath) void plugin.deleteDownload({ fileName: meta.posterPath.split('/').pop() ?? '' }).catch(() => undefined)
  downloadAnimeStore.set((a) => {
    if (!a[animeId]) return a
    const next = { ...a }
    delete next[animeId]
    return next
  })
}

/** Menghapus episode yang sudah di-download (file ikut dihapus dari penyimpanan aplikasi). */
export async function removeDownload(id: string) {
  const e = downloadsStore.get()[id]
  if (!e) return
  if (e.status === 'queued' || e.status === 'downloading') return cancelDownload(id)
  await plugin.deleteDownload({ fileName: e.fileName }).catch(() => undefined)
  dropEntry(id)
  cleanupAnimeIfEmpty(e.animeId)
}

export async function removeAnimeDownloads(animeId: string) {
  const ids = Object.values(downloadsStore.get())
    .filter((e) => e.animeId === animeId)
    .map((e) => e.id)
  for (const id of ids) await removeDownload(id)
}

/** Dipanggil sekali saat aplikasi dibuka. */
export function initDownloads() {
  if (!isNative) return
  // download yang terputus karena aplikasi ditutup -> bisa dilanjutkan lewat tombol "Coba lagi"
  downloadsStore.set((d) => {
    let changed = false
    const next: Record<string, DownloadEntry> = {}
    for (const [k, e] of Object.entries(d)) {
      if (e.status === 'queued' || e.status === 'downloading') {
        changed = true
        next[k] = { ...e, status: 'error', error: 'Terputus saat aplikasi ditutup' }
      } else next[k] = e
    }
    return changed ? next : d
  })

  plugin
    .addListener('downloadProgress', (e) => {
      if (e.id.startsWith('poster:')) return
      setProgress(e.id, { received: e.received, total: e.total })
    })
    .catch(() => undefined)

  // file yang hilang dari penyimpanan (mis. dihapus manual) dibersihkan dari daftar
  void (async () => {
    for (const e of Object.values(downloadsStore.get())) {
      if (e.status !== 'done') continue
      const ok = await plugin
        .downloadExists({ fileName: e.fileName })
        .then((r) => r.exists)
        .catch(() => true)
      if (!ok) {
        dropEntry(e.id)
        cleanupAnimeIfEmpty(e.animeId)
      }
    }
  })()
}
