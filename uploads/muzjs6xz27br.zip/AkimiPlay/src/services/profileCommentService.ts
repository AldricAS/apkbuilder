// Komentar di profile: profileComments/{targetUid}/{cid} (+ replies/{rid}).
// Boleh dibaca & ditulis oleh pemilik profile dan temannya; Security Rules ada di database.rules.json.
import { onValue, orderByChild, limitToLast, push, query, ref, remove, serverTimestamp, set } from 'firebase/database'
import { db } from '../firebase/config'
import { identityOf, sanitizeText } from './identity'
import type { Role, UserProfile } from './userService'

export const PC_MAX = 300

export type PCReply = {
  id: string
  uid: string
  userId: number
  name: string
  photoURL?: string
  role: Role
  verified?: boolean
  level: number
  clanTag?: string
  text: string
  ts: number
}
export type PComment = PCReply & { replies: PCReply[] }

type Raw = Omit<PComment, 'id' | 'replies'> & { replies?: Record<string, Omit<PCReply, 'id'>> }

const valid = (v: unknown): v is Omit<PCReply, 'id'> =>
  !!v && typeof (v as PCReply).uid === 'string' && typeof (v as PCReply).text === 'string' && typeof (v as PCReply).ts === 'number'

export function subscribeProfileComments(target: string, cb: (l: PComment[]) => void, onError?: (e: Error) => void): () => void {
  const q = query(ref(db, `profileComments/${target}`), orderByChild('ts'), limitToLast(200))
  return onValue(
    q,
    (s) => {
      const out: PComment[] = []
      s.forEach((c) => {
        const v = c.val() as Raw | null
        if (!valid(v)) return
        const replies: PCReply[] = Object.entries(v.replies ?? {})
          .filter(([, r]) => valid(r))
          .map(([id, r]) => ({ ...r, id }))
          .sort((a, b) => a.ts - b.ts)
        out.push({ ...v, id: c.key as string, replies })
      })
      cb(out)
    },
    (e) => onError?.(e),
  )
}

// Urutan tampil komentar diatur oleh arrange() di bawah.
const TOP_WINDOW_MS = 3 * 24 * 60 * 60 * 1000
const isStaffNote = (c: PComment) => c.role === 'developer'
export const isLapsed = (c: PComment, now: number) => isStaffNote(c) && now - c.ts >= TOP_WINDOW_MS
const isTop = (c: PComment, now: number) => isStaffNote(c) && now - c.ts < TOP_WINDOW_MS

export function arrange(list: PComment[], now: number): PComment[] {
  const visible = list.filter((c) => !isLapsed(c, now))
  const byNew = (a: PComment, b: PComment) => b.ts - a.ts
  return [...visible.filter((c) => isTop(c, now)).sort(byNew), ...visible.filter((c) => !isTop(c, now)).sort(byNew)]
}

export async function postComment(me: UserProfile, target: string, raw: string): Promise<void> {
  const text = sanitizeText(raw, PC_MAX)
  if (!text) throw new Error('Komentar kosong')
  const r = push(ref(db, `profileComments/${target}`))
  await set(r, { ...identityOf(me), text, ts: serverTimestamp() })
}

export async function postReply(me: UserProfile, target: string, cid: string, raw: string): Promise<void> {
  const text = sanitizeText(raw, PC_MAX)
  if (!text) throw new Error('Balasan kosong')
  const r = push(ref(db, `profileComments/${target}/${cid}/replies`))
  await set(r, { ...identityOf(me), text, ts: serverTimestamp() })
}

export const deleteComment = (target: string, cid: string) => remove(ref(db, `profileComments/${target}/${cid}`))
export const deleteReply = (target: string, cid: string, rid: string) => remove(ref(db, `profileComments/${target}/${cid}/replies/${rid}`))
