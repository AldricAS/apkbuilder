// Jembatan ke Android: tombol Back, fullscreen/rotasi, layar tetap menyala, Picture-in-Picture.
import { Capacitor, registerPlugin, type PluginListenerHandle } from '@capacitor/core'
import { App } from '@capacitor/app'
import { useEffect, useRef } from 'react'
import { flushAllStores } from '../storage/stores'

interface AkimiNativePlugin {
  setFullscreen(o: { enabled: boolean }): Promise<void>
  setKeepAwake(o: { enabled: boolean }): Promise<void>
  isPipSupported(): Promise<{ supported: boolean }>
  enterPip(): Promise<void>
  setPipReady(o: { ready: boolean }): Promise<void>
  addListener(event: 'pipChanged', fn: (e: { active: boolean }) => void): Promise<PluginListenerHandle>
  addListener(
    event: 'downloadProgress',
    fn: (e: { id: string; received: number; total: number }) => void,
  ): Promise<PluginListenerHandle>
  // download offline: file disimpan di folder privat aplikasi (bukan galeri)
  downloadFile(o: {
    id: string
    url: string
    fileName: string
    referer?: string
    video?: boolean
  }): Promise<{ path: string; size: number }>
  cancelDownload(o: { id: string }): Promise<void>
  deleteDownload(o: { fileName: string }): Promise<void>
  downloadExists(o: { fileName: string }): Promise<{ exists: boolean }>
  // notifikasi APK asli
  notifStatus(): Promise<{ granted: boolean; asked: boolean }>
  requestNotifPermission(): Promise<{ granted: boolean; asked: boolean }>
  openNotifSettings(): Promise<void>
  configureNotifications(o: { enabled: boolean; dbUrl: string; apiBase: string }): Promise<void>
  seedBroadcast(o: { ts: number }): Promise<void>
  showBroadcast(o: { ts: number; from: string; text: string }): Promise<{ shown: boolean }>
  // pembayaran Premium: popup Sociabuzz di dalam aplikasi (form diisi otomatis) + WhatsApp admin
  openPayment(o: {
    url: string
    title: string
    amount: number
    message: string
    name: string
    email: string
    waNumber: string
    waText: string
  }): Promise<void>
  openWhatsApp(o: { number: string; text: string }): Promise<void>
  // buka link https di peramban eksternal (dipakai halaman update)
  openUrl(o: { url: string }): Promise<void>
}

export const plugin = registerPlugin<AkimiNativePlugin>('AkimiNative')
export const isNative = Capacitor.isNativePlatform()

async function safe<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  if (!isNative) return fallback
  try {
    return await fn()
  } catch {
    return fallback
  }
}

export const native = {
  /** true bila popup native terbuka. false (mis. di browser / APK lama) -> pakai popup web cadangan. */
  openPayment: (o: Parameters<AkimiNativePlugin['openPayment']>[0]) => safe(() => plugin.openPayment(o).then(() => true), false),
  openUrl: (url: string) => safe(() => plugin.openUrl({ url }).then(() => true), false),
  openWhatsApp: (number: string, text: string) => safe(() => plugin.openWhatsApp({ number, text }).then(() => true), false),
  setFullscreen: (enabled: boolean) => safe(() => plugin.setFullscreen({ enabled }), undefined),
  setKeepAwake: (enabled: boolean) => safe(() => plugin.setKeepAwake({ enabled }), undefined),
  setPipReady: (ready: boolean) => safe(() => plugin.setPipReady({ ready }), undefined),
  pipSupported: () => safe(async () => (await plugin.isPipSupported()).supported, false),
  enterPip: () => safe(() => plugin.enterPip().then(() => true), false),
  onPipChanged(cb: (active: boolean) => void): () => void {
    if (!isNative) return () => undefined
    let handle: PluginListenerHandle | undefined
    let cancelled = false
    plugin
      .addListener('pipChanged', (e) => cb(!!e.active))
      .then((h) => (cancelled ? h.remove() : (handle = h)))
      .catch(() => undefined)
    return () => {
      cancelled = true
      handle?.remove()
    }
  },
}

// ---------- Tombol Back Android ----------
type Handler = { fn: () => boolean; priority: number }
const handlers = new Set<Handler>()

export function registerBackHandler(fn: () => boolean, priority = 0): () => void {
  const h: Handler = { fn, priority }
  handlers.add(h)
  return () => {
    handlers.delete(h)
  }
}

/** Handler dengan prioritas tertinggi dicoba dulu; kembalikan true jika Back sudah ditangani. */
export function useBackHandler(fn: () => boolean, priority = 0, enabled = true) {
  const ref = useRef(fn)
  ref.current = fn
  useEffect(() => {
    if (!enabled) return
    return registerBackHandler(() => ref.current(), priority)
  }, [priority, enabled])
}

export function initNative() {
  if (!isNative) return
  App.addListener('backButton', () => {
    const list = [...handlers].reverse().sort((a, b) => b.priority - a.priority)
    for (const h of list) if (h.fn()) return
  })
  App.addListener('appStateChange', ({ isActive }) => {
    if (!isActive) void flushAllStores()
  })
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) void flushAllStores()
  })
}

export function exitApp() {
  if (isNative) void App.exitApp()
}
