import type { CapacitorConfig } from '@capacitor/cli'
import { readFileSync } from 'node:fs'

// Nama & ID aplikasi dibaca dari app.config.json (satu-satunya tempat untuk mengganti).
const app = JSON.parse(readFileSync('app.config.json', 'utf-8')) as {
  appName: string
  appId: string
}

const config: CapacitorConfig = {
  appId: app.appId,
  appName: app.appName,
  webDir: 'dist',
  backgroundColor: '#08080B',
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: true,
  },
  plugins: {
    // Login Google dilakukan native; sesi Firebase dipakai lewat Firebase JS SDK (Auth + Realtime Database).
    FirebaseAuthentication: {
      skipNativeAuth: true,
      providers: ['google.com'],
    },
  },
}

export default config
