# AkimiPlay

Aplikasi Android (APK) untuk streaming anime. React + TypeScript + Tailwind, dibungkus **Capacitor**.
Sumber data: [AnimeInWeb API](https://animeinweb-api.vercel.app). Ini **bukan PWA** dan tidak perlu di-deploy ke server.

- Application ID: `com.akimiplay.app`
- Ganti nama/ID/versi di **satu file**: `app.config.json`, lalu jalankan `npm run build`.

## Status build (baca ini dulu)

Fitur Firebase (login Google, chat, komentar, XP) ditambahkan tanpa bisa diuji terhadap project Firebase asli dan tanpa build Gradle. Hanya logika XP/level dan anti-abuse rentang tontonan yang dites dengan skrip, dan tipe TypeScript dicek. Konfigurasi plugin Android (`rgcfaIncludeGoogle`) berdasarkan dokumentasi yang saya ingat dan perlu dibuktikan lewat build pertama.

Project ini ditulis tanpa akses internet, jadi **`npm install`, `npm run build`, dan build Gradle belum pernah saya jalankan**.
Kode TypeScript sudah dicek sintaksnya, tapi build pertama kamu adalah uji pertama. Jika ada error, kirim pesan error-nya.

Dua hal yang perlu kamu tahu:

1. `android/gradle/wrapper/gradle-wrapper.jar` (file biner) tidak ikut. `npm run apk` membuatnya otomatis dengan `gradle wrapper`.
   Android Studio dan GitHub Actions tidak membutuhkannya.
2. Bentuk respons AnimeInWeb API tidak terdokumentasi. `src/services/adapters.ts` dibuat toleran terhadap beberapa nama field,
   tapi belum diuji terhadap data asli. Jika ada gambar/judul/episode yang kosong, buka **Akun → Diagnostik API** (hanya tampil untuk role developer),
   salin hasilnya, dan adapter bisa disesuaikan.

## Cara termudah dari HP: GitHub Actions (disarankan)

Build APK penuh di Termux sering gagal (lihat bawah). Cara paling andal dari HP:

1. Upload project ini ke repo GitHub.
2. Buka tab **Actions → Build APK → Run workflow**.
3. Setelah selesai, unduh artifact **AkimiPlay-debug-apk** (berisi `app-debug.apk`), lalu install.

## Build di Termux

```bash
pkg update
pkg upgrade
pkg install nodejs git
```

Lalu, dari folder project:

```bash
bash scripts/termux-setup.sh   # sekali saja: Java 21, aapt2, Android SDK (platform 35)
npm install
npm run build
npx cap sync android
npm run apk                    # Gradle assembleDebug, hasilnya disalin ke ./AkimiPlay.apk
```

Kebutuhan: Java 21, Android SDK (`platforms;android-35`, `build-tools;34.0.0`), Gradle 8.11.1 (diunduh wrapper), sekitar 3 GB ruang kosong dan RAM lega.

**Keterbatasan Termux (jujur):** `aapt2` bawaan Google adalah biner x86_64 yang tidak jalan di HP ARM.
Script memakai `aapt2` dari paket Termux (`-Pandroid.aapt2FromMavenOverride`). Ini cara yang umum dipakai, tapi tergantung versi
Termux/AGP dan bisa gagal atau kehabisan memori di HP kelas bawah. Jika gagal, pakai GitHub Actions atau Android Studio.

Install APK: buka `AkimiPlay.apk` dari file manager (izinkan "install dari sumber ini"), atau `termux-open AkimiPlay.apk`.

## Build di Android Studio

1. `npm install && npm run build && npx cap sync android`
2. Buka folder `android/` di Android Studio (File → Open). Biarkan Gradle sync selesai (perlu JDK 21, sudah bawaan Android Studio terbaru).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Lokasi APK

```
android/app/build/outputs/apk/debug/app-debug.apk
```

`npm run apk` juga menyalinnya ke `AkimiPlay.apk` di root project.

## Perintah

| Perintah | Fungsi |
|---|---|
| `npm run build` | Sinkronkan `app.config.json` ke Android + build web ke `dist/` |
| `npx cap sync android` | Salin `dist/` dan plugin ke project Android |
| `npm run apk` | build + sync + Gradle debug APK + salin ke `AkimiPlay.apk` |
| `npm run typecheck` | Cek tipe TypeScript |
| `npm run dev` | Pratinjau UI di browser (fitur native seperti PiP tidak aktif) |

## Fitur

Home (hero, Continue Watching, Ongoing, Anime Terbaru, Episode Terbaru, Populer, Rekomendasi, Genre), Ongoing (per hari, genre, cari, infinite scroll),
Favorit, Histori (lanjutkan/hapus/hapus semua), Pencarian (debounce), Detail (episode per 50, status ditonton, rekomendasi),
Player (seek, volume, kualitas sesuai API, prev/next, daftar episode, ketuk dua kali untuk lompat, resume, simpan progres, fullscreen landscape, PiP),
Akun (statistik, pengaturan player, clear cache/history, privacy, about, diagnostik API), splash native, tombol Back Android, indikator offline.

Data lokal memakai Capacitor Preferences (SharedPreferences), sehingga tetap ada setelah aplikasi ditutup.

## Struktur

```
android/                 Project Android (Gradle, manifest, ikon, splash, plugin Java untuk PiP/fullscreen)
src/services/animeApi.ts Semua request API
src/services/adapters.ts Adapter respons API -> model internal
src/storage/stores.ts    Favorit, histori, progres, pengaturan
src/pages/               Layar aplikasi
app.config.json          Nama, ID, versi
```

## Catatan teknis

- `targetSdk 35` memakai opt-out edge-to-edge (`values-v35/styles.xml`). Jika kamu menaikkan ke SDK 36, tambahkan penanganan insets.
- Request API anime memakai `CapacitorHttp` (HTTP native) secara eksplisit agar tidak terblokir CORS. Patch global CapacitorHttp sengaja dimatikan supaya tidak mengganggu Firebase. `allowMixedContent` dan `usesCleartextTraffic` aktif untuk video berbasis http.
- Tidak ada secret/API key di kode. AnimeInWeb API tidak memerlukan autentikasi.
- API ini tidak resmi; ketersediaan dan bentuk datanya bisa berubah sewaktu-waktu.

## Firebase: login, ID user, XP, chat, komentar

Project Firebase: `akimiplay-login` (Realtime Database `asia-southeast1`). Tanpa Cloud Functions, tanpa Admin SDK, cukup paket Spark.
`android/app/google-services.json` sudah disertakan. Package tetap `com.akimiplay.app`.

### Yang harus dilakukan sekali di Firebase Console

1. **Authentication → Sign-in method → Google → Enable.**
2. **Realtime Database → Rules**: salin isi `database.rules.json` lalu **Publish**. Tanpa ini profil gagal dibuat ("Akses database ditolak").
   Alternatif lewat CLI: `firebase deploy --only database` (file `firebase.json` dan `.firebaserc` sudah ada; tidak ada folder `functions/`).
3. **SHA-1**: Google Sign-In hanya jalan jika SHA-1 keystore yang menandatangani APK terdaftar di Project settings → Your apps → AkimiPlay.
   SHA-1 yang sudah terdaftar: `78:48:C0:E5:DA:5D:36:6F:C3:E0:E3:FA:42:DF:B9:9F:59:90:0C:7A`.
   Itu cocok jika Anda membangun APK di perangkat/keystore yang sama dengan sebelumnya. Build di mesin lain (Android Studio di PC, GitHub Actions)
   memakai debug keystore berbeda: ambil SHA-1 mesin itu lalu **Add fingerprint**, dan unduh ulang `google-services.json` jika diminta.
   - Termux: `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android`
   - Jika muncul error "DEVELOPER_ERROR" atau kode 10, SHA-1 belum cocok.
4. Firestore tidak dipakai. `firestore.rules` hanya mengunci Firestore total (`allow read, write: if false`).

### Cara kerja

| Fitur | Implementasi |
|---|---|
| Login | Google Sign-In native (`@capacitor-firebase/authentication`) lalu sesi Firebase JS SDK, tersimpan di IndexedDB sehingga tetap login setelah aplikasi ditutup. Logout ada di halaman Akun. |
| User ID `#1, #2, ...` | Transaction atomik pada `/meta/userIdCounter` (`{ value, lastUid }`). Rules hanya mengizinkan profile dibuat jika `userId` sama dengan counter saat ini dan `lastUid` adalah user itu sendiri. Dua user bersamaan tidak pernah mendapat angka sama. Pada tabrakan waktu, satu user bisa melompati satu angka (angka itu hangus, tidak pernah dipakai ulang). ID permanen, disimpan di `/users/{uid}`. |
| Profile | `/users/{uid}`: uid, userId, email, displayName, username, photoURL, role, verified, clanTag, level, xp, totalWatchMinutes, createdAt, xpAt, updatedAt, lastLoginAt. |
| XP | 1 menit menonton = 240 XP. Hanya kemajuan putar alami yang dihitung; seek diabaikan; detik yang sama tidak diberi XP dua kali (rentang tersimpan di `/watch/{uid}/{episode}`); speed 2x tidak melipatgandakan XP. |
| Level | `requiredXp(level) = 1000 + (level-1)*700`; level dihitung dari total XP kumulatif, termasuk lompat beberapa level sekaligus. Level 2 pada 1.000 XP, level 3 pada 2.700 XP, dst. |
| Global Chat | `/globalChat`, listener realtime (`onChildAdded`), 40 pesan terakhir, scroll ke atas memuat pesan lama, maksimal 300 karakter, timestamp server. |
| Presence | `.info/connected` + `onDisconnect()` di `/presence/{uid}`; offline saat aplikasi di background. |
| Komentar | `/comments/{animeId}/{commentId}` difilter per episode, balasan di `.../replies`, suka di `.../likes`. Realtime, bisa edit/hapus komentar sendiri. "Top Comment" diurutkan dari suka dan balasan. |
| Favorit & histori | Tetap tersimpan lokal, plus sinkron ke `/userData/{uid}` agar ikut berpindah perangkat. |

### Peran (role)
Default `user`. Untuk menjadikan seseorang `beta` / `moderator` / `admin` / `developer` / `special` atau `verified`, ubah field `role` / `verified` / `clanTag` langsung di
Realtime Database lewat Firebase Console (`/users/{uid}`). Aplikasi tidak bisa mengubahnya (Rules menolak). Moderator dan admin bisa menghapus pesan/komentar siapa pun.

### Batas keamanan tanpa server (jujur)
Tanpa Cloud Functions, validasi hanya bisa dilakukan oleh Security Rules:
- User tidak bisa mengubah `userId`, `role`, `verified`, `createdAt`, dan tidak bisa menulis XP/level sembarangan. Kenaikan XP dibatasi maksimal 240 XP per menit waktu server dan level harus cocok dengan XP.
  Namun klien yang dimodifikasi masih bisa mengklaim XP sampai batas itu tanpa benar-benar menonton. Cheat total tidak bisa dicegah tanpa server.
- Pengirim pesan/komentar divalidasi sama dengan profilnya (nama, ID, level, role). Tidak ada pembatasan kecepatan kirim di sisi server (hanya jeda 1 detik di aplikasi).
- Akun yang sudah punya profile tidak bisa menaikkan counter ID, tetapi akun baru yang berniat jahat bisa membuang beberapa nomor ID.

### Troubleshooting login
- `DEVELOPER_ERROR` / kode 10: SHA-1 belum terdaftar (langkah 3).
- `auth/requests-from-referer...blocked` atau `api-key-not-valid`: API key di `google-services.json` dibatasi hanya untuk aplikasi Android.
  Ganti `apiKey` di `src/firebase/config.ts` dengan API key tipe Browser (Google Cloud Console → APIs & Services → Credentials), lalu build ulang.
- "Akses database ditolak": rules belum dipublikasikan (langkah 2).
- Build Gradle gagal di plugin autentikasi: pastikan `rgcfaIncludeGoogle = true` ada di `android/variables.gradle` dan jalankan `npx cap sync android`.

### Warna centang
- `developer` dan `admin`: centang merah (lencana "Developer" / "Admin").
- `moderator`: centang ungu.
- `beta`: centang dan lencana oranye (tanpa hak moderasi). Isi `/users/{uid}/role` dengan `beta` lewat Firebase Console.
- `verified: true` tanpa role khusus: centang biru.
- Developer, admin, dan moderator bisa menghapus pesan/komentar siapa pun. Role diubah manual di `/users/{uid}/role` lewat Firebase Console.

### Login Google gagal "Your device doesn't support credential manager"

Login memakai Credential Manager (butuh Google Play Services). Jika HP tidak mendukungnya, aplikasi otomatis mencoba jalur Google Sign-In klasik.
Jika tetap gagal, pengguna melihat petunjuk: perbarui **Google Play Services**, pastikan ada **akun Google** di HP, lalu coba lagi.
HP tanpa Google Play Services sama sekali (mis. sebagian HP Huawei) tidak bisa memakai login Google native.


### Download & mode offline
- Tombol **Download** ada di daftar episode (per episode, ikon panah di kanan baris) dan di header "Episode" halaman anime
  (pilih banyak episode atau "Download semua"). Maksimal 2 episode diunduh bersamaan, sisanya antre.
- Video diunduh oleh kode native (`AkimiNativePlugin.downloadFile`) ke folder **privat aplikasi** (`files/downloads`):
  tidak muncul di galeri / folder Download, hanya bisa diputar di AkimiPlay, dan tidak ikut backup cloud.
- Daftar unduhan (episode, anime, status) disimpan di penyimpanan lokal aplikasi (`akimi.downloads`, `akimi.downloadAnime`),
  poster anime juga disalin lokal agar tampil tanpa internet.
- Saat offline, **Home** hanya menampilkan "Anime yang di download". Jika aplikasi dibuka tanpa internet (login/profil belum bisa
  dimuat) dan ada unduhan, aplikasi langsung masuk mode offline. Kembali online: ketuk "Buka AkimiPlay".
- Batasan: hanya sumber video langsung (mp4/webm). Sumber HLS (.m3u8) ditolak dengan pesan jelas. XP/komentar/chat butuh internet;
  progres tonton offline tetap tersimpan lokal.

## Notifikasi APK & Panel Developer

- **Izin**: aplikasi meminta izin notifikasi (Android 13+) sekali setelah login. Bisa dimatikan di Akun → Notifikasi.
- **Episode baru**: `NotifyWorker` (WorkManager) mengecek `/homepage` tiap ~15 menit (batas minimum Android) walau aplikasi ditutup. Pengecekan pertama hanya menyimpan batas awal, jadi tidak ada notifikasi lama yang membanjir.
- **Pesan developer**: Akun → Panel Developer → tab Notif (hanya role `developer`). Pesan ditulis ke `/broadcasts`; muncul seketika di HP yang aplikasinya terbuka dan paling lambat ~15 menit untuk yang tertutup. Tanpa Cloud Functions/FCM, jadi tetap gratis (Spark). Karena itu aplikasi yang sudah ditutup bisa terlambat sampai ±15 menit atau lebih (Doze/hemat baterai); notifikasi instan saat aplikasi tertutup butuh FCM + Cloud Functions (paket Blaze). Di Panel Developer → Notif ada tombol "Tes notifikasi" untuk memeriksa izin HP.
- **Rules `/broadcasts`**: baca terbuka (pengecekan latar belakang tidak punya token login); tulis/hapus hanya `role === 'developer'`; pesan tidak bisa diedit; `from` 1-40, `text` 1-200 karakter; `ts` harus waktu server; `byId` harus sama dengan userId pengirim; jeda 10 detik antar pesan dijaga di aplikasi; field lain ditolak.
- **Cari user (`/users`)**: Panel Developer → tab User. Mencari user dengan ID (#nomor) yang tepat dan hanya menampilkan nama + UID (bisa disalin). Membaca/meng-query koleksi `users` secara keseluruhan hanya boleh `role === 'developer'` (`.read` di `/users` + `.indexOn: userId`); user lain tetap hanya bisa membaca satu profil per UID. Di View Profil, baris UID hanya tampil untuk developer. Catatan: UID tidak benar-benar rahasia karena dipakai sebagai kunci profil yang bisa dibuka semua user; yang dikunci adalah kemampuan mencari/menelusuri user.
- **AkimiShard (`/users/{uid}/shard`)**: angka bulat 0 - 1.000.000.000. User biasa tidak bisa menulis, menambah, atau menghapusnya: akun baru hanya boleh dibuat dengan `shard` = 0 (atau tanpa field). Satu-satunya yang boleh mengubah adalah `role === 'developer'`, lewat **Akun → Panel Developer → Shard** (tempel UID user, lalu Tambah / Atur ke angka) atau lewat Firebase Console/Admin SDK. Setelah mengganti rules, Publish ulang `database.rules.json`.
- Setelah mengganti rules, **Publish** ulang `database.rules.json`, lalu jalankan `npm install` (dependensi Gradle `work-runtime` ikut terunduh saat build).
- Role `special` (badge & centang gradasi hitam-ungu): set `/users/{uid}/role` = `special` lewat Console. Teks badge diatur di `SPECIAL_ROLE_LABEL` (`src/components/UserBadges.tsx`).


## Fitur Teman (Connections)

Memakai Firebase Realtime Database yang sama (bukan Firestore). Node baru: `friends`, `friendRequests`, `friendSent`, `userIndex`, `profileComments`.
**Publikasikan `database.rules.json` terbaru** (Firebase Console, Realtime Database, Rules) sebelum mencoba fitur ini, jika tidak semua aksi teman akan ditolak.
Akun lama baru bisa dicari lewat User ID setelah pemiliknya membuka aplikasi sekali (indeks `userIndex` dibuat otomatis).

## Chat pribadi antar teman

- Buka **Connections → Teman** lalu ketuk baris chat di bawah kartu teman, atau buka profil teman lalu **Kirim Pesan**.
- Data: `dm/{uid}/{peerUid}/{mid}` (dua salinan per pesan) dan `dmRead/{uid}/{peerUid}` (penanda belum dibaca). Hanya bisa ditulis jika kedua akun saling berteman.
- **Publikasikan ulang `database.rules.json`** agar node `dm` dan `dmRead` aktif.
- Rules aslinya dipertahankan utuh; hanya ditambah node `dm` dan `dmRead`.

## Role `maou`

Badge dan centang gradasi merah ke hitam. Cara memberi: Firebase Console, Realtime Database, Data, `users/{uid}/role`, isi `maou`. Teks badge diubah di `MAOU_ROLE_LABEL` (`src/components/UserBadges.tsx`). Tidak perlu mengubah rules.

Catatan rules: `users` boleh di-query satu User ID (`orderByChild('userId')` + `equalTo`, maksimal 2 hasil) oleh akun login, supaya Cari Teman tidak bergantung pada `userIndex`. Role `maou` ikut diizinkan di validasi role.

## Banner developer

**Akun → Panel Developer → Banner**: isi Judul dan Teks, lihat pratinjau, lalu Kirim. Banner muncul sebagai pop-up setiap aplikasi dibuka (dan saat dibuka kembali dari latar belakang setelah lebih dari 30 detik, ubah di `BANNER_RESHOW_AFTER_MS` di `src/components/BannerHost.tsx`). Pengguna menutupnya dengan tombol X, tombol Kembali, atau mengetuk area gelap. Hanya satu banner aktif: mengirim yang baru menggantikan yang lama; banner terus muncul sampai dihapus dari tab yang sama. Data di node `banner` (butuh rules terbaru).

## Clan (AkimiGames → Clan)

- **Alur:** ketuk Clan di AkimiGames. Sudah punya clan: langsung ke halaman clan-nya. Belum: ke halaman Clans (Buat Clan, Cari Clan, Top Clans). Info dan Dino ditandai "Segera".
- **Buat clan:** pembuat jadi leader, mendapat 30 slot gratis. Nama (3-24), tag unik (2-5 huruf/angka), warna, dan emblem tidak bisa diubah setelah dibuat.
- **Gabung:** user mengirim permintaan (maksimal satu pada satu waktu), leader menerima atau menolak di tab Permintaan.
- **Donasi:** AkimiShard user berkurang, XP clan naik sama persis (1 shard = 1 XP, `SHARD_TO_XP`). Dua angka XP dipisah: `xp` (total, dipakai Top Clans dan level, tidak pernah turun) dan `xpBalance` (XP tersedia yang tampil di halaman clan, bisa dibelanjakan).
- **Upgrade slot:** leader menukar 1.000 XP tersedia dengan +5 slot (maksimal 100). Hanya `xpBalance` yang berkurang; `xp` di Top Clans tetap.
- **Keluar / dikeluarkan:** anggota biasa bisa keluar, leader bisa mengeluarkan anggota. Leader tidak bisa keluar; ia bisa membubarkan clan saat menjadi anggota terakhir.
- Tag clan otomatis dipasang ke profil (`users/{uid}/clanTag`) sehingga lencana muncul di chat dan komentar (`ClanTagSync`).
- Konstanta (slot, harga, batas) ada di `src/services/clanService.ts` dan harus sama dengan `database.rules.json` (dibangun dari konstanta yang sama).
- **Publikasikan ulang `database.rules.json`.** Node baru: `clans`, `clanMembers`, `clanRequests`, `userClan`, `userClanReq`, `clanTags`; aturan `users/$uid/shard` dan `users/$uid/clanTag` diperluas dengan syarat ketat.


## Clan: warna, gacha, dan biaya (update)

- Buat clan butuh **3.500 AkimiShard** (dipotong dari saldo calon leader). Warna awal selalu **White**, tidak ada pilihan warna saat membuat.
- Leader membuka **Shop Clan → Spin Warna**: Spin 1× = 250 XP, Spin 5× = 1.125 XP. Dibayar dari **XP clan tersedia** (`xpBalance`), sama seperti beli slot dan tier, BUKAN dari AkimiShard pribadi leader. XP total di Top Clans tidak berkurang.
- Peluang: Common 75%, Rare 24%, Legend 1%. Koleksi warna ada di tab "Koleksi"; leader menekan warna untuk memakainya.
- Lencana clan (komentar, chat global, profil, daftar clan) menampilkan emblem + tag dengan warna clan; Legend "Black Shine" punya kilau yang bergerak pelan.
- Angka harga ada di `src/services/clanService.ts` (`CLAN_CREATE_COST`, `COLOR_SPIN_COST`, `COLOR_SPIN5_COST`) dan HARUS sama dengan `database.rules.json`
  (3500 / 250 / 1125). Setelah mengubah rules, publikasikan: `firebase deploy --only database`.

### Developer: hapus clan
Panel Developer → tab **Clan**: semua clan terlihat (bisa dicari), ketuk satu → Detail → **Hapus clan**.
Penghapusan atomik (clan, anggota, permintaan masuk, tag, koleksi warna, penunjuk clan & lencana tag tiap anggota). Rules hanya mengizinkan role `developer`
dan menolak penghapusan yang tidak lengkap (mis. tag yatim). Wajib publikasikan ulang `database.rules.json`.

### Public Diskusi hanya menyimpan 30 pesan terakhir
Tiap pesan punya nomor urut (`seq`) yang dicatat di `meta/chatHead` (naik 1 per pesan, terikat ke pesan barunya). Setelah mengirim, aplikasi menghapus pesan di luar 30 terbaru.
Rules mengizinkan siapa pun menghapus pesan HANYA kalau `seq`-nya <= head - 30 (pesan lama tanpa `seq` boleh dihapus setelah head >= 30).
Angka 30 ada di `CHAT_KEEP` (`chatService.ts`) dan di `database.rules.json`.

### Sebar Premium / Giveaway Premium (Public Diskusi)
Tombol **tiket pink-emas** di samping tombol kirim chat membuka sheet **Sebar Premium**: lama tiap tiket (1 / 3 / 7 / 30 hari), jumlah tiket (1-50, slider), pesan untuk penonton, lalu **Struk Premium** (tiket disebar, Premium terpakai, Premium kamu, sisa setelah disebar, Hadiah XP).
- **Bayar dengan hari Premium sendiri, bukan AkimiShard.** Tanpa biaya dan tanpa pajak: hari x orang = hari Premium yang dipotong dari `premiumUntil` pembuat. Contoh 1 hari x 5 orang = 5 hari Premium. Pembuat WAJIB punya Premium aktif yang cukup.
- **Bonus XP untuk pembuat:** hari x orang x **900 XP** (`GIVEAWAY_XP_PER_DAY`). Contoh 1 x 5 = 4.500 XP. XP ini menaikkan level, tetapi TIDAK masuk leaderboard XP (`xpBoard`).
- **Ambil tiket:** siapa pun selain pembuat, satu kali per giveaway, sampai tiket habis. Premium ditambahkan di belakang masa aktif yang tersisa (maks total 10 tahun). Kartu tiket ada di bawah pesan pengumuman, dan bar **"Tiket Premium lagi dibagi"** di atas chat menampilkan maksimal 3 giveaway yang masih punya tiket.
- **Tidak ada refund:** hari Premium terpotong penuh saat dibuat, termasuk tiket yang tidak diambil. Disengaja agar Bonus XP tidak bisa dipanen dengan membuat lalu membatalkan giveaway.
- Pembuatan = SATU tulisan atomik (premiumUntil, XP, level, giveaway, pesan chat). Gagal sebagian = tidak ada yang berubah.
- Data: `giveaways/{gid}`, `giveawayClaims/{gid}/{uid}`, `giveawayLastClaim/{uid}`, `giveawayOp/{uid}` (dua penunjuk terakhir dipakai rules). Angka XP di `src/services/giveawayService.ts` HARUS sama dengan `database.rules.json`.
- Rules `users/$uid/premiumUntil`, `xp`, dan `shard` diperluas: tetap hanya developer yang bisa memberi Premium manual, tetapi user boleh menulis premiumUntil MILIKNYA SENDIRI persis sebesar hasil klaim (toleransi jam 5 menit).
- Tes rules: `node rules-tests/t8.js`.
- **Publikasikan ulang `database.rules.json`** dan bangun APK baru.

### Role clan (Leader / Vice-Leader / Admiral / Officer / Member)
Role disimpan di `clanMembers/{clanId}/{uid}/role` (`leader | vice | admiral | officer | member`). Hanya Leader yang bisa mengangkat Vice-Leader; anggota biasa tidak bisa mengubah role siapa pun.

| Aksi | Leader | Vice-Leader (ungu) | Admiral | Officer | Member |
|---|---|---|---|---|---|
| Terima / tolak permintaan masuk | ya | ya | ya | - | - |
| Upgrade tier, spin & pakai warna | ya | ya | - | - | - |
| Beli slot, bubarkan clan | ya | - | - | - | - |
| Kick | semua selain dirinya | Admiral, Officer, Member | - | - | - |
| Ubah role | siapa pun (termasuk jadikan Vice-Leader) | Admiral / Officer / Member (hanya untuk yang pangkatnya di bawah Vice) | Officer <-> Member | - | - |
| Pindahkan jabatan Leader | ya | - | - | - | - |

- Urutan pangkat: Leader > Vice-Leader > Admiral > Officer > Member. Tidak ada yang bisa kick Leader; Vice tidak bisa kick Vice lain.
- **Transfer Leader:** Leader membuka anggota -> *Jadikan Leader*. Satu tulisan atomik: `clans/{id}/leaderUid` ganti, role leader baru = `leader`, leader lama otomatis jadi `vice`. Leader lama bisa lalu keluar clan sendiri.
- Leader tidak bisa keluar clan (harus transfer dulu, atau bubarkan saat sendirian). Role lain boleh keluar sendiri.
- Officer saat ini hanya gelar (belum ada wewenang). Wewenang tiap role dijaga di `database.rules.json` dan di `canManageRequests / canManageClan / canKick / assignableRoles` (`src/services/clanService.ts`); keduanya harus sama.
- Tes rules role: `node rules-tests/t7.js`.

### Donasi per periode (Harian / Mingguan / Bulanan / Full)
Tab **Donasi** di halaman clan punya filter: **Harian** (reset tiap hari), **Mingguan** (reset tiap Senin), **Bulanan** (reset tiap tanggal 1), dan **Full** (total sepanjang masa, tidak pernah reset).
Semua memakai zona waktu WIB (00.00), sama dengan leaderboard XP (`src/lib/board.ts`). Data: `clanDonations/{clanId}/{daily|weekly|monthly}/{key}/{uid}`; reset terjadi otomatis karena key periode baru = node baru
(tanpa cron/server). **Full** memakai field `clanMembers/{clanId}/{uid}/donated` yang sudah ada. Donasi lama (sebelum update) hanya muncul di Full.
**Publikasikan ulang `database.rules.json`** (node baru `clanDonations`).

### Tier clan (1-3)
Lencana berubah bentuk: Tier 1 lancip, Tier 2 berbingkai + permata, Tier 3 bingkai emas + mahkota. Leader menaikkan satu tier per pembelian di Shop Clan,
dibayar dengan XP clan: Tier 2 = 3.000 XP, Tier 3 = 8.000 XP (`CLAN_TIER_COST` di `clanService.ts`, harus sama dengan rules). Clan lama dianggap Tier 1.

### Tes rules
`node rules-tests/t2.js` dan `node rules-tests/t3.js` (simulator sederhana; menguji logika rules, bukan pengganti Firebase emulator).

### Premium (BUKAN role)
Premium hanya masa berlaku di `users/{uid}/premiumUntil` (ms); role di database tidak pernah diubah dan nilai role `premium` ditolak rules.
Tampilan (nama biru, centang biru berkilau, badge biru dengan sisi hitam + kilau bergerak) hanya muncul untuk akun ber-role **user** biasa yang Premium-nya aktif;
akun dengan role lain (beta, moderator, admin, developer, special, raja_iblis, maou) tetap memakai badge & centang rolenya, masa Premium-nya tetap berjalan.
Premium yang habis hilang otomatis dari tampilan (dihitung di klien lewat `normalizeProfile`, tanpa penulisan database).
Diberikan dari Panel Developer -> **Shard** -> **Premium** (30 hari, 2/3/6 bulan, 1 tahun, atau jumlah sendiri; menambah di belakang masa aktif; maks 10 tahun).
Akun lama yang pernah tersimpan dengan role `premium` dirapikan otomatis saat developer memberi/mencabut Premium, atau lewat tab Role (ketik `user`).

### Panel Developer: Ubah ID & Role
- **Ubah ID**: cari UID, ketik ID baru (mis. `#10`), Enter. ID harus belum dipakai dan <= counter pendaftaran. Profil, `userIndex` baru, dan `userIndex` lama diubah dalam satu update.
- **Role**: cari UID, ketik teks role (user, beta, moderator, admin, developer, special, raja_iblis, maou), Enter. Role akun sendiri tidak bisa diubah. Premium bukan role (lewat tab Shard).
- Semua dijaga `database.rules.json` (hanya role developer). Tes: `node rules-tests/t4.js`.

### Beli Premium (Sociabuzz + WhatsApp)
- Home: tombol **Beli Premium di sini** (jadi **Perpanjang Premium** bila masih aktif) -> halaman `PremiumPage` (status premium + daftar paket).
- Paket di `src/services/premiumPlans.ts`: 1 Bulan Rp5.000 (+2.500 shard), 3 Bulan Rp14.000 (+7.500), 6 Bulan Rp27.000 (+15.000), 1 Tahun Rp50.000 (+30.000).
- **Pilih Paket** membuka popup native di dalam aplikasi (`PaymentPopup.java`, WebView ke `https://sociabuzz.com/stark_akimiplay/support`), bukan Chrome.
  Jumlah, pesan (= UID), nama, dan email diisi otomatis oleh `android/app/src/main/assets/sociabuzz_autofill.js` (hanya di domain sociabuzz.com;
  pernyataan/persetujuan TIDAK dicentang otomatis). Bar hijau di bawah popup membuka WhatsApp admin (`6287769840134`) dengan teks terisi (UID, paket, nama).
- Pembayaran TIDAK terdeteksi otomatis. Setelah bukti masuk lewat WhatsApp, developer mengaktifkan Premium + bonus shard dari Panel Developer -> Shard (cari UID dari pesan).
- Di browser/APK lama (tanpa method native `openPayment`), muncul popup web cadangan: form Sociabuzz dalam iframe + tombol salin data.
- Tes pengisi otomatis (halaman tiruan, input ala React): `python3 tools/autofill-test/run.py` (butuh playwright).
- Setelah mengubah Java/assets: `npm run build && npx cap sync android`, lalu bangun ulang APK.

## Force update / update opsional

Aplikasi membaca versi APK yang benar-benar terpasang (`versionName` lewat `@capacitor/app`), lalu membandingkannya dengan
`app_config` di Realtime Database. Versi dibandingkan angka per angka (1.0.10 > 1.0.9), logikanya ada di `src/lib/version.ts`.

```
app_config/
  latestVersion   "1.0.2"
  minimumVersion  "1.0.1"
  updateUrl       "https://.../AkimiPlay-1.0.2.apk"   (wajib https)
  updateMessage   "teks opsional"
  enabled         true                                  (harus boolean true agar update aktif)
```

- versi terpasang < `minimumVersion` -> halaman **Update Diperlukan** (tanpa tombol Lewati/Nanti)
- `minimumVersion` <= versi terpasang < `latestVersion` -> dialog **Update Tersedia** (ada tombol Nanti)
- selain itu -> aplikasi normal
- `app_config` hanya bisa ditulis role `developer` (lihat `database.rules.json`); isi lewat Firebase Console
- Firebase gagal diakses / `app_config` kosong atau rusak -> aplikasi tetap terbuka (tidak ada loop)
- Naikkan `version` DAN `versionCode` di `app.config.json` setiap rilis APK baru.

Tes: `npx tsx tools/update-check.test.ts` (logika versi) dan `node rules-tests/t6.js` (rules app_config).

## AkimiGames baru + Nobar (nonton bareng global) - v1.0.7

**Tampilan AkimiGames**: bintang Clan besar di sisi kiri (memanjang ke bawah, dengan cincin orbit & garis rasi), tombol **Nobar** (kotak)
di sisi kanan sedikit lebih rendah dari puncak bintang, Dino & Info di bawahnya. Partikel latar: bintang berkelip, kelopak sakura pink
(ciri khas AkimiPlay), bintang jatuh, watermark logo. Animasi ada di `tailwind.config.js` (`twinkle`, `petal`, `shoot`, `orbit`, `dash`) dan
otomatis mati bila HP memakai "kurangi animasi".

**Alur Nobar** (`src/pages/NobarPage.tsx`):
- **[Buat global nobar]** -> `[Search anime]` + `Rekomendasi anime:` -> pilih anime -> popup "Buat global nobar" -> room langsung muncul di **Nobar aktif**.
- Kartu nobar aktif: `Owner <nama> | (Join)`, `Judul anime: ...`, `Org n/20`.
- **Owner** (pembuat) satu-satunya yang bisa play, jeda, geser, ganti episode, ganti anime, stop nobar, dan **kick**. Anggota hanya menonton
  (tombol & slider terkunci; kalau memaksa lewat PiP, video dikembalikan ke status room).
- Mini player & Picture-in-Picture tetap jalan di dalam nobar. Anime lain tidak bisa dibuka diam-diam saat masih di nobar.
- Komentar room (maks 200 huruf, jeda 1,5 dtk). Owner bisa menghapus komentar siapa pun dan men-**Kick** pengirimnya.
  Yang di-kick langsung keluar dan **tidak bisa masuk lagi ke room milik owner itu** (daftar `nobarKicks/{owner}`), tetapi tetap bisa join room owner lain.
- Maksimal 20 orang per room (1 owner + 19 anggota), dijaga lewat node slot di rules, bukan hanya di aplikasi.
- Owner terputus > 3 menit -> room otomatis dibersihkan; anggota yang koneksinya putus otomatis dikeluarkan (slot bebas).

**Aturan membuat room (ketat, dijaga `database.rules.json`)**: hanya **Premium aktif** atau role selain `user` (beta, moderator, admin, developer,
special, raja_iblis, maou). Role `user` biasa **tidak bisa membuat** room tetapi **bisa join**. Premium yang habis di tengah sesi tidak mematikan
room yang sedang berjalan, tapi tidak bisa membuat room baru. Identitas room/anggota/komentar (userId, nama, role, level) dicocokkan dengan `/users`,
jadi tidak bisa dipalsukan. Hanya owner yang bisa menulis status putar (jeda minimal 250 ms); hanya owner/moderator/admin/developer yang bisa
menghentikan room orang; hanya owner yang bisa kick.

Data: `nobarRooms`, `nobarSlots`, `nobarMembers`, `nobarKicks`, `nobarChat`, `nobarRate`. Konstanta di `src/services/nobarService.ts`
(`NOBAR_MAX`, dll.) harus sama dengan rules. Tes: `node rules-tests/t9.js`.
**Publikasikan ulang `database.rules.json`** (Firebase Console, Realtime Database, Rules) lalu bangun APK 1.0.7: `npm run apk`.

## Perbaikan bug (XP, level, giveaway, badge clan)

- **XP tidak naik & toast "Naik level" berulang padahal level tidak naik**: rules `users/$uid/xp` memuat cabang giveaway yang membaca
  `giveaways/{gid dari giveawayOp}`. Untuk user yang belum pernah membuat giveaway, `gid` kosong sehingga `child(null)` menjadi error dan SEMUA
  penulisan XP ditolak; aplikasi menampilkan level sementara (naik), lalu server menolak dan level kembali. Sekarang cabang menonton dievaluasi
  lebih dulu dan cabang giveaway dijaga `.exists()`. Toast naik level juga hanya muncul bila level bertahan 2,5 detik.
- **Sebarkan Premium memuat tanpa akhir**: `serverNow()` memakai `onValue` sekali pakai yang memanggil `off()` di dalam callback; saat nilai sudah ada
  di cache callback jalan sinkron sebelum `off` terdefinisi, `resolve()` tidak pernah terpanggil. Diganti pendengar tetap (`src/services/serverTime.ts`),
  ditambah batas waktu 25 detik dengan pesan jelas. Rules `premiumUntil` juga dijaga `.exists()` untuk pembuat/penerima giveaway pertama kali.
- **Badge clan anggota baru**: lencana dipasang atomik saat ACC (`acceptRequest`), diizinkan rules hanya untuk leader/vice/admiral bersamaan dengan
  pembuatan keanggotaan. `ClanTagSync` juga mencoba ulang bila penulisan gagal. Anggota lama yang belum punya badge otomatis tersinkron saat membuka aplikasi.
- Tes: `node rules-tests/t10.js` (simulator `sim.js` sekarang ketat: `child(null)` = error). **Publikasikan ulang `database.rules.json`.**

- **Bar "Tiket Premium lagi dibagi" di atas chat dihapus** (mengganggu). Tiket tetap muncul sebagai kartu di dalam chat saat disebar; tidak ada lagi
  pengumuman yang menempel di atas layar. Toast hanya muncul untuk aksi kamu sendiri (menyebar / mengambil tiket).

- **Halaman AkimiGames & Nobar tidak bisa lagi digeser ke samping**: wadah halaman sebelumnya hanya `overflow-y-auto`, sehingga hiasan (kelopak, watermark logo,
  cahaya) yang melewati tepi layar membuat halaman bisa ditarik horizontal. Sekarang `overflow-x-hidden`, `overscroll-x-none`, dan hanya boleh geser vertikal.
- **Kontrol video meluber di HP layar sempit** (baris volume/PiP keluar dari kotak video dan menimpa judul): jarak atas/bawah dan tombol tengah dirapatkan,
  dan lapisan kontrol sekarang `overflow-hidden`, jadi tidak ada lagi yang keluar dari kotak video.
- **Tombol Skip Intro** di baris waktu kontrol video (di kiri label kualitas, tempat yang kamu lingkari). Sekali tekan melompat maju sesuai pengaturan:
  Pengaturan, Tombol Skip Intro, pilihan 80 / 85 / 90 / 95 detik (default 90). Di nobar hanya owner yang bisa memakainya; peserta ikut lewat sinkronisasi.

## AkimiGame: Dino Run (tombol Dino di AkimiGames)

- **Alur**: AkimiGames, Dino, menu (Main, Dino Collection, Spin). Halaman: `src/pages/DinoPage.tsx`; game: `src/dino/engine.ts` (canvas pixel-art 176 px, nearest-neighbor,
  partikel di array tetap/pooling, loop berhenti saat pause/background/halaman ditutup); spin: `src/dino/SpinScreen.tsx`; data: `src/services/dinoService.ts`.
- **Sprite**: `tools/gen_dino_sprites.py` membuat sprite sheet (`public/dino/*.png`, 4x4 frame 32x32 per skin: idle, kedip, hit, run x4, antisipasi/launch/udara/landing,
  jongkok x2, jatuh) untuk 12 skin + `neutral.png` (Akimi Orb, avatar netral BUKAN Dino) + `obstacles.png`. Hanya skin yang dipakai yang dimuat (lazy).
- **Tidak ada Dino gratis**: semua terkunci. Main dengan Akimi Orb, kumpulkan AkimiShard, lalu **Unlock Pertama** (Common dijamin, 50 shard, sekali) atau **Spin** (150) / **Gacha 5x** (650).
- **Peluang**: Common 80%, Rare 17,5%, Legend 2,3%, Mythic 0,2%. Pity keras: Rare tiap 10 spin, Legend tiap 80, Mythic tiap 250 (progress terlihat di layar Spin).
- **Duplikat** bisa dijual (Common 30, Rare 90, Legend 300, Mythic 900); Dino terakhir tidak bisa dijual.
- **Batas harian**: 10 game/hari, hari dihitung dari jam SERVER (WIB). Hadiah per game = **1 skor : 1 AkimiShard**, dibatasi per game menurut Dino yang dipakai (netral 1.500, Common 2.500, Rare 3.500, Legend 5.000, Mythic 7.500). Skor dibatasi laju waktu server (maks 25 poin/detik).
- **Keamanan (database.rules.json, node `dino_game/{uid}`)**: client tidak bisa memberi Dino, mengubah rarity, menambah shard, mengubah batas harian, best, atau total. Hasil undian dihitung dari
  seed = jam server saat bayar + hitungan undian + pity (rumus yang sama di rules dan `dinoService.ts`), jadi memilih hasil sendiri ditolak. Skor dibatasi laju waktu server (maks 25 poin/detik).
  Keterbatasan jujur: tanpa server yang mensimulasikan game, skor tidak bisa diverifikasi 100%; kerugiannya dibatasi (10 game/hari, cap shard per game). Untuk verifikasi penuh pindahkan `startRun/finishRun/revealNext`
  ke backend VPS dengan uid Firebase yang sama (struktur data sudah disiapkan).
- **Suara**: sintetis WebAudio, tanpa musik otomatis, ada tombol mute. Tes rules: `node rules-tests/t11.js` (73 skenario). **Publikasikan ulang `database.rules.json`.**

## Banner: GIF tahan banting + tombol link (Panel Developer)

- **Banner profil (GIF/gambar) kadang tampil, kadang tidak**: penyebab yang ditemukan: (1) kolom input memotong link di 500 huruf padahal link CDN (mis. Discord) sering lebih panjang,
  sehingga link terpotong diam-diam dan rusak; (2) link halaman (Giphy/Imgur/GitHub/Tenor) dipasang, bukan file langsung; (3) sebagian host menolak permintaan tanpa Referer atau memblokir hotlink dari aplikasi;
  (4) link .mp4/.webm tidak bisa dimuat sebagai gambar. Perbaikan: batas link 1000 huruf (rules + input), link Giphy/Imgur/GitHub/Dropbox otomatis diubah ke file langsung (`src/lib/media.ts`),
  link halaman yang tidak bisa diubah (Tenor, Pinterest, Instagram, dll.) ditolak dengan pesan jelas, dan tampilan (`src/components/RemoteMedia.tsx`) mencoba bertahap: tanpa Referer, dengan Referer, lalu lewat proxy gambar
  publik wsrv.nl (mendukung GIF beranimasi). Video .mp4/.webm diputar otomatis berulang tanpa suara.
- **Banner pengumuman developer** (Panel Developer, tab Banner): Judul, Teks, **Teks tombol + saklar ON/OFF** (ON memunculkan kolom link https://), pratinjau, Kirim. Bila ON, banner punya tombol yang membuka link
  lalu menutup banner. OFF = banner tanpa tombol. Data `banner/{title,text,btn?,link?}`; rules mewajibkan btn (maks 30) dan link (https, maks 500) muncul berpasangan. Tes: `node rules-tests/t12.js`.
