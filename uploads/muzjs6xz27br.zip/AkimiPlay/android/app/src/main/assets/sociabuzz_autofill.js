/*
 * Mengisi otomatis form dukungan Sociabuzz di dalam popup pembayaran AkimiPlay.
 * Nilainya datang dari window.__AKIMI_FILL = { amount, message, name, email } (disuntik oleh PaymentPopup.java).
 *
 * - Hanya mengisi kolom: jumlah, pesan, nama, email. Tidak pernah mencentang pernyataan/persetujuan apa pun
 *   (itu pernyataan si pembayar sendiri) dan tidak menekan tombol apa pun.
 * - Form dirender belakangan (SPA), jadi dicek berulang tiap 0,5 dtk sampai 40 dtk.
 * - Kolom hanya diisi bila masih kosong: kalau pengguna sudah mengetik sendiri, tidak ditimpa.
 * - Nilai dimasukkan lewat setter asli + event "input" supaya framework (React) ikut mengetahui perubahannya.
 */
(function () {
  var F = window.__AKIMI_FILL
  if (!F) return
  if (!/(^|\.)sociabuzz\.com$/i.test(location.hostname)) return
  if (window.__akimiFillTimer) return

  var TARGET = { amount: String(F.amount || ''), message: String(F.message || ''), name: String(F.name || ''), email: String(F.email || '') }
  var LABEL = {
    amount: /^(amount( to be given)?|jumlah( .*)?|nominal( .*)?)$/i,
    message: /^(write your message|your message|message|tulis pesan.*|pesan.*)$/i,
    name: /^(your name|name|nama\w*( .*)?)$/i,
    email: /^(your e-?mail|e-?mail\w*( .*)?)$/i,
  }
  var filled = {}
  var tries = 0

  function norm(t) {
    return String(t || '')
      .replace(/\s+/g, ' ')
      .replace(/\(.*?\)/g, '')
      .replace(/[*:]+\s*$/g, '')
      .trim()
  }
  function visible(el) {
    var r = el.getBoundingClientRect()
    return r.width > 0 && r.height > 0
  }
  function fields() {
    var out = []
    var all = document.querySelectorAll('input, textarea')
    for (var i = 0; i < all.length; i++) {
      var el = all[i]
      var type = (el.getAttribute('type') || 'text').toLowerCase()
      if (el.tagName === 'INPUT' && !/^(text|email|number|tel|search|url)?$/.test(type)) continue
      if (el.readOnly || el.disabled || !visible(el)) continue
      out.push(el)
    }
    return out
  }
  function isCurrency(el) {
    return el.tagName === 'INPUT' && /^[A-Za-z]{3}$/.test(el.value || '') && (el.value || '').toUpperCase() === el.value
  }
  function labelNodes(key) {
    var out = []
    var nodes = document.querySelectorAll('label, p, span, div, h1, h2, h3, h4, h5, legend, strong, b')
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i]
      if (n.children.length > 2) continue
      var t = norm(n.textContent)
      if (t && t.length <= 40 && LABEL[key].test(t)) out.push(n)
    }
    return out
  }
  function findByLabel(key, cands) {
    var nodes = labelNodes(key)
    for (var i = 0; i < nodes.length; i++) {
      var L = nodes[i]
      var forId = L.getAttribute && L.getAttribute('for')
      if (forId) {
        var byId = document.getElementById(forId)
        if (byId && cands.indexOf(byId) >= 0) return byId
      }
      for (var j = 0; j < cands.length; j++) {
        var c = cands[j]
        if (key === 'message' && c.tagName !== 'TEXTAREA') continue
        if (key !== 'message' && c.tagName === 'TEXTAREA') continue
        if (key === 'amount' && isCurrency(c)) continue
        if (L.contains(c) || L.compareDocumentPosition(c) & Node.DOCUMENT_POSITION_FOLLOWING) return c
      }
    }
    return null
  }
  function findByOrder(key, cands) {
    var ta = cands.filter(function (c) { return c.tagName === 'TEXTAREA' })
    var inputs = cands.filter(function (c) { return c.tagName === 'INPUT' && !isCurrency(c) })
    if (key === 'message') return ta[0] || null
    var mail = inputs.filter(function (c) { return (c.getAttribute('type') || '').toLowerCase() === 'email' || /mail/i.test(c.name || c.id || c.placeholder || '') })[0]
    if (key === 'email') return mail || null
    var rest = inputs.filter(function (c) { return c !== mail })
    if (key === 'amount') return rest[0] || null
    if (key === 'name') return rest[1] || null
    return null
  }
  function setVal(el, v) {
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
    var d = Object.getOwnPropertyDescriptor(proto, 'value')
    d.set.call(el, v)
    el.dispatchEvent(new Event('input', { bubbles: true }))
    el.dispatchEvent(new Event('change', { bubbles: true }))
  }
  function same(key, el) {
    return key === 'amount' ? String(el.value).replace(/\D/g, '') === TARGET.amount.replace(/\D/g, '') : el.value === TARGET[key]
  }
  function tick() {
    tries++
    var cands = fields()
    if (cands.length) {
      ;['amount', 'message', 'name', 'email'].forEach(function (key) {
        if (!TARGET[key]) return
        var el = findByLabel(key, cands) || (tries > 10 ? findByOrder(key, cands) : null)
        if (!el) return
        var empty = el.value === '' || (key === 'amount' && /^[0\s.,]*$/.test(el.value))
        // isi bila kosong (juga bila framework mengosongkannya lagi); jangan timpa ketikan pengguna
        if (empty && !same(key, el)) {
          setVal(el, TARGET[key])
          filled[key] = true
        }
      })
    }
    if (tries >= 80) {
      clearInterval(window.__akimiFillTimer)
    }
  }
  window.__akimiFillTimer = setInterval(tick, 500)
  tick()
})()
