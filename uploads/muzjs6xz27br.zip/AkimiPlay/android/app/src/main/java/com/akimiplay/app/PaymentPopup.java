package com.akimiplay.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;

/**
 * Popup pembayaran di dalam aplikasi (bukan Chrome): WebView halaman dukungan Sociabuzz AkimiPlay.
 *
 * - Kolom jumlah, pesan (UID), nama, dan email diisi otomatis oleh assets/sociabuzz_autofill.js
 *   (hanya di domain sociabuzz.com; pernyataan/persetujuan tidak pernah dicentang otomatis).
 * - Di bagian bawah selalu ada tombol "Kirim Bukti ke WhatsApp" (tersedia saat memilih QRIS / e-wallet).
 * - Aplikasi e-wallet (DANA, OVO, GoPay, dll.) dibuka lewat deep link; link WhatsApp dibuka di aplikasi WhatsApp.
 */
final class PaymentPopup {

    private PaymentPopup() {}

    static void show(
        final Activity activity,
        final String url,
        final String title,
        final String waNumber,
        final String waText,
        final JSONObject fill
    ) {
        final float d = activity.getResources().getDisplayMetrics().density;

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(false);

        // ----- kartu popup (sudut atas membulat), menempel di bawah layar -----
        final LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#101016"));
        float r = 22 * d;
        cardBg.setCornerRadii(new float[] { r, r, r, r, 0, 0, 0, 0 });
        card.setBackground(cardBg);
        card.setClipToOutline(true);

        // header
        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView titleView = new TextView(activity);
        titleView.setText(title);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(16);
        titleView.setTypeface(titleView.getTypeface(), android.graphics.Typeface.BOLD);
        titleView.setSingleLine(true);
        titleView.setPadding((int) (18 * d), 0, 0, 0);
        header.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = new TextView(activity);
        close.setText("\u2715");
        close.setTextColor(Color.parseColor("#C9C9D6"));
        close.setTextSize(20);
        close.setGravity(Gravity.CENTER);
        close.setContentDescription("Tutup");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        header.addView(close, new LinearLayout.LayoutParams((int) (52 * d), (int) (52 * d)));
        card.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (52 * d)));

        // progres muat
        final ProgressBar progress = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(5);
        card.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (3 * d)));

        // WebView
        final WebView web = new WebView(activity);
        web.setBackgroundColor(Color.WHITE);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        final String script = buildScript(activity, fill);

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(activity, view, request.getUrl().toString());
            }

            @Override
            public void onPageFinished(WebView view, String pageUrl) {
                // isi form hanya di Sociabuzz (bukan di halaman gateway pembayaran)
                if (script != null && isSociabuzz(pageUrl)) view.evaluateJavascript(script, null);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    String html = "<html><body style='font-family:sans-serif;padding:32px;text-align:center;color:#333'>"
                        + "<h3>Halaman gagal dimuat</h3><p>Periksa koneksi internet, lalu tutup popup ini dan buka lagi.</p></body></html>";
                    view.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
                }
            }
        });
        // QRIS / bukti bayar yang berupa file: serahkan ke aplikasi lain (browser/unduhan)
        web.setDownloadListener((dlUrl, userAgent, contentDisposition, mimeType, contentLength) -> openExternal(activity, dlUrl));

        card.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // bar WhatsApp
        LinearLayout bar = new LinearLayout(activity);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#0B0B10"));
        int pad = (int) (12 * d);
        bar.setPadding(pad, (int) (8 * d), pad, pad);
        TextView hint = new TextView(activity);
        hint.setText("Sudah bayar lewat QRIS / e-wallet? Kirim bukti pembayaran ke WhatsApp admin.");
        hint.setTextColor(Color.parseColor("#9A9AAB"));
        hint.setTextSize(12);
        hint.setPadding(0, 0, 0, (int) (6 * d));
        bar.addView(hint);
        TextView wa = new TextView(activity);
        wa.setText("Kirim Bukti ke WhatsApp");
        wa.setTextColor(Color.WHITE);
        wa.setTextSize(15);
        wa.setTypeface(wa.getTypeface(), android.graphics.Typeface.BOLD);
        wa.setGravity(Gravity.CENTER);
        GradientDrawable waBg = new GradientDrawable();
        waBg.setColor(Color.parseColor("#1FA855"));
        waBg.setCornerRadius(26 * d);
        wa.setBackground(waBg);
        wa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWhatsApp(activity, waNumber, waText);
            }
        });
        bar.addView(wa, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (48 * d)));
        card.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ----- susun ke jendela dialog -----
        FrameLayout root = new FrameLayout(activity);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.BOTTOM);
        lp.topMargin = (int) (56 * d);
        root.addView(card, lp);
        dialog.setContentView(root);

        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setDimAmount(0.6f);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        // Back: mundur di dalam halaman dulu, baru tutup popup
        dialog.setOnKeyListener(new Dialog.OnKeyListener() {
            @Override
            public boolean onKey(android.content.DialogInterface di, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    if (web.canGoBack()) web.goBack();
                    else dialog.dismiss();
                    return true;
                }
                return false;
            }
        });
        dialog.setOnDismissListener(di -> {
            web.stopLoading();
            web.loadUrl("about:blank");
            card.removeAllViews();
            web.destroy();
        });

        dialog.show();
        web.loadUrl(url);
    }

    // ---------- pembantu ----------

    private static boolean isSociabuzz(String url) {
        try {
            String host = Uri.parse(url).getHost();
            return host != null && (host.equals("sociabuzz.com") || host.endsWith(".sociabuzz.com"));
        } catch (Exception e) {
            return false;
        }
    }

    /** Memuat skrip pengisi dari assets lalu menyuntikkan nilainya sebagai window.__AKIMI_FILL. */
    private static String buildScript(Activity activity, JSONObject fill) {
        try {
            InputStream in = activity.getAssets().open("sociabuzz_autofill.js");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return "window.__AKIMI_FILL=" + fill.toString() + ";\n" + out.toString("UTF-8");
        } catch (Exception e) {
            return null; // tanpa pengisi otomatis, form tetap bisa diisi manual
        }
    }

    private static boolean handleUrl(Activity activity, WebView view, String url) {
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
        if (scheme.equals("http") || scheme.equals("https")) {
            if (host.equals("wa.me") || host.equals("api.whatsapp.com") || host.equals("wa.link") || host.endsWith(".whatsapp.com")) {
                openExternal(activity, url);
                return true;
            }
            return false; // tetap di dalam popup
        }
        if (scheme.equals("intent")) {
            try {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setComponent(null);
                intent.setSelector(null);
                activity.startActivity(intent);
            } catch (Exception e) {
                String fallback = null;
                try {
                    fallback = Intent.parseUri(url, Intent.URI_INTENT_SCHEME).getStringExtra("browser_fallback_url");
                } catch (Exception ignored) {
                    // abaikan
                }
                if (fallback != null && fallback.startsWith("http")) view.loadUrl(fallback);
                else Toast.makeText(activity, "Aplikasi pembayaran tidak ditemukan di HP ini", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        // deep link e-wallet (dana://, gojek://, shopeeid://, ovo://, ...)
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(activity, "Aplikasi pembayaran tidak ditemukan di HP ini", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {
            // abaikan
        }
        return true;
    }

    private static void openExternal(Activity activity, String url) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(activity, "Tidak bisa membuka tautan", Toast.LENGTH_SHORT).show();
        }
    }

    static void openWhatsApp(Activity activity, String number, String text) {
        String digits = number == null ? "" : number.replaceAll("[^0-9]", "");
        if (digits.length() < 8) {
            Toast.makeText(activity, "Nomor WhatsApp tidak valid", Toast.LENGTH_SHORT).show();
            return;
        }
        Uri uri = Uri.parse("https://wa.me/" + digits + (text == null || text.isEmpty() ? "" : "?text=" + Uri.encode(text)));
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            Toast.makeText(activity, "WhatsApp tidak ditemukan di HP ini", Toast.LENGTH_SHORT).show();
        }
    }
}
