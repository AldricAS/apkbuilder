package com.akimiplay.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Notifikasi APK asli (status bar Android): pesan dari developer dan episode baru.
 * Dipakai oleh plugin (saat aplikasi terbuka) dan oleh NotifyWorker (saat aplikasi ditutup).
 */
final class NotifyHelper {
    static final String CHANNEL_ID = "akimi_updates";
    static final String PREFS = "akimi_notif";

    private static final String K_ENABLED = "enabled";
    private static final String K_DB_URL = "dbUrl";
    private static final String K_API_BASE = "apiBase";
    private static final String K_LAST_BC = "lastBroadcastTs";
    private static final String K_EP_KEYS = "epKeys";
    private static final String K_ASKED = "permAsked";
    private static final int MAX_BODY = 300;

    private NotifyHelper() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void configure(Context c, boolean enabled, String dbUrl, String apiBase) {
        SharedPreferences.Editor e = prefs(c).edit().putBoolean(K_ENABLED, enabled);
        if (dbUrl != null && dbUrl.startsWith("https://")) e.putString(K_DB_URL, dbUrl);
        if (apiBase != null && apiBase.startsWith("https://")) e.putString(K_API_BASE, apiBase);
        e.apply();
    }

    static void markAsked(Context c) {
        prefs(c).edit().putBoolean(K_ASKED, true).apply();
    }

    static boolean wasAsked(Context c) {
        return prefs(c).getBoolean(K_ASKED, false);
    }

    /** Izin POST_NOTIFICATIONS (Android 13+) dan notifikasi tidak dimatikan dari pengaturan sistem. */
    static boolean canNotify(Context c) {
        if (Build.VERSION.SDK_INT >= 33
            && ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return NotificationManagerCompat.from(c).areNotificationsEnabled();
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Info & episode baru", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Pesan dari developer dan episode anime terbaru");
        nm.createNotificationChannel(ch);
    }

    static void show(Context c, int id, String title, String body) {
        if (!canNotify(c)) return;
        ensureChannel(c);
        Intent open = new Intent(c, MainActivity.class)
            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(c, id, open, flags);
        String text = body.length() > MAX_BODY ? body.substring(0, MAX_BODY) : body;
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_akimi)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi);
        try {
            NotificationManagerCompat.from(c).notify(id, b.build());
        } catch (SecurityException ignored) {
            // izin dicabut saat notifikasi dikirim
        }
    }

    // ---------- pesan developer ----------

    /** Hanya mengisi batas awal (sekali) supaya pesan lama tidak muncul sebagai notifikasi. */
    static void seedBroadcast(Context c, long ts) {
        SharedPreferences p = prefs(c);
        if (p.getLong(K_LAST_BC, 0) == 0 && ts > 0) p.edit().putLong(K_LAST_BC, ts).apply();
    }

    /** Menampilkan notifikasi jika pesan ini lebih baru dari yang terakhir ditampilkan. */
    static boolean showBroadcast(Context c, long ts, String from, String text) {
        SharedPreferences p = prefs(c);
        if (!p.getBoolean(K_ENABLED, true) || ts <= p.getLong(K_LAST_BC, 0)) return false;
        p.edit().putLong(K_LAST_BC, ts).apply();
        String f = (from == null || from.trim().isEmpty()) ? "Developer" : from.trim();
        show(c, (int) (ts % 100000) + 1000, "Pesan dari " + f, text == null ? "" : text);
        return true;
    }

    // ---------- pengecekan di latar belakang ----------

    static void checkAll(Context c) {
        SharedPreferences p = prefs(c);
        if (!p.getBoolean(K_ENABLED, true)) return;
        try {
            checkBroadcasts(c, p);
        } catch (Exception ignored) {
        }
        try {
            checkEpisodes(c, p);
        } catch (Exception ignored) {
        }
    }

    private static String httpGet(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(20000);
        con.setRequestProperty("Accept", "application/json");
        try {
            if (con.getResponseCode() / 100 != 2) throw new Exception("HTTP " + con.getResponseCode());
            InputStream in = con.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > 2000000) throw new Exception("respons terlalu besar");
            }
            return out.toString("UTF-8");
        } finally {
            con.disconnect();
        }
    }

    private static void checkBroadcasts(Context c, SharedPreferences p) throws Exception {
        String db = p.getString(K_DB_URL, null);
        if (db == null) return;
        String json = httpGet(db + "/broadcasts.json?orderBy=%22ts%22&limitToLast=5");
        if (json == null || json.trim().equals("null") || json.trim().equals("{}")) {
            // belum ada pesan: tandai "sudah dicek" supaya pesan pertama nanti tetap ditampilkan
            if (p.getLong(K_LAST_BC, 0) == 0) p.edit().putLong(K_LAST_BC, 1).apply();
            return;
        }
        JSONObject root = new JSONObject(json);
        List<JSONObject> list = new ArrayList<>();
        Iterator<String> it = root.keys();
        while (it.hasNext()) {
            JSONObject o = root.optJSONObject(it.next());
            if (o != null && o.optLong("ts", 0) > 0) list.add(o);
        }
        Collections.sort(list, (a, b) -> Long.compare(a.optLong("ts"), b.optLong("ts")));
        if (list.isEmpty()) {
            if (p.getLong(K_LAST_BC, 0) == 0) p.edit().putLong(K_LAST_BC, 1).apply();
            return;
        }
        if (p.getLong(K_LAST_BC, 0) == 0) { // pemakaian pertama: jadikan batas awal
            p.edit().putLong(K_LAST_BC, list.get(list.size() - 1).optLong("ts")).apply();
            return;
        }
        for (JSONObject o : list) {
            showBroadcast(c, o.optLong("ts"), o.optString("from", ""), o.optString("text", ""));
        }
    }

    private static String firstString(JSONObject o, String... keys) {
        for (String k : keys) {
            if (!o.has(k) || o.isNull(k)) continue;
            Object v = o.opt(k);
            if (v instanceof String || v instanceof Number) {
                String s = String.valueOf(v).trim();
                if (!s.isEmpty()) return s;
            }
        }
        return null;
    }

    private static void checkEpisodes(Context c, SharedPreferences p) throws Exception {
        String api = p.getString(K_API_BASE, null);
        if (api == null) return;
        JSONObject root = new JSONObject(httpGet(api + "/homepage"));
        for (int i = 0; i < 3; i++) { // buka pembungkus { data: {...} }
            JSONObject inner = root.optJSONObject("data");
            if (inner == null) inner = root.optJSONObject("result");
            if (inner == null) break;
            root = inner;
        }
        JSONArray arr = null;
        for (String k : new String[] {"new", "latest", "newest"}) {
            arr = root.optJSONArray(k);
            if (arr != null) break;
        }
        if (arr == null) return;

        List<String> keys = new ArrayList<>();
        List<String> titles = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            JSONObject src = o;
            if (firstString(o, "title", "name") == null && o.optJSONObject("anime") != null) src = o.optJSONObject("anime");
            String id = firstString(src, "id", "anime_id", "animeId", "_id", "slug", "uuid");
            String title = firstString(src, "title", "name", "anime_title", "title_english");
            if (id == null || title == null) continue;
            String ep = firstString(o, "latest_episode", "latestEpisode", "last_episode", "current_episode", "episode",
                "episode_number", "new_episode", "latest", "episode_label");
            keys.add(id + "|" + (ep == null ? "" : ep));
            titles.add(title);
            labels.add(ep == null ? "" : ep);
        }
        if (keys.isEmpty()) return;

        Set<String> known = new HashSet<>(p.getStringSet(K_EP_KEYS, new HashSet<String>()));
        if (known.isEmpty()) { // pemakaian pertama: simpan sebagai batas awal tanpa notifikasi
            p.edit().putStringSet(K_EP_KEYS, new HashSet<>(keys)).apply();
            return;
        }
        int shown = 0;
        int extra = 0;
        for (int i = 0; i < keys.size(); i++) {
            if (known.contains(keys.get(i))) continue;
            if (shown < 3) {
                String label = labels.get(i);
                String body = label.isEmpty()
                    ? "Ada pembaruan baru."
                    : "Episode " + label.replaceFirst("(?i)^(episode|eps?)\\.?\\s*", "") + " sudah tersedia.";
                show(c, 2000 + (Math.abs(keys.get(i).hashCode()) % 90000), titles.get(i), body);
                shown++;
            } else {
                extra++;
            }
        }
        if (extra > 0) show(c, 1999, "Episode baru", "Dan " + extra + " episode baru lainnya sudah tayang.");
        Set<String> merged = new HashSet<>(keys);
        int room = 150;
        for (String k : known) {
            if (room-- <= 0) break;
            merged.add(k);
        }
        p.edit().putStringSet(K_EP_KEYS, merged).apply();
    }
}
