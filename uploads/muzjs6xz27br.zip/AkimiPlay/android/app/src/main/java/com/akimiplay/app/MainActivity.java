package com.akimiplay.app;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import androidx.core.splashscreen.SplashScreen;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    private boolean keepSplash = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Splash native Android: tampil sebentar, lalu logo memudar dan membesar tipis.
        SplashScreen splash = SplashScreen.installSplashScreen(this);
        splash.setKeepOnScreenCondition(() -> keepSplash);
        new Handler(Looper.getMainLooper()).postDelayed(() -> keepSplash = false, 900);
        splash.setOnExitAnimationListener(provider -> {
            final View view = provider.getView();
            view.animate()
                .alpha(0f)
                .scaleX(1.06f)
                .scaleY(1.06f)
                .setDuration(320)
                .withEndAction(provider::remove)
                .start();
        });

        registerPlugin(AkimiNativePlugin.class);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        AkimiNativePlugin.handleUserLeaveHint(this);
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        AkimiNativePlugin.handlePipChanged(isInPictureInPictureMode);
    }
}
