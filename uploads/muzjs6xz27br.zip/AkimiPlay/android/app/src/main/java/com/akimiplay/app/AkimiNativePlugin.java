package com.akimiplay.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.app.PictureInPictureParams;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.StatFs;
import android.util.Rational;
import android.webkit.WebSettings;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Jembatan native untuk player: fullscreen + rotasi landscape, layar tetap menyala,
 * Picture-in-Picture, dan download video ke penyimpanan privat aplikasi.
 *
 * File download disimpan di getFilesDir()/downloads (folder privat AkimiPlay), BUKAN di galeri /
 * folder Download publik, sehingga hanya bisa diputar lewat aplikasi ini dan ikut terhapus saat
 * aplikasi di-uninstall.
 */
@CapacitorPlugin(
    name = "AkimiNative",
    permissions = {
        @Permission(strings = { Manifest.permission.POST_NOTIFICATIONS }, alias = "notifications")
    }
)
public class AkimiNativePlugin extends Plugin {

    private static AkimiNativePlugin instance;
    private boolean pipReady = false;

    @Override
    public void load() {
        instance = this;
    }

    // ---------- notifikasi APK ----------

    private JSObject notifState() {
        JSObject ret = new JSObject();
        ret.put("granted", NotifyHelper.canNotify(getContext()));
        ret.put("asked", NotifyHelper.wasAsked(getContext()));
        return ret;
    }

    @PluginMethod
    public void notifStatus(PluginCall call) {
        call.resolve(notifState());
    }

    @PluginMethod
    public void requestNotifPermission(PluginCall call) {
        NotifyHelper.ensureChannel(getContext());
        if (Build.VERSION.SDK_INT < 33 || NotifyHelper.canNotify(getContext())) {
            NotifyHelper.markAsked(getContext());
            call.resolve(notifState());
            return;
        }
        NotifyHelper.markAsked(getContext());
        requestPermissionForAlias("notifications", call, "notifPermResult");
    }

    @PermissionCallback
    private void notifPermResult(PluginCall call) {
        call.resolve(notifState());
    }

    @PluginMethod
    public void openNotifSettings(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName())
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Tidak bisa membuka pengaturan notifikasi");
        }
    }

    /** Menyimpan pengaturan & menjadwalkan pengecekan latar belakang (atau membatalkannya jika dimatikan). */
    @PluginMethod
    public void configureNotifications(PluginCall call) {
        boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", true));
        NotifyHelper.configure(getContext(), enabled, call.getString("dbUrl"), call.getString("apiBase"));
        NotifyHelper.ensureChannel(getContext());
        if (enabled) NotifyWorker.schedule(getContext());
        else NotifyWorker.cancel(getContext());
        call.resolve();
    }

    @PluginMethod
    public void seedBroadcast(PluginCall call) {
        Double ts = call.getDouble("ts", 0.0);
        NotifyHelper.seedBroadcast(getContext(), ts == null ? 0L : ts.longValue());
        call.resolve();
    }

    @PluginMethod
    public void showBroadcast(PluginCall call) {
        Double ts = call.getDouble("ts", 0.0);
        boolean shown = NotifyHelper.showBroadcast(
            getContext(), ts == null ? 0L : ts.longValue(), call.getString("from"), call.getString("text"));
        JSObject ret = new JSObject();
        ret.put("shown", shown);
        call.resolve(ret);
    }

    @PluginMethod
    public void setFullscreen(final PluginCall call) {
        final boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        final Activity activity = getActivity();
        activity.runOnUiThread(() -> {
            try {
                activity.setRequestedOrientation(
                    enabled
                        ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                );
                Window window = activity.getWindow();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    WindowManager.LayoutParams lp = window.getAttributes();
                    lp.layoutInDisplayCutoutMode = enabled
                        ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
                    window.setAttributes(lp);
                }
                WindowInsetsControllerCompat controller =
                    WindowCompat.getInsetsController(window, window.getDecorView());
                if (enabled) {
                    controller.setSystemBarsBehavior(
                        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    );
                    controller.hide(WindowInsetsCompat.Type.systemBars());
                } else {
                    controller.show(WindowInsetsCompat.Type.systemBars());
                }
                call.resolve();
            } catch (Exception e) {
                call.reject(e.getMessage());
            }
        });
    }

    @PluginMethod
    public void setKeepAwake(final PluginCall call) {
        final boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        final Activity activity = getActivity();
        activity.runOnUiThread(() -> {
            if (enabled) {
                activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } else {
                activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
            call.resolve();
        });
    }

    @PluginMethod
    public void isPipSupported(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("supported", pipSupported(getActivity()));
        call.resolve(ret);
    }

    @PluginMethod
    public void enterPip(PluginCall call) {
        if (!enterPipInternal(getActivity())) {
            call.reject("Picture-in-Picture tidak didukung di perangkat ini");
            return;
        }
        call.resolve();
    }

    @PluginMethod
    public void setPipReady(PluginCall call) {
        pipReady = Boolean.TRUE.equals(call.getBoolean("ready", false));
        call.resolve();
    }

    private static boolean pipSupported(Activity activity) {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            && activity.getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);
    }

    private static boolean enterPipInternal(Activity activity) {
        if (!pipSupported(activity)) return false;
        try {
            PictureInPictureParams params = new PictureInPictureParams.Builder()
                .setAspectRatio(new Rational(16, 9))
                .build();
            return activity.enterPictureInPictureMode(params);
        } catch (IllegalStateException e) {
            return false;
        }
    }

    /** Dipanggil MainActivity saat user menekan Home: masuk PiP otomatis jika video sedang diputar. */
    public static void handleUserLeaveHint(Activity activity) {
        if (instance != null && instance.pipReady) {
            enterPipInternal(activity);
        }
    }

    /** Dipanggil MainActivity saat mode PiP berubah; diteruskan ke JavaScript. */
    public static void handlePipChanged(boolean active) {
        if (instance != null) {
            JSObject data = new JSObject();
            data.put("active", active);
            instance.notifyListeners("pipChanged", data);
        }
    }

    // ------------------------------------------------------------------------------------------
    // Download offline
    // ------------------------------------------------------------------------------------------

    private static final String UA =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    private final ExecutorService downloadPool = Executors.newFixedThreadPool(2);
    private final Map<String, AtomicBoolean> cancelFlags = new ConcurrentHashMap<>();

    private String userAgent() {
        try {
            return WebSettings.getDefaultUserAgent(getContext());
        } catch (Exception e) {
            return UA;
        }
    }

    private File downloadsDir() {
        File dir = new File(getContext().getFilesDir(), "downloads");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    /** Nama file aman: tanpa path separator / karakter aneh. */
    private static String safeName(String name) {
        return name == null ? "" : name.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    @PluginMethod
    public void getDownloadsDir(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("path", downloadsDir().getAbsolutePath());
        call.resolve(ret);
    }

    /**
     * Mengunduh url ke downloads/fileName. Progress dikirim lewat event "downloadProgress"
     * { id, received, total }. Mendukung lanjut (resume) dari file .part jika server mengizinkan Range.
     */
    @PluginMethod
    public void downloadFile(final PluginCall call) {
        final String id = call.getString("id");
        final String url = call.getString("url");
        final String fileName = safeName(call.getString("fileName"));
        final String referer = call.getString("referer");
        final boolean video = Boolean.TRUE.equals(call.getBoolean("video", true));
        if (id == null || url == null || fileName.isEmpty()) {
            call.reject("Parameter download tidak lengkap");
            return;
        }
        final AtomicBoolean cancelled = new AtomicBoolean(false);
        cancelFlags.put(id, cancelled);

        downloadPool.execute(() -> {
            File target = new File(downloadsDir(), fileName);
            File part = new File(downloadsDir(), fileName + ".part");
            HttpURLConnection conn = null;
            try {
                long existing = part.exists() ? part.length() : 0;
                int code = 0;
                // Server video sering menolak (403) tergantung header. Coba beberapa profil header,
                // dimulai dari yang paling mirip dengan pemutar di dalam aplikasi (WebView).
                String[][] profiles = new String[][] {
                    {"https://localhost/", "https://localhost"},   // seperti <video> di WebView aplikasi
                    {null, null},                                  // tanpa Referer/Origin
                    {referer, null},                               // Referer situs sumber
                    {referer, referer == null ? null : referer.replaceAll("/+$", "")},
                };
                String current = url;
                for (int pi = 0; pi < profiles.length; pi++) {
                    if (pi > 0 && conn != null) conn.disconnect();
                    String[] pr = profiles[pi];
                    current = url;
                    for (int hop = 0; hop < 6; hop++) {
                        conn = (HttpURLConnection) new URL(current).openConnection();
                        conn.setInstanceFollowRedirects(false);
                        conn.setConnectTimeout(15000);
                        conn.setReadTimeout(20000);
                        conn.setRequestProperty("User-Agent", userAgent());
                        conn.setRequestProperty("Accept", "*/*");
                        conn.setRequestProperty("Accept-Language", "id-ID,id;q=0.9,en;q=0.8");
                        if (pr[0] != null && !pr[0].isEmpty()) conn.setRequestProperty("Referer", pr[0]);
                        if (pr[1] != null && !pr[1].isEmpty()) conn.setRequestProperty("Origin", pr[1]);
                        // Range selalu dikirim (seperti pemutar video); 0- = dari awal
                        conn.setRequestProperty("Range", "bytes=" + existing + "-");
                        code = conn.getResponseCode();
                        if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                            String loc = conn.getHeaderField("Location");
                            conn.disconnect();
                            if (loc == null) throw new Exception("Redirect tanpa tujuan");
                            current = new URL(new URL(current), loc).toString();
                            continue;
                        }
                        break;
                    }
                    if (code == 200 || code == 206) break;
                    if (code != 401 && code != 403 && code != 400 && code != 416) break;
                    if (code == 416 && existing > 0) {
                        // file parsial tidak cocok dengan server: mulai ulang dari awal
                        part.delete();
                        existing = 0;
                    }
                }
                if (conn == null) throw new Exception("Gagal terhubung");

                if (code != 200 && code != 206) throw new Exception("Server menolak download (kode " + code + ")");

                String type = conn.getContentType() == null ? "" : conn.getContentType().toLowerCase();
                if (video && (type.contains("mpegurl") || current.toLowerCase().contains(".m3u8"))) {
                    throw new Exception("Sumber ini berformat streaming (HLS) dan belum bisa di-download");
                }
                if (video && (type.contains("text/html") || type.contains("json"))) {
                    throw new Exception("Link video tidak valid atau sudah kedaluwarsa");
                }

                boolean resumed = code == 206 && existing > 0;
                if (!resumed) existing = 0;
                long remaining = conn.getContentLengthLong();
                long total = remaining > 0 ? remaining + existing : -1;

                if (total > 0) {
                    StatFs stat = new StatFs(downloadsDir().getAbsolutePath());
                    if (stat.getAvailableBytes() < (total - existing) + 50L * 1024 * 1024) {
                        throw new Exception("Ruang penyimpanan tidak cukup");
                    }
                }

                long received = existing;
                long lastEmit = 0;
                byte[] buf = new byte[64 * 1024];
                try (InputStream in = conn.getInputStream();
                     FileOutputStream out = new FileOutputStream(part, resumed)) {
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        if (cancelled.get()) throw new CancelledException();
                        out.write(buf, 0, n);
                        received += n;
                        long now = System.currentTimeMillis();
                        if (now - lastEmit > 350) {
                            lastEmit = now;
                            emitProgress(id, received, total);
                        }
                    }
                }
                if (total > 0 && received < total) throw new Exception("Koneksi terputus sebelum selesai");
                if (target.exists()) target.delete();
                if (!part.renameTo(target)) throw new Exception("Gagal menyimpan file");
                emitProgress(id, received, received);

                JSObject ret = new JSObject();
                ret.put("path", target.getAbsolutePath());
                ret.put("size", target.length());
                call.resolve(ret);
            } catch (CancelledException e) {
                part.delete();
                call.reject("cancelled");
            } catch (Exception e) {
                // .part sengaja dibiarkan agar bisa dilanjutkan (resume) saat dicoba lagi
                call.reject(e.getMessage() == null ? "Download gagal" : e.getMessage());
            } finally {
                cancelFlags.remove(id);
                if (conn != null) conn.disconnect();
            }
        });
    }

    private void emitProgress(String id, long received, long total) {
        JSObject data = new JSObject();
        data.put("id", id);
        data.put("received", received);
        data.put("total", total);
        notifyListeners("downloadProgress", data);
    }

    private static class CancelledException extends Exception {}

    @PluginMethod
    public void cancelDownload(PluginCall call) {
        String id = call.getString("id");
        AtomicBoolean flag = id == null ? null : cancelFlags.get(id);
        if (flag != null) flag.set(true);
        call.resolve();
    }

    /** Menghapus file download (dan sisa .part). Hanya file di dalam folder downloads yang bisa dihapus. */
    @PluginMethod
    public void deleteDownload(PluginCall call) {
        String name = safeName(call.getString("fileName"));
        if (!name.isEmpty()) {
            new File(downloadsDir(), name).delete();
            new File(downloadsDir(), name + ".part").delete();
        }
        call.resolve();
    }

    @PluginMethod
    public void downloadExists(PluginCall call) {
        String name = safeName(call.getString("fileName"));
        JSObject ret = new JSObject();
        ret.put("exists", !name.isEmpty() && new File(downloadsDir(), name).exists());
        call.resolve(ret);
    }

    // ---------- pembayaran Premium (popup Sociabuzz di dalam aplikasi) ----------

    /**
     * Membuka popup pembayaran. Hanya URL https di domain sociabuzz.com yang diterima.
     * Parameter: url, title, amount, message, name, email, waNumber, waText.
     */
    @PluginMethod
    public void openPayment(final PluginCall call) {
        final String url = call.getString("url", "");
        Uri u = Uri.parse(url);
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase();
        boolean ok = "https".equals(u.getScheme()) && (host.equals("sociabuzz.com") || host.endsWith(".sociabuzz.com"));
        if (!ok) {
            call.reject("URL pembayaran tidak valid");
            return;
        }
        final String title = call.getString("title", "Pembayaran");
        final String waNumber = call.getString("waNumber", "");
        final String waText = call.getString("waText", "");
        final org.json.JSONObject fill = new org.json.JSONObject();
        try {
            Integer amount = call.getInt("amount");
            fill.put("amount", amount == null ? 0 : amount);
            fill.put("message", call.getString("message", ""));
            fill.put("name", call.getString("name", ""));
            fill.put("email", call.getString("email", ""));
        } catch (Exception e) {
            call.reject("Data pembayaran tidak valid");
            return;
        }
        final Activity activity = getActivity();
        if (activity == null) {
            call.reject("Activity tidak tersedia");
            return;
        }
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    PaymentPopup.show(activity, url, title, waNumber, waText, fill);
                    call.resolve();
                } catch (Exception e) {
                    call.reject(e.getMessage() == null ? "Gagal membuka pembayaran" : e.getMessage());
                }
            }
        });
    }

    /** Membuka WhatsApp ke nomor admin dengan teks terisi (dipakai juga dari layar Premium). */
    @PluginMethod
    public void openWhatsApp(PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null) {
            call.reject("Activity tidak tersedia");
            return;
        }
        final String number = call.getString("number", "");
        final String text = call.getString("text", "");
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                PaymentPopup.openWhatsApp(activity, number, text);
                call.resolve();
            }
        });
    }

    /** Membuka link https di peramban eksternal (halaman update APK). */
    @PluginMethod
    public void openUrl(final PluginCall call) {
        final Activity activity = getActivity();
        final String url = call.getString("url", "");
        if (activity == null) {
            call.reject("Activity tidak tersedia");
            return;
        }
        if (url == null || !url.startsWith("https://")) {
            call.reject("URL tidak valid");
            return;
        }
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addCategory(Intent.CATEGORY_BROWSABLE);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(i);
                    call.resolve();
                } catch (Exception e) {
                    call.reject("Tidak ada aplikasi untuk membuka link");
                }
            }
        });
    }
}
