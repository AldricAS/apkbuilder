# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class com.getcapacitor.** { *; }
-keep class com.akimiplay.app.** { *; }
