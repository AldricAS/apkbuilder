// Membangun APK debug lewat Gradle lalu menyalinnya menjadi <NamaApp>.apk di root project.
import { spawnSync } from 'node:child_process'
import { existsSync, copyFileSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

const cfg = JSON.parse(readFileSync('app.config.json', 'utf-8'))
const androidDir = 'android'
const isWin = process.platform === 'win32'
const gradlew = join(androidDir, isWin ? 'gradlew.bat' : 'gradlew')
const wrapperJar = join(androidDir, 'gradle', 'wrapper', 'gradle-wrapper.jar')

function run(cmd, args, cwd) {
  const r = spawnSync(cmd, args, { cwd, stdio: 'inherit', shell: isWin })
  return r.status === 0
}

// 1. Pastikan Gradle Wrapper lengkap (file .jar tidak bisa disertakan di repo ini).
if (!existsSync(wrapperJar)) {
  console.log('[apk] gradle-wrapper.jar belum ada, membuatnya dengan `gradle wrapper`...')
  const ok = run('gradle', ['wrapper', '--gradle-version', '8.11.1', '--distribution-type', 'bin'], androidDir)
  if (!ok) {
    console.error(
      '\nGagal membuat Gradle Wrapper. Pasang Gradle dulu:\n' +
        '  Termux : pkg install gradle\n' +
        '  Lainnya: https://gradle.org/install/\n' +
        'Atau buka folder android/ di Android Studio (wrapper dibuat otomatis).',
    )
    process.exit(1)
  }
}

// 2. Argumen Gradle. Di Termux, aapt2 bawaan Google (x86_64) tidak bisa jalan, jadi pakai aapt2 milik Termux.
const args = ['assembleDebug', '--no-daemon']
const prefix = process.env.PREFIX || ''
if (prefix.includes('com.termux')) {
  const aapt2 = join(prefix, 'bin', 'aapt2')
  if (existsSync(aapt2)) {
    args.push(`-Pandroid.aapt2FromMavenOverride=${aapt2}`)
    console.log(`[apk] Termux terdeteksi, memakai aapt2: ${aapt2}`)
  } else {
    console.warn('[apk] aapt2 Termux tidak ditemukan. Jalankan: pkg install aapt2')
  }
}

if (!existsSync(gradlew)) {
  console.error('android/gradlew tidak ditemukan.')
  process.exit(1)
}
if (!isWin) run('chmod', ['+x', 'gradlew'], androidDir)

console.log('[apk] menjalankan Gradle, ini bisa memakan waktu beberapa menit...')
if (!run(isWin ? 'gradlew.bat' : './gradlew', args, androidDir)) {
  console.error('\nBuild Gradle gagal. Baca pesan error di atas.')
  process.exit(1)
}

const built = join(androidDir, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk')
if (!existsSync(built)) {
  console.error(`APK tidak ditemukan di ${built}`)
  process.exit(1)
}
const out = `${cfg.appName}.apk`
copyFileSync(built, out)
console.log(`\nSelesai!\n  APK Gradle : ${built}\n  Salinan    : ${out}`)
