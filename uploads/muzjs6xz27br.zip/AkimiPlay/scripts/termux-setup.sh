#!/data/data/com.termux/files/usr/bin/bash
# Menyiapkan Termux untuk membangun APK (best-effort, lihat README bagian "Keterbatasan Termux").
set -e

pkg update -y
pkg upgrade -y
pkg install -y nodejs git openjdk-21 wget unzip aapt2

export JAVA_HOME="$PREFIX/lib/jvm/java-21-openjdk"
export ANDROID_HOME="$HOME/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  cd "$HOME"
  wget -q --show-progress -O cmdline-tools.zip \
    https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q cmdline-tools.zip -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm cmdline-tools.zip
fi

SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses >/dev/null || true
"$SDKM" "platforms;android-35" "build-tools;34.0.0"

grep -q ANDROID_HOME "$HOME/.bashrc" 2>/dev/null || {
  echo "export JAVA_HOME=$JAVA_HOME" >> "$HOME/.bashrc"
  echo "export ANDROID_HOME=$ANDROID_HOME" >> "$HOME/.bashrc"
}

echo "sdk.dir=$ANDROID_HOME" > "$(dirname "$0")/../android/local.properties"
echo
echo "Selesai. Tutup dan buka lagi Termux, lalu jalankan: npm install && npm run apk"
