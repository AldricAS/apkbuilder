// Menyalin app.config.json ke file-file Android (nama app, applicationId, versi).
// Dijalankan otomatis oleh `npm run build`.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'

const cfg = JSON.parse(readFileSync('app.config.json', 'utf-8'))
const { appName, appId, version, versionCode } = cfg

if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(appId)) {
  console.error(`applicationId tidak valid: "${appId}". Contoh yang valid: com.akimiplay.app`)
  process.exit(1)
}
if (!appName || !version || !Number.isInteger(versionCode)) {
  console.error('app.config.json harus berisi appName, version, dan versionCode (angka bulat).')
  process.exit(1)
}

const xml = (s) =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/'/g, "\\'")

writeFileSync(
  'android/app-config.properties',
  `applicationId=${appId}\nversionName=${version}\nversionCode=${versionCode}\n`,
)

mkdirSync('android/app/src/main/res/values', { recursive: true })
writeFileSync(
  'android/app/src/main/res/values/strings.xml',
  `<?xml version='1.0' encoding='utf-8'?>
<resources>
    <string name="app_name">${xml(appName)}</string>
    <string name="title_activity_main">${xml(appName)}</string>
    <string name="package_name">${appId}</string>
    <string name="custom_url_scheme">${appId}</string>
</resources>
`,
)

console.log(`[config] ${appName} (${appId}) v${version} (${versionCode})`)
