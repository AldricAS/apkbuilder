# Kas Harian – cara build jadi APK

Aplikasi pencatat pemasukan & pengeluaran (data tersimpan offline di HP).

## Cara 1: Android Studio (APK asli)
Syarat: Node.js 18+, Android Studio, JDK 17.

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

Di Android Studio: Build > Build Bundle(s)/APK(s) > Build APK(s).
Hasil: android/app/build/outputs/apk/debug/app-debug.apk

## Cara 2: Tanpa Android Studio
Upload isi folder `www/` (zip) ke layanan online seperti WebIntoApp atau
Appilix, lalu download APK-nya.

## Ganti nama/ID app
Edit `appId` dan `appName` di capacitor.config.json sebelum `cap add android`.
