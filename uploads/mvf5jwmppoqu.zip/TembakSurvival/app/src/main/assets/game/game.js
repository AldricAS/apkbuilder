import * as THREE from './three.module.min.js';
import { makeSoldier, makeRifle, makeCrate, makeSandbagWall, makeBarrel, makeWatchtower, makeRock, groundTex } from './models.js';

// ===== Pengaturan =====
const ARENA = 40, SPEED = 6, LOOK = 0.004, FIRE_RATE = 0.1, MAG = 30, RELOAD_T = 1.6;
const $ = id => document.getElementById(id);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.9;
document.body.prepend(renderer.domElement);

const scene = new THREE.Scene();
const SKY = new THREE.Color('#9a9583');
scene.background = SKY; scene.fog = new THREE.Fog(SKY, 15, 75);
const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.05, 200);
scene.add(camera);

scene.add(new THREE.HemisphereLight('#d9d2b8', '#4a4330', 0.9));
const sun = new THREE.DirectionalLight('#ffe6bf', 2.2);
sun.position.set(20, 30, 10); sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024); Object.assign(sun.shadow.camera, { left: -45, right: 45, top: 45, bottom: -45 });
scene.add(sun);

const ground = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ map: groundTex, roughness: 1 }));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);

// ===== Arena & rintangan (collider lingkaran) =====
const colliders = [];
function place(obj, x, z, r, rot = 0) { obj.position.x = x; obj.position.z = z; obj.rotation.y = rot; scene.add(obj); colliders.push({ x, z, r }); }
for (let i = 0; i < 14; i++) { const a = Math.random() * 6.28, d = 8 + Math.random() * 28; const s = 0.9 + Math.random() * 0.6; place(makeCrate(s), Math.cos(a) * d, Math.sin(a) * d, s * 0.75, Math.random()); }
for (let i = 0; i < 8; i++) { const a = i / 8 * 6.28 + 0.3, d = 14 + (i % 2) * 10; place(makeSandbagWall(4), Math.cos(a) * d, Math.sin(a) * d, 1.6, -a + Math.PI / 2); }
for (let i = 0; i < 10; i++) { const a = Math.random() * 6.28, d = 6 + Math.random() * 30; place(makeBarrel(), Math.cos(a) * d, Math.sin(a) * d, 0.45); }
for (const [x, z] of [[-30, -30], [30, -30], [-30, 30], [30, 30]]) place(makeWatchtower(), x, z, 1.6);
for (let i = 0; i < 25; i++) { const a = Math.random() * 6.28, d = ARENA + 2 + Math.random() * 15; const r = makeRock(1 + Math.random() * 2); r.position.set(Math.cos(a) * d, r.position.y, Math.sin(a) * d); scene.add(r); }
// Pagar perbatasan
const fenceMat = new THREE.MeshStandardMaterial({ color: '#4d4a3c', roughness: 0.6, metalness: 0.5 });
for (let i = 0; i < 64; i++) { const a = i / 64 * 6.28; const p = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 6), fenceMat); p.position.set(Math.cos(a) * ARENA, 1.1, Math.sin(a) * ARENA); p.castShadow = true; scene.add(p); }

// ===== Pemain & senjata =====
const player = { pos: new THREE.Vector3(0, 1.65, 0), yaw: 0, pitch: 0, hp: 100, ammo: MAG, reloading: 0, cd: 0 };
const gun = makeRifle(); gun.scale.setScalar(0.6); gun.position.set(0.22, -0.22, -0.45); camera.add(gun);
const flash = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), new THREE.MeshBasicMaterial({ color: '#ffcf70' }));
flash.position.set(0, 0, -0.75); flash.visible = false; gun.add(flash);
const flashLight = new THREE.PointLight('#ffb050', 0, 6); gun.add(flashLight); flashLight.position.copy(flash.position);

// ===== Efek =====
const tracers = [], sparks = [];
const tracerMat = new THREE.LineBasicMaterial({ color: '#ffd27a', transparent: true });
function tracer(a, b, color) {
  const l = new THREE.Line(new THREE.BufferGeometry().setFromPoints([a, b]), color ? new THREE.LineBasicMaterial({ color, transparent: true }) : tracerMat.clone());
  l.userData.t = 0.06; scene.add(l); tracers.push(l);
}
const sparkGeo = new THREE.SphereGeometry(0.04, 4, 3);
function burst(p, color, n = 8) {
  for (let i = 0; i < n; i++) { const m = new THREE.Mesh(sparkGeo, new THREE.MeshBasicMaterial({ color })); m.position.copy(p); m.userData = { v: new THREE.Vector3((Math.random() - .5) * 4, Math.random() * 4, (Math.random() - .5) * 4), t: 0.5 }; scene.add(m); sparks.push(m); }
}

// ===== Audio sintetis =====
let actx;
function sfx(freq, dur, vol = 0.3, noise = true) {
  if (!actx) return;
  const t = actx.currentTime, g = actx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); g.connect(actx.destination);
  if (noise) { const b = actx.createBuffer(1, actx.sampleRate * dur, actx.sampleRate), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; const s = actx.createBufferSource(); s.buffer = b; const f = actx.createBiquadFilter(); f.frequency.value = freq; s.connect(f).connect(g); s.start(); }
  else { const o = actx.createOscillator(); o.frequency.value = freq; o.connect(g); o.start(); o.stop(t + dur); }
}

// ===== Musuh =====
const enemies = [];
let wave = 0, score = 0, toSpawn = 0, spawnT = 0, state = 'menu', waveBreak = 0;
function spawnEnemy() {
  const heavy = wave >= 3 && Math.random() < 0.25;
  const e = makeSoldier(heavy); if (heavy) e.scale.setScalar(1.15);
  const a = Math.random() * 6.28; e.position.set(Math.cos(a) * (ARENA - 2), 0, Math.sin(a) * (ARENA - 2));
  e.userData.hp = heavy ? 6 : 3; e.userData.speed = (heavy ? 1.8 : 2.6) + wave * 0.15;
  e.userData.fireCd = 1 + Math.random() * 2; e.userData.walk = Math.random() * 6; e.userData.dead = 0; e.userData.flash = 0;
  e.userData.points = heavy ? 250 : 100;
  scene.add(e); enemies.push(e);
}
function startWave() {
  wave++; toSpawn = 4 + wave * 3; spawnT = 0;
  $('wave').textContent = wave; showMsg('GELOMBANG ' + wave);
}
function showMsg(t) { const m = $('msg'); m.textContent = t; m.style.opacity = 1; clearTimeout(showMsg.h); showMsg.h = setTimeout(() => m.style.opacity = 0, 1800); }

function collide(p, r) {
  for (const c of colliders) { const dx = p.x - c.x, dz = p.z - c.z, d = Math.hypot(dx, dz), min = c.r + r; if (d < min && d > 0.0001) { p.x = c.x + dx / d * min; p.z = c.z + dz / d * min; } }
  const d = Math.hypot(p.x, p.z); if (d > ARENA - 1) { p.x *= (ARENA - 1) / d; p.z *= (ARENA - 1) / d; }
}

// Garis pandang terhalang rintangan?
function blocked(a, b) {
  const dx = b.x - a.x, dz = b.z - a.z, L = Math.hypot(dx, dz);
  for (const c of colliders) { const t = Math.max(0, Math.min(1, ((c.x - a.x) * dx + (c.z - a.z) * dz) / (L * L))); if (Math.hypot(a.x + dx * t - c.x, a.z + dz * t - c.z) < c.r * 0.8 && t > 0.05 && t < 0.95) return true; }
  return false;
}

// ===== Menembak =====
const ray = new THREE.Raycaster(), center = new THREE.Vector2(0, 0);
let firing = false, recoil = 0;
function shoot() {
  if (player.reloading > 0 || player.cd > 0) return;
  if (player.ammo <= 0) { reload(); return; }
  player.ammo--; player.cd = FIRE_RATE; recoil = 1; sfx(1800, 0.12, 0.35);
  flash.visible = true; flashLight.intensity = 4; setTimeout(() => { flash.visible = false; flashLight.intensity = 0; }, 40);
  const spread = new THREE.Vector2((Math.random() - .5) * 0.02, (Math.random() - .5) * 0.02);
  ray.setFromCamera(spread.add(center), camera);
  const targets = [ground, ...scene.children.filter(o => o !== ground && o !== camera && o.type !== 'Line' && !sparks.includes(o))];
  const hits = ray.intersectObjects(targets, true);
  const from = new THREE.Vector3(); flash.getWorldPosition(from);
  if (hits.length) {
    const h = hits[0]; tracer(from, h.point);
    let o = h.object; while (o.parent && o.parent !== scene) o = o.parent;
    if (enemies.includes(o) && !o.userData.dead) {
      const head = h.object === o.userData.head;
      o.userData.hp -= head ? 3 : 1; o.userData.flash = 0.1; burst(h.point, '#7a1010', 6); sfx(400, 0.08, 0.2);
      if (o.userData.hp <= 0) { o.userData.dead = 1.2; score += o.userData.points * (head ? 2 : 1); if (head) showMsg('HEADSHOT!'); }
    } else burst(h.point, '#d8c28a', 5);
  } else tracer(from, ray.ray.at(80, new THREE.Vector3()));
  hud();
}
function reload() { if (player.reloading > 0 || player.ammo === MAG) return; player.reloading = RELOAD_T; sfx(600, 0.2, 0.2); $('ammo').textContent = '...'; }

function hud() {
  $('score').textContent = score; if (player.reloading <= 0) $('ammo').textContent = player.ammo;
  $('hp').style.width = Math.max(0, player.hp) + '%'; $('hp').style.background = player.hp < 35 ? '#b3402a' : '#7da544';
  $('left').textContent = enemies.filter(e => !e.userData.dead).length + toSpawn;
}

// ===== Kontrol sentuh + keyboard =====
const move = { x: 0, y: 0 }, keys = {};
let joyId = null, lookId = null, lookLast = null;
const joy = $('joy'), knob = $('knob');
function joyUpdate(t) { const r = joy.getBoundingClientRect(); let dx = t.clientX - (r.left + 65), dy = t.clientY - (r.top + 65); const d = Math.hypot(dx, dy); if (d > 50) { dx *= 50 / d; dy *= 50 / d; } move.x = dx / 50; move.y = dy / 50; knob.style.transform = `translate(${dx}px,${dy}px)`; }
joy.addEventListener('touchstart', e => { const t = e.changedTouches[0]; joyId = t.identifier; joyUpdate(t); e.preventDefault(); }, { passive: false });
$('fire').addEventListener('touchstart', e => { firing = true; e.preventDefault(); }, { passive: false });
$('fire').addEventListener('touchend', () => firing = false);
$('reload').addEventListener('touchstart', e => { reload(); e.preventDefault(); }, { passive: false });
addEventListener('touchstart', e => { for (const t of e.changedTouches) if (t.clientX > innerWidth * 0.4 && lookId === null && t.target === renderer.domElement) { lookId = t.identifier; lookLast = [t.clientX, t.clientY]; } });
addEventListener('touchmove', e => {
  for (const t of e.changedTouches) {
    if (t.identifier === joyId) joyUpdate(t);
    if (t.identifier === lookId) { player.yaw -= (t.clientX - lookLast[0]) * LOOK; player.pitch -= (t.clientY - lookLast[1]) * LOOK; lookLast = [t.clientX, t.clientY]; }
  }
}, { passive: false });
addEventListener('touchend', e => { for (const t of e.changedTouches) { if (t.identifier === joyId) { joyId = null; move.x = move.y = 0; knob.style.transform = ''; } if (t.identifier === lookId) lookId = null; } });
// Desktop (untuk uji di emulator)
addEventListener('keydown', e => { keys[e.code] = true; if (e.code === 'KeyR') reload(); });
addEventListener('keyup', e => keys[e.code] = false);
renderer.domElement.addEventListener('mousedown', () => { if (state === 'play') { renderer.domElement.requestPointerLock?.(); firing = true; } });
addEventListener('mouseup', () => firing = false);
addEventListener('mousemove', e => { if (document.pointerLockElement) { player.yaw -= e.movementX * 0.0025; player.pitch -= e.movementY * 0.0025; } });

$('start').addEventListener('click', () => {
  actx = actx || new (window.AudioContext || window.webkitAudioContext)();
  for (const e of enemies) scene.remove(e); enemies.length = 0;
  Object.assign(player, { hp: 100, ammo: MAG, reloading: 0, yaw: 0, pitch: 0 }); player.pos.set(0, 1.65, 0);
  wave = 0; score = 0; state = 'play'; $('menu').style.display = 'none'; startWave(); hud();
});
function gameOver() {
  state = 'over'; const best = Math.max(score, +localStorage.best || 0); localStorage.best = best;
  $('menu').querySelector('h1').textContent = 'GUGUR DI MEDAN PERANG';
  $('sub').innerHTML = `Gelombang ${wave} · Skor ${score}<br>Rekor terbaik: ${best}`;
  $('start').textContent = 'MAIN LAGI'; $('menu').style.display = 'flex'; firing = false;
}

addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });

// ===== Loop utama =====
const clock = new THREE.Clock(), fwd = new THREE.Vector3(), right = new THREE.Vector3(), tmp = new THREE.Vector3();
let bob = 0;
function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(clock.getDelta(), 0.05);
  if (state === 'play') update(dt);
  else player.yaw += dt * 0.1;
  player.pitch = Math.max(-1.3, Math.min(1.3, player.pitch));
  camera.position.copy(player.pos); camera.rotation.set(player.pitch + recoil * 0.03, player.yaw, 0, 'YXZ');
  for (let i = tracers.length - 1; i >= 0; i--) { const l = tracers[i]; l.userData.t -= dt; l.material.opacity = l.userData.t / 0.06; if (l.userData.t <= 0) { scene.remove(l); tracers.splice(i, 1); } }
  for (let i = sparks.length - 1; i >= 0; i--) { const s = sparks[i]; s.userData.v.y -= 12 * dt; s.position.addScaledVector(s.userData.v, dt); s.userData.t -= dt; if (s.userData.t <= 0) { scene.remove(s); sparks.splice(i, 1); } }
  renderer.render(scene, camera);
}

function update(dt) {
  // Gerak relatif kamera
  let mx = move.x + ((keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0)), my = move.y + ((keys.KeyS ? 1 : 0) - (keys.KeyW ? 1 : 0));
  fwd.set(-Math.sin(player.yaw), 0, -Math.cos(player.yaw)); right.set(Math.cos(player.yaw), 0, -Math.sin(player.yaw));
  tmp.set(0, 0, 0).addScaledVector(right, mx).addScaledVector(fwd, -my); if (tmp.length() > 1) tmp.normalize();
  player.pos.addScaledVector(tmp, SPEED * dt); collide(player.pos, 0.4);
  const moving = tmp.lengthSq() > 0.01; bob += dt * (moving ? 10 : 2);
  gun.position.set(0.22 + Math.sin(bob) * (moving ? 0.012 : 0.003), -0.22 + Math.abs(Math.cos(bob)) * (moving ? 0.012 : 0.003), -0.45 + recoil * 0.05);
  gun.rotation.x = recoil * 0.12 + (player.reloading > 0 ? -0.8 : 0);
  recoil *= Math.exp(-15 * dt);

  player.cd -= dt;
  if (player.reloading > 0) { player.reloading -= dt; if (player.reloading <= 0) { player.ammo = MAG; hud(); } }
  if (firing) shoot();

  // Spawn & gelombang
  if (toSpawn > 0) { spawnT -= dt; if (spawnT <= 0) { spawnEnemy(); toSpawn--; spawnT = Math.max(0.6, 2.2 - wave * 0.15); hud(); } }
  else if (!enemies.some(e => !e.userData.dead)) {
    if (waveBreak <= 0) { waveBreak = 4; player.hp = Math.min(100, player.hp + 25); score += wave * 200; showMsg('GELOMBANG SELESAI'); hud(); }
    waveBreak -= dt; if (waveBreak <= 0) startWave();
  }

  // AI musuh
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i], u = e.userData;
    if (u.dead) { u.dead -= dt; e.rotation.x = Math.max(-Math.PI / 2, e.rotation.x - dt * 4); if (u.dead <= 0) { e.position.y -= dt * 2; if (e.position.y < -2) { scene.remove(e); enemies.splice(i, 1); } } continue; }
    const dx = player.pos.x - e.position.x, dz = player.pos.z - e.position.z, d = Math.hypot(dx, dz);
    e.rotation.y = Math.atan2(-dx, -dz);
    const see = !blocked(e.position, player.pos);
    if (d > 7 || !see) { e.position.x += dx / d * u.speed * dt; e.position.z += dz / d * u.speed * dt; u.walk += dt * u.speed * 3; }
    collide(e.position, 0.4);
    for (const o of enemies) if (o !== e && !o.userData.dead) { const ox = e.position.x - o.position.x, oz = e.position.z - o.position.z, od = Math.hypot(ox, oz); if (od < 0.9 && od > 0) { e.position.x += ox / od * 0.02; e.position.z += oz / od * 0.02; } }
    const sw = Math.sin(u.walk) * 0.6; u.legL.rotation.x = sw; u.legR.rotation.x = -sw;
    e.traverse(m => { if (m.isMesh && m.material.emissive) m.material.emissive?.setRGB(u.flash > 0 ? 0.6 : 0, 0, 0); }); u.flash -= dt;
    u.fireCd -= dt;
    if (u.fireCd <= 0 && d < 30 && see) {
      u.fireCd = Math.max(0.7, 2.2 - wave * 0.1) + Math.random();
      const from = e.position.clone(); from.y = 1.35;
      const acc = Math.max(0.25, 0.75 - d / 50);
      sfx(900, 0.1, 0.15 * Math.max(0.2, 1 - d / 30));
      if (Math.random() < acc) { player.hp -= 6 + wave; tracer(from, player.pos.clone().add(new THREE.Vector3(0, -0.3, 0)), '#ff9a6a'); $('hit').style.opacity = 1; setTimeout(() => $('hit').style.opacity = 0, 150); hud(); if (player.hp <= 0) return gameOver(); }
      else tracer(from, player.pos.clone().add(new THREE.Vector3((Math.random() - .5) * 2, (Math.random() - .5), (Math.random() - .5) * 2)), '#ff9a6a');
    }
  }
}
loop();
