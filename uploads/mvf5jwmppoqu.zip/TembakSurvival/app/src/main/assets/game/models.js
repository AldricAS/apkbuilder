// Semua model 3D dibuat secara prosedural (tanpa file eksternal).
import * as THREE from './three.module.min.js';

const M = (c, r = 0.85, m = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });
const box = (w, h, d, mat) => { const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); o.castShadow = o.receiveShadow = true; return o; };
const cyl = (rt, rb, h, mat, s = 10) => { const o = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, s), mat); o.castShadow = o.receiveShadow = true; return o; };

export function canvasTex(draw, size = 256, rep = 1) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  draw(c.getContext('2d'), size);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep, rep);
  t.colorSpace = THREE.SRGBColorSpace; return t;
}
function noise(g, s, base, n, amt) {
  g.fillStyle = base; g.fillRect(0, 0, s, s);
  for (let i = 0; i < n; i++) { const v = Math.random() * amt; g.fillStyle = `rgba(${v > amt / 2 ? '255,240,210' : '0,0,0'},${Math.random() * 0.12})`; g.fillRect(Math.random() * s, Math.random() * s, 2 + Math.random() * 6, 2 + Math.random() * 6); }
}
const camoTex = canvasTex((g, s) => { g.fillStyle = '#4f5434'; g.fillRect(0, 0, s, s); const cs = ['#3a3d25', '#6b6a45', '#2c2a1c']; for (let i = 0; i < 40; i++) { g.fillStyle = cs[i % 3]; g.beginPath(); g.ellipse(Math.random() * s, Math.random() * s, 10 + Math.random() * 30, 6 + Math.random() * 18, Math.random() * 3, 0, 7); g.fill(); } }, 128);
const woodTex = canvasTex((g, s) => { g.fillStyle = '#7a5a34'; g.fillRect(0, 0, s, s); for (let y = 0; y < s; y += 4) { g.fillStyle = `rgba(40,25,10,${Math.random() * 0.3})`; g.fillRect(0, y, s, 2); } g.strokeStyle = '#3b2a16'; g.lineWidth = 8; g.strokeRect(4, 4, s - 8, s - 8); g.beginPath(); g.moveTo(0, 0); g.lineTo(s, s); g.stroke(); }, 128);
const sandTex = canvasTex((g, s) => noise(g, s, '#9c8a62', 400, 1), 64);

export const groundTex = canvasTex((g, s) => { noise(g, s, '#7d7150', 3000, 1); for (let i = 0; i < 30; i++) { g.fillStyle = 'rgba(60,70,35,.25)'; g.beginPath(); g.arc(Math.random() * s, Math.random() * s, 10 + Math.random() * 30, 0, 7); g.fill(); } }, 512, 24);

const mCamo = new THREE.MeshStandardMaterial({ map: camoTex, roughness: 0.95 });
const mSkin = M('#b08566'), mBoot = M('#1e1a14'), mVest = M('#3f4229'), mHelm = M('#4a4e30', 0.7);
const mGun = M('#3a3c3f', 0.4, 0.6), mGunWood = M('#5b3d22', 0.7);

export function makeRifle() {
  const g = new THREE.Group();
  g.add(box(0.06, 0.09, 0.55, mGun));                       // receiver
  const barrel = cyl(0.015, 0.015, 0.45, mGun, 8); barrel.rotation.x = Math.PI / 2; barrel.position.z = -0.48; g.add(barrel);
  const hand = box(0.07, 0.07, 0.25, mGunWood); hand.position.set(0, -0.01, -0.3); g.add(hand);
  const mag = box(0.045, 0.18, 0.08, mGun); mag.position.set(0, -0.12, -0.08); mag.rotation.x = 0.25; g.add(mag);
  const grip = box(0.045, 0.12, 0.05, mGun); grip.position.set(0, -0.09, 0.12); grip.rotation.x = -0.3; g.add(grip);
  const stock = box(0.05, 0.1, 0.25, mGunWood); stock.position.set(0, -0.02, 0.38); g.add(stock);
  const sight = box(0.02, 0.05, 0.04, mGun); sight.position.set(0, 0.07, -0.2); g.add(sight);
  return g;
}

export function makeSoldier(tint = 0) {
  const s = new THREE.Group();
  const vest = tint ? M(new THREE.Color().setHSL(0.08, 0.3, 0.25)) : mVest;
  const legL = new THREE.Group(), legR = new THREE.Group();
  for (const [leg, x] of [[legL, -0.13], [legR, 0.13]]) {
    const thigh = box(0.18, 0.5, 0.2, mCamo); thigh.position.y = -0.25; leg.add(thigh);
    const shin = box(0.16, 0.42, 0.18, mCamo); shin.position.y = -0.7; leg.add(shin);
    const boot = box(0.18, 0.12, 0.3, mBoot); boot.position.set(0, -0.95, -0.05); leg.add(boot);
    leg.position.set(x, 1.0, 0); s.add(leg);
  }
  const torso = box(0.5, 0.6, 0.28, mCamo); torso.position.y = 1.3; s.add(torso);
  const v = box(0.54, 0.45, 0.33, vest); v.position.y = 1.35; s.add(v);
  for (let i = -1; i <= 1; i++) { const p = box(0.1, 0.12, 0.06, vest); p.position.set(i * 0.15, 1.25, -0.19); s.add(p); }
  const belt = box(0.52, 0.08, 0.3, mBoot); belt.position.y = 1.02; s.add(belt);
  const neck = cyl(0.07, 0.08, 0.1, mSkin); neck.position.y = 1.65; s.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 10), mSkin); head.position.y = 1.8; head.castShadow = true; s.add(head);
  const helm = new THREE.Mesh(new THREE.SphereGeometry(0.17, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), mHelm); helm.position.y = 1.83; helm.castShadow = true; s.add(helm);
  const brim = cyl(0.19, 0.19, 0.02, mHelm, 14); brim.position.y = 1.83; s.add(brim);
  const goggles = box(0.22, 0.05, 0.05, M('#111', 0.2, 0.5)); goggles.position.set(0, 1.82, -0.13); s.add(goggles);
  const armL = new THREE.Group(), armR = new THREE.Group();
  for (const [arm, x] of [[armL, -0.32], [armR, 0.32]]) {
    const up = box(0.14, 0.38, 0.15, mCamo); up.position.y = -0.18; arm.add(up);
    const lo = box(0.12, 0.34, 0.13, mCamo); lo.position.set(0, -0.42, -0.12); lo.rotation.x = -0.9; arm.add(lo);
    arm.position.set(x, 1.55, 0); arm.rotation.x = -0.9; s.add(arm);
  }
  const rifle = makeRifle(); rifle.position.set(0.1, 1.3, -0.45); s.add(rifle);
  s.userData = { legL, legR, armL, armR, head };
  return s;
}

export function makeCrate(size = 1) { const b = box(size, size, size, new THREE.MeshStandardMaterial({ map: woodTex, roughness: 0.9 })); b.position.y = size / 2; return b; }

export function makeSandbagWall(len = 4) {
  const g = new THREE.Group(); const mat = new THREE.MeshStandardMaterial({ map: sandTex, roughness: 1, color: '#b8a77c' });
  for (let row = 0; row < 3; row++) for (let i = 0; i < len * 2; i++) {
    const bag = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.32, 4, 8), mat);
    bag.rotation.z = Math.PI / 2; bag.scale.set(1, 1, 0.6 + Math.random() * 0.1);
    bag.position.set(-len / 2 + i * 0.5 + (row % 2) * 0.25, 0.14 + row * 0.24, 0);
    bag.castShadow = bag.receiveShadow = true; g.add(bag);
  }
  return g;
}

export function makeBarrel() {
  const g = new THREE.Group(); const red = M('#5d2b1c', 0.6, 0.4);
  const b = cyl(0.35, 0.35, 1.1, red, 16); b.position.y = 0.55; g.add(b);
  for (const y of [0.2, 0.55, 0.9]) { const r = cyl(0.36, 0.36, 0.04, M('#333', 0.5, 0.6), 16); r.position.y = y; g.add(r); }
  return g;
}

export function makeWatchtower() {
  const g = new THREE.Group(); const w = new THREE.MeshStandardMaterial({ map: woodTex, roughness: 0.9 });
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { const p = box(0.2, 5, 0.2, w); p.position.set(x, 2.5, z); g.add(p); }
  const floor = box(2.6, 0.15, 2.6, w); floor.position.y = 4; g.add(floor);
  for (const [x, z, rw, rd] of [[0, -1.25, 2.6, 0.1], [0, 1.25, 2.6, 0.1], [-1.25, 0, 0.1, 2.6], [1.25, 0, 0.1, 2.6]]) { const r = box(rw, 0.8, rd, w); r.position.set(x, 4.5, z); g.add(r); }
  const roof = new THREE.Mesh(new THREE.ConeGeometry(2.1, 1, 4), M('#3d3a2a')); roof.position.y = 6.2; roof.rotation.y = Math.PI / 4; roof.castShadow = true; g.add(roof);
  return g;
}

export function makeRock(s = 1) {
  const geo = new THREE.DodecahedronGeometry(s, 1); const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) p.setXYZ(i, p.getX(i) * (0.8 + Math.random() * 0.4), p.getY(i) * (0.5 + Math.random() * 0.3), p.getZ(i) * (0.8 + Math.random() * 0.4));
  geo.computeVertexNormals();
  const r = new THREE.Mesh(geo, M('#6b6455', 1)); r.castShadow = r.receiveShadow = true; r.position.y = s * 0.3; return r;
}
