# Tembak Survival 3D (Proyek Android)

Mode: Survival Gelombang. Gaya: militer realistis. Semua model 3D (prajurit musuh,
senapan, peti, karung pasir, tong, menara) dibuat secara prosedural di `app/src/main/assets/game/models.js`.

## Cara build
1. Buka folder ini di Android Studio (Koala atau lebih baru).
2. Biarkan Gradle sync (Android Studio akan mengunduh Gradle 8.7 otomatis).
3. Run ke HP / emulator, atau Build > Build APK.

## Kontrol
- Joystick kiri: bergerak
- Geser layar kanan: membidik
- Tombol TEMBAK, ISI (reload)
