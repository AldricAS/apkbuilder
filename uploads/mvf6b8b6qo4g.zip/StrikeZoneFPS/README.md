# Strike Zone FPS (Godot 4 - Android)

Game FPS tembak-tembakan dengan gelombang musuh.

## Bebas hak cipta
- Semua model 3D (senjata, tangan, prajurit musuh, peti, bangunan) dibuat langsung dari kode, jadi 100% milikmu.
- Semua efek suara (folder `sfx/`) dibuat sendiri dari sintesis suara, jadi tidak ada hak cipta pihak lain.

## Fitur
- Animasi reload bertahap: senjata dimiringkan, magazen dilepas, dimasukkan lagi, lalu bolt ditarik, masing-masing dengan suaranya
- Recoil, kilatan moncong, efek senjata bergoyang saat jalan, percikan dan lubang peluru
- Musuh: animasi jalan, gerak ke samping, efek kena tembak (berkedip merah dan terdorong), animasi jatuh saat mati, dan suara 3D
- Headshot langsung mematikan, ada penanda kena tembak, efek layar merah saat terluka
- Kontrol sentuh: joystick di kiri, geser kanan untuk melihat, tombol TEMBAK / RELOAD / LOMPAT
- Di PC: WASD, mouse, R untuk reload, Spasi untuk lompat
- Memakai renderer Mobile, satu bayangan matahari, dan bentuk sederhana supaya lancar di HP

## Cara membuat APK
1. Install **Godot 4.3+** (godotengine.org) dan Android SDK + JDK 17.
2. Buka Godot, lalu Import, pilih `project.godot`.
3. Buka Editor, Manage Export Templates, lalu Download.
4. Buka Editor Settings, Export, Android, lalu isi path SDK dan debug keystore.
5. Buka Project, Export, pilih preset **Android**, lalu Export Project. Hasilnya `build/StrikeZoneFPS.apk`.
