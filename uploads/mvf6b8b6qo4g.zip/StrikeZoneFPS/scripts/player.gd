extends CharacterBody3D
## Pemain: kontrol sentuh + keyboard/mouse, senjata viewmodel, recoil, reload, HUD.

const SPEED := 5.0
const JUMP := 4.8
const GRAV := 14.0
const MAG_SIZE := 30
const FIRE_RATE := 0.1
const SENS_MOUSE := 0.0022
const SENS_TOUCH := 0.005
const BUTTONS := {
	"fire": [Vector2(170, 190), 85.0],
	"reload": [Vector2(330, 105), 52.0],
	"jump": [Vector2(105, 360), 52.0],
}

var hp := 100.0
var ammo := MAG_SIZE
var reserve := 150
var kills := 0
var reloading := false
var dead := false
var fire_cd := 0.0
var yaw := 0.0
var pitch := 0.0
var recoil_pitch := 0.0
var bob_t := 0.0
var step_t := 0.0
var kick := 0.0
var sway := Vector2.ZERO

var head: Node3D
var cam: Camera3D
var gun_root: Node3D
var gun: Node3D
var mag: Node3D
var mag_base := Vector3(0, -0.1, -0.07)
var flash: OmniLight3D
var flash_mesh: MeshInstance3D
var gun_base_pos := Vector3(0.2, -0.19, -0.42)

var hud: CanvasLayer
var lbl_ammo: Label
var lbl_wave: Label
var lbl_kills: Label
var lbl_center: Label
var lbl_hit: Label
var hp_bar: ProgressBar
var vignette: ColorRect
var joy_base: Panel
var joy_knob: Panel

var move_id := -1
var look_id := -1
var fire_id := -1
var move_origin := Vector2.ZERO
var move_vec := Vector2.ZERO
var holes: Array[Node3D] = []
var snd := {}


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1 | 4
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.75
	col.shape = cap
	col.position.y = 0.875
	add_child(col)
	head = Node3D.new()
	head.position.y = 1.6
	add_child(head)
	cam = Camera3D.new()
	cam.fov = 75
	cam.near = 0.02
	cam.far = 200
	head.add_child(cam)
	cam.current = true
	_build_gun()
	_build_hud()
	for n in ["shot", "reload_out", "reload_in", "bolt", "empty", "hit", "step", "hurt"]:
		var p := AudioStreamPlayer.new()
		p.stream = load("res://sfx/%s.wav" % n)
		p.max_polyphony = 4
		add_child(p)
		snd[n] = p


func play(n: String, vary := 0.05) -> void:
	var p: AudioStreamPlayer = snd[n]
	p.pitch_scale = 1.0 + randf_range(-vary, vary)
	p.play()


# ---------- Senjata (model prosedural) ----------
func _m(c: Color, rough := 0.5, metal := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	return m


func _p(parent: Node3D, size: Vector3, pos: Vector3, m: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	mi.mesh = b
	mi.position = pos
	mi.rotation = rot
	mi.material_override = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _build_gun() -> void:
	gun_root = Node3D.new()
	gun_root.position = gun_base_pos
	cam.add_child(gun_root)
	gun = Node3D.new()
	gun_root.add_child(gun)
	var metal := _m(Color(0.09, 0.09, 0.1), 0.35, 0.85)
	var poly := _m(Color(0.16, 0.15, 0.13), 0.75)
	var tan := _m(Color(0.45, 0.38, 0.27), 0.7)
	var skin := _m(Color(0.7, 0.53, 0.4), 0.7)
	var glove := _m(Color(0.12, 0.12, 0.11), 0.9)
	var sleeve := _m(Color(0.3, 0.32, 0.22), 0.9)

	_p(gun, Vector3(0.065, 0.085, 0.34), Vector3(0, 0, 0), metal)
	_p(gun, Vector3(0.07, 0.075, 0.24), Vector3(0, 0.002, -0.27), tan)
	var barrel := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.011
	cyl.bottom_radius = 0.011
	cyl.height = 0.2
	barrel.mesh = cyl
	barrel.rotation.x = PI / 2
	barrel.position = Vector3(0, 0.012, -0.48)
	barrel.material_override = metal
	barrel.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	gun.add_child(barrel)
	_p(gun, Vector3(0.03, 0.03, 0.06), Vector3(0, 0.012, -0.58), metal)
	_p(gun, Vector3(0.052, 0.08, 0.22), Vector3(0, -0.015, 0.27), tan)
	_p(gun, Vector3(0.04, 0.11, 0.05), Vector3(0, -0.09, 0.09), poly, Vector3(-0.3, 0, 0))
	_p(gun, Vector3(0.02, 0.008, 0.3), Vector3(0, 0.047, -0.05), metal)
	_p(gun, Vector3(0.04, 0.045, 0.08), Vector3(0, 0.072, 0.0), metal)
	_p(gun, Vector3(0.012, 0.03, 0.012), Vector3(0, 0.06, -0.36), metal)

	mag = Node3D.new()
	mag.position = mag_base
	gun.add_child(mag)
	_p(mag, Vector3(0.042, 0.16, 0.07), Vector3(0, -0.06, 0), poly, Vector3(0.18, 0, 0))

	# Tangan
	_p(gun, Vector3(0.06, 0.07, 0.09), Vector3(0.01, -0.09, 0.12), glove)
	_p(gun, Vector3(0.075, 0.075, 0.3), Vector3(0.05, -0.12, 0.3), sleeve, Vector3(0.25, -0.2, 0))
	_p(gun, Vector3(0.07, 0.05, 0.1), Vector3(-0.01, -0.05, -0.27), glove)
	_p(gun, Vector3(0.075, 0.075, 0.35), Vector3(-0.12, -0.12, -0.08), sleeve, Vector3(0.2, 0.75, 0))
	_p(gun, Vector3(0.05, 0.03, 0.04), Vector3(0.005, -0.055, 0.07), skin)

	flash = OmniLight3D.new()
	flash.position = Vector3(0, 0.012, -0.65)
	flash.light_color = Color(1, 0.75, 0.4)
	flash.light_energy = 4.0
	flash.omni_range = 5.0
	flash.visible = false
	gun.add_child(flash)
	flash_mesh = MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(0.14, 0.14)
	flash_mesh.mesh = q
	var fm := StandardMaterial3D.new()
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fm.albedo_color = Color(1, 0.7, 0.3, 0.9)
	var g := GradientTexture2D.new()
	g.fill = GradientTexture2D.FILL_RADIAL
	g.fill_from = Vector2(0.5, 0.5)
	g.fill_to = Vector2(1.0, 0.5)
	var grad := Gradient.new()
	grad.set_color(0, Color(1, 1, 1, 1))
	grad.set_color(1, Color(1, 1, 1, 0))
	g.gradient = grad
	fm.albedo_texture = g
	flash_mesh.material_override = fm
	flash_mesh.position = Vector3(0, 0.012, -0.66)
	flash_mesh.visible = false
	flash_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	gun.add_child(flash_mesh)


# ---------- HUD ----------
func _place(c: Control, anchor: Vector2, pos: Vector2, size: Vector2) -> void:
	c.anchor_left = anchor.x
	c.anchor_right = anchor.x
	c.anchor_top = anchor.y
	c.anchor_bottom = anchor.y
	c.offset_left = pos.x
	c.offset_top = pos.y
	c.offset_right = pos.x + size.x
	c.offset_bottom = pos.y + size.y
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE


func _label(parent: Control, text: String, anchor: Vector2, pos: Vector2, size: Vector2, fs: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("shadow_offset_x", 2)
	l.add_theme_constant_override("shadow_offset_y", 2)
	_place(l, anchor, pos, size)
	parent.add_child(l)
	return l


func _circle(r: float, alpha: float) -> Panel:
	var p := Panel.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(1, 1, 1, alpha)
	sb.border_color = Color(1, 1, 1, 0.4)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(int(r))
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.size = Vector2(r, r) * 2
	return p


func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(root)

	vignette = ColorRect.new()
	vignette.color = Color(0.8, 0, 0, 0)
	vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(vignette)

	for r in [Rect2(-1, -14, 2, 8), Rect2(-1, 6, 2, 8), Rect2(-14, -1, 8, 2), Rect2(6, -1, 8, 2)]:
		var c := ColorRect.new()
		c.color = Color(1, 1, 1, 0.9)
		_place(c, Vector2(0.5, 0.5), r.position, r.size)
		root.add_child(c)
	lbl_hit = _label(root, "X", Vector2(0.5, 0.5), Vector2(-12, -20), Vector2(24, 40), 28)
	lbl_hit.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_hit.visible = false

	lbl_ammo = _label(root, "", Vector2(1, 0), Vector2(-260, 20), Vector2(240, 50), 40)
	lbl_ammo.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	lbl_wave = _label(root, "", Vector2(0.5, 0), Vector2(-150, 16), Vector2(300, 40), 26)
	lbl_wave.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_kills = _label(root, "", Vector2(0, 0), Vector2(24, 64), Vector2(200, 30), 20)
	lbl_center = _label(root, "", Vector2(0.5, 0.5), Vector2(-300, -120), Vector2(600, 80), 34)
	lbl_center.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	hp_bar = ProgressBar.new()
	hp_bar.max_value = 100
	hp_bar.value = 100
	hp_bar.show_percentage = false
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.5)
	var fg := StyleBoxFlat.new()
	fg.bg_color = Color(0.85, 0.2, 0.2)
	hp_bar.add_theme_stylebox_override("background", bg)
	hp_bar.add_theme_stylebox_override("fill", fg)
	_place(hp_bar, Vector2(0, 0), Vector2(24, 26), Vector2(260, 22))
	root.add_child(hp_bar)

	if DisplayServer.is_touchscreen_available():
		for k in BUTTONS:
			var off: Vector2 = BUTTONS[k][0]
			var r: float = BUTTONS[k][1]
			var p := _circle(r, 0.14)
			_place(p, Vector2(1, 1), -off - Vector2(r, r), Vector2(r, r) * 2)
			root.add_child(p)
			var l := _label(p, {"fire": "TEMBAK", "reload": "RELOAD", "jump": "LOMPAT"}[k], Vector2(0, 0), Vector2.ZERO, Vector2(r, r) * 2, 18)
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		joy_base = _circle(90, 0.08)
		joy_base.visible = false
		root.add_child(joy_base)
		joy_knob = _circle(38, 0.35)
		joy_base.add_child(joy_knob)
		joy_knob.position = Vector2(52, 52)
	else:
		lbl_center.text = "Klik untuk mulai  |  WASD, Mouse, R reload, Spasi lompat"


func set_wave(w: int) -> void:
	lbl_wave.text = "GELOMBANG %d" % w
	lbl_center.text = "GELOMBANG %d" % w
	get_tree().create_timer(2.0).timeout.connect(_clear_center)


func _clear_center() -> void:
	if not dead:
		lbl_center.text = ""


# ---------- Input ----------
func _button_at(pos: Vector2, vs: Vector2) -> String:
	for k in BUTTONS:
		var c: Vector2 = vs - BUTTONS[k][0]
		if pos.distance_to(c) < BUTTONS[k][1] * 1.2:
			return k
	return ""


func _input(event: InputEvent) -> void:
	if dead:
		if (event is InputEventScreenTouch or event is InputEventMouseButton) and event.pressed:
			get_tree().reload_current_scene()
		return
	var vs := get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			var b := _button_at(event.position, vs)
			if b == "fire":
				fire_id = event.index
				if look_id == -1:
					look_id = event.index
			elif b == "reload":
				reload()
			elif b == "jump":
				_jump()
			elif event.position.x < vs.x * 0.4 and move_id == -1:
				move_id = event.index
				move_origin = event.position
				joy_base.position = move_origin - Vector2(90, 90)
				joy_knob.position = Vector2(52, 52)
				joy_base.visible = true
			elif look_id == -1:
				look_id = event.index
		else:
			if event.index == move_id:
				move_id = -1
				move_vec = Vector2.ZERO
				joy_base.visible = false
			if event.index == look_id:
				look_id = -1
			if event.index == fire_id:
				fire_id = -1
	elif event is InputEventScreenDrag:
		if event.index == move_id:
			var d: Vector2 = (event.position - move_origin).limit_length(90.0)
			move_vec = d / 90.0
			joy_knob.position = Vector2(52, 52) + d
		elif event.index == look_id:
			_look(event.relative * SENS_TOUCH)
	elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_look(event.relative * SENS_MOUSE)
	elif event is InputEventMouseButton and event.pressed:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			lbl_center.text = ""
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_R:
			reload()
		elif event.keycode == KEY_SPACE:
			_jump()
		elif event.keycode == KEY_ESCAPE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _look(r: Vector2) -> void:
	yaw -= r.x
	pitch = clampf(pitch - r.y, -1.4, 1.4)
	sway += r * 4.0


func _jump() -> void:
	if is_on_floor():
		velocity.y = JUMP


# ---------- Loop ----------
func _physics_process(delta: float) -> void:
	if dead:
		return
	var input := move_vec
	var kb := Vector2(
		float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)),
		float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
	if kb != Vector2.ZERO:
		input = kb.normalized()
	rotation.y = yaw
	recoil_pitch = lerpf(recoil_pitch, 0.0, delta * 7.0)
	head.rotation.x = pitch + recoil_pitch

	var dir := transform.basis * Vector3(input.x, 0, input.y)
	velocity.x = lerpf(velocity.x, dir.x * SPEED, delta * 10.0)
	velocity.z = lerpf(velocity.z, dir.z * SPEED, delta * 10.0)
	if not is_on_floor():
		velocity.y -= GRAV * delta
	move_and_slide()

	var hs := Vector2(velocity.x, velocity.z).length()
	var k := minf(hs / SPEED, 1.0)
	if is_on_floor() and hs > 0.5:
		bob_t += delta * hs * 1.7
		step_t += delta * hs
		if step_t > 2.0:
			step_t = 0.0
			play("step", 0.15)
	head.position.y = 1.6 - absf(cos(bob_t)) * 0.035 * k

	sway = sway.lerp(Vector2.ZERO, delta * 8.0)
	kick = lerpf(kick, 0.0, delta * 14.0)
	var bob := Vector3(sin(bob_t) * 0.012, -absf(cos(bob_t)) * 0.012, 0) * k
	var sw := Vector3(clampf(-sway.x, -0.03, 0.03), clampf(sway.y, -0.03, 0.03), 0)
	gun_root.position = gun_root.position.lerp(gun_base_pos + bob + sw + Vector3(0, 0, kick), delta * 16.0)
	if not reloading:
		gun.rotation = gun.rotation.lerp(Vector3.ZERO, delta * 12.0)

	fire_cd -= delta
	var held := fire_id != -1 or (Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED)
	if held and fire_cd <= 0 and not reloading:
		shoot()

	lbl_ammo.text = "%d / %d" % [ammo, reserve]
	lbl_kills.text = "Kill: %d" % kills
	hp_bar.value = hp
	vignette.color.a = move_toward(vignette.color.a, 0.0, delta * 0.8)


# ---------- Tembak ----------
func shoot() -> void:
	if ammo <= 0:
		play("empty", 0.0)
		fire_cd = 0.3
		if reserve > 0:
			reload()
		return
	ammo -= 1
	fire_cd = FIRE_RATE
	play("shot", 0.06)
	recoil_pitch += 0.016
	yaw += randf_range(-0.004, 0.004)
	kick = 0.06
	gun.rotation.x += 0.07
	gun.rotation.z += randf_range(-0.03, 0.03)
	flash.visible = true
	flash_mesh.visible = true
	flash_mesh.rotation.z = randf() * TAU
	get_tree().create_timer(0.04).timeout.connect(_hide_flash)

	var b := cam.global_transform.basis
	var spread := 0.004 + (0.012 if Vector2(velocity.x, velocity.z).length() > 1.0 else 0.0)
	var d := (-b.z + b.x * randf_range(-spread, spread) + b.y * randf_range(-spread, spread)).normalized()
	var from := cam.global_position
	var q := PhysicsRayQueryParameters3D.create(from, from + d * 150.0)
	q.exclude = [get_rid()]
	q.collision_mask = 1 | 4
	var r := get_world_3d().direct_space_state.intersect_ray(q)
	if r.is_empty():
		return
	var c = r.collider
	if c.is_in_group("enemy"):
		var head_hit: bool = r.position.y - c.global_position.y > 1.62
		c.take_damage(100.0 if head_hit else 34.0, d)
		_show_hit(head_hit)
		_impact(r.position, r.normal, Color(0.55, 0.03, 0.03), false)
	else:
		_impact(r.position, r.normal, Color(0.75, 0.7, 0.6), true)


func _hide_flash() -> void:
	flash.visible = false
	flash_mesh.visible = false


func _show_hit(head_hit: bool) -> void:
	lbl_hit.visible = true
	lbl_hit.modulate = Color(1, 0.2, 0.2) if head_hit else Color(1, 1, 1)
	play("hit", 0.1)
	get_tree().create_timer(0.12).timeout.connect(lbl_hit.hide)


func _impact(pos: Vector3, normal: Vector3, color: Color, hole: bool) -> void:
	var world := get_tree().current_scene
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = 10
	p.lifetime = 0.45
	p.explosiveness = 1.0
	p.direction = normal
	p.spread = 35.0
	p.initial_velocity_min = 1.5
	p.initial_velocity_max = 4.0
	p.gravity = Vector3(0, -9.8, 0)
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.2
	var bm := BoxMesh.new()
	bm.size = Vector3(0.025, 0.025, 0.025)
	var mm := StandardMaterial3D.new()
	mm.albedo_color = color
	bm.material = mm
	p.mesh = bm
	world.add_child(p)
	p.global_position = pos + normal * 0.02
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)
	if hole:
		var h := MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2(0.07, 0.07)
		var hm := StandardMaterial3D.new()
		hm.albedo_color = Color(0.05, 0.05, 0.05, 0.85)
		hm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		qm.material = hm
		h.mesh = qm
		h.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		world.add_child(h)
		var up := Vector3.RIGHT if absf(normal.y) > 0.99 else Vector3.UP
		h.global_position = pos + normal * 0.005
		h.look_at(pos - normal, up)
		holes.append(h)
		if holes.size() > 40:
			holes.pop_front().queue_free()


# ---------- Reload (animasi bertahap) ----------
func reload() -> void:
	if reloading or ammo == MAG_SIZE or reserve <= 0 or dead:
		return
	reloading = true
	var tw := create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(gun, "rotation", Vector3(-0.3, 0.45, 0.5), 0.25)
	tw.tween_callback(play.bind("reload_out", 0.05))
	tw.tween_property(mag, "position", mag_base + Vector3(0, -0.35, 0.06), 0.22).set_ease(Tween.EASE_IN)
	tw.tween_callback(mag.hide)
	tw.tween_interval(0.35)
	tw.tween_callback(mag.show)
	tw.tween_property(mag, "position", mag_base + Vector3(0, -0.05, 0.01), 0.28).set_ease(Tween.EASE_OUT)
	tw.tween_callback(play.bind("reload_in", 0.05))
	tw.tween_property(mag, "position", mag_base, 0.07)
	tw.tween_property(gun, "rotation", Vector3(-0.08, 0.2, -0.3), 0.2)
	tw.tween_callback(play.bind("bolt", 0.05))
	tw.tween_property(gun, "position", Vector3(0, 0, 0.045), 0.07)
	tw.tween_property(gun, "position", Vector3.ZERO, 0.1)
	tw.tween_property(gun, "rotation", Vector3.ZERO, 0.22)
	tw.tween_callback(_finish_reload)


func _finish_reload() -> void:
	var take := mini(MAG_SIZE - ammo, reserve)
	ammo += take
	reserve -= take
	reloading = false


# ---------- Damage ----------
func take_damage(amount: float) -> void:
	if dead:
		return
	hp -= amount
	vignette.color.a = 0.4
	recoil_pitch += randf_range(-0.03, 0.03)
	play("hurt", 0.1)
	if hp <= 0:
		hp = 0
		dead = true
		hp_bar.value = 0
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		lbl_center.text = "KAMU TEWAS  -  Kill: %d\nTap untuk main lagi" % kills
		gun_root.visible = false
		var tw := create_tween().set_parallel(true)
		tw.tween_property(head, "position", Vector3(0, 0.3, 0), 0.8).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
		tw.tween_property(head, "rotation", Vector3(0.3, 0, 1.2), 0.8)
