extends CharacterBody3D
## Prajurit musuh: rig prosedural, animasi jalan, tembak, kena tembak, dan jatuh mati.

signal died

var hp := 100.0
var target: Node3D
var dead := false
var speed := 2.5
var t := 0.0
var shoot_cd := 2.0
var strafe := 1.0
var strafe_t := 0.0
var hurt_t := 0.0
var recoil_t := 0.0

var rig: Node3D
var torso: Node3D
var leg_l: Node3D
var leg_r: Node3D
var arm_l: Node3D
var arm_r: Node3D
var flash: OmniLight3D
var col: CollisionShape3D
var mats: Array[StandardMaterial3D] = []
var snd_shot: AudioStreamPlayer3D
var snd_die: AudioStreamPlayer3D
var snd_hit: AudioStreamPlayer3D


func _mat(c: Color, rough := 0.85, metal := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	mats.append(m)
	return m


func _part(parent: Node3D, mesh: Mesh, pos: Vector3, m: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = m
	parent.add_child(mi)
	return mi


func _bx(x: float, y: float, z: float) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = Vector3(x, y, z)
	return b


func _sph(r: float, h: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = h
	s.radial_segments = 16
	s.rings = 8
	return s


func _snd(n: String) -> AudioStreamPlayer3D:
	var p := AudioStreamPlayer3D.new()
	p.stream = load("res://sfx/%s.wav" % n)
	p.unit_size = 8.0
	p.position.y = 1.5
	add_child(p)
	return p


func _ready() -> void:
	add_to_group("enemy")
	collision_layer = 4
	collision_mask = 1 | 4
	shoot_cd = randf_range(1.5, 3.5)
	speed = randf_range(2.0, 3.0)

	col = CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.85
	col.shape = cap
	col.position.y = 0.925
	add_child(col)

	var camo := _mat(Color(0.3, 0.33, 0.22))
	var vest := _mat(Color(0.18, 0.2, 0.15))
	var dark := _mat(Color(0.1, 0.1, 0.09))
	var skin := _mat(Color(0.72, 0.55, 0.42), 0.7)
	var metal := _mat(Color(0.07, 0.07, 0.07), 0.4, 0.8)

	rig = Node3D.new()
	add_child(rig)
	torso = Node3D.new()
	torso.position.y = 1.0
	rig.add_child(torso)
	_part(torso, _bx(0.38, 0.18, 0.24), Vector3(0, 0.02, 0), camo)
	_part(torso, _bx(0.44, 0.6, 0.25), Vector3(0, 0.38, 0), camo)
	_part(torso, _bx(0.48, 0.44, 0.31), Vector3(0, 0.42, 0), vest)
	_part(torso, _bx(0.1, 0.1, 0.1), Vector3(0, 0.72, 0), skin)
	_part(torso, _sph(0.12, 0.26), Vector3(0, 0.84, 0), skin)
	_part(torso, _sph(0.145, 0.19), Vector3(0, 0.9, 0.01), vest)
	_part(torso, _bx(0.17, 0.04, 0.03), Vector3(0, 0.86, -0.11), dark)

	leg_l = _leg(-0.11, camo, dark)
	leg_r = _leg(0.11, camo, dark)

	arm_r = _arm(0.29, camo, skin)
	arm_r.rotation = Vector3(1.35, 0.15, 0)
	arm_l = _arm(-0.29, camo, skin)
	arm_l.rotation = Vector3(1.45, -0.55, 0)

	var gun := Node3D.new()
	gun.position = Vector3(0.08, 0.5, -0.4)
	torso.add_child(gun)
	_part(gun, _bx(0.06, 0.1, 0.55), Vector3.ZERO, metal)
	_part(gun, _bx(0.03, 0.03, 0.3), Vector3(0, 0.02, -0.4), metal)
	_part(gun, _bx(0.05, 0.14, 0.06), Vector3(0, -0.1, -0.05), metal)
	_part(gun, _bx(0.05, 0.09, 0.2), Vector3(0, -0.02, 0.33), metal)
	flash = OmniLight3D.new()
	flash.position = Vector3(0, 0.02, -0.6)
	flash.light_color = Color(1, 0.75, 0.4)
	flash.light_energy = 3.0
	flash.omni_range = 4.0
	flash.visible = false
	gun.add_child(flash)

	snd_shot = _snd("enemy_shot")
	snd_die = _snd("enemy_die")
	snd_hit = _snd("hit")


func _leg(x: float, camo: Material, dark: Material) -> Node3D:
	var p := Node3D.new()
	p.position = Vector3(x, 0.95, 0)
	rig.add_child(p)
	_part(p, _bx(0.17, 0.5, 0.19), Vector3(0, -0.25, 0), camo)
	_part(p, _bx(0.15, 0.42, 0.17), Vector3(0, -0.68, 0), camo)
	_part(p, _bx(0.16, 0.1, 0.28), Vector3(0, -0.9, -0.04), dark)
	return p


func _arm(x: float, camo: Material, skin: Material) -> Node3D:
	var p := Node3D.new()
	p.position = Vector3(x, 0.6, 0)
	torso.add_child(p)
	_part(p, _bx(0.12, 0.32, 0.13), Vector3(0, -0.16, 0), camo)
	_part(p, _bx(0.1, 0.28, 0.11), Vector3(0, -0.44, 0), camo)
	_part(p, _bx(0.09, 0.1, 0.09), Vector3(0, -0.62, 0), skin)
	return p


func _physics_process(delta: float) -> void:
	if dead:
		return
	if not is_on_floor():
		velocity.y -= 14.0 * delta
	if target == null or target.dead:
		velocity.x = 0
		velocity.z = 0
		move_and_slide()
		return

	var to := target.global_position - global_position
	to.y = 0
	var dist := to.length()
	var fwd := to.normalized()
	rotation.y = lerp_angle(rotation.y, atan2(-fwd.x, -fwd.z), delta * 6.0)

	strafe_t -= delta
	if strafe_t <= 0:
		strafe = [-1.0, 1.0].pick_random()
		strafe_t = randf_range(1.5, 3.0)

	var move := Vector3.ZERO
	if dist > 13:
		move = fwd
	elif dist < 7:
		move = -fwd * 0.6
	if dist < 22:
		move += fwd.cross(Vector3.UP) * strafe * 0.6
	if move.length() > 0.01:
		move = move.normalized() * speed
	velocity.x = lerp(velocity.x, move.x, delta * 5.0)
	velocity.z = lerp(velocity.z, move.z, delta * 5.0)
	move_and_slide()

	# Animasi jalan prosedural
	var hs := Vector2(velocity.x, velocity.z).length()
	var k := clampf(hs / 2.5, 0.0, 1.0)
	t += delta * (2.0 + hs * 3.2)
	var sw := sin(t) * k * 0.7
	leg_l.rotation.x = sw
	leg_r.rotation.x = -sw
	rig.position.y = absf(cos(t)) * 0.05 * k
	hurt_t = move_toward(hurt_t, 0.0, delta * 4.0)
	recoil_t = move_toward(recoil_t, 0.0, delta * 10.0)
	torso.rotation = Vector3(-hurt_t * 0.45 - recoil_t * 0.08, sin(t) * 0.07 * k, sin(t * 0.5) * 0.03)

	shoot_cd -= delta
	if shoot_cd <= 0 and dist < 35 and _can_see():
		_fire(dist)
		shoot_cd = randf_range(0.9, 2.2)


func _can_see() -> bool:
	var q := PhysicsRayQueryParameters3D.create(global_position + Vector3(0, 1.7, 0), target.global_position + Vector3(0, 1.5, 0))
	q.collision_mask = 1
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func _fire(dist: float) -> void:
	snd_shot.pitch_scale = randf_range(0.92, 1.08)
	snd_shot.play()
	flash.visible = true
	recoil_t = 1.0
	get_tree().create_timer(0.05).timeout.connect(flash.hide)
	var chance := clampf(0.75 - dist * 0.02, 0.15, 0.65)
	if randf() < chance:
		target.take_damage(randf_range(6.0, 11.0))


func take_damage(amount: float, dir: Vector3) -> void:
	if dead:
		return
	hp -= amount
	hurt_t = 1.0
	snd_hit.play()
	for m in mats:
		m.emission_enabled = true
		m.emission = Color(0.7, 0.05, 0.05)
	get_tree().create_timer(0.07).timeout.connect(_unflash)
	dir.y = 0
	velocity += dir * 2.0
	if hp <= 0:
		_die()


func _unflash() -> void:
	for m in mats:
		m.emission_enabled = false


func _die() -> void:
	dead = true
	remove_from_group("enemy")
	collision_layer = 0
	col.set_deferred("disabled", true)
	snd_die.play()
	died.emit()
	var tw := create_tween().set_parallel(true)
	tw.tween_property(rig, "rotation", Vector3(1.52, 0, randf_range(-0.3, 0.3)), 0.7).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tw.tween_property(rig, "position", Vector3(0, 0.1, 0), 0.7)
	tw.tween_property(leg_l, "rotation", Vector3(-0.2, 0, 0), 0.5)
	tw.tween_property(leg_r, "rotation", Vector3(0.3, 0, 0), 0.5)
	tw.tween_property(arm_l, "rotation", Vector3(2.6, -0.4, 0.5), 0.6)
	tw.tween_property(arm_r, "rotation", Vector3(2.4, 0.3, -0.5), 0.6)
	tw.tween_property(torso, "rotation", Vector3(0.15, 0, 0), 0.5)
	tw.chain().tween_interval(5.0)
	tw.chain().tween_property(rig, "position", Vector3(0, -0.6, 0), 1.5)
	tw.chain().tween_callback(queue_free)
