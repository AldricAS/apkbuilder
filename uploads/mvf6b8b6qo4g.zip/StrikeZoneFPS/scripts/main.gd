extends Node3D
## Dunia, gelombang musuh, dan lingkungan. Semua model dibuat dari primitif (bebas hak cipta).

const Enemy = preload("res://scripts/enemy.gd")
const Player = preload("res://scripts/player.gd")

var player
var wave := 0
var alive := 0
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	rng.seed = 7
	_build_world()
	player = Player.new()
	player.position = Vector3(0, 0.2, 0)
	add_child(player)
	_next_wave()


func make_mat(c: Color, rough := 0.85, metal := 0.0, tex_freq := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	if tex_freq > 0.0:
		var n := FastNoiseLite.new()
		n.frequency = tex_freq
		var tex := NoiseTexture2D.new()
		tex.noise = n
		tex.seamless = true
		tex.width = 256
		tex.height = 256
		var ntex := NoiseTexture2D.new()
		ntex.noise = n
		ntex.seamless = true
		ntex.as_normal_map = true
		ntex.bump_strength = 6.0
		ntex.width = 256
		ntex.height = 256
		m.albedo_texture = tex
		m.normal_enabled = true
		m.normal_texture = ntex
		m.uv1_triplanar = true
		m.uv1_scale = Vector3(0.5, 0.5, 0.5)
	return m


func _box(pos: Vector3, size: Vector3, m: Material, rot_y := 0.0) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation.y = rot_y
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = m
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	body.add_child(cs)
	add_child(body)


func _build_world() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.32, 0.47, 0.72)
	sm.sky_horizon_color = Color(0.78, 0.74, 0.66)
	sm.ground_horizon_color = Color(0.6, 0.55, 0.48)
	sm.ground_bottom_color = Color(0.3, 0.28, 0.25)
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.8
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_density = 0.01
	env.fog_light_color = Color(0.72, 0.7, 0.65)
	env.glow_enabled = true
	env.glow_intensity = 0.6
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, 35, 0)
	sun.light_energy = 1.3
	sun.light_color = Color(1.0, 0.95, 0.85)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)

	var ground := make_mat(Color(0.62, 0.56, 0.46), 0.95, 0.0, 0.08)
	ground.uv1_scale = Vector3(0.25, 0.25, 0.25)
	var concrete := make_mat(Color(0.6, 0.6, 0.58), 0.9, 0.0, 0.15)
	var wood := make_mat(Color(0.55, 0.38, 0.2), 0.8, 0.0, 0.4)
	var metal := make_mat(Color(0.3, 0.35, 0.3), 0.45, 0.6, 0.3)
	var brick := make_mat(Color(0.55, 0.32, 0.25), 0.9, 0.0, 0.2)

	_box(Vector3(0, -0.5, 0), Vector3(90, 1, 90), ground)
	for s in [-1, 1]:
		_box(Vector3(s * 44, 3, 0), Vector3(2, 6, 90), concrete)
		_box(Vector3(0, 3, s * 44), Vector3(90, 6, 2), concrete)

	# Bangunan
	for i in 7:
		var p := Vector3(rng.randf_range(-35, 35), 0, rng.randf_range(-35, 35))
		if p.length() < 12:
			continue
		var h := rng.randf_range(4, 9)
		_box(p + Vector3(0, h / 2, 0), Vector3(rng.randf_range(5, 9), h, rng.randf_range(5, 9)), brick, rng.randf() * PI)

	# Peti & barrier sebagai perlindungan
	for i in 40:
		var p := Vector3(rng.randf_range(-40, 40), 0, rng.randf_range(-40, 40))
		if p.length() < 5:
			continue
		var k := rng.randi() % 3
		if k == 0:
			var s := rng.randf_range(1.0, 1.6)
			_box(p + Vector3(0, s / 2, 0), Vector3(s, s, s), wood, rng.randf() * PI)
		elif k == 1:
			_box(p + Vector3(0, 0.55, 0), Vector3(3.0, 1.1, 0.5), concrete, rng.randf() * PI)
		else:
			_box(p + Vector3(0, 1.3, 0), Vector3(2.4, 2.6, 6.0), metal, rng.randf() * PI)


func _next_wave() -> void:
	if player.dead:
		return
	wave += 1
	player.set_wave(wave)
	if wave > 1:
		player.reserve += 60
	var n := 2 + wave * 2
	for i in n:
		var e = Enemy.new()
		var a := randf() * TAU
		var r := randf_range(20, 36)
		e.position = Vector3(cos(a) * r, 0.3, sin(a) * r)
		e.target = player
		e.died.connect(_on_enemy_died)
		add_child(e)
		alive += 1


func _on_enemy_died() -> void:
	alive -= 1
	player.kills += 1
	if alive <= 0:
		get_tree().create_timer(3.0).timeout.connect(_next_wave)
