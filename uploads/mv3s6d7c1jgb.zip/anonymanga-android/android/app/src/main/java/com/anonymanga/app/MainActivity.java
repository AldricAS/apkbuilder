package com.anonymanga.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
